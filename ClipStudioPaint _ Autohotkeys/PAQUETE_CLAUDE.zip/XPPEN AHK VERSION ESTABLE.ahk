#Requires AutoHotkey v2.0
#SingleInstance Force
if !A_IsAdmin {
    try Run('*RunAs "' A_ScriptFullPath '"')
    ExitApp()
}
try TraySetIcon("C:\Users\jbard\Documents\@Otros\icons\clipstudio.ico")
DllCall("SetThreadDpiAwarenessContext","ptr",-3,"ptr")
SendMode("Input")
KEY_NTILDE := "{vkC0sc027}"
KEY_MENOR := "{vkE2sc056}"
EnviarNtilde() => SendInput(KEY_NTILDE)
EnviarMenor() => SendInput(KEY_MENOR)
SetWorkingDir(A_ScriptDir)
SetKeyDelay(-1,-1)
SetMouseDelay(-1)
SetDefaultMouseSpeed(0)
CoordMode("Mouse","Screen")
CoordMode("ToolTip","Screen")
SetTitleMatchMode(2)
sys := {lastModTime:"",modoEscritura:false}
stylus := {altActive:false,rButtonHeld:false,comboUsado:false,upSinteticoTick:0,botonSostenido:false,smearSend:false,ignorarUpSintetico:false,bSinteticoTick:0,origX:0,origY:0,spaceFlipTimerRunning:0}
sel := {estado:0,estadoAltX:false,estadoC:0,guiActivo:false,sRapido:false}
colorEstado := 0
UP_SINTETICO_MS := 70
S_RAPIDO_MS := 400
ESTAB_MIN := 7
ESTAB_MAX := 75
ESTAB_RACHA := 10
ESTAB_RITMO := 18
ESTAB_COLOR := "9A7BFF"
ESTAB_ALPHA_H := 128
ESTAB_ALPHA_ACT := 235
ESTAB_ALPHA_F := 150
FOCO_GRACIA_MS := 200
FOCO_TIMEOUT_MS := 10000
; --- Estabilizador universal ---
STAB_BASE := ESTAB_MIN            ; base de toda herramienta (0 = piso absoluto)
STAB_RESET_FISICO := true         ; true: manda j×100 + «-»×base a CSP; false: solo marca desincronizado
STAB_RESET_DELAY_MS := 60         ; espera a que CSP termine de cambiar de herramienta
STAB_POR_HERRAMIENTA := Map()     ; override opcional, ej: Map("q",40,"w",0,"e",0,"l",0)
STAB_ABSOLUTO := true             ; true: el valor de AHK manda (j x100 + «-» x valor) cuando la base es dudosa; false: comportamiento relativo anterior
STAB_CONFIANZA_MS := 1500         ; ventana (>=500) en que AHK confía en su base tras sincronizar/mover; un clic en CSP la anula
stabU := {tool:"",ocupado:false,rearmar:false,syncTick:0}
E := {procesando:false,last:0}
W := {last:0}
Z := {last:0,timerRunning:0}
Q := {last:0,estadoEstab:0,pendiente:false}
RM := {last:0}
A_state := {lastPress:0}
AltS_state := {lastPress:0}
AltB_s_state := {lastPress:0,timerRunning:0}
AltB_a_state := {lastPress:0,timerRunning:0}
AltF_state := {lastPress:0,timerRunning:0,held:false}
S := {estadoCaracter:0,skipNext:false,lastTick:0}
O := {ciclo:0}
N6 := {estadoEscala:0,layerVis:1}
hist := {abierto:false,modo:1,id:0}
btn := {b1:false,b2:false,b3:false}
botDer := {b1:false,b2:false,b3:false}
colorV := {dsID:0,dsVis:false,bDS:0,hover:true,cspHwnd:0,dsX:0,dsY:0,dsW:0,dsH:0,supresionHasta:0}
colorCC := {id:0,dsVis:false,bCC:0,hover:false,ccX:0,ccY:0,ccW:0,ccH:0,supresionHasta:0}
ar := {id:0,dsVis:false,bAR:0,hover:false}
global floatGui := {miniTip:0,miniGUI:0,tooltipToggle:0,enfoque:0,miniTipTick:0,miniTipID:0,hud:0,hudLabel:0,hudBar:0,hudHwnd:0,hudID:0,hudTick:0,overlayIcon:0,overlayIconID:0,badge:0,badgeHwnd:0,badgeSub:0,badgeMain:0,badgeSubBar:0,badgeBar:0,badgeID:0,badgeTick:0}
global _AvisoBadgesActivos := []
enfoque := {activo:false}
shiftSostenido := {activo:false}
opacidad := {nivel:100}
boost := {holdDelay:300,maxBoost:5}
spc := {last:0,downTick:0,selectArmed:false,rotOn:false}
dial := {modo:1,g:0,icono:0,label:0,barra:0}
dsGui := {g:0,icono:0,label:0,barra:0}
ccGui := {g:0,icono:0,label:0,barra:0}
arGui := {g:0,icono:0,label:0,barra:0}
hcGui := {g:0,icono:0,label:0,barra:0}
reloadGui := {g:0,icono:0,label:0,barra:0}
puntosGui := {g:0,icono:0,barra:0}
ptsEd := {g:0,lv:0,ex:0,ey:0,dx:0,dy:0,hAlto:0,eEsc:0,eEscAv:0,eAlpha:0,eAlphaF:0,st:0,bCap:0,sel:0,capturando:false,dibujando:false,ovl:[]}
lockGui := {g:0,icono:0,barra:0}
frenteGui := {g:0,icono:0,barra:0}
hubGui := {g:0,icono:0,barra:0,embebidos:Map()}
estabBtnGui := {g:0,icono:0,label:0,barra:0}
estabGui := {g:0,valorTxt:0,grip:0,valor:50,previsto:50,sincronizado:false,arrastrando:false,visible:true,ancho:0,alto:0,txtH:0,trackW:0,trackX:0,trackY:0,trackH:0,knobSize:0,horiz:false,txtW:0,fuente:9,foco:false,rectNormal:0,fAbajo:false,fSoltado:0,fTick:0,fPrevHasta:0,dibV:-1,dibG:""}
panelBlk := {locked:true,frente:false}
global g_sweepActivo := false
global g_sweepAtomico := true   ; true = congelar/aplicar/redibujar al conmutar el barrido (false = comportamiento anterior)
global _iniPend := Map()
; Ola 7 (D): el repintado por WM_PAINT se descarto. Registrar OnMessage(0x000F) global
; costaba +1,3-1,7 s de arranque; el panel se repinta a demanda con _EstabPanelPintar.
; Si se retoma, el codigo del handler esta en el .bak-ola7 de esta ola.
PANEL_GAP := 6
LAYOUT_NORMAL := {ds:{x:-1059,y:143,w:383,h:185},cc:{x:-676,y:143,w:359,h:295},ar:{x:-537,y:438,w:220,h:483},hc:{x:-2240,y:1253,w:1905,h:104}}
LAYOUT_ENFOQUE := {ds:{x:-836,y:136,w:383,h:185},cc:{x:-453,y:118,w:359,h:295},ar:{x:-317,y:413,w:223,h:483},hc:{x:-2240,y:1253,w:1905,h:104}}
PUNTOS_DEF := [[1970,-154],[4437,-154],[1924,-132],[1976,-130],[1923,-95],[1973,-94],[1925,-91],[1973,-89],[1926,-55],[1975,-55],[1927,-47],[1974,-46],[1924,-15],[1976,-10],[4423,-132],[4473,-131],[4423,-99],[4476,-98],[4425,-90],[4474,-89],[4423,-55],[4473,-55],[4426,-47],[4472,-47],[4424,-13],[4475,-10],[2246,1158],[4136,1156],[2011,-225],[2239,-98],[1900,500],[1940,700]]
PUNTOS := []
AVISO_ESC := 1.0
HIST_ALTO := 104
ZONAS := {}
PERFILES := ["Laptop + tableta","Monitor + tableta"]
PERFIL := 1
ElegirPerfil()
ESC := 1.0
CargarEscala()
CargarEscalaAvisos()
CargarPuntos()
SetTimer(CheckReload,600)
SetTimer(ChequearZonaHistorial,200)
SetTimer(ChequearZonaAltA,35)
SetTimer(ChequearZonaDerecha,35)
SetTimer(LoopColorV,80)
SetTimer(LoopColorCC,80)
SetTimer(LoopAccesoRapido,80)
SetTimer(ResetAlphaStates,500)
SetTimer(LimpiarAltPegadoPureRef,150)
IniciarDeteccion()
IniciarDsGUI()
IniciarCcGUI()
IniciarArGUI()
IniciarHCGUI()
IniciarLockGUI()
IniciarFrenteGUI()
IniciarEstabGUI()
IniciarEstabBtnGUI()
IniciarReloadGUI()
IniciarPuntosGUI()
IniciarHubGUI()
A_TrayMenu.Add("🎨 Paleta del tema",(*) => _AbrirSelectorTema())

; ===== PAQUETE 2: SANITIZE DE MODIFICADORES =====
global _cspEraActiva := false
global _bSmearAbajo := false

_AltF_SoltarB(*) {
    global _bSmearAbajo
    if !_bSmearAbajo
        return
    _bSmearAbajo := false
    SendEvent("{b up}")
}

; Restaura Alt solo si el lápiz lo sigue sosteniendo Y CSP tiene el foco
_AltRestaurar(seguia) {
    if (seguia && stylus.altActive && WinActive("ahk_exe CLIPStudioPaint.exe"))
        SendEvent("{Alt down}")
}

; Suelta lo que Windows cree abajo pero tú no pulsas físicamente.
; Respeta los sostenidos intencionales (Alt del lápiz, Shift sostenido).
_LiberarFantasmas() {
    for k in ["Shift", "Alt", "Ctrl", "LWin", "RWin", "Space"] {
        if !GetKeyState(k) || GetKeyState(k, "P")
            continue
        if (k = "Alt" && stylus.altActive)
            continue
        if (k = "Shift" && shiftSostenido.activo)
            continue
        SendEvent("{" k " up}")
    }
}

; Limpieza total: foco perdido o tecla de rescate
_LiberarModificadores(*) {
    SetTimer(_AltF_SoltarB, 0)
    _AltF_SoltarB()
    for k in ["Shift", "Alt", "Ctrl", "LWin", "RWin", "Space"] {
        if GetKeyState(k)
            SendEvent("{" k " up}")
    }
    stylus.altActive := false
    shiftSostenido.activo := false
}

_VigilaFocoCSP() {
    global _cspEraActiva
    activa := WinActive("ahk_exe CLIPStudioPaint.exe") ? true : false
    if (_cspEraActiva && !activa)
        _LiberarModificadores()
    _cspEraActiva := activa
}
SetTimer(_VigilaFocoCSP, 150)

Pause::_LiberarModificadores()   ; tecla de rescate manual

EsEditorTexto() => WinActive("ahk_exe notepad++.exe") || WinActive("ahk_exe notepad.exe")
#HotIf EsEditorTexto()
^s:: {
    SendInput("^s")
    Sleep(200)
    Reload()
}
^g:: {
    if !(WinActive("ahk_exe notepad++.exe") || WinActive("ahk_exe notepad.exe"))
        return
    ts := FormatTime(,"yyyy-MM-dd_HH-mm-ss")
    ; El script vive en <repo>\ClipStudioPaint _ Autohotkeys\: el repo es el padre.
    repoPath := RegExReplace(A_ScriptDir,"\\[^\\]+$")
    cmd := 'git -C "' repoPath '" add -A && git -C "' repoPath '" commit -m "auto_' ts '" && git -C "' repoPath '" push'
    Run('cmd /k "' cmd ' && timeout /t 3 && exit"',,"")
    SetTimer(_CheckGitDone,-5000)
}
#HotIf
#SuspendExempt
$`:: {
    sys.modoEscritura := !sys.modoEscritura
    if (sys.modoEscritura) {
        Suspend(1)
        MostrarIndicador("🔴📝 MODO ESCRITURA — puedes escribir libremente 📝🔴")
    } else {
        Suspend(0)
        MostrarIndicador("🟢✅ MODO AHK ACTIVO — hotkeys habilitadas ✅🟢")
    }
}
#SuspendExempt False
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")
RButton:: {
    stylus.rButtonHeld := true
    stylus.comboUsado := false
    stylus.upSinteticoTick := 0
}
RButton up:: {
    elapsed := (stylus.upSinteticoTick > 0) ? (A_TickCount - stylus.upSinteticoTick) : 9999
    if (elapsed < UP_SINTETICO_MS) {
        stylus.rButtonHeld := true
        stylus.upSinteticoTick := 0
        return
    }
    stylus.rButtonHeld := false
    if (!stylus.comboUsado)
        SendInput("{RButton}")
}
Space & RButton:: {
    stylus.comboUsado := true
    _InvSeleccionConGUI()
}
Numpad0:: {
    hcOn := _ToggleHistorialColor()
    ActualizarHCGUI()
    MostrarHUD(hcOn ? "🟢 DYNAMIC HISTORY" : "🔒 HISTORY LOCKED",hcOn ? "00E5FF" : "FF6B00",5000)
}
_ToggleHistorialColor() {
    hist.modo := (hist.modo = 1) ? 2 : 1
    if (hist.modo = 2 && hist.abierto) {
        hist.abierto := false
        Send("{Numpad9}")
    }
    return (hist.modo = 1)
}
^s:: {
    SendInput("^s")
    _VigilarGuardado()
}

; ── Telemetría de guardado .clip: espera a que desaparezca el "*" del título ──
_VigilarGuardado() {
    global _svT0, _svVisto
    _svT0 := A_TickCount
    _svVisto := false
    SetTimer(_TickGuardado, 30)          ; reiniciar si se pulsa Ctrl+S de nuevo
}
_TickGuardado() {
    global _svT0, _svVisto
    t := WinExist("ahk_exe CLIPStudioPaint.exe")
        ? WinGetTitle("ahk_exe CLIPStudioPaint.exe") : ""
    dirty := InStr(t, "*") > 0
    if (dirty)
        _svVisto := true
    elapsed := A_TickCount - _svT0
    ; Guardado terminado: el asterisco se vio y ya no está
    ; (o no había cambios pendientes: tras 350 ms de gracia sin "*" el archivo ya está en disco)
    if ((_svVisto && !dirty) || (!_svVisto && !dirty && elapsed > 350)) {
        SetTimer(_TickGuardado, 0)
        _SonarUI("guardar")
        MostrarHUD("💾 GUARDADO Y MODIFICADO","44DD88",800)
        return
    }
    if (elapsed > 15000)                 ; timeout de seguridad: cancelado o CSP bloqueado
        SetTimer(_TickGuardado, 0)
}
~!b:: {
    elapsedB := (stylus.bSinteticoTick > 0) ? (A_TickCount - stylus.bSinteticoTick) : 9999
    if (elapsedB < UP_SINTETICO_MS) {
        stylus.bSinteticoTick := 0
        return
    }
    if (stylus.smearSend)
        return
    stylus.altActive := true
}
~!b up:: {
    elapsedB := (stylus.bSinteticoTick > 0) ? (A_TickCount - stylus.bSinteticoTick) : 9999
    if (elapsedB < UP_SINTETICO_MS) {
        stylus.bSinteticoTick := 0
        return
    }
    Send("{Alt up}")
    stylus.altActive := false
    if (stylus.smearSend) {
        stylus.smearSend := false
        SendInput("b")
        MostrarHUD("SMEAR","AA44FF",950)
    }
}
c:: _InvSeleccionConGUI()
_InvSeleccionConGUI() {
    if (sel.estadoC = 0) {
        MostrarMiniTexto("🔄 INV. ÁREA SELECC.","FF6F61",900)
        _SonarUI("seleccion")
        sel.estadoC := 1
        SetTimer(__ResetEstadoC,-2000)
    } else {
        MostrarMiniTexto("🔁 INV. ÁREA SELECC.","32CD32",900)
        sel.estadoC := 0
        SetTimer(__ResetEstadoC,0)
    }
    Send("c")
}
x:: {
    if stylus.altActive
        return
    if (sel.sRapido) {
        sel.sRapido := false
        MostrarMiniTexto("❌ DESELECCIÓN","C0392B",700)
        Send("x")
        sel.estado := 1
        return
    }
    if (sel.estado = 0) {
        MostrarMiniTexto("❌ DESELECCIÓN","C0392B",700)
        Send("x")
        sel.estado := 1
    } else {
        MostrarMiniTexto("✅ RESELECCIÓN","27AE60",1200)
        Send("{F10}")
        sel.estado := 0
    }
}
$^z:: _DeshacerRehacer()
_MaskRButton() {
    stylus.comboUsado := true
    if (stylus.botonSostenido)
        return
    stylus.botonSostenido := true
    Send("!m")
    MostrarHUD("MASK (ALT+M)","00E5FF",900)
}
_DeshacerRehacer() {
    if (stylus.rButtonHeld || stylus.altActive) {
        stylus.comboUsado := true
        if (!stylus.botonSostenido) {
            stylus.botonSostenido := true
            if (stylus.rButtonHeld) {
                stylus.upSinteticoTick := A_TickCount
                MouseGetPos(&origX,&origY)
                MouseMove(PUNTOS[29][1],PUNTOS[29][2],0)
                SendInput("{RButton up}")
                SendInput("^y")
                MouseMove(origX,origY,0)
            } else {
                SendInput("^y")
            }
        } else {
            SendInput("^y")
        }
        ToolTipCS("🟢 REHACER",600)
    } else {
        SendInput("^z")
        ToolTipCS("🔴 DESHACER",300)
    }
}
$^z up:: stylus.botonSostenido := false
!z:: {
    SendInput("^c")
    _SonarUI("copiar")
    ToolTipCS("📋 COPIAR",600)
}
!^z:: {
    stylus.botonSostenido := true
    SendInput("^y")
    ToolTipCS("🟢 REHACER",600)
}
!^z up:: stylus.botonSostenido := false
#HotIf stylus.altActive && !WinActive("ahk_exe PureRef.exe")
z:: {
    SendInput("^c")
    _SonarUI("copiar")
    ToolTipCS("📋 COPIAR",600)
}
w:: {
    Send("+s")
    MostrarHUD("SHIFT+S","00E5FF",800)   ; solo visual, sin llamada a _SonarUI
}
-:: _CicloO()
e:: {
    MostrarHUD("ALL LAYERS ERASER","FF4444",800)   ; solo visual
    Send("{F5}")
}
x:: {
    if (AltB_a_state.lastPress = 1) {
        AltB_a_state.lastPress := 0
        SendEvent("p")
        MostrarHUD("SMUDGE  (P)","FF6B00",950)
    } else {
        AltB_a_state.lastPress := 1
        SendEvent("d")
        MostrarHUD("COLOR MIX  (D)","FF8C42",950)
    }
}
a:: {
    now := A_TickCount
    if (now - AltB_a_state.lastPress < 2400) {
        AltB_a_state.lastPress := 0
        Send("p")
        MostrarHUD("SMUDGE  (P)","FF6B00",950)
    } else {
        AltB_a_state.lastPress := now
        Send("d")
        MostrarHUD("COLOR MIX  (D)","FF8C42",950)
    }
}
s:: {
    now := A_TickCount
    if (now - AltB_s_state.lastPress < 2400) {
        AltB_s_state.lastPress := 0
        SendInput("{F7}")
        MostrarHUD("ALL LAYERS (2)","FF6B00",3140)
    } else {
        AltB_s_state.lastPress := now
        SendInput("{Blind}a")
        MostrarHUD("LAYER CURRENT (1)","00E5FF",950)
    }
}
f:: {
    if AltF_state.held
        return
    AltF_state.held := true
    now := A_TickCount
    if (now - AltF_state.lastPress < 2400) {
        AltF_state.lastPress := 0
        SendInput("{NumpadEnd}")
        MostrarHUD("SMEAR SOFT  (2)","FF6B00",950)
    } else {
        AltF_state.lastPress := now
        stylus.bSinteticoTick := A_TickCount
        SendInput("{Blind}{b up}{b down}")
        MostrarHUD("SMEAR  (1)","00E5FF",950)
    }
}
f up:: AltF_state.held := false
$!Space::
$Space:: {
    stylus.comboUsado := true
    SendInput("!g")
    MostrarHUD("FLIP HORIZONTAL","888888",700)
    _SonarUI("flip")
}
#HotIf
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")
$a:: {
    _FlushPendentes()
    if stylus.altActive
        return
    now := A_TickCount
    if (now - A_state.lastPress < 2400) {
        A_state.lastPress := 0
        SendInput("{F7}")
        MostrarHUD("ALL LAYERS (2)","FF6B00",3140)
    } else {
        A_state.lastPress := now
        SendInput("{Blind}a")
        MostrarHUD("LAYER CURRENT (1)","00E5FF",950)
    }
}
~RButton & a:: {
    stylus.comboUsado := true
    EnviarNtilde()
    MostrarHUD("REFERENCE LAYER","AA44FF",1680)
}
$e:: {
    _FlushPendentes()
    global colorEstado
    now := A_TickCount
    if GetKeyState("Shift") {
        Send("e")
        return
    }
    if (now - E.last < 300) {
        E.last := 0
        SendInput("{e up}")
        if (colorEstado = 2) {
            Send("k")
            colorEstado := 0
        }
        Send("l")
        Stab_ResetUniversal("l")
        MostrarToolTipE("SOFT ERASER  (2)")
        return
    }
    E.last := now
    if (colorEstado = 2) {
        Send("k")
        colorEstado := 0
    }
    Send("e")
    Stab_ResetUniversal("e")
    MostrarToolTipE("ERASER  (1)")
}
~RButton & e:: {
    stylus.comboUsado := true
    Send("{F12}")
    _SonarUI("borrador")
    MostrarHUD("ERASER LAZO","FF4444",1200)
}
^e:: {
    MostrarHUD("ALL LAYERS ERASER","FF4444",800)
    Send("{F5}")
}
!e:: {
    MostrarHUD("ALL LAYERS ERASER","FF4444",800)
    Send("{F5}")
}
!q:: {
    Send("y")
    MostrarBadgeCombo("ALT + Q","SOFT BRUSH","FF6B00",2200)
}
~LAlt & 1::
~RAlt & 1:: {
    opacidad.nivel := Min(opacidad.nivel + 10,100)
    _EnviarOpacidad()
}
~LAlt & 2::
~RAlt & 2:: {
    opacidad.nivel := Max(opacidad.nivel - 10,10)
    _EnviarOpacidad()
}
!Home:: {
    Send("{PageDown}")
    MostrarHUD("ACCESO RÁPIDO","AA8844",800)
}
!-:: _CicloO()
$w:: {
    _FlushPendentes()
    global colorEstado
    Stab_ResetUniversal("w")
    now := A_TickCount
    if (now - W.last < 300) {
        W.last := 0
        if (colorEstado = 2) {
            SendInput("k")
            colorEstado := 0
            SendInput("{Blind}w")
            _SonarUI("aerografo")
            MostrarMiniTexto("💨 AERÓGRAFO","1A1A2E",1200)
        } else {
            if (colorEstado = 1)
                SendInput("^2")
            SendInput("k")
            colorEstado := 2
            SendInput("{Blind}w")
            _SonarUI("aerografo")
            MostrarMiniTexto("⚪ AERÓGRAFO ALPHA","1C6EA4",1200)
        }
        return
    }
    W.last := now
    SendInput("{Blind}w")
    _SonarUI("aerografo")
    MostrarMiniTexto(colorEstado = 2 ? "⚪ AERÓGRAFO ALPHA" : "💨 AERÓGRAFO",colorEstado = 2 ? "1C6EA4" : "1A1A2E",1200)
}
$z:: {
    _FlushPendentes()
    now := A_TickCount
    if (now - Z.last < 300) {
        Z.last := 0
        Z.timerRunning := 0
        SendInput("{z up}")
        SendInput("r")
        MostrarToolTipZ("✋ R",800)
        return
    }
    Z.last := now
    Z.timerRunning := 1
    SendInput("{Blind}z")
    MostrarToolTipZ("🔍 Z",800)
}
$q:: {
    if GetKeyState("Alt","P") {
        Send("!q")
        return
    }
    now := A_TickCount
    if (now - Q.last < 300) {
        Q.last := 0
        Q.pendiente := false
        SetTimer(__Q_SEND_NORMAL,0)
        global colorEstado
        if (colorEstado = 2) {
            Send("k")
            colorEstado := 0
        }
        SendInput("^2")
        if (colorEstado = 0) {
            colorEstado := 1
            _SonarUI("color_secundario")
            MostrarMiniTextoOscuro("🟡 COLOR SECUNDARIO","51D67B",1200)
        } else {
            colorEstado := 0
            _SonarUI("color_primario")
            MostrarMiniTexto("🔵 COLOR PRIMARIO","2B3B32",1200)
        }
        return
    }
    Q.last := now
    if GetKeyState("RButton","P") {
        AlternarEstabilizacion()
        return
    }
    Q.pendiente := true
    SetTimer(__Q_SEND_NORMAL,-50)
}
_FlushPendentes() {
    if Q.pendiente {
        SetTimer(__Q_SEND_NORMAL,0)
        Q.pendiente := false
        Q.last := 0
        __Q_SEND_NORMAL()
    }
    if AltB_a_state.timerRunning {
        SetTimer(__AltX_SEND_NORMAL,0)
        __AltX_SEND_NORMAL()
    }
    if AltB_s_state.timerRunning {
        SetTimer(__AltS_SEND_NORMAL,0)
        __AltS_SEND_NORMAL()
    }
}
_ToggleLayerVis() {
    SendEvent("{Alt up}{Shift down}d{Shift up}")
    MostrarHUD(N6.layerVis ? "🚫 HIDE LAYER" : "👁 SHOW LAYER",N6.layerVis ? "FF4444" : "44DD88",600)
    N6.layerVis := !N6.layerVis
}
+w:: {
    hoverOn := _ToggleHoverPaneles()
    ActualizarDsGUI()
    ActualizarCcGUI()
    ActualizarArGUI()
    if (hoverOn)
        MostrarMiniTexto("🟠 HOVER ON — deslizador + círculo + acceso rápido","1E8449",1200)
    else
        MostrarMiniTexto("👁 HOVER OFF — paneles visibles","1A5276",1200)
}
+q:: {
    Send("y")
    MostrarHUD("SOFT (Y)","00E5FF",800)
}
!j:: {
    hoverOn := _ToggleHoverPaneles()
    ActualizarDsGUI()
    ActualizarCcGUI()
    ActualizarArGUI()
    if (hoverOn)
        MostrarTooltipToggle("HOVER ACTIVO","▶","verde")
    else
        MostrarTooltipToggle("HOVER PAUSADO","⏸","rojo")
}
_FadeAlpha(hwnd,hasta,pasos := 6,delayMs := 0) {
    global g_sweepActivo
    if g_sweepActivo {
        try WinSetTransparent(hasta,"ahk_id " hwnd)
        return
    }
    if !HasProp(floatGui,"fade")
        floatGui.fade := Map()
    key := "" hwnd, actual := ""
    if floatGui.fade.Has(key) {
        SetTimer(floatGui.fade[key].fn,0)
        floatGui.fade.Delete(key)
    }
    try actual := WinGetTransparent("ahk_id " hwnd)
    if (actual = "" || !IsNumber(actual))
        actual := hasta
    if (actual = hasta)
        return
    tot := _Tema("motion","fast","60")
    tot := (IsInteger(tot) && Integer(tot) > 0) ? Integer(tot) : 60
    pasos := Max(1,pasos)
    ; Min(12,...) = contrato con los llamadores (rearman el bucle a 80 ms): NO quitar
    ms := (delayMs > 0) ? delayMs : Max(1,Min(12,Round(tot / pasos)))
    st := {desde: actual, hasta: hasta, total: pasos, i: 0, ms: ms, lin: (_Tema("motion","easing","out-cubic") = "linear"), fn: _FadePaso.Bind(key)}
    floatGui.fade[key] := st
    SetTimer(st.fn,-ms)
}
_FadePaso(key) {
    if !floatGui.fade.Has(key)
        return
    st := floatGui.fade[key]
    st.i += 1
    t := st.i / st.total
    v := (st.i >= st.total) ? st.hasta : Round(st.desde + (st.hasta - st.desde) * (st.lin ? t : 1 - (1 - t) ** 3))
    try WinSetTransparent(Max(0,Min(255,v)),"ahk_id " key)
    if (st.i >= st.total)
        floatGui.fade.Delete(key)
    else
        SetTimer(st.fn,-st.ms)
}
_SetColorV(on) {
    colorV.hover := on
    colorV.dsVis := !on
    if (on)
        colorV.supresionHasta := A_TickCount + 400
    if (colorV.dsID && WinExist("ahk_id " colorV.dsID)) {
        SetTimer(LoopColorV,0)
        if (on) {
            _FadeAlpha(colorV.dsID,5)
            try WinSetExStyle("+0x20","ahk_id " colorV.dsID)
        } else {
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
            try WinSetExStyle("-0x20","ahk_id " colorV.dsID)
            _FadeAlpha(colorV.dsID,255)
        }
        SetTimer(LoopColorV,80)
    }
    return on
}
_SetColorCC(on) {
    colorCC.hover := on
    colorCC.dsVis := !on
    if (on)
        colorCC.supresionHasta := A_TickCount + 400
    if (colorCC.id && WinExist("ahk_id " colorCC.id)) {
        SetTimer(LoopColorCC,0)
        if (on) {
            _FadeAlpha(colorCC.id,5)
            try WinSetExStyle("+0x20","ahk_id " colorCC.id)
        } else {
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
            try WinSetExStyle("-0x20","ahk_id " colorCC.id)
            _FadeAlpha(colorCC.id,255)
        }
        SetTimer(LoopColorCC,80)
    }
    return on
}
_SetAR(on) {
    ar.hover := on
    ar.dsVis := !on
    if (ar.id && WinExist("ahk_id " ar.id)) {
        SetTimer(LoopAccesoRapido,0)
        if (on) {
            _FadeAlpha(ar.id,5)
            try WinSetExStyle("+0x20","ahk_id " ar.id)
        } else {
            if IsObject(ar.bAR)
                ar.bAR.Hide()
            try WinSetExStyle("-0x20","ahk_id " ar.id)
            _FadeAlpha(ar.id,255)
        }
        SetTimer(LoopAccesoRapido,80)
    }
    return on
}
_ToggleColorV() => _SetColorV(!colorV.hover)
_ToggleColorCC() => _SetColorCC(!colorCC.hover)
_ToggleAR() => _SetAR(!ar.hover)
_ToggleHoverPaneles() {
    target := !colorV.hover
    _SetColorV(target)
    _SetColorCC(target)
    _SetAR(target)
    return target
}
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe") && stylus.altActive
$!x:: {
    now := A_TickCount
    if (now - AltB_a_state.lastPress < 300) {
        SetTimer(__AltX_SEND_NORMAL,0)
        AltB_a_state.timerRunning := 0
        AltB_a_state.lastPress := 0
        SendEvent("{Alt up}p")
        _AltRestaurar(stylus.altActive)
        Stab_ResetUniversal("p")
        MostrarHUD("SMUDGE  (P)","FF6B00",950)
        return
    }
    AltB_a_state.lastPress := now
    AltB_a_state.timerRunning := 1
    SetTimer(__AltX_SEND_NORMAL,-250)
}
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")
__AltX_SEND_NORMAL() {
    if !AltB_a_state.timerRunning
        return
    AltB_a_state.timerRunning := 0
    seguiaSostenido := stylus.altActive
    SendEvent("{Alt up}d")
    _AltRestaurar(seguiaSostenido)
    Stab_ResetUniversal("d")
    MostrarHUD("COLOR MIX  (D)","FF8C42",950)
}
!s:: {
    if !stylus.altActive
        return
    now := A_TickCount
    if (now - AltB_s_state.lastPress < 300) {
        SetTimer(__AltS_SEND_NORMAL,0)
        AltB_s_state.timerRunning := 0
        AltB_s_state.lastPress := 0
        SendEvent("{Alt up}{F7}")
        _AltRestaurar(stylus.altActive)
        MostrarHUD("ALL LAYERS (2)","FF6B00",3140)
        return
    }
    AltB_s_state.lastPress := now
    AltB_s_state.timerRunning := 1
    SetTimer(__AltS_SEND_NORMAL,-250)
}
__AltS_SEND_NORMAL() {
    if !AltB_s_state.timerRunning
        return
    AltB_s_state.timerRunning := 0
    seguiaSostenido := stylus.altActive
    SendEvent("{Alt up}a")
    _AltRestaurar(seguiaSostenido)
    MostrarHUD("LAYER CURRENT (1)","00E5FF",950)
}
$s:: {
    if stylus.altActive
        return
    if GetKeyState("Alt","P")
        return
    _FlushPendentes()
    ahora := A_TickCount
    esRapido := (S.lastTick > 0 && ahora - S.lastTick < S_RAPIDO_MS)
    S.lastTick := esRapido ? 0 : ahora
    if (esRapido) {
        S.skipNext := true
        sel.sRapido := true
        MostrarMiniTexto("🟢 ÁREA CON COLOR","27AE60",1200)
        SendInput("^x")
        SendEvent("{F7}")
        Send("{Alt down}{x}{Alt up}")
        sel.guiActivo := true
        sel.estadoAltX := true
        SetTimer(ResetEstadoAltX,-3000)
        _SonarUI("lazo")
        return
    }
    if (GetKeyState("Space","P") || spc.selectArmed) {
        S.skipNext := true
        if (spc.selectArmed)
            SetTimer(_DesarmarSpaceSelect,-500)
        if (S.estadoCaracter = 0) {
            Send(",")
            MostrarTooltipToggle("AGREGAR A SELECCION","+","verde")
            S.estadoCaracter := 1
        } else {
            Send(".")
            MostrarTooltipToggle("ELIMINAR SELECCIÓN","–","rojo")
            S.estadoCaracter := 0
        }
        SetTimer(QuitarTooltipToggle,-1500)
        return
    }
    if S.skipNext {
        S.skipNext := false
        return
    }
    Send("s")
    Stab_ResetUniversal("s")
    SetTimer(() => MostrarHUD("LASSO","FF6B00",950),-1)
}
$o:: _CicloO()
_CicloO() {
    O.ciclo := Mod(O.ciclo,3) + 1
    if (O.ciclo = 1) {
        Send("h")
        MostrarMiniTexto("🔍 BUSCAR CAPAS (1/3)","1A5276",1200)
    } else if (O.ciclo = 2) {
        SendInput("{Ctrl down}{Numpad1}{Ctrl up}")
        MostrarMiniTexto("🎨 COLOR CAPA (2/3)","6C3483",1200)
    } else {
        SendInput("{Ctrl down}{Numpad2}{Ctrl up}")
        MostrarMiniTexto("🗑 BORRAR COLOR CAPA (3/3)","424949",1200)
    }
}
$Escape:: {
    if (O.ciclo != 0) {
        O.ciclo := 0
        MostrarMiniTexto("↺ CICLO O RESETADO","555555",900)
    }
    global colorEstado
    if (colorEstado = 2) {
        colorEstado := 0
        Send("k")
        MostrarMiniTexto("🎨 ALPHA RESETEADO","555555",900)
    }
    if (sel.guiActivo) {
        sel.guiActivo := false
        sel.estadoAltX := false
        sel.estado := 0
        Send("{Alt down}{x}{Alt up}")
        SetTimer(ResetEstadoAltX,0)
        MostrarMiniTexto("↩ SELECCIÓN CANCELADA","C0392B",700)
        Send("x")
        Send("{Escape}")
        return
    }
    Send("{Escape}")
}
+r:: {
    MostrarHUD("REFLEJAR HORIZONTAL","00E5FF",1500)
    Send("+r")
}
Tab::
+Escape::
F3:: AccionEnfoque()
~f:: {
}
~RButton & s:: {
    stylus.comboUsado := true
    Send("m")
    MostrarHUD("SELECCIÓN (M)","00E5FF",900)
}
~RButton & q:: {
    stylus.comboUsado := true
    Send("{F6}")
    MostrarBadgeCombo("PEN + Q","HARD BRUSH","FF6B00",2200)
}
~RButton & f:: {
    if (!shiftSostenido.activo && !WinActive("ahk_exe CLIPStudioPaint.exe"))
        return   ; no anclar Shift fuera de CSP; sí permitir soltarlo
    stylus.comboUsado := true
    shiftSostenido.activo := !shiftSostenido.activo
    if (shiftSostenido.activo) {
        Send("{Shift down}")
        _SonarUI("shift_on")
        _BadgeSFT(true)
        MostrarAvisoUI("moderno", "REGLA RECTA", "SHIFT SOSTENIDO", 2, "00E5FF", 1600)
    } else {
        Send("{Shift up}")
        _SonarUI("shift_off")
        _BadgeSFT(false)
        MostrarAvisoUI("moderno", "REGLA LIBERADA", "SHIFT OFF", 2, "888888", 1200)
    }
}

; ── Micro-badge persistente "SFT" visible en la pantalla XP-Pen de dibujo ──
_BadgeSFT(on) {
    global _sftGui, AVISO_ESC
    if (!on) {
        SetTimer(_BadgeSFTGuardia, 0)
        if (IsObject(_sftGui)) {
            try _sftGui.Destroy()
            _sftGui := ""
        }
        return
    }
    if (IsObject(_sftGui))
        return
    mon := ObtenerMonitorCSP()
    w := Round(90 * AVISO_ESC)
    h := Round(32 * AVISO_ESC)
    posX := mon.x + mon.w - w - 24
    posY := mon.y + mon.h - h - 44
    g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 +E0x80")
    g.BackColor := "12141A"
    g.MarginX := 0
    g.MarginY := 0
    WinSetTransparent(235, g)
    ; Acento izquierdo y base del estilo avanzado
    bLeft := g.Add("Progress", "x0 y0 w" Round(4 * AVISO_ESC) " h" h)
    bLeft.Opt("c00E5FF")
    bLeft.Value := 100
    bBot := g.Add("Progress", "x0 y" (h - Round(3 * AVISO_ESC)) " w" w " h" Round(3 * AVISO_ESC))
    bBot.Opt("c00E5FF")
    bBot.Value := 100
    lbl := g.Add("Text", "x" Round(8 * AVISO_ESC) " y0 w" (w - Round(12 * AVISO_ESC)) " h" h " c00E5FF Center +0x200 BackgroundTrans", "SFT  •  ON")
    lbl.SetFont("s" Max(7, Round(9 * AVISO_ESC)) " bold", "Segoe UI")
    g.Show("NoActivate x" posX " y" posY " w" w " h" h)
    _sftGui := g
    SetTimer(_BadgeSFTGuardia, 500)
}
_BadgeSFTGuardia() {                      ; red de seguridad si el Shift se libera por otra vía
    if (!shiftSostenido.activo)
        _BadgeSFT(false)
}
~RButton & w:: {
    stylus.comboUsado := true
    EnviarNtilde()
    MostrarBadgeCombo("PEN + W","DIFU MIXER 2","00E5FF",2200)
}
!w:: {
    EnviarMenor()
    MostrarBadgeCombo("ALT + W","★ OPC PRESSURE 2","00E5FF",2200)
}
~RButton & -:: {
    stylus.comboUsado := true
    now := A_TickCount
    if (now - RM.last < 300) {
        RM.last := 0
        Send("!t")
        MostrarHUD("OCULTAR REGLA","1A1A2E",800)
        return
    }
    RM.last := now
    Send("t")
    MostrarHUD("Rule","1A1A2E",800)
}
~RButton & z:: {
    stylus.comboUsado := true
    Send("^v")
    _SonarUI("copiar")
    MostrarHUD("📋 PEGAR (CTRL+V)","44DD88",800)
}
~RButton & z up:: stylus.botonSostenido := false
~RButton & x:: {
    stylus.comboUsado := true
    Send("u")
    MostrarHUD("GRADIENT (U)","00E5FF",900)
}
~RButton & 1:: {
    stylus.comboUsado := true
    MostrarToolTipE("FILL  (V)")
    Send("v")
}
~RButton & 2:: {
    stylus.comboUsado := true
    Send("{F11}")
    MostrarHUD("Advanced fill","AA8844",800)
}
_EnviarOpacidad() {
    key := (opacidad.nivel = 100) ? "0" : String(opacidad.nivel // 10)
    SendInput("+" key)
    ActualizarDialGUI()
    MostrarHUD("OPACIDAD " opacidad.nivel "%","00E5FF",900)
}
~RButton & 3::
~RButton & 4::
~RButton & 5::
~RButton & 6::
~RButton & 7::
~RButton & 8::
~RButton & 9::
~RButton & 0:: {
    stylus.comboUsado := true
    key := SubStr(A_ThisHotkey,StrLen(A_ThisHotkey))
    porcentaje := (key = "0") ? 100 : Integer(key) * 10
    opacidad.nivel := porcentaje
    SendInput("+" key)
    ActualizarDialGUI()
    MostrarHUD("OPACIDAD " porcentaje "%","00E5FF",900)
}
~1:: {
    if (dial.modo != 1) {
        dial.modo := 1
        ActualizarDialGUI()
    }
}
~2:: {
    if (dial.modo != 1) {
        dial.modo := 1
        ActualizarDialGUI()
    }
}
~3:: {
    if (dial.modo != 2) {
        dial.modo := 2
        ActualizarDialGUI()
    }
}
~4:: {
    if (dial.modo != 2) {
        dial.modo := 2
        ActualizarDialGUI()
    }
}
NumpadDiv:: {
    dial.modo := (dial.modo = 1) ? 2 : 1
    ActualizarDialGUI()
}
Numpad8:: {
    _LimpiarGUIs()
    try dial.g.Destroy()
    dial.g := 0
    dial.icono := 0
    dial.label := 0
    dial.barra := 0
    IniciarDialGUI()
    try dsGui.g.Destroy()
    dsGui.g := 0
    dsGui.icono := 0
    dsGui.label := 0
    dsGui.barra := 0
    try OnMessage(0x0201,_DsGUI_WM_LBUTTONDOWN,0)
    IniciarDsGUI()
    try ccGui.g.Destroy()
    ccGui.g := 0
    ccGui.icono := 0
    ccGui.label := 0
    ccGui.barra := 0
    try OnMessage(0x0201,_CcGUI_WM_LBUTTONDOWN,0)
    IniciarCcGUI()
    try arGui.g.Destroy()
    arGui.g := 0
    arGui.icono := 0
    arGui.label := 0
    arGui.barra := 0
    try OnMessage(0x0201,_ArGUI_WM_LBUTTONDOWN,0)
    IniciarArGUI()
    try hcGui.g.Destroy()
    hcGui.g := 0
    hcGui.icono := 0
    hcGui.label := 0
    hcGui.barra := 0
    try OnMessage(0x0201,_HCGUI_WM_LBUTTONDOWN,0)
    IniciarHCGUI()
    try lockGui.g.Destroy()
    lockGui.g := 0
    lockGui.icono := 0
    lockGui.barra := 0
    try OnMessage(0x0201,_LockGUI_WM_LBUTTONDOWN,0)
    IniciarLockGUI()
    try frenteGui.g.Destroy()
    frenteGui.g := 0
    frenteGui.icono := 0
    frenteGui.barra := 0
    try OnMessage(0x0201,_FrenteGUI_WM_LBUTTONDOWN,0)
    IniciarFrenteGUI()
    try estabGui.g.Destroy()
    estabGui.g := 0
    estabGui.valorTxt := 0
    estabGui.grip := 0
    estabGui.foco := false
    estabGui.dibV := -1
    SetTimer(_EstabFocoVigilar,0)
    try OnMessage(0x0201,_EstabGUI_WM_LBUTTONDOWN,0)
    try OnMessage(0x0207,_EstabGUI_WM_MBUTTONDOWN,0)
    IniciarEstabGUI()
    try estabBtnGui.g.Destroy()
    estabBtnGui.g := 0
    estabBtnGui.icono := 0
    estabBtnGui.label := 0
    estabBtnGui.barra := 0
    try OnMessage(0x0201,_EstabBtnGUI_WM_LBUTTONDOWN,0)
    IniciarEstabBtnGUI()
    try hubGui.g.Destroy()
    hubGui.g := 0
    hubGui.icono := 0
    hubGui.barra := 0
    try OnMessage(0x0201,_HubGUI_WM_LBUTTONDOWN,0)
    try OnMessage(0x0205,_Companion_WM_RBUTTON,0)
    IniciarHubGUI()
    ToolTip("🔄 GUIs reiniciadas")
    SetTimer(() => ToolTip(),-1000)
}
~Space & NumpadAdd:: {
    Send("+p")
    MostrarMiniTexto("SPACE  +  +","1E8449",700)
}
~Space & NumpadSub:: {
    Send("^+p")
    MostrarMiniTexto("SPACE  +  −","922B21",700)
}
~Space & w:: {
    _FlushPendentes()
    Send("+w")
    MostrarMiniTexto("Up","1E8449",700)
}
~Space & x:: {
    _FlushPendentes()
    Send("+s")
    MostrarMiniTexto("Down","1E8449",700)
}
~Space & e:: {
    _FlushPendentes()
    _ToggleLayerVis()
}
~Space & q:: {
    _FlushPendentes()
    AccionEnfoque()
}
~Space & s:: {
    _FlushPendentes()
    SendInput("+f")
    _SonarUI("shift_on")
    MostrarHUD("🔒 BLOQUEO TRANSPARENCIA","00E5FF",900)
}
~Space & f:: {
    _FlushPendentes()
    static estado := 0
    Send("{Insert}")
    if (estado = 0) {
        MostrarHUD("Gray scale","888888",1000)
        estado := 1
    } else {
        MostrarHUD("color","FF4444",1000)
        estado := 0
    }
}
~Space & Numpad1::
~Space & Numpad2::
~Space & Numpad3::
~Space & Numpad4::
~Space & Numpad5::
~Space & Numpad6:: {
    tecla := SubStr(A_ThisHotkey,StrLen(A_ThisHotkey))
    tipos := Map("1","HSV","2","Brillo/Contraste","3","Equilibrio color","4","Curva tonos","5","Niveles","6","Degradado")
    MostrarHUD("Capa: " tipos[tecla],"AA44FF",500)
    Send("^!" tecla)
}
$Numpad6:: {
    Send("{Insert}")
    MostrarHUD("Grayscale Toggle","888888",800)
}
*Backspace:: {
    if GetKeyState("Space","P") {
        Send("8")
        MostrarHUD("BORRAR CAPA DE CORRECCIÓN","FF4444",1200)
        return
    }
    Send("{Backspace}")
}
~Space:: spc.downTick := A_TickCount
~Space up:: {
    held := A_TickCount - spc.downTick
    now := A_TickCount
    if (held <= 180) && (now - spc.last < 320) {
        spc.last := 0
        sel.guiActivo := true
        if sel.estadoAltX {
            MostrarMiniTexto("👁 MOSTRAR BORDE","2ECC71",1200)
            sel.estadoAltX := false
        } else {
            MostrarMiniTexto("🚫 OCULTAR BORDE","E74C3C",1200)
            sel.estadoAltX := true
        }
        Send("{Alt down}{x}{Alt up}")
        SetTimer(ResetEstadoAltX,-3000)
        return
    }
    if (held <= 180)
        spc.last := now
    if (held <= 450) {
        spc.selectArmed := true
        SetTimer(_DesarmarSpaceSelect,-500)
    }
}
_DesarmarSpaceSelect() => spc.selectArmed := false
#HotIf
class BorderFrame {
    T := 0
    B := 0
    L := 0
    R := 0
    __New(color) {
        opts := "-Caption +AlwaysOnTop +ToolWindow +E0x20"
        for side in ["T","B","L","R"] {
            g := Gui(opts)
            g.BackColor := color
            g.Show("w0 h0 NoActivate")
            this.%side% := g
        }
    }
    Show(x,y,w,h,g := 1) {
        flags := 0x10 | 0x40
        DllCall("SetWindowPos","Ptr",this.T.Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",w,"Int",g,"UInt",flags)
        DllCall("SetWindowPos","Ptr",this.B.Hwnd,"Ptr",-1,"Int",x,"Int",y + h - g,"Int",w,"Int",g,"UInt",flags)
        DllCall("SetWindowPos","Ptr",this.L.Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",g,"Int",h,"UInt",flags)
        DllCall("SetWindowPos","Ptr",this.R.Hwnd,"Ptr",-1,"Int",x + w - g,"Int",y,"Int",g,"Int",h,"UInt",flags)
        WinSetTransparent(85,"ahk_id " this.T.Hwnd)
        WinSetTransparent(85,"ahk_id " this.B.Hwnd)
        WinSetTransparent(85,"ahk_id " this.L.Hwnd)
        WinSetTransparent(85,"ahk_id " this.R.Hwnd)
    }
    Hide() {
        this.T.Hide()
        this.B.Hide()
        this.L.Hide()
        this.R.Hide()
    }
}
ObtenerMonitorCSP() {
    if (colorV.cspHwnd) {
        try {
            WinGetPos(&wx,&wy,&ww,&wh,"ahk_id " colorV.cspHwnd)
            cx := wx + ww // 2
            cy := wy + wh // 2
            loop MonitorGetCount() {
                MonitorGet(A_Index,&mL,&mT,&mR,&mB)
                if (cx >= mL && cx < mR && cy >= mT && cy < mB)
                    return {x:mL,y:mT,w:mR - mL,h:mB - mT}
            }
        }
    }
    pri := MonitorGetPrimary()
    MonitorGet(pri,&mL,&mT,&mR,&mB)
    return {x:mL,y:mT,w:mR - mL,h:mB - mT}
}
IniciarDeteccion() {
    bestHwnd := 0
    bestArea := 0
    for hwnd in WinGetList("ahk_exe CLIPStudioPaint.exe") {
        try {
            WinGetPos(&tx,&ty,&tw,&th,"ahk_id " hwnd)
            if (tw * th > bestArea) {
                bestArea := tw * th
                bestHwnd := hwnd
            }
        }
    }
    colorV.cspHwnd := bestHwnd
    colorV.dsID := BuscarVentanaCSP(0,"eslizador","colores")
    if (colorV.dsID) {
        colorV.bDS := BorderFrame("44AA66")
        colorV.hover := true
        colorV.dsVis := false
        try WinSetTransparent(5,"ahk_id " colorV.dsID)
        try WinSetExStyle("+0x20","ahk_id " colorV.dsID)
    }
    colorCC.id := BuscarVentanaCSP(0,"rculo de colores","olores")
    if (colorCC.id) {
        colorCC.bCC := BorderFrame("AA6622")
        colorCC.hover := false
        colorCC.dsVis := true
        try WinSetTransparent(255,"ahk_id " colorCC.id)
        try WinSetExStyle("-0x20","ahk_id " colorCC.id)
    }
    ar.id := BuscarVentanaCSP(0,"Acceso r","pido")
    if (ar.id) {
        ar.bAR := BorderFrame("AA8844")
        ar.hover := false
        ar.dsVis := true
        try WinSetTransparent(255,"ahk_id " ar.id)
        try WinSetExStyle("-0x20","ahk_id " ar.id)
    }
}
BuscarVentanaCSP(idActual,frag1,frag2) {
    if (idActual) {
        try {
            if WinExist("ahk_id " idActual)
                return idActual
        }
    }
    for hwnd in WinGetList("ahk_exe CLIPStudioPaint.exe") {
        try {
            t := WinGetTitle("ahk_id " hwnd)
            if InStr(t,frag1) && InStr(t,frag2)
                return hwnd
        }
    }
    return 0
}
CheckReload() {
    try newTime := FileGetTime(A_ScriptFullPath,"M")
    catch
        return
    if (sys.lastModTime = "") {
        sys.lastModTime := newTime
        return
    }
    if (newTime != sys.lastModTime) {
        sys.lastModTime := newTime
        mon := ObtenerMonitorCSP()
        x := mon.x + (mon.w // 2) - 120
        y := mon.y + (mon.h // 2) - 20
        ToolTip("💾 Script actualizado y recargado",x,y)
        _SonarUI("reload")
        Sleep(300)
        ToolTip()
        Reload()
    }
}
ChequearZonaHistorial() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe")
        return
    if sys.modoEscritura
        return
    if (hist.modo = 2)
        return
    MouseGetPos(&mx,&my)
    z := ZONAS.hist
    enZona := (mx >= z.x1 && mx <= z.x2 && my >= z.y1 && my <= z.y2)
    if (enZona && !hist.abierto) {
        hist.abierto := true
        Send("{Numpad9}")
    } else if (!enZona && hist.abierto) {
        hist.abierto := false
        Send("{Numpad9}")
    }
}
LimpiarAltPegadoPureRef() {
    if !stylus.altActive
        return
    if !WinActive("ahk_exe PureRef.exe")
        return
    stylus.altActive := false
    Send("{Alt up}")
}
ChequearZonaAltA() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe")
        return
    if sys.modoEscritura
        return
    _ChequearBotones(btn,ZONAS.izq)
}
ChequearZonaDerecha() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe")
        return
    if sys.modoEscritura
        return
    _ChequearBotones(botDer,ZONAS.der)
}
_ChequearBotones(estado,zonas) {
    if !enfoque.activo
        return
    MouseGetPos(&mx,&my)
    Loop 3 {
        z := zonas[A_Index]
        k := "b" A_Index
        enZona := (mx >= z.x1 && mx <= z.x2 && my >= z.y1 && my <= z.y2)
        if (enZona && !estado.%k%) {
            estado.%k% := true
            SendEvent("{Click " mx " " my "}")
        } else if (!enZona && estado.%k%)
            estado.%k% := false
    }
}
LoopColorV() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if (colorV.hover) {
            if (colorV.dsVis && colorV.dsID) {
                colorV.dsVis := false
                try WinSetTransparent(5,"ahk_id " colorV.dsID)
                try WinSetExStyle("+0x20","ahk_id " colorV.dsID)
            }
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
        }
        return
    }
    if (!colorV.dsID) {
        colorV.dsID := BuscarVentanaCSP(0,"eslizador","colores")
        if (colorV.dsID) {
            colorV.bDS := BorderFrame("44AA66")
            colorV.dsVis := false
            try WinSetTransparent(5,"ahk_id " colorV.dsID)
            try WinSetExStyle("+0x20","ahk_id " colorV.dsID)
        }
        return
    }
    try {
        if !WinExist("ahk_id " colorV.dsID) {
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
            colorV.dsID := 0
            colorV.dsVis := false
            return
        }
        WinGetPos(&wx,&wy,&ww,&wh,"ahk_id " colorV.dsID)
        colorV.dsX := wx
        colorV.dsY := wy
        colorV.dsW := ww
        colorV.dsH := wh
    } catch {
        if IsObject(colorV.bDS)
            colorV.bDS.Hide()
        colorV.dsID := 0
        colorV.dsVis := false
        return
    }
    if (!colorV.hover)
        return
    MouseGetPos(&mx,&my)
    enDS := (mx >= wx && mx <= wx + ww && my >= wy && my <= wy + wh)
    enCirculo := false
    if (colorCC.id && colorCC.ccW > 0) {
        if (colorCC.hover)
            enCirculo := colorCC.dsVis
        else
            enCirculo := (mx >= colorCC.ccX && mx <= colorCC.ccX + colorCC.ccW && my >= colorCC.ccY && my <= colorCC.ccY + colorCC.ccH)
    }
    if (A_TickCount < colorV.supresionHasta) {
        enDS := false
        enCirculo := false
    }
    if (enDS || enCirculo) {
        if (!colorV.dsVis) {
            colorV.dsVis := true
            try WinSetTransparent(255,"ahk_id " colorV.dsID)
            try WinSetExStyle("-0x20","ahk_id " colorV.dsID)
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
        }
    } else {
        if (colorV.dsVis) {
            colorV.dsVis := false
            try WinSetTransparent(5,"ahk_id " colorV.dsID)
            try WinSetExStyle("+0x20","ahk_id " colorV.dsID)
        }
        if IsObject(colorV.bDS)
            colorV.bDS.Show(wx,wy,ww,wh)
    }
}
LoopColorCC() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if (colorCC.hover) {
            if (colorCC.dsVis && colorCC.id) {
                colorCC.dsVis := false
                try WinSetTransparent(5,"ahk_id " colorCC.id)
                try WinSetExStyle("+0x20","ahk_id " colorCC.id)
            }
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
        }
        colorCC.ccW := 0
        return
    }
    if (!colorCC.id) {
        colorCC.id := BuscarVentanaCSP(0,"rculo de colores","olores")
        if (colorCC.id) {
            colorCC.bCC := BorderFrame("AA6622")
            colorCC.dsVis := false
            try WinSetTransparent(5,"ahk_id " colorCC.id)
            try WinSetExStyle("+0x20","ahk_id " colorCC.id)
        }
        return
    }
    try {
        if !WinExist("ahk_id " colorCC.id) {
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
            colorCC.id := 0
            colorCC.dsVis := false
            colorCC.ccW := 0
            return
        }
        WinGetPos(&wx,&wy,&ww,&wh,"ahk_id " colorCC.id)
        colorCC.ccX := wx
        colorCC.ccY := wy
        colorCC.ccW := ww
        colorCC.ccH := wh
    } catch {
        if IsObject(colorCC.bCC)
            colorCC.bCC.Hide()
        colorCC.id := 0
        colorCC.dsVis := false
        colorCC.ccW := 0
        return
    }
    if (!colorCC.hover)
        return
    MouseGetPos(&mx,&my)
    dentro := (mx >= wx && mx <= wx + ww && my >= wy && my <= wy + wh)
    if (!dentro) {
        enDeslizador := false
        if (!colorV.hover && colorV.dsID && colorV.dsW > 0)
            enDeslizador := (mx >= colorV.dsX && mx <= colorV.dsX + colorV.dsW && my >= colorV.dsY && my <= colorV.dsY + colorV.dsH)
        dentro := enDeslizador
    }
    if (A_TickCount < colorCC.supresionHasta)
        dentro := false
    if (dentro) {
        if (!colorCC.dsVis) {
            colorCC.dsVis := true
            try WinSetTransparent(255,"ahk_id " colorCC.id)
            try WinSetExStyle("-0x20","ahk_id " colorCC.id)
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
        }
    } else {
        if (colorCC.dsVis) {
            colorCC.dsVis := false
            try WinSetTransparent(5,"ahk_id " colorCC.id)
            try WinSetExStyle("+0x20","ahk_id " colorCC.id)
        }
        if IsObject(colorCC.bCC)
            colorCC.bCC.Show(wx,wy,ww,wh)
    }
}
LoopAccesoRapido() {
    if (!ar.hover)
        return
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if (ar.dsVis && ar.id) {
            ar.dsVis := false
            try WinSetTransparent(5,"ahk_id " ar.id)
            try WinSetExStyle("+0x20","ahk_id " ar.id)
        }
        if IsObject(ar.bAR)
            ar.bAR.Hide()
        return
    }
    if (!ar.id) {
        ar.id := BuscarVentanaCSP(0,"Acceso r","pido")
        if (ar.id) {
            ar.bAR := BorderFrame("AA8844")
            ar.dsVis := false
            try WinSetTransparent(5,"ahk_id " ar.id)
            try WinSetExStyle("+0x20","ahk_id " ar.id)
        }
        return
    }
    try {
        if !WinExist("ahk_id " ar.id) {
            if IsObject(ar.bAR)
                ar.bAR.Hide()
            ar.id := 0
            ar.dsVis := false
            return
        }
        WinGetPos(&wx,&wy,&ww,&wh,"ahk_id " ar.id)
    } catch {
        if IsObject(ar.bAR)
            ar.bAR.Hide()
        ar.id := 0
        ar.dsVis := false
        return
    }
    MouseGetPos(&mx,&my)
    dentro := (mx >= wx && mx <= wx + ww && my >= wy && my <= wy + wh)
    if (dentro) {
        if (!ar.dsVis) {
            ar.dsVis := true
            try WinSetTransparent(255,"ahk_id " ar.id)
            try WinSetExStyle("-0x20","ahk_id " ar.id)
            if IsObject(ar.bAR)
                ar.bAR.Hide()
        }
    } else {
        if (ar.dsVis) {
            ar.dsVis := false
            try WinSetTransparent(5,"ahk_id " ar.id)
            try WinSetExStyle("+0x20","ahk_id " ar.id)
        }
        if IsObject(ar.bAR)
            ar.bAR.Show(wx,wy,ww,wh)
    }
}
ResetProcesando() => E.procesando := false
__Q_SEND_NORMAL() {
    global colorEstado
    Q.pendiente := false
    SendInput("q")
    _SonarUI("pluma")
    Stab_ResetUniversal("q")
    if (colorEstado = 1)
        MostrarMiniTextoOscuro("🟡 COLOR SECUNDARIO", _Tema("color", "color_secundario", "51D67B"), 800)
    else if (colorEstado = 2)
        MostrarMiniTexto("⚪ ALPHA TRANSPARENTE", _Tema("color", "color_alpha", "1C6EA4"), 800)
    else
        MostrarMiniTexto("🔵 COLOR PRIMARIO", _Tema("color", "color_primario", "2B3B32"), 800)
}
AlternarEstabilizacion() {
    global stabU
    static ocupado := false
    static lastTick := 0
    static lastPressTime := 0
    if stabU.ocupado
        return
    now := A_TickCount
    if (ocupado || (now - lastTick < 80))
        return
    if GetKeyState("LButton","P") || GetKeyState("RButton","P")
        return
    lastTick := now
    ocupado := true
    esDobleTap := (now - lastPressTime < 350)
    lastPressTime := esDobleTap ? 0 : now
    delta := ESTAB_MAX - ESTAB_MIN
    try {
        BlockInput(true)
        if (esDobleTap) {
            if (Q.estadoEstab = 0) {
                SendInput("{j 100}{- " ESTAB_MAX "}")
                Q.estadoEstab := 1
                MostrarMiniTexto("🔄 RE-SINCRONIZADO: ALTA (" ESTAB_MAX ")","1A5C2A",1000)
                SetTimer(_BeepEstabAlta,-1)
            } else {
                SendInput("{j 100}{- " ESTAB_MIN "}")
                Q.estadoEstab := 0
                MostrarMiniTexto("🔄 RE-SINCRONIZADO: BAJA (" ESTAB_MIN ")","1A2E5C",1000)
                SetTimer(_BeepEstabBaja,-1)
            }
        } else {
            if (Q.estadoEstab = 0) {
                SendInput("{j 100}{- " ESTAB_MAX "}")
                Q.estadoEstab := 1
                MostrarMiniTexto("🟢 ESTABILIZACIÓN ALTA (" ESTAB_MAX ")","1A5C2A",700)
                SetTimer(_BeepEstabAlta,-1)
            } else {
                SendInput("{j 100}{- " ESTAB_MIN "}")
                Q.estadoEstab := 0
                MostrarMiniTexto("🔵 ESTABILIZACIÓN BAJA (" ESTAB_MIN ")","1A2E5C",700)
                SetTimer(_BeepEstabBaja,-1)
            }
        }
    } finally {
        BlockInput(false)
        ocupado := false
        estabGui.sincronizado := false
    }
}
; ── MOTOR UNIFICADO DE FEEDBACK SONORO UI (Paquete 2 Avanzado) ──
; Cero pitidos de BIOS, cero alertas estridentes de Windows.
; Micro-tonos hápticos de 15-30 ms y WAVs sutiles locales.
_SonarUI(evento, val := 0) {
    if (_SonarFast(evento))              ; ruta RAM de latencia cero; si no aplica, sigue la lógica actual
        return
    static iniPath := A_ScriptDir "\theme.ini"
    try {
        if (IniRead(iniPath, "audio", "enabled", "1") = "0")
            return
    }
    switch evento {
        case "slider":
            ; Micro-click háptico continuo (18 ms, frecuencia de 450 Hz a 1250 Hz según estabilizador)
            freq := 450 + Round(Max(0, Min(100, val)) * 8)
            SetTimer(() => DllCall("kernel32\Beep", "UInt", freq, "UInt", 18), -1)

        case "borrador", "relleno", "lazo", "pincel":
            ; Micro-tap orgánico rápido para herramientas
            _SonarWav("alpha_loud", A_WinDir "\Media\Windows Navigation Start.wav")

        case "shift_on", "enfoque_on", "color":
            ; Micro-tono suave ascendente
            SetTimer(() => DllCall("kernel32\Beep", "UInt", 760, "UInt", 22), -1)

        case "shift_off", "enfoque_off":
            ; Micro-tono suave descendente
            SetTimer(() => DllCall("kernel32\Beep", "UInt", 520, "UInt", 22), -1)

        case "guardar", "layout", "sync":
            ; Confirmación suave melódica
            _SonarWav("alpha_short", A_WinDir "\Media\Windows Feed Discovered.wav")

        case "reload":
            ; Micro-tono de recarga
            _SonarWav("alpha_loud", A_WinDir "\Media\Windows Navigation Start.wav")

        case "copiar", "flip", "calib":
            ; Micro-tick discreto (15 ms)
            SetTimer(() => DllCall("kernel32\Beep", "UInt", 680, "UInt", 15), -1)

        case "seleccion":
            ; Micro-doble tick de lazo
            SetTimer(() => DllCall("kernel32\Beep", "UInt", 580, "UInt", 16), -1)

        default:
            return
    }
}

_SonarWav(nombreWav, fallbackWin := "") {
    ruta := A_ScriptDir "\sonidos\" nombreWav ".wav"
    if !FileExist(ruta) {
        if (fallbackWin = "" || !FileExist(fallbackWin))
            return
        ruta := fallbackWin
    }
    SetTimer(() => SoundPlay(ruta), -1)
}
_BeepEstabAlta() => _SonarUI("slider", 100)
_BeepEstabBaja() => _SonarUI("slider", 0)
_CheckGitDone() {
    MostrarHUD("✅ GitHub actualizado","44DD88",2000)
    _SonarUI("guardar")
}
ResetEstadoAltX() {
    sel.estadoAltX := false
    sel.guiActivo := false
}
__ResetEstadoC() => sel.estadoC := 0
_DestruirGui(guiObj) {
    if !IsObject(guiObj)
        return
    try {
        if (guiObj.Hwnd && DllCall("IsWindow", "Ptr", guiObj.Hwnd)) {
            DllCall("ShowWindow", "Ptr", guiObj.Hwnd, "Int", 0)
            DllCall("DestroyWindow", "Ptr", guiObj.Hwnd)
        }
        guiObj.Destroy()
    }
}
_LimpiarGUIs() {
    _AvisoCerrarBadge()
    _AvisoCerrarHUD()
    _DestruirGui(floatGui.hud)
    floatGui.hud := 0
    floatGui.hudHwnd := 0
    floatGui.hudLabel := 0
    floatGui.hudBar := 0
    _DestruirGui(floatGui.miniTip)
    floatGui.miniTip := 0
    floatGui.miniTipID := 0
    floatGui.miniTipTick := 0
    _DestruirGui(floatGui.tooltipToggle)
    floatGui.tooltipToggle := 0
    _DestruirGui(floatGui.miniGUI)
    floatGui.miniGUI := 0
    _DestruirGui(floatGui.enfoque)
    floatGui.enfoque := 0
    enfoque.activo := false
    OcultarGUIEnfoque()
    _DestruirGui(floatGui.overlayIcon)
    floatGui.overlayIcon := 0
    floatGui.overlayIconID := 0
}
; ── Micro-tonos en RAM: winmm\PlaySoundW con SND_MEMORY | SND_ASYNC | SND_NODEFAULT ──
_SonarFast(evento) {
    static perfil := Map(
        ; evento           [Hz inicio, Hz fin, ms]
        "pluma",           [1600, 1800, 14],   ; Q: plumilla tinta  → agudo seco, sube
        "aerografo",       [ 600,  480, 18],   ; W: aerógrafo       → grave suave, baja
        "color_primario",  [1000, 1250, 12],   ; color frontal      → corto ascendente
        "color_secundario",[ 820,  660, 12],   ; color alterno      → corto descendente
        "shift_on",        [ 900, 1200, 16],
        "shift_off",       [1200,  900, 16]
    )
    static ram := Map()
    if (!perfil.Has(evento))
        return false                       ; no es mío: lo atiende _SonarUI original
    if (!ram.Has(evento)) {
        p := perfil[evento]
        ram[evento] := _CrearTonoRAM(p[1], p[2], p[3])
    }
    ; el Buffer vive en ram, así que sigue válido mientras suena (requisito de SND_MEMORY)
    DllCall("winmm\PlaySoundW", "Ptr", ram[evento], "Ptr", 0, "UInt", 0x0001 | 0x0002 | 0x0004)
    return true
}
_CrearTonoRAM(f0, f1, ms, vol := 0.18) {
    sr := 22050, pi := 3.14159265358979
    n := Integer(sr * ms / 1000)
    buf := Buffer(44 + n * 2, 0)
    NumPut("UInt", 0x46464952, buf, 0)        ; "RIFF"
    NumPut("UInt", 36 + n * 2, buf, 4)
    NumPut("UInt", 0x45564157, buf, 8)        ; "WAVE"
    NumPut("UInt", 0x20746D66, buf, 12)       ; "fmt "
    NumPut("UInt", 16, buf, 16)
    NumPut("UShort", 1, buf, 20)              ; PCM
    NumPut("UShort", 1, buf, 22)              ; mono
    NumPut("UInt", sr, buf, 24)
    NumPut("UInt", sr * 2, buf, 28)
    NumPut("UShort", 2, buf, 32)
    NumPut("UShort", 16, buf, 34)
    NumPut("UInt", 0x61746164, buf, 36)       ; "data"
    NumPut("UInt", n * 2, buf, 40)
    phase := 0.0
    loop n {
        i := A_Index - 1
        f := f0 + (f1 - f0) * i / n           ; barrido lineal de frecuencia
        phase += 2 * pi * f / sr
        env := Sin(pi * i / n) ** 2           ; ataque/caída suaves: sin clic
        NumPut("Short", Round(Sin(phase) * env * vol * 32767), buf, 44 + i * 2)
    }
    return buf
}

; ==========================================================================
; AVISOS VISUALES UNIFICADOS (2 formatos x 3 zonas de prioridad)
;   Formatos : "moderno" (badge 240x72, 2 niveles) | "bruto" (HUD 208x40)
;   Zonas    : 1 = centro del lienzo | 2 = tercio superior/central | 3 = P30 (periferica)
; Opcional: definir AVISO_MONITOR_LIENZO := N (indice de monitor) para forzar la pantalla XP-Pen.
; ==========================================================================

_PosicionAviso(w,h) => _CalcularPosicionZona(3, w, h)

; Monitor del lienzo: detecta con precision la pantalla donde esta CLIP Studio Paint (XP-Pen secundaria)
_AvisoMonitorLienzo(&l, &t, &r, &b) {
    global AVISO_MONITOR_LIENZO
    n := MonitorGetCount()
    if (IsSet(AVISO_MONITOR_LIENZO) && IsNumber(AVISO_MONITOR_LIENZO) && AVISO_MONITOR_LIENZO >= 1 && AVISO_MONITOR_LIENZO <= n) {
        MonitorGet(Integer(AVISO_MONITOR_LIENZO), &l, &t, &r, &b)
        return
    }
    mon := ObtenerMonitorCSP()
    l := mon.x, t := mon.y, r := mon.x + mon.w, b := mon.y + mon.h
}

; Devuelve {x, y} ya recortado al monitor segun la zona de prioridad calibrada.
_CalcularPosicionZona(zona, w, h) {
    clave := (zona = 1) ? "HUD_Alta" : ((zona = 2) ? "HUD_Media" : "HUD_Baja")
    rg := ObtenerRango(clave)
    if (IsObject(rg) && IsInteger(rg.w) && IsInteger(rg.h) && rg.w >= 30 && rg.h >= 16) {
        px := rg.x + (rg.w - w) // 2
        py := rg.y + (rg.h - h) // 2
        p := _AvisoClamp(px, py, w, h)
        return {x: p[1], y: p[2]}
    }
    _AvisoMonitorLienzo(&l, &t, &r, &b)
    mw := r - l, mh := b - t
    x := l + (mw - w) // 2
    if (zona = 1)
        y := t + Round(mh * 0.42) - h // 2     ; zona 1: centro focal del lienzo
    else if (zona = 2)
        y := t + Round(mh * 0.16)              ; zona 2: tercio superior/central
    else
        y := t + Round(mh * 0.78) - h // 2     ; zona 3: tercio inferior del lienzo
    p := _AvisoClamp(x, y, w, h)
    return {x: p[1], y: p[2]}
}

_AvisoCerrarAuxiliares() {
    global floatGui
    if IsObject(floatGui.miniTip)
        _DestruirGui(floatGui.miniTip)
    if IsObject(floatGui.miniGUI)
        _DestruirGui(floatGui.miniGUI)
    if IsObject(floatGui.tooltipToggle)
        _DestruirGui(floatGui.tooltipToggle)
    if IsObject(floatGui.overlayIcon)
        _DestruirGui(floatGui.overlayIcon)
}
_AvisoCerrarBadge() {
    global floatGui, _AvisoBadgesActivos
    try SetTimer(_TimerOcultarBadge, 0)
    if (IsObject(floatGui) && IsObject(floatGui.badge)) {
        try {
            if (floatGui.badgeHwnd && DllCall("IsWindow", "Ptr", floatGui.badgeHwnd)) {
                DllCall("ShowWindow", "Ptr", floatGui.badgeHwnd, "Int", 0)
                DllCall("DestroyWindow", "Ptr", floatGui.badgeHwnd)
            }
            floatGui.badge.Destroy()
        }
    }
    if (IsSet(_AvisoBadgesActivos) && IsObject(_AvisoBadgesActivos)) {
        for h in _AvisoBadgesActivos {
            if (h && DllCall("IsWindow", "Ptr", h)) {
                try DllCall("ShowWindow", "Ptr", h, "Int", 0)
                try DllCall("DestroyWindow", "Ptr", h)
            }
        }
        _AvisoBadgesActivos := []
    }
    if IsObject(floatGui) {
        floatGui.badge := floatGui.badgeHwnd := floatGui.badgeSub := floatGui.badgeMain := floatGui.badgeSubBar := floatGui.badgeBar := 0
        floatGui.badgeTick := 0
    }
}
_TimerOcultarBadge() {
    _AvisoCerrarBadge()
}
_AvisoCerrarHUD() {
    global floatGui
    try SetTimer(_TimerOcultarHUD, 0)
    if (IsObject(floatGui) && IsObject(floatGui.hud)) {
        try {
            if (floatGui.hudHwnd && DllCall("IsWindow", "Ptr", floatGui.hudHwnd))
                DllCall("ShowWindow", "Ptr", floatGui.hudHwnd, "Int", 0)
            floatGui.hud.Hide()
        }
    }
    if IsObject(floatGui)
        floatGui.hudTick := 0
}
_TimerOcultarHUD() {
    _AvisoCerrarHUD()
}

; Despachador universal irrompible: sin ventanas huérfanas ni letras superpuestas.
; formato: "moderno" | "bruto"    zona: 1 (Alta), 2 (Media), 3 (Baja)
MostrarAvisoUI(formato, textoPrincipal, subtexto := "", zona := 2, colorAcento := "00E5FF", duracion := 1500, opacidad := 0) {
    global AVISO_ESC, floatGui, _AvisoBadgesActivos
    f := StrLower(String(formato))
    if (f = "desactivado" || f = "ninguno" || f = "off" || f = "sin gui" || f = "0")
        return
    bruto := (f = "bruto" || f = "hud" || f = "compacto" || f = "2")
    if !(zona = 1 || zona = 2 || zona = 3)
        zona := 2
    _AvisoCerrarAuxiliares()

    if (!bruto) {
        ; ---------- MODO MODERNO: Focus Brackets / Cinema HUD ----------
        _AvisoCerrarHUD()
        _AvisoCerrarBadge()

        ; Rango adaptativo según zona calibrada
        w := Round(240 * AVISO_ESC)
        h := Round(72  * AVISO_ESC)
        px := "", py := ""
        claveRango := (zona = 1) ? "HUD_Alta" : ((zona = 2) ? "HUD_Media" : "HUD_Baja")
        rg := ObtenerRango(claveRango)
        if (IsObject(rg) && IsInteger(rg.w) && IsInteger(rg.h) && rg.w >= 40 && rg.h >= 20) {
            w := Round(rg.w), h := Round(rg.h)
            px := Round(rg.x), py := Round(rg.y)
        }
        if (px = "" || py = "") {
            p := _CalcularPosicionZona(zona, w, h)
            px := p.x, py := p.y
        }

        grande := (h >= 90)
        brazo := grande ? 16 : 10
        grosor := grande ? 3 : 2

        ; Ventana limpia con +E0x20 (click-through limpio sin artefactos DWM)
        g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20 -DPIScale")
        g.BackColor := "12141A"
        g.MarginX := 0
        g.MarginY := 0

        ; Opacidad seleccionable (100% = 255, 70% = 178, 40% = 102)
        if (opacidad = 0)
            opacidad := (zona = 1) ? 70 : ((zona = 2) ? 70 : 100)
        alpha := (opacidad <= 40) ? 102 : ((opacidad <= 70) ? 178 : 255)
        WinSetTransparent(alpha, g)

        ; Esquinas luminosas (viewfinder brackets)
        xr := w - brazo, yb := h - brazo
        xr2 := w - grosor, yb2 := h - grosor
        c := "Background" colorAcento
        g.Add("Text", Format("x0 y0 w{} h{} {}", brazo, grosor, c))
        g.Add("Text", Format("x0 y0 w{} h{} {}", grosor, brazo, c))
        g.Add("Text", Format("x{} y0 w{} h{} {}", xr, brazo, grosor, c))
        g.Add("Text", Format("x{} y0 w{} h{} {}", xr2, grosor, brazo, c))
        g.Add("Text", Format("x0 y{} w{} h{} {}", yb2, brazo, grosor, c))
        g.Add("Text", Format("x0 y{} w{} h{} {}", yb, grosor, brazo, c))
        g.Add("Text", Format("x{} y{} w{} h{} {}", xr, yb2, brazo, grosor, c))
        g.Add("Text", Format("x{} y{} w{} h{} {}", xr2, yb, grosor, brazo, c))

        ; Micro-barra de acento en la base (centrada, 3 px)
        mbw := Max(30, Round(w * 0.30))
        g.Add("Text", Format("x{} y{} w{} h3 {}", (w - mbw) // 2, h - 7, mbw, c))

        ; Tipografía que se expande proporcionalmente al tamaño dibujado
        tSize := Max(10, Min(36, Round(h * 0.16)))
        sSize := grande ? 10 : 8
        tAlto := tSize * 2
        tY := (h - tAlto) // 2 + (subtexto != "" ? 8 : 0)
        ancho := Max(40, w - 24)

        if (subtexto != "") {
            g.SetFont("s" sSize " bold c9AA7C7", "Segoe UI")
            g.Add("Text", Format("x12 y{} w{} h18 Center BackgroundTrans +0x200 +0x4000", Max(4, tY - 18), ancho), subtexto)
        }
        g.SetFont("s" tSize " bold cFFFFFF", "Segoe UI")
        g.Add("Text", Format("x12 y{} w{} h{} Center BackgroundTrans +0x200 +0x4000", tY, ancho, tAlto), textoPrincipal)

        floatGui.badge := g
        floatGui.badgeHwnd := g.Hwnd
        floatGui.badgeTick := A_TickCount
        _AvisoBadgesActivos.Push(g.Hwnd)
        try g.Show(Format("x{} y{} w{} h{} NoActivate", px, py, w, h))
        SetTimer(_TimerOcultarBadge, -duracion)
        return
    }

    ; ---------- MODO BRUTO: HUD compacto (se adapta al rango calibrado) ----------
    _AvisoCerrarBadge()
    _AvisoCerrarHUD()
    w := Round(208 * AVISO_ESC)
    h := Round(40  * AVISO_ESC)
    claveRango := (zona = 1) ? "HUD_Alta" : ((zona = 2) ? "HUD_Media" : "HUD_Baja")
    rg := ObtenerRango(claveRango)
    if (IsObject(rg) && IsInteger(rg.w) && IsInteger(rg.h) && rg.w >= 40 && rg.h >= 20) {
        w := Round(rg.w), h := Round(rg.h)
    }
    p := _CalcularPosicionZona(zona, w, h)
    if (opacidad = 0)
        opacidad := (zona = 1) ? 70 : ((zona = 2) ? 70 : 100)
    alpha := (opacidad <= 40) ? 102 : ((opacidad <= 70) ? 178 : 235)

    if (!IsObject(floatGui.hud) || !floatGui.hudHwnd || !DllCall("IsWindow", "Ptr", floatGui.hudHwnd)) {
        g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
        g.BackColor := "1A1A1A"
        g.MarginX := 0
        g.MarginY := 0
        WinSetTransparent(alpha, g)
        barH := Max(2, Round(3 * AVISO_ESC))
        lblY := Round(4 * AVISO_ESC)
        lblH := Max(16, h - barH - lblY - Round(3 * AVISO_ESC))
        fSize := Max(7, Min(28, Round(h * 0.22)))
        lbl := g.Add("Text", "x0 y" lblY " w" w " h" lblH " cFFFFFF +0x200 +0x4000 Center", textoPrincipal)
        lbl.SetFont("s" fSize " bold", "Segoe UI")
        bar := g.Add("Progress", "x0 y" (h - barH) " w" w " h" barH)
        bar.Opt("c" colorAcento)
        bar.Value := 100
        try g.Show(Format("x{} y{} w{} h{} NoActivate", p.x, p.y, w, h))
        floatGui.hud := g
        floatGui.hudLabel := lbl
        floatGui.hudBar := bar
        floatGui.hudHwnd := g.Hwnd
        floatGui.hudTick := A_TickCount
    } else {
        WinSetTransparent(alpha, floatGui.hud)
        floatGui.hudLabel.Value := textoPrincipal
        floatGui.hudBar.Opt("c" colorAcento)
        floatGui.hudBar.Value := 100
        DllCall("SetWindowPos", "Ptr", floatGui.hudHwnd, "Ptr", -1, "int", p.x, "int", p.y, "int", w, "int", h, "uint", 0x0040 | 0x0010)
        floatGui.hudTick := A_TickCount
        try floatGui.hud.Show("NoActivate")
    }
    SetTimer(_TimerOcultarHUD, -duracion)
}

; ===== DESPACHADOR DE EVENTOS CONFIGURADOS EN CALIBRADOR =====
_AvisoEvento(clave, textoPrincipal := "", subtexto := "", colorAcento := "00E5FF", duracion := 1500) {
    c := HudConfigEvento(clave)
    zNum := (c.zona = "alta") ? 1 : ((c.zona = "media") ? 2 : 3)
    if (textoPrincipal = "") {
        for ev in _PtsEventosDefs() {
            if (ev[1] = clave) {
                textoPrincipal := Trim(RegExReplace(ev[2],"\s*\(.*\)\s*$"))
                break
            }
        }
    }
    MostrarAvisoUI(c.formato, textoPrincipal, subtexto, zNum, colorAcento, duracion, c.opacidad)
}

_MapearTextoAEvento(texto) {
    t := StrUpper(texto)
    if InStr(t, "AERÓGRAFO ALPHA") || InStr(t, "AEROGRAFO ALPHA")
        return "aerografo_alpha"
    if InStr(t, "AERÓGRAFO") || InStr(t, "AEROGRAFO")
        return "aerografo"
    if InStr(t, "SOFT BRUSH") || InStr(t, "PINCEL SUAVE")
        return "pincel_suave"
    if InStr(t, "HARD BRUSH") || InStr(t, "PINCEL DURO")
        return "pincel_duro"
    if InStr(t, "DIFU MIXER") || InStr(t, "DIFUMINADOR")
        return "difu_mixer"
    if InStr(t, "OPC PRESSURE") || InStr(t, "OPACIDAD POR PRESIÓN") || InStr(t, "OPACIDAD")
        return "opc_presion"
    if InStr(t, "ERASER LAZO") || InStr(t, "BORRADOR LAZO")
        return "borrador_lazo"
    if InStr(t, "SOFT ERASER") || InStr(t, "BORRADOR SUAVE")
        return "borrador_suave"
    if InStr(t, "ERASER") || InStr(t, "BORRADOR")
        return "borrador"
    if InStr(t, "SMUDGE") || InStr(t, "DEDO")
        return "smudge"
    if InStr(t, "SMEAR")
        return "smear"
    if InStr(t, "COLOR MIX") || InStr(t, "MEZCLA DE COLOR")
        return "color_mix"
    if InStr(t, "COLOR SECUNDARIO")
        return "color_secundario"
    if InStr(t, "COLOR PRIMARIO")
        return "color_primario"
    if InStr(t, "ALPHA TRANSPARENTE")
        return "color_alpha"
    if InStr(t, "FILL") || InStr(t, "RELLENO")
        return "relleno"
    if InStr(t, "LASSO") || InStr(t, "LAZO")
        return "lazo"
    if InStr(t, "DESELECCIÓN") || InStr(t, "DESELECCION")
        return "deseleccion"
    if InStr(t, "RESELECCIÓN") || InStr(t, "RESELECCION")
        return "reseleccion"
    if InStr(t, "INVERTIR SELECCIÓN") || InStr(t, "INV. ÁREA") || InStr(t, "INV_SELECCION")
        return "inv_seleccion"
    if InStr(t, "ÁREA CON COLOR") || InStr(t, "AREA CON COLOR")
        return "area_color"
    if InStr(t, "SELECCIÓN") || InStr(t, "SELECCION")
        return "seleccion"
    if InStr(t, "SHIFT SOSTENIDO") || InStr(t, "REGLA RECTA") || InStr(t, "REGLA LIBERADA") || InStr(t, "SHIFT+S")
        return "shift_sostenido"
    if InStr(t, "FLIP HORIZONTAL") || InStr(t, "REFLEJAR HORIZONTAL")
        return "flip_horizontal"
    if InStr(t, "ROTAR") || InStr(t, "ROTACIÓN") || InStr(t, "✋ R")
        return "rotar_lienzo"
    if InStr(t, "ZOOM") || InStr(t, "🔍 Z")
        return "zoom_lienzo"
    if InStr(t, "REGLA") || InStr(t, "RULE")
        return "regla_ocultar"
    if InStr(t, "HIDE LAYER") || InStr(t, "SHOW LAYER") || InStr(t, "VISIBILIDAD")
        return "capa_visibilidad"
    if InStr(t, "BUSCAR CAPAS")
        return "capa_buscar"
    if InStr(t, "COLOR CAPA") || InStr(t, "COLOR DE CAPA")
        return "capa_color"
    if InStr(t, "BORRAR COLOR") || InStr(t, "BORRAR CAPA")
        return "capa_borrar_color"
    if InStr(t, "REFERENCE LAYER") || InStr(t, "CAPA DE REFERENCIA")
        return "capa_referencia"
    if InStr(t, "GUARDAR") || InStr(t, "GUARDADO")
        return "guardar"
    if InStr(t, "DESHACER")
        return "deshacer"
    if InStr(t, "REHACER")
        return "rehacer"
    if InStr(t, "PEGAR") || InStr(t, "COPIAR")
        return "copiar"
    if InStr(t, "ENFOQUE") || InStr(t, "FOCUS")
        return "enfoque"
    if InStr(t, "HOVER") || InStr(t, "ACCESO RÁPIDO") || InStr(t, "ACCESO RAPIDO")
        return "hover_paneles"
    if InStr(t, "HISTORY LOCKED") || InStr(t, "DYNAMIC HISTORY") || InStr(t, "HISTORIAL")
        return "history_lock"
    if InStr(t, "BLOQUE") || InStr(t, "FIJAR") || InStr(t, "MOVER BOTONES")
        return "bloque_gui"
    if InStr(t, "AL FRENTE") || InStr(t, "SOLO EN CSP")
        return "gui_frente"
    if InStr(t, "ESTABILIZADOR") || InStr(t, "ESTABILIZACIÓN") || InStr(t, "ESTABILIZACION")
        return "estab_slider"
    if InStr(t, "SINCRONIZ")
        return "estab_sync"
    if InStr(t, "LAYOUT")
        return "layout"
    if InStr(t, "RELOAD") || InStr(t, "REINICI") || InStr(t, "GITHUB")
        return "reload"
    return ""
}

; ---- Compatibilidad hacia atras redirigida al motor de prioridades ----
MostrarBadgeCombo(comboText, toolText, colorAcento := "00E5FF", duracion := 1500, zona := 2) {
    ev := _MapearTextoAEvento(toolText)
    if (!ev)
        ev := _MapearTextoAEvento(comboText)
    if (ev != "")
        return _AvisoEvento(ev, toolText, comboText, colorAcento, duracion)
    return MostrarAvisoUI("moderno", toolText, comboText, zona, colorAcento, duracion)
}

MostrarHUD(texto, colorBarra := "00E5FF", duracion := 1200, zona := 3) {
    ev := _MapearTextoAEvento(texto)
    if (ev != "")
        return _AvisoEvento(ev, texto, "", colorBarra, duracion)
    return MostrarAvisoUI("bruto", texto, "", zona, colorBarra, duracion)
}

QuitarToolTip() => ToolTip()
OcultarToolTip() => ToolTip()
OcultarToolTipAltG() => ToolTip()
OcultarToolTipQ() => ToolTip()
OcultarIndicador() => ToolTip()
QuitarToolTipE() => ToolTip()
QuitarToolTipZ() => ToolTip()
MostrarIndicador(texto) => MostrarHUD(texto, "00E5FF", 2500)
MostrarToolTipE(texto, duracion := 1200) {
    ev := _MapearTextoAEvento(texto)
    if (ev != "")
        return _AvisoEvento(ev, texto, "BORRADOR", "FF4444", duracion)
    return MostrarAvisoUI("bruto", texto, "", 2, "FF4444", duracion)
}

MostrarIconoHerramienta(tipo,duracion := 700) {
    global AVISO_ESC
    if IsObject(floatGui.overlayIcon)
        _DestruirGui(floatGui.overlayIcon)
    thisID := A_TickCount
    floatGui.overlayIconID := thisID
    lado := Round(110 * AVISO_ESC)
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := "181818"
    g.MarginX := 0
    g.MarginY := 0
    iconoChar := (tipo = "zoom") ? "🔍" : (tipo = "rotar") ? "↻" : "⚙"
    fSize := (tipo = "rotar") ? Round(56 * AVISO_ESC) : Round(50 * AVISO_ESC)
    txt := g.Add("Text","x0 y0 w" lado " h" lado " Center +0x0200 cWhite",iconoChar)
    txt.SetFont("s" fSize " bold","Segoe UI Symbol")
    g.Show("w" lado " h" lado " NoActivate Hide")
    _AvisoPosicionar(g.Hwnd)
    try {
        rad := Round(50 * AVISO_ESC)
        rgn := DllCall("Gdi32\CreateRoundRectRgn","int",0,"int",0,"int",lado + 1,"int",lado + 1,"int",rad,"int",rad,"Ptr")
        DllCall("SetWindowRgn","Ptr",g.Hwnd,"Ptr",rgn,"int",1)
    }
    WinSetTransparent(185,"ahk_id " g.Hwnd)
    floatGui.overlayIcon := g
    SetTimer(() => _OcultarIconoSi(thisID),-duracion)
}
_OcultarIconoSi(id) {
    if (floatGui.overlayIconID != id)
        return
    if IsObject(floatGui.overlayIcon)
        _DestruirGui(floatGui.overlayIcon)
    floatGui.overlayIcon := 0
    floatGui.overlayIconID := 0
}
MostrarToolTipZ(texto,duracion := 800) {
    ev := _MapearTextoAEvento(texto)
    if (ev != "")
        return _AvisoEvento(ev, texto, "LIENZO", "00E5FF", duracion)
    if InStr(texto,"Z")
        MostrarIconoHerramienta("zoom",duracion)
    else if InStr(texto,"R")
        MostrarIconoHerramienta("rotar",duracion)
    else
        MostrarHUD(texto,"00E5FF",duracion)
}
ToolTipCS(texto,duracion := 800) {
    ev := _MapearTextoAEvento(texto)
    if (ev != "")
        return _AvisoEvento(ev, texto, "", texto = "🟢 REHACER" ? "44DD88" : "FF4444", duracion)
    return MostrarAvisoUI("bruto", texto, "", 3, texto = "🟢 REHACER" ? "44DD88" : "FF4444", duracion)
}

_AvisoClamp(x, y, w, h) {
    mejor := 1, mejorD := 1e18
    Loop MonitorGetCount() {
        MonitorGetWorkArea(A_Index, &L, &T, &R, &B)
        dx := (x < L) ? L - x : (x > R ? x - R : 0)
        dy := (y < T) ? T - y : (y > B ? y - B : 0)
        d := dx*dx + dy*dy
        if (d < mejorD) {
            mejorD := d, mejor := A_Index
        }
    }
    MonitorGetWorkArea(mejor, &L, &T, &R, &B)
    return [Max(L, Min(x, R - w)), Max(T, Min(y, B - h)), mejorD]
}

_AvisoPosicionar(hwnd) {
    rc := Buffer(16, 0)
    DllCall("GetWindowRect", "Ptr", hwnd, "Ptr", rc)
    w := NumGet(rc, 8, "Int") - NumGet(rc, 0, "Int")
    h := NumGet(rc, 12, "Int") - NumGet(rc, 4, "Int")
    p := _PosicionAviso(w, h)
    DllCall("SetWindowPos","Ptr",hwnd,"Ptr",-1,"int",p.x,"int",p.y,"int",0,"int",0,"uint",0x0040 | 0x0010 | 0x0001)
}

MostrarMiniTexto(texto,colorHex := "00E5FF",duracion := 1200,colorTexto := "FFFFFF") {
    ev := _MapearTextoAEvento(texto)
    acento := (colorHex = "222222" || colorHex = "1A1A2E") ? "00E5FF" : colorHex
    tit := RegExReplace(texto, "^[🔄🔁❌✅💨⚪🟡🔵🟠👁🟢🔍🎨🗑↺↩\s]+", "")
    if (tit = "")
        tit := texto
    if (ev != "")
        return _AvisoEvento(ev, tit, "HERRAMIENTA", acento, duracion)
    MostrarAvisoUI("moderno", tit, "CLIP STUDIO PAINT", 2, acento, duracion)
}
_OcultarMiniTipSi(id) {
}
MostrarMiniTextoOscuro(texto,colorHex := "EEEEEE",duracion := 1200) => MostrarMiniTexto(texto, "FFD166", duracion)
MostrarMiniGUI(texto,colorHex := "00E5FF",duracion := 1200) => MostrarMiniTexto(texto, colorHex, duracion)
_OcultarMiniGUISi(hwndMG) {
    if (IsObject(floatGui.miniGUI) && floatGui.miniGUI.Hwnd = hwndMG) {
        floatGui.miniGUI.Destroy()
        floatGui.miniGUI := 0
    }
}
MostrarTooltipToggle(titulo,simbolo,color) {
    ev := _MapearTextoAEvento(titulo)
    colHex := (color = "verde") ? "44DD88" : "FF4444"
    if (ev != "")
        return _AvisoEvento(ev, titulo, simbolo, colHex, 1500)
    MostrarAvisoUI("moderno", titulo, simbolo, 3, colHex, 1500)
}
_OcultarToggleSi(hwndT) {
}
QuitarTooltipToggle() {
    if IsObject(floatGui.tooltipToggle)
        try floatGui.tooltipToggle.Destroy()
    floatGui.tooltipToggle := 0
}
_AplicarEstabVisibilidadBase() {
    if !IsObject(estabGui.g) || estabGui.foco
        return
    if (estabGui.visible && enfoque.activo) {
        try estabGui.g.Show("NoActivate")
        _EstabDibujar()
    } else {
        try estabGui.g.Hide()
    }
}
AccionEnfoque() {
    enfoque.activo := !enfoque.activo
    MouseGetPos(&origX,&origY)
    Click(PUNTOS[1][1] " " PUNTOS[1][2])
    Click(PUNTOS[2][1] " " PUNTOS[2][2])
    DllCall("SetCursorPos","int",origX,"int",origY)
    _AplicarLayoutPaneles(enfoque.activo ? "Enfoque" : "Normal")
    _NotificarPureRef(enfoque.activo ? 1 : 0)
    if (enfoque.activo) {
        _EstabFocoOcultar()
        _AplicarEstabVisibilidadBase()
        MostrarGUIEnfoque()
        MostrarHUD("🎯 MODO ENFOQUE","00E5FF",900)
        _SonarUI("enfoque_on")
    } else {
        OcultarGUIEnfoque()
        _EstabFocoOcultar()
        _AplicarEstabVisibilidadBase()
        _SonarUI("enfoque_off")
    }
}
_NotificarPureRef(modo) {
    prevDHW := A_DetectHiddenWindows
    DetectHiddenWindows(true)
    for hwnd in WinGetList("ahk_class AutoHotkey") {
        try {
            title := WinGetTitle("ahk_id " hwnd)
            if InStr(title,"PureRef_layout.ahk")
                PostMessage(0x5501,modo,0,,"ahk_id " hwnd)
        }
    }
    DetectHiddenWindows(prevDHW)
}
_IdsPaneles() {
    try {
        if (!colorV.dsID || !WinExist("ahk_id " colorV.dsID))
            colorV.dsID := BuscarVentanaCSP(0,"eslizador","colores")
        if (!colorCC.id || !WinExist("ahk_id " colorCC.id))
            colorCC.id := BuscarVentanaCSP(0,"rculo de colores","olores")
        if (!ar.id || !WinExist("ahk_id " ar.id))
            ar.id := BuscarVentanaCSP(0,"Acceso r","pido")
        if (!hist.id || !WinExist("ahk_id " hist.id))
            hist.id := BuscarVentanaCSP(0,"istorial","color")
    }
    ids := Map()
    ids["ds"] := colorV.dsID
    ids["cc"] := colorCC.id
    ids["ar"] := ar.id
    ids["hc"] := hist.id
    return ids
}
_LayoutPanelGuardado(nombre,clave,mon) {
    ini := _PosGuiIniPath()
    sec := "Layout" nombre
    x := IniRead(ini,sec,clave "x","")
    y := IniRead(ini,sec,clave "y","")
    w := IniRead(ini,sec,clave "w","")
    h := IniRead(ini,sec,clave "h","")
    if (x = "" || y = "" || w = "" || h = "")
        return 0
    return {x:mon.x + Integer(x),y:mon.y + Integer(y),w:Integer(w),h:Integer(h)}
}
_AplicarLayoutPaneles(nombre) {
    mon := ObtenerMonitorCSP()
    def := (nombre = "Enfoque") ? LAYOUT_ENFOQUE : LAYOUT_NORMAL
    SWP_FLAGS := 0x0004 | 0x0010
    for clave,id in _IdsPaneles() {
        if (!id || !WinExist("ahk_id " id))
            continue
        r := _LayoutPanelGuardado(nombre,clave,mon)
        if (!r)
            r := def.%clave%
        x := Max(mon.x,Min(r.x,mon.x + mon.w - r.w))
        y := Max(mon.y,Min(r.y,mon.y + mon.h - r.h))
        try {
            DllCall("SetWindowPos","Ptr",id,"Ptr",0,"int",x,"int",y,"int",r.w,"int",r.h,"uint",SWP_FLAGS)
            if (clave = "ds") {
                colorV.dsX := x
                colorV.dsY := y
                colorV.dsW := r.w
                colorV.dsH := r.h
            } else if (clave = "cc") {
                colorCC.ccX := x
                colorCC.ccY := y
                colorCC.ccW := r.w
                colorCC.ccH := r.h
            }
        }
    }
}
_CapturarLayout(nombre) {
    _SonarUI("layout")
    ToolTip("Guardando layout " nombre "...")
    SetTimer(() => ToolTip(),-1500)
    try {
        if (!colorV.dsID)
            colorV.dsID := BuscarVentanaCSP(0,"eslizador","colores")
        if (!colorCC.id)
            colorCC.id := BuscarVentanaCSP(0,"rculo de colores","olores")
        if (!ar.id)
            ar.id := BuscarVentanaCSP(0,"Acceso r","pido")
        if (!hist.id)
            hist.id := BuscarVentanaCSP(0,"istorial","color")
    }
    mon := ObtenerMonitorCSP()
    ini := _PosGuiIniPath()
    sec := "Layout" nombre
    guardados := 0
    for clave,id in _IdsPaneles() {
        if (!id || !WinExist("ahk_id " id))
            continue
        try {
            WinGetPos(&x,&y,&w,&h,"ahk_id " id)
            IniWrite(x - mon.x,ini,sec,clave "x")
            IniWrite(y - mon.y,ini,sec,clave "y")
            IniWrite(w,ini,sec,clave "w")
            IniWrite(h,ini,sec,clave "h")
            guardados++
        }
    }
    MostrarHUD("LAYOUT " StrUpper(nombre) " GUARDADO (" guardados "/4)",guardados = 4 ? "44DD88" : "FF6B00",1600)
}
$^F11:: _CapturarLayout("Normal")
$^F12:: _CapturarLayout("Enfoque")
$^F10:: AbrirPanelPuntos()
$^!+c:: AbrirPanelPuntos()
$^!+t:: _AbrirSelectorTema()
MostrarGUIEnfoque() {
    mon := ObtenerMonitorCSP()
    opts := "-Caption +AlwaysOnTop +ToolWindow +E0x20"
    flags := 0x0010 | 0x0040
    x := mon.x
    y := mon.y
    w := mon.w
    h := mon.h
    if (!HasProp(floatGui,"enfoqueGuis") || !IsObject(floatGui.enfoqueGuis) || floatGui.enfoqueGuis.Length != 8) {
        floatGui.enfoqueGuis := []
        Loop 4 {
            g := Gui(opts)
            g.BackColor := "0077B6"
            g.Show("w0 h0 NoActivate")
            WinSetTransparent(46,g)
            floatGui.enfoqueGuis.Push(g)
        }
        Loop 4 {
            g := Gui(opts)
            g.BackColor := "00B4D8"
            g.Show("w0 h0 NoActivate")
            WinSetTransparent(76,g)
            floatGui.enfoqueGuis.Push(g)
        }
    }
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[1].Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",w,"Int",6,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[2].Hwnd,"Ptr",-1,"Int",x,"Int",y + h - 6,"Int",w,"Int",6,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[3].Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",6,"Int",h,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[4].Hwnd,"Ptr",-1,"Int",x + w - 6,"Int",y,"Int",6,"Int",h,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[5].Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",w,"Int",3,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[6].Hwnd,"Ptr",-1,"Int",x,"Int",y + h - 3,"Int",w,"Int",3,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[7].Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",3,"Int",h,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[8].Hwnd,"Ptr",-1,"Int",x + w - 3,"Int",y,"Int",3,"Int",h,"UInt",flags)
}
OcultarGUIEnfoque() {
    if (HasProp(floatGui,"enfoqueGuis") && IsObject(floatGui.enfoqueGuis)) {
        for g in floatGui.enfoqueGuis {
            try DllCall("ShowWindow","Ptr",g.Hwnd,"Int",0)
        }
    }
}
ResetEnfoque() {
    if (enfoque.activo) {
        enfoque.activo := false
        OcultarGUIEnfoque()
        _EstabFocoOcultar()
        _AplicarEstabVisibilidadBase()
    }
}
ResetAlphaStates() {
    global colorEstado,panelBlk,floatGui
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if panelBlk.frente {
            _MostrarPaneles()
            _TraerPanelesAlFrente()
            return
        }
        for g in [dial,dsGui,ccGui,arGui,hcGui,lockGui,frenteGui,estabBtnGui,reloadGui,estabGui] {
            if IsObject(g.g)
                g.g.Hide()
        }
        _AvisoCerrarBadge()
        _AvisoCerrarHUD()
        _AvisoCerrarAuxiliares()
        return
    }
    _MostrarPaneles()
    ; Watchdog anti-atasco para HUD y Badge
    if (IsObject(floatGui)) {
        if (floatGui.badgeHwnd && DllCall("IsWindow", "Ptr", floatGui.badgeHwnd)) {
            if (floatGui.badgeTick > 0 && (A_TickCount - floatGui.badgeTick > 3000))
                _AvisoCerrarBadge()
        }
        if (floatGui.hudHwnd && DllCall("IsWindow", "Ptr", floatGui.hudHwnd)) {
            if (floatGui.hudTick > 0 && (A_TickCount - floatGui.hudTick > 3500))
                _AvisoCerrarHUD()
        }
        if (floatGui.miniTipID != 0 && floatGui.miniTipTick != 0) {
            if (A_TickCount - floatGui.miniTipTick > 4000) {
                try {
                    if IsObject(floatGui.miniTip)
                        floatGui.miniTip.Destroy()
                }
                floatGui.miniTip := 0
                floatGui.miniTipID := 0
                floatGui.miniTipTick := 0
            }
        }
    }
}
_EsPanelEmbebido(g) {
    global hubGui, lockGui, frenteGui, puntosGui, estabBtnGui, reloadGui, dsGui, ccGui, arGui, hcGui
    if !IsObject(g) || !IsObject(g.g) || !IsSet(hubGui) || !IsObject(hubGui) || !hubGui.HasOwnProp("embebidos")
        return false
    h := g.g.Hwnd
    if (IsObject(lockGui.g) && h = lockGui.g.Hwnd)
        return (hubGui.embebidos.Has("lock") && hubGui.embebidos["lock"])
    if (IsObject(frenteGui.g) && h = frenteGui.g.Hwnd)
        return (hubGui.embebidos.Has("frente") && hubGui.embebidos["frente"])
    if (IsObject(puntosGui.g) && h = puntosGui.g.Hwnd)
        return (hubGui.embebidos.Has("puntos") && hubGui.embebidos["puntos"])
    if (IsObject(estabBtnGui.g) && h = estabBtnGui.g.Hwnd)
        return (hubGui.embebidos.Has("estab") && hubGui.embebidos["estab"])
    if (IsObject(reloadGui.g) && h = reloadGui.g.Hwnd)
        return (hubGui.embebidos.Has("reload") && hubGui.embebidos["reload"])
    if (IsObject(dsGui.g) && h = dsGui.g.Hwnd)
        return (hubGui.embebidos.Has("ds") && hubGui.embebidos["ds"])
    if (IsObject(ccGui.g) && h = ccGui.g.Hwnd)
        return (hubGui.embebidos.Has("cc") && hubGui.embebidos["cc"])
    if (IsObject(arGui.g) && h = arGui.g.Hwnd)
        return (hubGui.embebidos.Has("ar") && hubGui.embebidos["ar"])
    if (IsObject(hcGui.g) && h = hcGui.g.Hwnd)
        return (hubGui.embebidos.Has("hc") && hubGui.embebidos["hc"])
    return false
}

_TraerPanelesAlFrente() {
    for g in [dsGui,ccGui,arGui,hcGui,lockGui,frenteGui,estabBtnGui,reloadGui,puntosGui,estabGui] {
        if !IsObject(g.g) || _EsPanelEmbebido(g)
            continue
        try {
            if DllCall("IsWindowVisible","Ptr",g.g.Hwnd)
                DllCall("SetWindowPos","Ptr",g.g.Hwnd,"Ptr",-1,"int",0,"int",0,"int",0,"int",0,"uint",0x0001 | 0x0002 | 0x0010)
        }
    }
}
_MostrarPaneles() {
    estabHwnd := IsObject(estabGui.g) ? estabGui.g.Hwnd : 0
    for g in [dial,dsGui,ccGui,arGui,hcGui,lockGui,frenteGui,estabBtnGui,reloadGui,estabGui] {
        if !IsObject(g.g) || _EsPanelEmbebido(g)
            continue
        if (g.g.Hwnd = estabHwnd && (!estabGui.visible || !enfoque.activo))
            continue
        try {
            if !DllCall("IsWindowVisible","Ptr",g.g.Hwnd) {
                g.g.Show("NoActivate")
                if (g.g.Hwnd = estabHwnd)
                    _EstabDibujar()
            }
        }
    }
    ; Sanado de posicion: va aparte del show porque puntosGui no participa del ciclo
    ; de alpha, y estabGui se excluye (ya se autorrecorta con _EstabMonitorEn).
    for g in [dsGui,ccGui,arGui,hcGui,lockGui,frenteGui,estabBtnGui,reloadGui,puntosGui,estabGui] {
        if !IsObject(g.g) || _EsPanelEmbebido(g)
            continue
        if (g.g.Hwnd = estabHwnd)
            continue
        _PanelFijaEnPantalla(g.g)
    }
}
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")
!f:: {
    global _bSmearAbajo
    if !stylus.altActive
        return
    if AltF_state.held
        return
    AltF_state.held := true
    now := A_TickCount
    if (now - AltF_state.lastPress < 300) {
        AltF_state.lastPress := 0
        seguiaSostenido := stylus.altActive
        SendEvent("{Alt up}{NumpadEnd}")
        _AltRestaurar(seguiaSostenido)
        MostrarHUD("SMEAR SOFT  (2)","FF6B00",950)
    } else {
        AltF_state.lastPress := now
        stylus.bSinteticoTick := A_TickCount
        seguiaSostenido := stylus.altActive
        _bSmearAbajo := true
        SendEvent("{Alt up}{b up}{b down}")
        SetTimer(_AltF_SoltarB, -3000)   ; failsafe: la b nunca queda más de 3 s
        _AltRestaurar(seguiaSostenido)
        MostrarHUD("SMEAR  (1)","00E5FF",950)
    }
}
!f up:: {
    AltF_state.held := false
    SetTimer(_AltF_SoltarB, 0)
    _AltF_SoltarB()
}
~b & k:: {
    global colorEstado
    if (colorEstado = 1)
        SendInput("^2")
    Send("k")
    Send("k")
    colorEstado := 0
    MostrarMiniTexto("🔄 RESET → COLOR PRIMARIO","1A1A2E",1200)
}
#HotIf
_PosGuiIniPath() => A_ScriptDir "\posiciones_gui.ini"
GuardarPosicionGUI(nombre,hwnd) {
    global PERFIL
    sec := nombre "_p" PERFIL
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",hwnd,"Ptr",rc)
    IniWrite(NumGet(rc,0,"int"),_PosGuiIniPath(),sec,"x")
    IniWrite(NumGet(rc,4,"int"),_PosGuiIniPath(),sec,"y")
}
LeerPosicionGUI(nombre) {
    global PERFIL
    for sec in [nombre "_p" PERFIL,nombre] {
        x := IniRead(_PosGuiIniPath(),sec,"x","")
        y := IniRead(_PosGuiIniPath(),sec,"y","")
        if (x != "" && y != "")
            return {x:Integer(x),y:Integer(y)}
    }
    return 0
}
_PosicionValidaEnPantalla(x,y) {
    Loop MonitorGetCount() {
        MonitorGet(A_Index,&l,&t,&r,&b)
        if (x >= l && x <= r && y >= t && y <= b)
            return true
    }
    return false
}
_MonitorDePunto(x,y) {
    Loop MonitorGetCount() {
        MonitorGet(A_Index,&l,&t,&r,&b)
        if (x >= l && x < r && y >= t && y < b)
            return A_Index
    }
    return 0
}
_RectaDentroDeMonitor(x,y,w,h) {
    Loop MonitorGetCount() {
        MonitorGet(A_Index,&l,&t,&r,&b)
        if (x >= l && x + w <= r && y >= t && y + h <= b)
            return true
    }
    return false
}
_RectaFijaEnPantalla(x,y,w,h) {
    ; Posicion donde el rectangulo ENTERO cabe en un monitor; si el punto no esta en
    ; ninguno, se elige el monitor mas cercano y se recorta hacia dentro.
    n := MonitorGetCount()
    if (n = 0)
        return {x:Integer(x),y:Integer(y)}
    idx := _MonitorDePunto(x,y)
    if (idx = 0) {
        mejor := 1, dist := -1
        Loop n {
            MonitorGet(A_Index,&l,&t,&r,&b)
            dx := Max(l - (x + w),x - r,0)
            dy := Max(t - (y + h),y - b,0)
            d := dx * dx + dy * dy
            if (dist < 0 || d < dist)
                dist := d, mejor := A_Index
        }
        idx := mejor
    }
    MonitorGet(idx,&l,&t,&r,&b)
    return {x: Max(l,Min(x,r - Min(w,r - l))),y: Max(t,Min(y,b - Min(h,b - t)))}
}
_EsquinaPanelBloque(i) {
    ; Casilla visible y predecible para un panel cuyo puesto calculado no cabe.
    ; i = 0,1,2... evita montar dos paneles en la misma casilla.
    mon := ObtenerMonitorCSP()
    return {x: mon.x + 4,y: mon.y + 4 + i * (_E(25) + PANEL_GAP)}
}
_PanelFijaEnPantalla(gui) {
    try {
        WinGetPos(&x,&y,&w,&h,"ahk_id " gui.Hwnd)
    } catch
        return
    if (w < 2 || h < 2)
        return
    if (_RectaDentroDeMonitor(x,y,w,h))
        return
    s := _RectaFijaEnPantalla(x,y,w,h)
    if (s.x != x || s.y != y)
        DllCall("SetWindowPos","Ptr",gui.Hwnd,"Ptr",0,"int",s.x,"int",s.y,"int",0,"int",0,"uint",0x0001 | 0x0004 | 0x0010)
}
_AnclaBloquePaneles() {
    static ancla := 0
    if IsObject(ancla)
        return ancla
    mon := ObtenerMonitorCSP()
    anchoBloque := _E(104) + PANEL_GAP + _E(104) + PANEL_GAP + _E(104)
    defX := mon.x + (mon.w - anchoBloque) // 2
    defY := mon.y + Round(mon.h * 0.02) + 42 + 4
    guardada := LeerPosicionGUI("PanelBlock")
    if IsObject(guardada) && _PosicionValidaEnPantalla(guardada.x,guardada.y) {
        ancla := guardada
        return ancla
    }
    vieja := LeerPosicionGUI("Slider")
    if IsObject(vieja) && _PosicionValidaEnPantalla(vieja.x,vieja.y) {
        ancla := vieja
        return ancla
    }
    ancla := {x:defX,y:defY}
    return ancla
}
GuardarIniDiferido(archivo, seccion, clave, valor) {
    global _iniPend
    _iniPend[archivo "|" seccion "|" clave] := valor
    SetTimer(_FlushIni, -400)
}
_FlushIni() {
    global _iniPend
    for k, v in _iniPend {
        p := StrSplit(k, "|")
        IniWrite(v, p[1], p[2], p[3])
    }
    _iniPend := Map()
}

_ArrastrarPanelBloque(hwndClick,lParam,guiObj) {
    global panelBlk
    static arrastrando := false
    if (arrastrando)
        return
    if !IsObject(guiObj.g)
        return
    if !(hwndClick = guiObj.g.Hwnd || guiObj.g.Hwnd = DllCall("GetParent","Ptr",hwndClick,"Ptr"))
        return
    arrastrando := true
    try {
        if panelBlk.locked
            _SweepToggle(guiObj)
        else
            _ClickOArrastre(hwndClick,lParam,guiObj)
    } finally {
        arrastrando := false
    }
}

_GetPanelEstado(guiObj) {
    h := guiObj.g.Hwnd
    if (h = dsGui.g.Hwnd)
        return colorV.hover
    if (h = ccGui.g.Hwnd)
        return colorCC.hover
    if (h = arGui.g.Hwnd)
        return ar.hover
    if (h = hcGui.g.Hwnd)
        return (hist.modo = 1)
    if (h = frenteGui.g.Hwnd)
        return panelBlk.frente
    if (h = estabBtnGui.g.Hwnd)
        return estabGui.visible
    return ""
}

_SetPanelEstado(guiObj, target) {
    h := guiObj.g.Hwnd
    if (h = dsGui.g.Hwnd) {
        if (colorV.hover != target) {
            _SetColorV(target)
            ActualizarDsGUI()
        }
    } else if (h = ccGui.g.Hwnd) {
        if (colorCC.hover != target) {
            _SetColorCC(target)
            ActualizarCcGUI()
        }
    } else if (h = arGui.g.Hwnd) {
        if (ar.hover != target) {
            _SetAR(target)
            ActualizarArGUI()
        }
    } else if (h = hcGui.g.Hwnd) {
        if ((hist.modo = 1) != target) {
            _ToggleHistorialColor()
            ActualizarHCGUI()
        }
    } else if (h = frenteGui.g.Hwnd) {
        if (panelBlk.frente != target) {
            _ToggleFrente()
        }
    } else if (h = estabBtnGui.g.Hwnd) {
        if (estabGui.visible != target) {
            _ToggleEstabVisible()
        }
    }
}

_PanelesSweep() {
    lista := []
    for p in [dsGui, ccGui, arGui, hcGui, frenteGui, estabBtnGui] {
        if (IsObject(p) && IsObject(p.g) && p.g.Hwnd)
            lista.Push(p)
    }
    return lista
}

; Rect cerrado en pixeles [l, r-1] x [t, b-1] (GetWindowRect es exclusivo en r/b).
; Liang-Barsky: true si el segmento (x0,y0)-(x1,y1) toca el rectangulo.
_SegCruzaRect(x0,y0,x1,y1,l,t,r,b) {
    r -= 1
    b -= 1
    dx := x1 - x0
    dy := y1 - y0
    t0 := 0.0
    t1 := 1.0
    for pq in [[-dx, x0 - l], [dx, r - x0], [-dy, y0 - t], [dy, b - y0]] {
        p := pq[1]
        q := pq[2]
        if (p = 0) {
            if (q < 0)
                return false
            continue
        }
        u := q / p
        if (p < 0) {
            if (u > t1)
                return false
            if (u > t0)
                t0 := u
        } else {
            if (u < t0)
                return false
            if (u < t1)
                t1 := u
        }
    }
    return true
}

; WM_SETREDRAW (0x000B). Al descongelar: RedrawWindow sincrono
; (INVALIDATE|ERASE|ALLCHILDREN|UPDATENOW = 0x0185) = un solo repintado por boton.
_CongelarPanel(h, congelar) {
    try {
        DllCall("SendMessage","Ptr",h,"UInt",0x000B,"Ptr",congelar ? 0 : 1,"Ptr",0)
        if !congelar
            DllCall("RedrawWindow","Ptr",h,"Ptr",0,"Ptr",0,"UInt",0x0185)
    }
}

; Aplica el estado a los botones barridos. frenteGui va en un segundo lote porque
; _ToggleFrente() llama _MostrarPaneles()/_TraerPanelesAlFrente() (usan IsWindowVisible).
_SweepAplicar(tocados, target) {
    global g_sweepAtomico
    grupo := []
    grupoFrente := []
    for p in tocados {
        if (p.g.Hwnd = frenteGui.g.Hwnd)
            grupoFrente.Push(p)
        else
            grupo.Push(p)
    }
    for lote in [grupo, grupoFrente] {
        if g_sweepAtomico {
            for p in lote
                _CongelarPanel(p.g.Hwnd, true)
        }
        try {
            for p in lote
                _SetPanelEstado(p, target)
        } finally {
            if g_sweepAtomico {
                for p in lote
                    _CongelarPanel(p.g.Hwnd, false)
            }
        }
    }
}

_SweepToggle(g0) {
    global g_sweepActivo
    if (!IsObject(g0) || !IsObject(g0.g))
        return
    if (g0.g.Hwnd = lockGui.g.Hwnd) {
        while GetKeyState("LButton","P")
            Sleep(5)
        _ToggleBloqueo()
        return
    }
    est := _GetPanelEstado(g0)
    if (est == "")
        return
    target := !est
    visitados := Map()
    visitados[g0.g.Hwnd] := true
    tocados := [g0]
    Thread("NoTimers", true)   ; ningun timer interrumpe el muestreo ni repinta paneles durante el gesto
    DllCall("winmm\timeBeginPeriod","UInt",1)
    try {
        paneles := _PanelesSweep()
        cur := Buffer(8,0), rc := Buffer(16,0)
        ; Rects cacheados una vez: con el bloqueo puesto los paneles no se mueven durante el barrido.
        rects := []
        for p in paneles {
            h := p.g.Hwnd
            if visitados.Has(h) || !DllCall("IsWindowVisible","Ptr",h)
                continue
            DllCall("GetWindowRect","Ptr",h,"Ptr",rc)
            rects.Push({p:p, h:h, l:NumGet(rc,0,"int"), t:NumGet(rc,4,"int"), r:NumGet(rc,8,"int"), b:NumGet(rc,12,"int")})
        }
        DllCall("GetCursorPos","Ptr",cur)
        px := NumGet(cur,0,"int"), py := NumGet(cur,4,"int")
        Loop {
            soltado := !GetKeyState("LButton","P")   ; se lee ANTES de muestrear: la ultima muestra cae en/tras el soltado
            DllCall("GetCursorPos","Ptr",cur)
            mx := NumGet(cur,0,"int"), my := NumGet(cur,4,"int")
            if (mx != px || my != py) {
                for rr in rects {
                    if visitados.Has(rr.h)
                        continue
                    if _SegCruzaRect(px,py,mx,my,rr.l,rr.t,rr.r,rr.b) {
                        visitados[rr.h] := true
                        tocados.Push(rr.p)
                    }
                }
                px := mx, py := my
            }
            if soltado
                break
            Sleep(1)
        }
        g_sweepActivo := true
        _SweepAplicar(tocados, target)
    } finally {
        DllCall("winmm\timeEndPeriod","UInt",1)
        g_sweepActivo := false
    }
}

_ClickOArrastre(hwndClick,lParam,guiObj) {
    global panelBlk
    pt := Buffer(8,0)
    NumPut("int",lParam & 0xFFFF,pt,0)
    NumPut("int",(lParam >> 16) & 0xFFFF,pt,4)
    DllCall("ClientToScreen","Ptr",hwndClick,"Ptr",pt)
    clickX := NumGet(pt,0,"int"), clickY := NumGet(pt,4,"int")
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",guiObj.g.Hwnd,"Ptr",rc)
    offX := clickX - NumGet(rc,0,"int")
    offY := clickY - NumGet(rc,4,"int")
    cur := Buffer(8,0)
    movido := false
    while GetKeyState("LButton","P") {
        DllCall("GetCursorPos","Ptr",cur)
        mx := NumGet(cur,0,"int"), my := NumGet(cur,4,"int")
        if (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4) {
            movido := true
            DllCall("SetWindowPos","Ptr",guiObj.g.Hwnd,"Ptr",0,"int",mx-offX,"int",my-offY
                ,"int",0,"int",0,"uint",0x0001|0x0004|0x0010)
        }
        Sleep(8)
    }
    if !movido {
        if (guiObj.g.Hwnd = lockGui.g.Hwnd)
            _ToggleBloqueo()
        else {
            est := _GetPanelEstado(guiObj)
            if (est != "")
                _SetPanelEstado(guiObj, !est)
        }
    } else {
        if (guiObj.g.Hwnd = dsGui.g.Hwnd) {
            GuardarPosicionGUI("Slider",dsGui.g.Hwnd)
            GuardarPosicionGUI("PanelBlock",dsGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = ccGui.g.Hwnd) {
            GuardarPosicionGUI("Circle",ccGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = arGui.g.Hwnd) {
            GuardarPosicionGUI("Quick",arGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = hcGui.g.Hwnd) {
            GuardarPosicionGUI("HC",hcGui.g.Hwnd)
            _GuardarOffsetHC()
        } else if (guiObj.g.Hwnd = lockGui.g.Hwnd) {
            GuardarPosicionGUI("Lock",lockGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = frenteGui.g.Hwnd) {
            GuardarPosicionGUI("Frente",frenteGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = estabBtnGui.g.Hwnd) {
            GuardarPosicionGUI("EstabBtn",estabBtnGui.g.Hwnd)
        }
    }
}
_GuardarOffsetHC() {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "PanelBlock_p" PERFIL
    rd := Buffer(16,0)
    rh := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",dsGui.g.Hwnd,"Ptr",rd)
    DllCall("GetWindowRect","Ptr",hcGui.g.Hwnd,"Ptr",rh)
    IniWrite(NumGet(rh,0,"int") - NumGet(rd,0,"int"),ini,sec,"hcdx")
    IniWrite(NumGet(rh,4,"int") - NumGet(rd,4,"int"),ini,sec,"hcdy")
}
_LeerEstadoBloque(clave,defecto) {
    global PERFIL
    ini := _PosGuiIniPath()
    v := IniRead(ini,"PanelBlock_p" PERFIL,clave,"")
    if (v = "")
        v := IniRead(ini,"PanelBlock",clave,defecto)
    return v
}
_EscribirEstadoBloque(clave,valor) {
    global PERFIL
    GuardarIniDiferido(_PosGuiIniPath(),"PanelBlock_p" PERFIL,clave,valor)
}
_ToggleBloqueo() {
    panelBlk.locked := !panelBlk.locked
    _EscribirEstadoBloque("locked",panelBlk.locked ? 1 : 0)
    ActualizarLockGUI()
    ActualizarHubGUI()
    MostrarHUD(panelBlk.locked ? "🔒 BLOQUE FIJADO" : "🔓 BLOQUE LIBRE",panelBlk.locked ? "44DD88" : "FF6B00",1200)
}
_HcOffsetBloque() {
    global ESC
    ini := _PosGuiIniPath()
    sec := "PanelBlock_p" PERFIL
    dx := IniRead(ini,sec,"hcdx","")
    dy := IniRead(ini,sec,"hcdy","")
    if (dx != "" && dy != "")
        return {dx:Integer(dx),dy:Integer(dy)}
    dx := IniRead(ini,"PanelBlock","hcdx","")
    dy := IniRead(ini,"PanelBlock","hcdy","")
    if (dx != "" && dy != "") {
        dx := Round(Integer(dx) * ESC)
        dy := Round(Integer(dy) * ESC)
        IniWrite(dx,ini,sec,"hcdx")
        IniWrite(dy,ini,sec,"hcdy")
        return {dx:dx,dy:dy}
    }
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",dsGui.g.Hwnd,"Ptr",rc)
    ah := NumGet(rc,12,"int") - NumGet(rc,4,"int")
    return {dx:0,dy:ah + PANEL_GAP}
}
IniciarDialGUI() => 0
ActualizarDialGUI() {
    global opacidad
    if (!IsObject(dial.g) || !dial.icono)
        return
    if (dial.modo = 1) {
        dial.icono.Value := "🖌"
        dial.label.Value := "Tamaño"
        dial.barra.Opt("c00e5ff")
        dial.barra.Value := 100
    } else {
        dial.icono.Value := "◑"
        dial.label.Value := "Opacidad " opacidad.nivel "%"
        dial.barra.Opt("cff6b00")
        dial.barra.Value := opacidad.nivel
    }
}
IniciarDsGUI() {
    dsGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    dsGui.g.BackColor := _Tema("color","surface.off","424242")
    dsGui.g.MarginX := 0
    dsGui.g.MarginY := 0
    WinSetTransparent(_AlphaTema("pill",235),dsGui.g)
    dsGui.icono := dsGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20) " BackgroundTrans","")
    dsGui.label := dsGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
    dsGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
    dsGui.barra := dsGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
    OnMessage(0x0201,_DsGUI_WM_LBUTTONDOWN)
    dsGui.g.OnEvent("ContextMenu", (*) => _MostrarMenuContextualHub())
    posDs := LeerPosicionGUI("Slider")
    if !(IsObject(posDs) && _PosicionValidaEnPantalla(posDs.x,posDs.y))
        posDs := _AnclaBloquePaneles()
    dsGui.g.Show("x" posDs.x " y" posDs.y " w" _E(104) " h" _E(25) " NoActivate")
    _DwmRedondear(dsGui.g.Hwnd)
    ActualizarDsGUI()
}
ActualizarDsGUI() {
    if (colorV.hover) {
        _SetIcono(dsGui.icono,"slider_on",true)
        dsGui.label.Value := "SLIDER"
        dsGui.barra.Opt("c" _Tema("color","accent.estabSoft","B4C0DE"))
        dsGui.g.BackColor := _Tema("color","surface.on","636D83")
        dsGui.label.SetFont("s" _FS(9) " bold c" _Tema("color","text.primary","FFFFFF"),"Segoe UI")
    } else {
        _SetIcono(dsGui.icono,"slider_off",false)
        dsGui.label.Value := "SLIDER"
        dsGui.barra.Opt("c" _Tema("color","track.pillOff","6A6A6A"))
        dsGui.g.BackColor := _Tema("color","surface.off","424242")
        dsGui.label.SetFont("s" _FS(9) " bold c" _Tema("color","text.idle","B2B2B2"),"Segoe UI")
    }
    dsGui.barra.Value := 100
}
_DsGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,dsGui)
IniciarCcGUI() {
    ccGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    ccGui.g.BackColor := _Tema("color","surface.off","424242")
    ccGui.g.MarginX := 0
    ccGui.g.MarginY := 0
    WinSetTransparent(_AlphaTema("pill",235),ccGui.g)
    ccGui.icono := ccGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20) " BackgroundTrans","")
    ccGui.label := ccGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
    ccGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
    ccGui.barra := ccGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
    OnMessage(0x0201,_CcGUI_WM_LBUTTONDOWN)
    ccGui.g.OnEvent("ContextMenu", (*) => _MostrarMenuContextualHub())
    posCc := LeerPosicionGUI("Circle")
    if (IsObject(posCc) && _PosicionValidaEnPantalla(posCc.x,posCc.y)) {
        ccX := posCc.x
        ccY := posCc.y
    } else {
        try {
            WinGetPos(&dsX,&dsY,&dsW,&dsH,"ahk_id " dsGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            dsX := ancla.x
            dsY := ancla.y
            dsW := _E(104)
        }
        ccX := dsX + dsW + PANEL_GAP
        ccY := dsY
    }
    ccGui.g.Show("x" ccX " y" ccY " w" _E(104) " h" _E(25) " NoActivate")
    _DwmRedondear(ccGui.g.Hwnd)
    ActualizarCcGUI()
}
ActualizarCcGUI() {
    if (colorCC.hover) {
        _SetIcono(ccGui.icono,"circle_on",true)
        ccGui.label.Value := "CIRCLE"
        ccGui.barra.Opt("c" _Tema("color","accent.estabSoft","B4C0DE"))
        ccGui.g.BackColor := _Tema("color","surface.on","636D83")
        ccGui.label.SetFont("s" _FS(9) " bold c" _Tema("color","text.primary","FFFFFF"),"Segoe UI")
    } else {
        _SetIcono(ccGui.icono,"circle_off",false)
        ccGui.label.Value := "CIRCLE"
        ccGui.barra.Opt("c" _Tema("color","track.pillOff","6A6A6A"))
        ccGui.g.BackColor := _Tema("color","surface.off","424242")
        ccGui.label.SetFont("s" _FS(9) " bold c" _Tema("color","text.idle","B2B2B2"),"Segoe UI")
    }
    ccGui.barra.Value := 100
}
_CcGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,ccGui)
IniciarArGUI() {
    arGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    arGui.g.BackColor := _Tema("color","surface.off","424242")
    arGui.g.MarginX := 0
    arGui.g.MarginY := 0
    WinSetTransparent(_AlphaTema("pill",235),arGui.g)
    arGui.icono := arGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20) " BackgroundTrans","")
    arGui.label := arGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
    arGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
    arGui.barra := arGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
    OnMessage(0x0201,_ArGUI_WM_LBUTTONDOWN)
    arGui.g.OnEvent("ContextMenu", (*) => _MostrarMenuContextualHub())
    posAr := LeerPosicionGUI("Quick")
    if (IsObject(posAr) && _PosicionValidaEnPantalla(posAr.x,posAr.y)) {
        arX := posAr.x
        arY := posAr.y
    } else {
        try {
            WinGetPos(&ccX,&ccY,&ccW,&ccH,"ahk_id " ccGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            ccX := ancla.x + _E(104) + PANEL_GAP
            ccY := ancla.y
            ccW := _E(104)
        }
        arX := ccX + ccW + PANEL_GAP
        arY := ccY
    }
    arGui.g.Show("x" arX " y" arY " w" _E(104) " h" _E(25) " NoActivate")
    _DwmRedondear(arGui.g.Hwnd)
    ActualizarArGUI()
}
ActualizarArGUI() {
    if (ar.hover) {
        _SetIcono(arGui.icono,"quick_on",true)
        arGui.label.Value := "QUICK"
        arGui.barra.Opt("c" _Tema("color","accent.estabSoft","B4C0DE"))
        arGui.g.BackColor := _Tema("color","surface.on","636D83")
        arGui.label.SetFont("s" _FS(9) " bold c" _Tema("color","text.primary","FFFFFF"),"Segoe UI")
    } else {
        _SetIcono(arGui.icono,"quick_off",false)
        arGui.label.Value := "QUICK"
        arGui.barra.Opt("c" _Tema("color","track.pillOff","6A6A6A"))
        arGui.g.BackColor := _Tema("color","surface.off","424242")
        arGui.label.SetFont("s" _FS(9) " bold c" _Tema("color","text.idle","B2B2B2"),"Segoe UI")
    }
    arGui.barra.Value := 100
}
_ArGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,arGui)
IniciarHCGUI() {
    hcGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    hcGui.g.BackColor := _Tema("color","surface.off","424242")
    hcGui.g.MarginX := 0
    hcGui.g.MarginY := 0
    WinSetTransparent(_AlphaTema("pill",235),hcGui.g)
    hcGui.icono := hcGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20) " BackgroundTrans","")
    hcGui.label := hcGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
    hcGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
    hcGui.barra := hcGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
    OnMessage(0x0201,_HCGUI_WM_LBUTTONDOWN)
    hcGui.g.OnEvent("ContextMenu", (*) => _MostrarMenuContextualHub())
    posHc := LeerPosicionGUI("HC")
    if (IsObject(posHc) && _PosicionValidaEnPantalla(posHc.x,posHc.y)) {
        x := posHc.x
        y := posHc.y
    } else {
        try {
            WinGetPos(&aX,&aY,,,"ahk_id " dsGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            aX := ancla.x
            aY := ancla.y
        }
        off := _HcOffsetBloque()
        x := aX + off.dx
        y := aY + off.dy
    }
    hcGui.g.Show("x" x " y" y " w" _E(104) " h" _E(25) " NoActivate")
    _DwmRedondear(hcGui.g.Hwnd)
    ActualizarHCGUI()
}
ActualizarHCGUI() {
    if (hist.modo = 1) {
        _SetIcono(hcGui.icono,"hist_on",true)
        hcGui.label.Value := "HC"
        hcGui.barra.Opt("c" _Tema("color","accent.estabSoft","B4C0DE"))
        hcGui.g.BackColor := _Tema("color","surface.on","636D83")
        hcGui.label.SetFont("s" _FS(9) " bold c" _Tema("color","text.primary","FFFFFF"),"Segoe UI")
    } else {
        _SetIcono(hcGui.icono,"hist_on",false)
        hcGui.label.Value := "HC"
        hcGui.barra.Opt("c" _Tema("color","track.pillOff","6A6A6A"))
        hcGui.g.BackColor := _Tema("color","surface.off","424242")
        hcGui.label.SetFont("s" _FS(9) " bold c" _Tema("color","text.idle","B2B2B2"),"Segoe UI")
    }
    hcGui.barra.Value := 100
}
_HCGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,hcGui)
IniciarLockGUI() {
    global panelBlk
    panelBlk.locked := (_LeerEstadoBloque("locked","1") = "1")
    lockGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    lockGui.g.BackColor := _Tema("color","surface.off","424242")
    lockGui.g.MarginX := 0
    lockGui.g.MarginY := 0
    WinSetTransparent(_AlphaTema("pill",235),lockGui.g)
    lockGui.icono := lockGui.g.Add("Picture","x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19) " BackgroundTrans","")
    lockGui.barra := lockGui.g.Add("Progress","x0 y" _E(22) " w" _E(31) " h" _E(3))
    OnMessage(0x0201,_LockGUI_WM_LBUTTONDOWN)
    OnMessage(0x0205,_Companion_WM_RBUTTON)
    lockGui.g.OnEvent("ContextMenu", (*) => _MostrarMenuContextualHub())
    posLock := LeerPosicionGUI("Lock")
    if (IsObject(posLock) && _PosicionValidaEnPantalla(posLock.x,posLock.y)) {
        lockX := posLock.x
        lockY := posLock.y
    } else {
        try {
            WinGetPos(&arX,&arY,&arW,&arH,"ahk_id " arGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            arX := ancla.x + 2 * (_E(104) + PANEL_GAP)
            arY := ancla.y
            arW := _E(104)
        }
        lockX := arX + arW + PANEL_GAP
        lockY := arY
    }
    lockGui.g.Show("x" lockX " y" lockY " w" _E(31) " h" _E(25) " NoActivate")
    _DwmRedondear(lockGui.g.Hwnd)
    ActualizarLockGUI()
}
ActualizarLockGUI() {
    if (panelBlk.locked) {
        _SetIcono(lockGui.icono,"lock_closed",false)
        lockGui.barra.Opt("c" _Tema("color","track.pillOff","6A6A6A"))
        lockGui.g.BackColor := _Tema("color","surface.off","424242")
    } else {
        _SetIcono(lockGui.icono,"lock_open",true)
        lockGui.barra.Opt("c" _Tema("color","accent.estabSoft","B4C0DE"))
        lockGui.g.BackColor := _Tema("color","surface.on","636D83")
    }
    lockGui.barra.Value := 100
    if IsObject(estabGui.grip)
        estabGui.grip.Visible := !panelBlk.locked
    if IsObject(estabGui.g)
        try {
            estabGui.g.BackColor := panelBlk.locked ? _Tema("color","surface.estabLocked","2B2B2B") : _Tema("color","surface.estabOpen","3A4260")
            ActualizarEstabGUI(-1)
        }
}
_LockGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,lockGui)
IniciarFrenteGUI() {
    global panelBlk
    panelBlk.frente := (_LeerEstadoBloque("frente","0") = "1")
    frenteGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    frenteGui.g.BackColor := _Tema("color","surface.off","424242")
    frenteGui.g.MarginX := 0
    frenteGui.g.MarginY := 0
    WinSetTransparent(_AlphaTema("pill",235),frenteGui.g)
    frenteGui.icono := frenteGui.g.Add("Picture","x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19) " BackgroundTrans","")
    frenteGui.barra := frenteGui.g.Add("Progress","x0 y" _E(22) " w" _E(31) " h" _E(3))
    OnMessage(0x0201,_FrenteGUI_WM_LBUTTONDOWN)
    frenteGui.g.OnEvent("ContextMenu", (*) => _MostrarMenuContextualHub())
    posF := LeerPosicionGUI("Frente")
    if (IsObject(posF) && _PosicionValidaEnPantalla(posF.x,posF.y)) {
        fX := posF.x
        fY := posF.y
    } else {
        try {
            WinGetPos(&lX,&lY,&lW,&lH,"ahk_id " lockGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            lX := ancla.x + 3 * (_E(104) + PANEL_GAP)
            lY := ancla.y
            lW := _E(31)
        }
        fX := lX + lW + PANEL_GAP
        fY := lY
    }
    sf := _RectaDentroDeMonitor(fX,fY,_E(31),_E(25)) ? {x:fX,y:fY} : _EsquinaPanelBloque(0)
    frenteGui.g.Show("x" sf.x " y" sf.y " w" _E(31) " h" _E(25) " NoActivate")
    _DwmRedondear(frenteGui.g.Hwnd)
    ActualizarFrenteGUI()
}
ActualizarFrenteGUI() {
    if !IsObject(frenteGui.icono)
        return
    if panelBlk.frente {
        _SetIcono(frenteGui.icono,"pin_on",true)
        frenteGui.barra.Opt("c" _Tema("color","accent.estabSoft","B4C0DE"))
        frenteGui.g.BackColor := _Tema("color","surface.on","636D83")
    } else {
        _SetIcono(frenteGui.icono,"pin_off")
        frenteGui.barra.Opt("c" _Tema("color","track.pillOff","6A6A6A"))
        frenteGui.g.BackColor := _Tema("color","surface.off","424242")
    }
    frenteGui.barra.Value := 100
}
_FrenteGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,frenteGui)
_ToggleFrente() {
    panelBlk.frente := !panelBlk.frente
    _EscribirEstadoBloque("frente",panelBlk.frente ? 1 : 0)
    ActualizarFrenteGUI()
    ActualizarHubGUI()
    if panelBlk.frente {
        _MostrarPaneles()
        _TraerPanelesAlFrente()
    }
    MostrarHUD(panelBlk.frente ? "📌 GUI AL FRENTE" : "📌 GUI SOLO EN CSP",panelBlk.frente ? _Tema("color","accent.success","44DD88") : _Tema("color","accent.warn","FF6B00"),1200)
}
IniciarEstabBtnGUI() {
    estabBtnGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    estabBtnGui.g.BackColor := _Tema("color","surface.off","424242")
    estabBtnGui.g.MarginX := 0
    estabBtnGui.g.MarginY := 0
    WinSetTransparent(_AlphaTema("pill",235),estabBtnGui.g)
    estabBtnGui.icono := estabBtnGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20) " BackgroundTrans","")
    estabBtnGui.label := estabBtnGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
    estabBtnGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
    estabBtnGui.barra := estabBtnGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
    OnMessage(0x0201,_EstabBtnGUI_WM_LBUTTONDOWN)
    estabBtnGui.g.OnEvent("ContextMenu", (*) => _MostrarMenuContextualHub())
    posB := LeerPosicionGUI("EstabBtn")
    if (IsObject(posB) && _PosicionValidaEnPantalla(posB.x,posB.y)) {
        eX := posB.x
        eY := posB.y
    } else {
        try {
            WinGetPos(&fX,&fY,&fW,&fH,"ahk_id " frenteGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            fX := ancla.x + 3 * (_E(104) + PANEL_GAP) + _E(31) + PANEL_GAP
            fY := ancla.y
            fW := _E(31)
        }
        eX := fX + fW + PANEL_GAP
        eY := fY
    }
    se := _RectaDentroDeMonitor(eX,eY,_E(104),_E(25)) ? {x:eX,y:eY} : _EsquinaPanelBloque(1)
    estabBtnGui.g.Show("x" se.x " y" se.y " w" _E(104) " h" _E(25) " NoActivate")
    _DwmRedondear(estabBtnGui.g.Hwnd)
    ActualizarEstabBtnGUI()
}
ActualizarEstabBtnGUI() {
    if !IsObject(estabBtnGui.g) || !IsObject(estabBtnGui.label)
        return
    v := estabGui.valor
    if estabGui.visible {
        _SetIcono(estabBtnGui.icono,"slider_on",true)
        estabBtnGui.label.Value := "ESTAB " v
        estabBtnGui.barra.Opt("c" _Tema("color","accent.estabSoft","B4C0DE"))
        estabBtnGui.g.BackColor := _Tema("color","surface.on","636D83")
        estabBtnGui.label.SetFont("s" _FS(9) " bold c" _Tema("color","text.primary","FFFFFF"),"Segoe UI")
    } else {
        _SetIcono(estabBtnGui.icono,"slider_on",false)
        estabBtnGui.label.Value := "ESTAB OFF"
        estabBtnGui.barra.Opt("c" _Tema("color","track.pillOff","6A6A6A"))
        estabBtnGui.g.BackColor := _Tema("color","surface.off","424242")
        estabBtnGui.label.SetFont("s" _FS(9) " bold c" _Tema("color","text.idle","B2B2B2"),"Segoe UI")
    }
    estabBtnGui.barra.Value := estabGui.visible ? v : 0
}
_EstabBtnGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,estabBtnGui)
_ToggleEstabVisible() {
    global PERFIL
    estabGui.visible := !estabGui.visible
    GuardarIniDiferido(_PosGuiIniPath(),"Estab_p" PERFIL,"visible",estabGui.visible ? 1 : 0)
    if estabGui.visible {
        _AplicarEstabVisibilidadBase()
        ActualizarEstabGUI()
    } else if (IsObject(estabGui.g) && !estabGui.foco)
        estabGui.g.Hide()
    ActualizarEstabBtnGUI()
    ActualizarHubGUI()
    MostrarHUD(estabGui.visible ? "🎚 DESLIZADOR VISIBLE" : "🎚 DESLIZADOR OCULTO",estabGui.visible ? _Tema("color","accent.success","44DD88") : _Tema("color","accent.warn","FF6B00"),1100)
}
IniciarEstabGUI() {
    global PERFIL,panelBlk,ESTAB_ALPHA_H,ESTAB_ALPHA_F
    ini := _PosGuiIniPath()
    v := IniRead(ini,"Estab_p" PERFIL,"valor","")
    estabGui.valor := (IsInteger(v) && Integer(v) >= 0 && Integer(v) <= 100) ? Integer(v) : 50
    estabGui.previsto := estabGui.valor
    pidGuardado := IniRead(ini,"Estab_p" PERFIL,"pid","")
    pidCSP := ProcessExist("CLIPStudioPaint.exe")
    estabGui.sincronizado := (pidCSP && pidGuardado != "" && String(pidCSP) = pidGuardado)
    estabGui.visible := (IniRead(ini,"Estab_p" PERFIL,"visible","1") = "1")
    estabGui.arrastrando := false
    a := IniRead(ini,"Estab_p" PERFIL,"alphaH","")
    if (IsInteger(a) && Integer(a) >= 10 && Integer(a) <= 100)
        ESTAB_ALPHA_H := Round(Integer(a) * 2.55)
    a := IniRead(ini,"Estab_p" PERFIL,"alphaF","")
    if (IsInteger(a) && Integer(a) >= 10 && Integer(a) <= 100)
        ESTAB_ALPHA_F := Round(Integer(a) * 2.55)
    r := _EstabRectGuardada()
    if IsObject(r) {
        w := r.w
        h := r.h
        px := r.x
        py := r.y
    } else {
        mon0 := ObtenerMonitorCSP()
        w := _E(420)
        h := _E(44)
        posE := LeerPosicionGUI("Estab")
        if (IsObject(posE) && _PosicionValidaEnPantalla(posE.x,posE.y)) {
            px := posE.x
            py := posE.y
        } else {
            px := mon0.x + (mon0.w - w) // 2
            py := mon0.y + Round(mon0.h * 0.14)
        }
    }
    mon := _EstabMonitorEn(px + w // 2,py + h // 2)
    w := Max(14,Min(w,mon.w))
    h := Max(14,Min(h,mon.h))
    px := Max(mon.x,Min(px,mon.x + mon.w - w))
    py := Max(mon.y,Min(py,mon.y + mon.h - h))
    _EstabCalcular(w,h)
    estabGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x08000000 -DPIScale","")
    estabGui.g.BackColor := panelBlk.locked ? _Tema("color","surface.estabLocked","2B2B2B") : _Tema("color","surface.estabOpen","3A4260")
    estabGui.g.MarginX := 0
    estabGui.g.MarginY := 0
    _EstabAlpha(false)
    ; track + relleno + knob: una sola capa pintada por GDI+ sobre el cliente del panel
    _EstabGdipIniciar()
    estabGui.valorTxt := estabGui.g.Add("Text","x0 y0 w" w " h" estabGui.txtH " Center +0x200 c" ESTAB_COLOR,"")
    estabGui.valorTxt.SetFont("s" estabGui.fuente " bold",_TemaFuente("valor"))
    estabGui.grip := estabGui.g.Add("Text","x" Max(0,w - _E(15)) " y" (h - _E(15)) " w" _E(15) " h" _E(15) " Right +0x200 BackgroundTrans c" _Tema("color","track.pillOff","6A6A6A"),"◢")
    estabGui.grip.SetFont("s" Max(7,Round(9 * ESC)),"Segoe UI")
    estabGui.grip.Visible := !panelBlk.locked
    OnMessage(0x0201,_EstabGUI_WM_LBUTTONDOWN)
    OnMessage(0x0207,_EstabGUI_WM_MBUTTONDOWN)
    HotIf(_EstabZonaRueda)
    try Hotkey("WheelUp",_EstabWheelUp,"On")
    try Hotkey("WheelDown",_EstabWheelDown,"On")
    HotIf(_EstabCSPActivo)
    try Hotkey("~j",_EstabTeclaJ,"On")
    try Hotkey("~-",_EstabTeclaMenos,"On")
    try Hotkey("~LButton",_EstabInvalidarConfianza,"On")
    HotIf(_EstabCSPActivo)
    try Hotkey("$+e",_EstabFocoTecla,"On")
    try Hotkey("$#+e",_EstabFocoTecla,"On")   ; Win fantasma: no se escapa al SO
    try Hotkey("~*e up",_EstabTeclaMenosUp,"On")
    try Hotkey("~*Shift up",_EstabTeclaMenosUp,"On")
    HotIf()
    estabGui.g.Show("x" px " y" py " w" w " h" h " NoActivate")
    if (!estabGui.visible || !enfoque.activo)
        estabGui.g.Hide()
    _EstabRegion(w,h)
    _DwmRedondear(estabGui.g.Hwnd)
    _EstabLayout(w,h)
    ActualizarEstabBtnGUI()
}
_EstabMonitorEn(x,y) {
    Loop MonitorGetCount() {
        MonitorGet(A_Index,&mL,&mT,&mR,&mB)
        if (x >= mL && x < mR && y >= mT && y < mB)
            return {x:mL,y:mT,w:mR - mL,h:mB - mT}
    }
    return ObtenerMonitorCSP()
}
_EstabTamanoValido(w,h) => (Min(w,h) >= 14 && Max(w,h) >= 60)
_EstabAlpha(activo := false) {
    if !IsObject(estabGui.g)
        return
    if estabGui.foco
        a := activo ? ESTAB_ALPHA_ACT : ESTAB_ALPHA_F
    else
        a := estabGui.horiz ? (activo ? ESTAB_ALPHA_ACT : ESTAB_ALPHA_H) : 235
    try WinSetTransparent(a,"ahk_id " estabGui.g.Hwnd)
}
_EstabCalcular(w,h) {
    estabGui.ancho := w
    estabGui.alto := h
    estabGui.horiz := (w > h)
    if estabGui.horiz {
        estabGui.knobSize := Max(12,Round(h * 0.86))
        ; Mismo criterio que en vertical: si el knob da para la cifra dentro
        ; (>= 30 px), no se reserva franja lateral y el texto de apoyo se apaga
        ; para no duplicar el numero. Si el knob es pequeño, se usa el lateral.
        estabGui.txtW := (estabGui.knobSize >= 30) ? 0 : Max(34,Round(h * 1.4))
        if IsObject(estabGui.valorTxt)
            estabGui.valorTxt.Visible := (estabGui.txtW > 0)
        estabGui.txtH := h
        estabGui.trackH := Max(6,Round(h * 0.46))
        estabGui.trackY := Round((h - estabGui.trackH) / 2)
        k := Round(estabGui.knobSize / 2)
        estabGui.trackX := k + 3
        estabGui.trackW := Max(20,w - estabGui.txtW - estabGui.trackX - k - 3)
        estabGui.fuente := Max(8,Round(h * 0.30))
    } else {
        dentro := (w >= 42)
        estabGui.txtH := dentro ? 0 : Max(18,Round(h * 0.10))
        estabGui.txtW := w
        estabGui.knobSize := dentro ? 36 : Max(14,Round(w * 0.58))
        if IsObject(estabGui.valorTxt)
            estabGui.valorTxt.Visible := !dentro
        k := Round(estabGui.knobSize / 2)
        estabGui.trackW := Max(6,Round(w * 0.22))
        estabGui.trackX := Round((w - estabGui.trackW) / 2)
        estabGui.trackY := Max(k + 3,Round(h * 0.03))
        estabGui.trackH := Max(24,h - estabGui.txtH - 2 * estabGui.trackY)
        estabGui.fuente := Max(7,Round(w * 0.26))
    }
}
_EstabLayout(w,h) {
    _EstabCalcular(w,h)
    if !IsObject(estabGui.valorTxt)
        return
    try {
        estabGui.valorTxt.SetFont("s" estabGui.fuente " bold",_TemaFuente("valor"))
        if estabGui.horiz {
            if (estabGui.txtW > 0)
                estabGui.valorTxt.Move(w - estabGui.txtW,0,estabGui.txtW,h)
        } else
            estabGui.valorTxt.Move(0,h - estabGui.txtH,w,estabGui.txtH)
        estabGui.grip.Move(Max(0,w - _E(15)),h - _E(15),_E(15),_E(15))
        estabGui.grip.Visible := (!panelBlk.locked && !estabGui.foco)
    }
    _EstabAlpha(false)
    ActualizarEstabGUI(-1,true)
}
_EstabRegion(w,h) {
    if !IsObject(estabGui.g)
        return
    try {
        rad := Max(6,Round(Min(w,h) * 0.50))
        rgn := DllCall("Gdi32\CreateRoundRectRgn","int",0,"int",0,"int",w + 1,"int",h + 1,"int",rad,"int",rad,"Ptr")
        DllCall("SetWindowRgn","Ptr",estabGui.g.Hwnd,"Ptr",rgn,"int",1)
    }
}
ActualizarEstabGUI(v := -1,forzar := false) {
    if !IsObject(estabGui.g)
        return
    if (v < 0)
        v := estabGui.valor
    sig := estabGui.ancho "x" estabGui.alto "x" estabGui.horiz "x" panelBlk.locked
    if (!forzar && v = estabGui.dibV && sig = estabGui.dibG)
        return
    try {
        estabGui.valorTxt.Value := String(v)
        estabGui.dibV := v
        estabGui.dibG := sig
        ; El canvas se repinta aqui mismo, desde el hilo que cambia el valor: no hay handler
        ; de WM_PAINT porque registrar OnMessage(0x000F) en mitad del arranque cuelga el
        ; proceso y porque cada vuelta por el hilo de mensajes cuesta ~34 ms (I13-b).
        _EstabDibujar()
        ActualizarEstabBtnGUI()
    }
}
_EstabCSPActivo(*) => WinActive("ahk_exe CLIPStudioPaint.exe")
_EstabZonaRueda(*) => _EstabCSPActivo() && _EstabBajoMouse()
_EstabBajoMouse() {
    if !IsObject(estabGui.g) || !DllCall("IsWindowVisible","Ptr",estabGui.g.Hwnd)
        return false
    MouseGetPos(&mx,&my)
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",estabGui.g.Hwnd,"Ptr",rc)
    return (mx >= NumGet(rc,0,"int") && mx <= NumGet(rc,8,"int") && my >= NumGet(rc,4,"int") && my <= NumGet(rc,12,"int"))
}
_EstabWheelUp(*) {
    _EstabAplicarValor(estabGui.valor + 5)
    _SonarUI("slider", estabGui.valor)
    MostrarHUD("ESTABILIZACIÓN " estabGui.valor,"9A7BFF",600)
}
_EstabWheelDown(*) {
    _EstabAplicarValor(estabGui.valor - 5)
    _SonarUI("slider", estabGui.valor)
    MostrarHUD("ESTABILIZACIÓN " estabGui.valor,"9A7BFF",600)
}
_EstabTeclaJ() => _EstabTeclaLocal(-1)
_EstabTeclaMenos() => _EstabTeclaLocal(1)
_EstabFocoCond(*) => enfoque.activo && WinActive("ahk_exe CLIPStudioPaint.exe")
_EstabFocoTecla(*) {
    _LiberarFantasmas()   ; suelta Win/Space/Ctrl/Alt anclados antes de actuar
    if (estabGui.foco && !estabGui.fAbajo) {
        _EstabFocoOcultar()
        return
    }
    _EstabFocoMostrar()
}
_EstabTeclaMenosUp(*) {
    if !estabGui.foco
        return
    estabGui.fAbajo := false
    estabGui.fSoltado := A_TickCount
}
_EstabFocoRect() {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "Estab_p" PERFIL
    x := IniRead(ini,sec,"fx","")
    y := IniRead(ini,sec,"fy","")
    w := IniRead(ini,sec,"fw","")
    h := IniRead(ini,sec,"fh","")
    if (IsInteger(x) && IsInteger(y) && IsInteger(w) && IsInteger(h)) {
        if (_EstabTamanoValido(Integer(w),Integer(h)) && _PosicionValidaEnPantalla(Integer(x),Integer(y)))
            return {x:Integer(x),y:Integer(y),w:Integer(w),h:Integer(h)}
    }
    mon := ObtenerMonitorCSP()
    w := Min(mon.w - 40,Round(mon.w * 0.45))
    h := _E(64)
    return {x:mon.x + (mon.w - w) // 2,y:mon.y + mon.h - h - Round(mon.h * 0.10),w:w,h:h}
}
_EstabFocoGuardarRect(x,y,w,h) {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "Estab_p" PERFIL
    IniWrite(x,ini,sec,"fx")
    IniWrite(y,ini,sec,"fy")
    IniWrite(w,ini,sec,"fw")
    IniWrite(h,ini,sec,"fh")
}
_EstabFocoMostrar() {
    if !IsObject(estabGui.g)
        return
    estabGui.fAbajo := true
    estabGui.fTick := A_TickCount
    estabGui.fPrevHasta := 0
    if estabGui.foco
        return
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",estabGui.g.Hwnd,"Ptr",rc)
    nx := NumGet(rc,0,"int")
    ny := NumGet(rc,4,"int")
    estabGui.rectNormal := {x:nx,y:ny,w:NumGet(rc,8,"int") - nx,h:NumGet(rc,12,"int") - ny}
    r := _EstabFocoRect()
    estabGui.foco := true
    DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",-1,"int",r.x,"int",r.y,"int",r.w,"int",r.h,"uint",0x0010)
    _EstabRegion(r.w,r.h)
    _EstabLayout(r.w,r.h)
    if !DllCall("IsWindowVisible","Ptr",estabGui.g.Hwnd)
        estabGui.g.Show("NoActivate")
    _EstabDibujar()
    _EstabAlpha(false)
    SetTimer(_EstabFocoVigilar,40)
}
_EstabFocoOcultar(*) {
    if !estabGui.foco
        return
    SetTimer(_EstabFocoVigilar,0)
    estabGui.foco := false
    estabGui.fAbajo := false
    estabGui.fPrevHasta := 0
    if !IsObject(estabGui.g)
        return
    r := estabGui.rectNormal
    if IsObject(r) {
        DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",0,"int",r.x,"int",r.y,"int",r.w,"int",r.h,"uint",0x0004 | 0x0010)
        _EstabRegion(r.w,r.h)
        _EstabLayout(r.w,r.h)
    }
    if (!enfoque.activo || !estabGui.visible)
        estabGui.g.Hide()
    _EstabAlpha(false)
}
_EstabFocoVigilar(*) {
    if !estabGui.foco {
        SetTimer(_EstabFocoVigilar,0)
        return
    }
    if (A_TickCount < estabGui.fPrevHasta)
        return
    if estabGui.arrastrando {
        estabGui.fTick := A_TickCount
        return
    }
    if estabGui.fPrevHasta != 0 {
        _EstabFocoOcultar()
        return
    }
    if (!WinActive("ahk_exe CLIPStudioPaint.exe") || GetKeyState("Escape","P") || A_TickCount - estabGui.fTick > FOCO_TIMEOUT_MS) {
        _EstabFocoOcultar()
        return
    }
}
_EstabFocoPrevisualizar() {
    if estabGui.foco
        return
    _EstabFocoMostrar()
    estabGui.fAbajo := false
    estabGui.fSoltado := 0
    estabGui.fPrevHasta := A_TickCount + 2200
}
_EstabTeclaLocal(d) {
    if !IsObject(estabGui.g) || !estabGui.sincronizado
        return
    estabGui.valor := Max(0,Min(100,estabGui.valor + d))
    ActualizarEstabGUI()
    _GuardarValorEstab()
}
_EstabEmitir(tecla,n,pausa := ESTAB_RITMO) {
    ; racha alta + ritmo entre rafagas: lo que CSP tragaba eran rafagas encadenadas muy juntas, no la racha en si
    while (n > 0) {
        if !WinActive("ahk_exe CLIPStudioPaint.exe")
            return false
        k := (n > ESTAB_RACHA) ? ESTAB_RACHA : n
        SendInput("{" tecla " " k "}")
        n -= k
        Sleep(pausa)
    }
    return true
}
_EstabFijarAbsoluto(target) {
    ; j x100 (piso) + «-» x target: el valor queda fijado sin importar la sub-herramienta activa ni su valor interno previo
    return _EstabEmitir("j",100,5) && (target <= 0 || _EstabEmitir("-",target,5))
}
_EstabConfiable() => (estabGui.sincronizado && (A_TickCount - stabU.syncTick) < STAB_CONFIANZA_MS)
_EstabInvalidarConfianza(*) {
    ; cualquier clic/toque en CSP pudo cambiar la sub-herramienta (paleta): la base de AHK deja de ser fiable
    if _EstabBajoMouse()
        return
    stabU.syncTick := 0
}
_EstabEnviarDelta(nuevo) {
    if (STAB_ABSOLUTO && !_EstabConfiable()) {
        if !_EstabFijarAbsoluto(nuevo) {
            estabGui.sincronizado := false
            return false
        }
        estabGui.valor := nuevo
        stabU.syncTick := A_TickCount
        return true
    }
    d := nuevo - estabGui.valor
    if (d = 0)
        return true
    ok := (d > 0) ? _EstabEmitir("-",d) : _EstabEmitir("j",Abs(d))
    if !ok {
        estabGui.sincronizado := false
        return false
    }
    estabGui.valor := nuevo
    stabU.syncTick := A_TickCount
    return true
}
_EstabPrevisualizar(cx,cy) {
    if estabGui.horiz
        nuevo := Round(((cx - estabGui.trackX) / estabGui.trackW) * 100)
    else
        nuevo := Round(((estabGui.trackY + estabGui.trackH - cy) / estabGui.trackH) * 100)
    estabGui.previsto := Max(0,Min(100,nuevo))
    ActualizarEstabGUI(estabGui.previsto)
}
_EstabEnBarra(rx,ry) {
    k := Round(estabGui.knobSize / 2)
    if estabGui.horiz
        return (rx >= estabGui.trackX - k - 2 && rx <= estabGui.trackX + estabGui.trackW + k + 2)
    return (rx >= estabGui.trackX - _E(10) && rx <= estabGui.trackX + estabGui.trackW + _E(10) && ry >= estabGui.trackY - k && ry <= estabGui.trackY + estabGui.trackH + k)
}
_EstabRectGuardada() {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "Estab_p" PERFIL
    x := IniRead(ini,sec,"x","")
    y := IniRead(ini,sec,"y","")
    w := IniRead(ini,sec,"w","")
    h := IniRead(ini,sec,"h","")
    if (IsInteger(x) && IsInteger(y) && IsInteger(w) && IsInteger(h)) {
        if (_EstabTamanoValido(Integer(w),Integer(h)) && _PosicionValidaEnPantalla(Integer(x),Integer(y)))
            return {x:Integer(x),y:Integer(y),w:Integer(w),h:Integer(h)}
    }
    return _EstabRectCalibrada()
}
_EstabRectCalibrada() {
    global PUNTOS,PUNTOS_DEF
    if (PUNTOS.Length < 32)
        return 0
    if (PUNTOS[31][1] = PUNTOS_DEF[31][1] && PUNTOS[31][2] = PUNTOS_DEF[31][2] && PUNTOS[32][1] = PUNTOS_DEF[32][1] && PUNTOS[32][2] = PUNTOS_DEF[32][2])
        return 0
    w := Abs(PUNTOS[32][1] - PUNTOS[31][1])
    h := Abs(PUNTOS[32][2] - PUNTOS[31][2])
    if !_EstabTamanoValido(w,h)
        return 0
    return {x:Min(PUNTOS[31][1],PUNTOS[32][1]),y:Min(PUNTOS[31][2],PUNTOS[32][2]),w:w,h:h}
}
_EstabGuardarRect() {
    global PERFIL
    if (!IsObject(estabGui.g) || estabGui.foco)
        return
    ini := _PosGuiIniPath()
    sec := "Estab_p" PERFIL
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",estabGui.g.Hwnd,"Ptr",rc)
    x := NumGet(rc,0,"int")
    y := NumGet(rc,4,"int")
    IniWrite(x,ini,sec,"x")
    IniWrite(y,ini,sec,"y")
    IniWrite(NumGet(rc,8,"int") - x,ini,sec,"w")
    IniWrite(NumGet(rc,12,"int") - y,ini,sec,"h")
}
_EstabAplicarRect(x,y,w,h) {
    global PUNTOS,PERFIL
    if !IsObject(estabGui.g)
        return false
    DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",0,"int",x,"int",y,"int",w,"int",h,"uint",0x0004 | 0x0010)
    _EstabLayout(w,h)
    _EstabRegion(w,h)
    if !estabGui.visible {
        estabGui.visible := true
        IniWrite(1,_PosGuiIniPath(),"Estab_p" PERFIL,"visible")
        estabGui.g.Show("NoActivate")
        _EstabDibujar()
        ActualizarEstabBtnGUI()
    }
    _EstabGuardarRect()
    if (PUNTOS.Length >= 32) {
        PUNTOS[31] := [x,y]
        PUNTOS[32] := [x + w,y + h]
    }
    ori := estabGui.horiz ? "HORIZONTAL" : "VERTICAL"
    MostrarHUD("🎚 DESLIZADOR " w "×" h " · " ori,"9A7BFF",1500)
    return true
}
_EstabGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) {
    global panelBlk
    if (estabGui.arrastrando || !IsObject(estabGui.g))
        return
    if !(hwnd = estabGui.g.Hwnd || estabGui.g.Hwnd = DllCall("GetParent","Ptr",hwnd,"Ptr"))
        return
    estabGui.arrastrando := true
    pt := Buffer(8,0)
    NumPut("int",lParam & 0xFFFF,pt,0)
    NumPut("int",(lParam >> 16) & 0xFFFF,pt,4)
    DllCall("ClientToScreen","Ptr",hwnd,"Ptr",pt)
    clickX := NumGet(pt,0,"int")
    clickY := NumGet(pt,4,"int")
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",estabGui.g.Hwnd,"Ptr",rc)
    winX := NumGet(rc,0,"int")
    winY := NumGet(rc,4,"int")
    rx := clickX - winX
    ry := clickY - winY
    winW := NumGet(rc,8,"int") - winX
    winH := NumGet(rc,12,"int") - winY
    grip := _E(15)
    enGrip := !panelBlk.locked && (rx >= winW - grip && ry >= winH - grip)
    enBarra := !enGrip && _EstabEnBarra(rx,ry)
    mon := _EstabMonitorEn(clickX,clickY)
    _EstabAlpha(true)
    cur := Buffer(8,0)
    try {
        if (estabGui.foco) {
            ; deslizador de ENFOQUE: toda la zona elige valor en vivo; sin mover ni redimensionar
            estabGui.fTick := A_TickCount
            _EstabPrevisualizar(rx,ry)
            if estabGui.sincronizado
                _EstabEnviarDelta(estabGui.previsto)
            while GetKeyState("LButton","P") {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                _EstabPrevisualizar(mx - winX,my - winY)
                if (estabGui.sincronizado && estabGui.previsto != estabGui.valor)
                    _EstabEnviarDelta(estabGui.previsto)
                estabGui.fTick := A_TickCount
                Sleep(8)
            }
            _EstabAplicarValor(estabGui.previsto)
        } else if (enGrip) {
            while GetKeyState("LButton","P") {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                nw := Max(14,Min(mon.w,winW + (mx - clickX)))
                nh := Max(14,Min(mon.h,winH + (my - clickY)))
                DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",0,"int",0,"int",0,"int",nw,"int",nh,"uint",0x0002 | 0x0004 | 0x0010)
                _EstabLayout(nw,nh)
                _EstabRegion(nw,nh)
                Sleep(8)
            }
            _EstabGuardarRect()
        } else if !panelBlk.locked {
            movido := false
            while GetKeyState("LButton","P") {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                if (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4)
                    movido := true
                if movido
                    DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",0,"int",mx - rx,"int",my - ry,"int",0,"int",0,"uint",0x0001 | 0x0004 | 0x0010)
                Sleep(8)
            }
            if movido
                _EstabGuardarRect()
            else if enBarra {
                _EstabPrevisualizar(rx,ry)
                _EstabAplicarValor(estabGui.previsto)
                MostrarHUD("ESTABILIZACIÓN " estabGui.valor,"9A7BFF",700)
            }
        } else if enBarra {
            _EstabPrevisualizar(rx,ry)
            if estabGui.sincronizado
                _EstabEnviarDelta(estabGui.previsto)
            while GetKeyState("LButton","P") {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                _EstabPrevisualizar(mx - winX,my - winY)
                if (estabGui.sincronizado && estabGui.previsto != estabGui.valor)
                    _EstabEnviarDelta(estabGui.previsto)
                Sleep(8)
            }
            _EstabAplicarValor(estabGui.previsto)
            MostrarHUD("ESTABILIZACIÓN " estabGui.valor,"9A7BFF",700)
        } else {
            while GetKeyState("LButton","P")
                Sleep(8)
        }
    } finally {
        _EstabAlpha(false)
        estabGui.arrastrando := false
        if estabGui.foco
            _EstabFocoOcultar()
    }
}
_EstabGUI_WM_MBUTTONDOWN(wParam,lParam,msg,hwnd) {
    if !IsObject(estabGui.g)
        return
    if !(hwnd = estabGui.g.Hwnd || estabGui.g.Hwnd = DllCall("GetParent","Ptr",hwnd,"Ptr"))
        return
    estabGui.sincronizado := false
    _EstabAplicarValor(estabGui.valor)
    MostrarHUD("🔄 ESTAB. RESINCRONIZADA","44DD88",900)
}
_EstabAplicarValor(nuevo) {
    nuevo := Max(0,Min(100,Round(nuevo)))
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        MostrarHUD("⚠ ACTIVA CLIP STUDIO PAINT","FF4444",1200)
        estabGui.sincronizado := false
        ActualizarEstabGUI()
        return
    }
    desfasado := !estabGui.sincronizado || Abs(nuevo - estabGui.valor) > 25 || (STAB_ABSOLUTO && !_EstabConfiable())
    if (nuevo = estabGui.valor && !desfasado) {
        ActualizarEstabGUI()
        _GuardarValorEstab()
        return
    }
    base := estabGui.valor
    ok := true
    try {
        BlockInput(true)
        if desfasado {
            MostrarHUD("🔄 SINCRONIZANDO…","9A7BFF",900)
            _SonarUI("sync")
            ok := _EstabEmitir("j",100,5)
            base := 0
            estabGui.sincronizado := ok
            if ok
                estabGui.valor := 0
        }
        if ok {
            d := nuevo - base
            if (d > 0)
                ok := _EstabEmitir("-",d)
            else if (d < 0)
                ok := _EstabEmitir("j",Abs(d))
        }
    } finally {
        BlockInput(false)
    }
    if !ok {
        estabGui.sincronizado := false
        MostrarHUD("⚠ SINCRONIZACIÓN INTERRUMPIDA","FFAA33",1300)
        ActualizarEstabGUI()
        return
    }
    estabGui.valor := nuevo
    estabGui.previsto := nuevo
    stabU.syncTick := A_TickCount
    ActualizarEstabGUI()
    _GuardarValorEstab()
}
_GuardarValorEstab() {
    global PERFIL
    ini := _PosGuiIniPath()
    IniWrite(estabGui.valor,ini,"Estab_p" PERFIL,"valor")
    pid := ProcessExist("CLIPStudioPaint.exe")
    try {
        if pid
            IniWrite(pid,ini,"Estab_p" PERFIL,"pid")
        else
            IniDelete(ini,"Estab_p" PERFIL,"pid")
    }
}
IniciarReloadGUI() {
    reloadGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    reloadGui.g.BackColor := _Tema("color","surface.reload","3B7A4B")
    reloadGui.g.MarginX := 0
    reloadGui.g.MarginY := 0
    WinSetTransparent(_AlphaTema("pill",235),reloadGui.g)
    reloadGui.icono := reloadGui.g.Add("Picture","x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19) " BackgroundTrans","")
    _SetIcono(reloadGui.icono,"reload_g",true)
    reloadGui.barra := reloadGui.g.Add("Progress","x0 y" _E(22) " w" _E(31) " h" _E(3))
    reloadGui.barra.Value := 100
    OnMessage(0x0201,_ReloadGUI_WM_LBUTTONDOWN)
    mon := ObtenerMonitorCSP()
    x := mon.x + (mon.w - _E(104)) // 2
    y := mon.y + Round(mon.h * 0.02) + 42 + 4 + _E(25) + 4 + _E(25) + 4 + _E(25) + 4 + _E(25) + 4
    guardada := LeerPosicionGUI("Reload")
    if IsObject(guardada) && _PosicionValidaEnPantalla(guardada.x,guardada.y) {
        x := guardada.x
        y := guardada.y
    }
    reloadGui.g.Show("x" x " y" y " w" _E(31) " h" _E(25) " NoActivate")
    _DwmRedondear(reloadGui.g.Hwnd)
}
_ReloadGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) {
    static arrastrando := false
    if (arrastrando)
        return
    if (hwnd = reloadGui.g.Hwnd || reloadGui.g.Hwnd = DllCall("GetParent","Ptr",hwnd,"Ptr")) {
        arrastrando := true
        pt := Buffer(8,0)
        NumPut("int",lParam & 0xFFFF,pt,0)
        NumPut("int",(lParam >> 16) & 0xFFFF,pt,4)
        DllCall("ClientToScreen","Ptr",hwnd,"Ptr",pt)
        clickX := NumGet(pt,0,"int")
        clickY := NumGet(pt,4,"int")
        rc := Buffer(16,0)
        DllCall("GetWindowRect","Ptr",reloadGui.g.Hwnd,"Ptr",rc)
        offX := clickX - NumGet(rc,0,"int")
        offY := clickY - NumGet(rc,4,"int")
        cur := Buffer(8,0)
        movido := false
        while GetKeyState("LButton","P") {
            DllCall("GetCursorPos","Ptr",cur)
            mx := NumGet(cur,0,"int")
            my := NumGet(cur,4,"int")
            if (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4) {
                movido := true
                DllCall("SetWindowPos","Ptr",reloadGui.g.Hwnd,"Ptr",0,"int",mx - offX,"int",my - offY,"int",0,"int",0,"uint",0x0001 | 0x0004 | 0x0010)
            }
            Sleep(8)
        }
        if !movido {
            _SonarUI("reload")
            Sleep(130)   ; deja sonar el micro-tono antes de que Reload() mate el proceso
            Reload()
        } else
            GuardarPosicionGUI("Reload",reloadGui.g.Hwnd)
        arrastrando := false
    }
}
PuntosPorDefecto() {
    r := []
    for p in PUNTOS_DEF
        r.Push([p[1],p[2]])
    return r
}
CargarPuntos() {
    global PUNTOS,HIST_ALTO,PERFIL
    ini := _PosGuiIniPath()
    sec := "Puntos" PERFIL
    PUNTOS := []
    for i,p in PUNTOS_DEF {
        x := IniRead(ini,sec,"P" i "x","")
        y := IniRead(ini,sec,"P" i "y","")
        if ((x = "" || y = "") && PERFIL = 1) {
            x := IniRead(ini,"Puntos","P" i "x","")
            y := IniRead(ini,"Puntos","P" i "y","")
        }
        if (IsInteger(x) && IsInteger(y))
            PUNTOS.Push([Integer(x),Integer(y)])
        else
            PUNTOS.Push([p[1],p[2]])
    }
    h := IniRead(ini,sec,"HistAlto","")
    if (h = "" && PERFIL = 1)
        h := IniRead(ini,"Puntos","HistAlto","")
    HIST_ALTO := IsInteger(h) ? Integer(h) : 104
    RecalcularZonas()
}
GuardarPuntos(conFirma := true) {
    global PUNTOS,HIST_ALTO,PERFIL
    ini := _PosGuiIniPath()
    sec := "Puntos" PERFIL
    for i,p in PUNTOS {
        IniWrite(p[1],ini,sec,"P" i "x")
        IniWrite(p[2],ini,sec,"P" i "y")
    }
    IniWrite(HIST_ALTO,ini,sec,"HistAlto")
    if (conFirma)
        IniWrite(_FirmaMonitores(),ini,sec,"firma")
}
CargarEscala() {
    global ESC,PERFIL
    v := IniRead(_PosGuiIniPath(),"Puntos" PERFIL,"escala","")
    if (!IsNumber(v) || Number(v) < 40 || Number(v) > 200)
        v := (PERFIL = 1) ? 75 : 100
    ESC := Number(v) / 100
}
CargarEscalaAvisos() {
    global AVISO_ESC,ESC,PERFIL
    v := IniRead(_PosGuiIniPath(),"Puntos" PERFIL,"escalaAvisos","")
    if (!IsNumber(v) || Number(v) < 40 || Number(v) > 250)
        v := Round(ESC * 110)
    AVISO_ESC := Number(v) / 100
}
_E(n) => Max(1,Round(n * ESC))
_FS(n) => Max(6,Round(n * ESC))
_FirmaMonitores() {
    f := ""
    Loop MonitorGetCount() {
        MonitorGet(A_Index,&l,&t,&r,&b)
        f .= (f = "" ? "" : ";") l "," t "," r "," b
    }
    f := Sort(f,"D;")
    return f
}
ElegirPerfil() {
    global PERFIL,PERFILES
    ini := _PosGuiIniPath()
    act := IniRead(ini,"Perfil","actual","1")
    PERFIL := (IsInteger(act) && Integer(act) >= 1 && Integer(act) <= PERFILES.Length) ? Integer(act) : 1
    firma := _FirmaMonitores()
    previa := IniRead(ini,"Perfil","ultimaFirma","")
    if (previa = firma)
        return
    IniWrite(firma,ini,"Perfil","ultimaFirma")
    primera := (previa = "")
    for i,nombre in PERFILES {
        if (IniRead(ini,"Puntos" i,"firma","") = firma) {
            PERFIL := i
            IniWrite(i,ini,"Perfil","actual")
            msg := "PERFIL AUTO: " nombre
            SetTimer(() => MostrarHUD(msg,"9AA7C7",2500),-1800)
            return
        }
    }
    if (primera)
        return
    msg := "MONITORES CAMBIARON — elige perfil en 📍 (actual: " PERFILES[PERFIL] ")"
    SetTimer(() => MostrarHUD(msg,"9AA7C7",3500),-1800)
}
_ZonaDePuntos(desde,n) {
    global PUNTOS
    x1 := PUNTOS[desde][1]
    x2 := x1
    y1 := PUNTOS[desde][2]
    y2 := y1
    Loop n - 1 {
        p := PUNTOS[desde + A_Index]
        x1 := Min(x1,p[1])
        x2 := Max(x2,p[1])
        y1 := Min(y1,p[2])
        y2 := Max(y2,p[2])
    }
    return {x1:x1,y1:y1,x2:x2,y2:y2}
}
RecalcularZonas() {
    global ZONAS,HIST_ALTO
    izq := []
    der := []
    Loop 3 {
        izq.Push(_ZonaDePuntos(3 + (A_Index - 1) * 4,4))
        der.Push(_ZonaDePuntos(15 + (A_Index - 1) * 4,4))
    }
    h := _ZonaDePuntos(27,2)
    if (HIST_ALTO >= 0)
        h.y2 := h.y2 + HIST_ALTO
    else
        h.y1 := h.y1 + HIST_ALTO
    ZONAS := {izq:izq,der:der,hist:h}
}
_NombrePunto(i) {
    if (i <= 2)
        return "Ocultar/mostrar · " (i = 1 ? "izq" : "der")
    if (i <= 14)
        return "Izq B" ((i - 3) // 4 + 1) " · esq " (Mod(i - 3,4) + 1)
    if (i <= 26)
        return "Der B" ((i - 15) // 4 + 1) " · esq " (Mod(i - 15,4) + 1)
    if (i = 27)
        return "Historial · izq"
    if (i = 28)
        return "Historial · der"
    if (i = 29)
        return "Zona segura (rehacer)"
    if (i = 30)
        return "Avisos · esq. sup. izq. (HUD)"
    return "Punto " i
}

; ══════════════════════════════════════════════════════════════════
; 🧩 BOTÓN HUB: Contenedor Inteligente de Botones Auxiliares (Camaleón)
; ══════════════════════════════════════════════════════════════════
IniciarHubGUI() {
    global hubGui, panelBlk, PERFIL
    ini := _PosGuiIniPath()
    sec := "Hub_p" PERFIL
    for k in ["lock","frente","puntos","estab","reload","ds","cc","ar","hc","flip","enfoque"] {
        hubGui.embebidos[k] := (IniRead(ini,sec,"embeber_" k,"0") = "1")
    }

    ; El boton solitario Hub en la barra superior se retira por peticion del usuario:
    ; se mantiene 'QUICK' (arGui) con su icono y texto, y se accede a todo mediante click derecho en los companion.
    hubGui.g := 0
    hubGui.icono := 0
    hubGui.barra := 0

    OnMessage(0x0205,_Companion_WM_RBUTTON)
    _AplicarVisibilidadEmbebidos()
}

_HayBotonesEmbebidos() {
    global hubGui
    if !IsObject(hubGui) || !hubGui.HasOwnProp("embebidos")
        return false
    for k, v in hubGui.embebidos {
        if (v)
            return true
    }
    return false
}

ActualizarHubGUI() {
    global hubGui
    if !IsObject(hubGui.g) || !IsObject(hubGui.icono)
        return
    hay := _HayBotonesEmbebidos()
    if (hay) {
        ; Azul marino leve para activado
        hubGui.g.BackColor := "2A3D5E"
        hubGui.barra.Opt("c" "688ECC")
        _SetIcono(hubGui.icono,"quick_on",true)
    } else {
        ; Como está ahora para no marcado
        hubGui.g.BackColor := _Tema("color","surface.off","424242")
        hubGui.barra.Opt("c" _Tema("color","track.pillOff","6A6A6A"))
        _SetIcono(hubGui.icono,"quick_on",false)
    }
    hubGui.barra.Value := 100
}

_AplicarVisibilidadEmbebidos() {
    global hubGui, lockGui, frenteGui, puntosGui, estabBtnGui, reloadGui, dsGui, ccGui, arGui, hcGui
    _SetVis(gObj, k) {
        if IsObject(gObj) && IsObject(gObj.g) {
            emb := (hubGui.HasOwnProp("embebidos") && hubGui.embebidos.Has(k) && hubGui.embebidos[k])
            emb ? gObj.g.Hide() : gObj.g.Show("NoActivate")
        }
    }
    _SetVis(lockGui, "lock")
    _SetVis(frenteGui, "frente")
    _SetVis(puntosGui, "puntos")
    _SetVis(estabBtnGui, "estab")
    _SetVis(reloadGui, "reload")
    _SetVis(dsGui, "ds")
    _SetVis(ccGui, "cc")
    _SetVis(arGui, "ar")
    _SetVis(hcGui, "hc")
}

_HubGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) {
    global hubGui, panelBlk
    if !IsObject(hubGui.g)
        return
    if !(hwnd = hubGui.g.Hwnd || hubGui.g.Hwnd = DllCall("GetParent","Ptr",hwnd,"Ptr"))
        return
    pt := Buffer(8,0)
    NumPut("int",lParam & 0xFFFF,pt,0)
    NumPut("int",(lParam >> 16) & 0xFFFF,pt,4)
    DllCall("ClientToScreen","Ptr",hwnd,"Ptr",pt)
    clickX := NumGet(pt,0,"int"), clickY := NumGet(pt,4,"int")
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",hubGui.g.Hwnd,"Ptr",rc)
    offX := clickX - NumGet(rc,0,"int")
    offY := clickY - NumGet(rc,4,"int")
    cur := Buffer(8,0)
    movido := false
    while GetKeyState("LButton","P") {
        DllCall("GetCursorPos","Ptr",cur)
        mx := NumGet(cur,0,"int"), my := NumGet(cur,4,"int")
        if (!panelBlk.locked && (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4)) {
            movido := true
            DllCall("SetWindowPos","Ptr",hubGui.g.Hwnd,"Ptr",0,"int",mx-offX,"int",my-offY,"int",0,"int",0,"uint",0x0001|0x0004|0x0010)
        }
        Sleep(8)
    }
    if (movido) {
        GuardarPosicionGUI("Hub",hubGui.g.Hwnd)
    } else {
        _MostrarMenuContextualHub()
    }
}

_Companion_WM_RBUTTON(wParam,lParam,msg,hwnd) {
    global hubGui, lockGui, frenteGui, puntosGui, estabBtnGui, reloadGui, dsGui, ccGui, arGui, hcGui
    hwnds := []
    for o in [hubGui, lockGui, frenteGui, puntosGui, estabBtnGui, reloadGui, dsGui, ccGui, arGui, hcGui] {
        if IsObject(o) && IsObject(o.g)
            hwnds.Push(o.g.Hwnd)
    }
    esValido := false
    for h in hwnds {
        if (hwnd = h || h = DllCall("GetParent","Ptr",hwnd,"Ptr")) {
            esValido := true
            break
        }
    }
    if (!esValido)
        return
    _MostrarMenuContextualHub()
    return 0
}

_EjecutarAccionHub(act, *) {
    global hubGui, panelBlk, estabGui, colorV, colorCC, ar, hist, enfoque
    switch act {
        case "lock":
            _ToggleBloqueo()
        case "frente":
            _ToggleFrente()
        case "puntos":
            AbrirPanelPuntos()
        case "estab":
            _ToggleEstabVisible()
        case "ds":
            _ToggleColorV()
            ActualizarDsGUI()
        case "cc":
            _ToggleColorCC()
            ActualizarCcGUI()
        case "ar":
            _ToggleAR()
            ActualizarArGUI()
        case "hc":
            _ToggleHistorialColor()
            ActualizarHCGUI()
        case "flip":
            SendInput("!g")
            MostrarHUD("FLIP HORIZONTAL","888888",700)
            _SonarUI("flip")
        case "enfoque":
            AccionEnfoque()
        case "reload":
            Reload()
    }
    ActualizarHubGUI()
}

_MostrarMenuContextualHub() {
    global hubGui, panelBlk, estabGui, colorV, colorCC, ar, hist, enfoque
    static ultMenuTick := 0
    if (A_TickCount - ultMenuTick < 400)
        return
    ultMenuTick := A_TickCount

    m := Menu()

    cat := [
        ["lock", "🔒 Bloquear Companion", () => panelBlk.locked ? "🔓 Desbloquear Companion" : "🔒 Fijar Companion"],
        ["frente", "📌 Modo Frente (AlwaysOnTop)", () => panelBlk.frente ? "📌 Modo Frente: Desactivar (Solo en CSP)" : "📌 Modo Frente: Activar (AlwaysOnTop)"],
        ["puntos", "📍 Calibrador de Zonas y Rangos", () => "📍 Calibrador de Zonas y Rangos"],
        ["estab", "🎚 Deslizador Estabilización", () => estabGui.visible ? "🎚 Deslizador: Ocultar" : "🎚 Deslizador: Mostrar"],
        ["ds", "🎚 Botón Slider / Pincel (DS)", () => colorV.hover ? "🎚 Slider / Pincel: Ocultar" : "🎚 Slider / Pincel: Mostrar"],
        ["cc", "🎨 Botón Círculo de Color (CC)", () => colorCC.hover ? "🎨 Círculo de Color: Ocultar" : "🎨 Círculo de Color: Mostrar"],
        ["ar", "⚡ Botón Acceso Rápido (AR)", () => ar.hover ? "⚡ Acceso Rápido: Ocultar" : "⚡ Acceso Rápido: Mostrar"],
        ["hc", "🕒 Botón Historial de Color (HC)", () => (hist.modo = 1) ? "🕒 Historial Color: Cambiar a Fijo" : "🕒 Historial Color: Cambiar a Dinámico"],
        ["flip", "🪞 Voltear Lienzo Horizontal", () => "🪞 Voltear Lienzo Horizontal"],
        ["enfoque", "🔍 Modo Enfoque", () => enfoque.activo ? "🔍 Salir de Modo Enfoque" : "🔍 Activar Modo Enfoque"],
        ["reload", "🔄 Recargar Script", () => "🔄 Recargar Script"]
    ]

    ; ── BLOQUE 1 (Superior): Comandos embebidos en el Hub ──
    cantEmbebidos := 0
    for item in cat {
        k := item[1]
        if (hubGui.embebidos.Has(k) && hubGui.embebidos[k]) {
            txtDyn := item[3]()
            m.Add(txtDyn, _EjecutarAccionHub.Bind(k))
            cantEmbebidos++
        }
    }

    if (cantEmbebidos = 0) {
        m.Add("📍 Abrir Calibrador de Zonas", (*) => _EjecutarAccionHub("puntos"))
        m.Add(panelBlk.locked ? "🔓 Desbloquear Companion" : "🔒 Fijar Companion", (*) => _EjecutarAccionHub("lock"))
        m.Add(panelBlk.frente ? "📌 Modo Frente: Desactivar" : "📌 Modo Frente: Activar", (*) => _EjecutarAccionHub("frente"))
        m.Add(estabGui.visible ? "🎚 Deslizador: Ocultar" : "🎚 Deslizador: Mostrar", (*) => _EjecutarAccionHub("estab"))
        m.Add("🔄 Recargar Script", (*) => _EjecutarAccionHub("reload"))
    }

    mLay := Menu()
    mLay.Add("💾 Guardar posición actual como Modo 1 (Normal)", (*) => _CapturarLayout("Normal"))
    mLay.Add("💾 Guardar posición actual como Modo 2 (Enfoque)", (*) => _CapturarLayout("Enfoque"))
    mLay.Add("▶ Aplicar Modo 1 (Normal)", (*) => _AplicarLayoutPaneles("Normal"))
    mLay.Add("▶ Aplicar Modo 2 (Enfoque)", (*) => _AplicarLayoutPaneles("Enfoque"))
    mLay.Add("🎯 Alternar Modo (1 ⇄ 2)", (*) => AccionEnfoque())
    m.Add("📐 Layout Paneles CSP (Modo 1 y 2)", mLay)

    m.Add("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", (*) => 0)
    m.Disable("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

    ; ── BLOQUE 2 (Inferior): Submenú para elegir cuáles embeber ──
    mEmb := Menu()
    for item in cat {
        k := item[1], txt := item[2]
        mEmb.Add(txt, _MenuToggleEmbebido.Bind(k))
        if (hubGui.embebidos.Has(k) && hubGui.embebidos[k])
            mEmb.Check(txt)
    }
    m.Add("☑ Embeber botones en el Hub", mEmb)

    m.Show()
}

_MenuToggleEmbebido(k, *) {
    global hubGui, PERFIL
    if !hubGui.embebidos.Has(k)
        hubGui.embebidos[k] := false
    hubGui.embebidos[k] := !hubGui.embebidos[k]
    IniWrite(hubGui.embebidos[k] ? 1 : 0,_PosGuiIniPath(),"Hub_p" PERFIL,"embeber_" k)
    _AplicarVisibilidadEmbebidos()
    ActualizarHubGUI()
    MostrarAvisoUI("moderno",hubGui.embebidos[k] ? "BOTÓN EMBEBIDO" : "BOTÓN SUELTO",StrUpper(k),2,"00E5FF",1200)
}

IniciarPuntosGUI() {
    global reloadGui
    puntosGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    puntosGui.g.BackColor := _Tema("color","surface.off","424242")
    puntosGui.g.MarginX := 0
    puntosGui.g.MarginY := 0
    WinSetTransparent(_AlphaTema("pill",235),puntosGui.g)
    puntosGui.icono := puntosGui.g.Add("Picture","x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19) " BackgroundTrans","")
    _SetIcono(puntosGui.icono,"calib",true)
    puntosGui.barra := puntosGui.g.Add("Progress","x0 y" _E(22) " w" _E(31) " h" _E(3))
    puntosGui.barra.Value := 100
    OnMessage(0x0201,_PuntosGUI_WM_LBUTTONDOWN)
    puntosGui.g.OnEvent("ContextMenu", (*) => _MostrarMenuContextualHub())
    mon := ObtenerMonitorCSP()
    x := mon.x + (mon.w - _E(104)) // 2 + _E(31) + PANEL_GAP
    y := mon.y + Round(mon.h * 0.02)
    try {
        WinGetPos(&rX,&rY,&rW,&rH,"ahk_id " reloadGui.g.Hwnd)
        x := rX + rW + PANEL_GAP
        y := rY
    }
    guardada := LeerPosicionGUI("PuntosBtn")
    if IsObject(guardada) && _PosicionValidaEnPantalla(guardada.x,guardada.y) {
        x := guardada.x
        y := guardada.y
    }
    puntosGui.g.Show("x" x " y" y " w" _E(31) " h" _E(25) " NoActivate")
    _DwmRedondear(puntosGui.g.Hwnd)
}
_PuntosGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) {
    global panelBlk
    static arrastrando := false
    if (arrastrando)
        return
    if !IsObject(puntosGui.g)
        return
    if (hwnd = puntosGui.g.Hwnd || puntosGui.g.Hwnd = DllCall("GetParent","Ptr",hwnd,"Ptr")) {
        arrastrando := true
        pt := Buffer(8,0)
        NumPut("int",lParam & 0xFFFF,pt,0)
        NumPut("int",(lParam >> 16) & 0xFFFF,pt,4)
        DllCall("ClientToScreen","Ptr",hwnd,"Ptr",pt)
        clickX := NumGet(pt,0,"int")
        clickY := NumGet(pt,4,"int")
        rc := Buffer(16,0)
        DllCall("GetWindowRect","Ptr",puntosGui.g.Hwnd,"Ptr",rc)
        offX := clickX - NumGet(rc,0,"int")
        offY := clickY - NumGet(rc,4,"int")
        cur := Buffer(8,0)
        movido := false
        while GetKeyState("LButton","P") {
            if (!panelBlk.locked) {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                if (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4) {
                    movido := true
                    DllCall("SetWindowPos","Ptr",puntosGui.g.Hwnd,"Ptr",0,"int",mx - offX,"int",my - offY,"int",0,"int",0,"uint",0x0001 | 0x0004 | 0x0010)
                }
            }
            Sleep(8)
        }
        if !movido
            AbrirPanelPuntos()
        else
            GuardarPosicionGUI("PuntosBtn",puntosGui.g.Hwnd)
        arrastrando := false
    }
}
AbrirPanelPuntos() {
    global PERFIL,PERFILES,ESC,AVISO_ESC,panelBlk,ESTAB_ALPHA_H,ESTAB_ALPHA_F
    if IsObject(ptsEd.g) {
        try {
            ptsEd.g.Show()
            return
        }
        ptsEd.g := 0
    }
    defs := _PtsZonaDefs()
    evs := _PtsEventosDefs()
    _PtsEvLeer()
    g := Gui("+AlwaysOnTop","📍 Calibración · rangos, avisos y sistema")
    g.SetFont("s9","Segoe UI")
    tb := g.Add("Tab3","x10 y10 w620 h540",["📐 Zonas y rangos","🔔 Eventos / HUD","⚙ Sistema y perfiles","🎨 Paleta de temas"])
    x0 := 24
    ; ---------------- Pestaña 1: zonas y rangos ----------------
    tb.UseTab(1)
    g.Add("Text","x" x0 " y48 w590 h34","Dibuja cada zona arrastrando el lápiz sobre la pantalla (un clic = punto). Doble toque en una fila = dibujar. Los puntos P1..P32 se recalculan solos para los demás scripts.")
    lv := g.Add("ListView","x" x0 " y88 w590 r14 -Multi NoSortHdr Grid",["Zona","Tipo","X","Y","Ancho","Alto"])
    for d in defs
        lv.Add("",d.n,(d.t = "punto") ? "Punto" : "Rango","","","","")
    lv.ModifyCol(1,205)
    lv.ModifyCol(2,60)
    Loop 4
        lv.ModifyCol(2 + A_Index,75)
    lv.GetPos(&lx,&ly,&lw,&lh)
    yb := ly + lh + 10
    bDib := g.Add("Button","x" x0 " y" yb " w150","✏ Dibujar con lápiz")
    bCad := g.Add("Button","x" (x0 + 156) " y" yb " w150","⏩ Dibujar en cadena")
    bVer := g.Add("Button","x" (x0 + 312) " y" yb " w120","👁 Ver zonas")
    bDef := g.Add("Button","x" (x0 + 438) " y" yb " w140","↺ Por defecto")
    y2 := yb + 38
    g.Add("Text","x" x0 " y" (y2 + 4),"X")
    eX := g.Add("Edit","x" (x0 + 18) " y" y2 " w72","")
    g.Add("Text","x" (x0 + 100) " y" (y2 + 4),"Y")
    eY := g.Add("Edit","x" (x0 + 118) " y" y2 " w72","")
    g.Add("Text","x" (x0 + 200) " y" (y2 + 4),"Ancho")
    eW := g.Add("Edit","x" (x0 + 245) " y" y2 " w72","")
    g.Add("Text","x" (x0 + 327) " y" (y2 + 4),"Alto")
    eH := g.Add("Edit","x" (x0 + 357) " y" y2 " w72","")
    bAp := g.Add("Button","x" (x0 + 440) " y" (y2 - 1) " w120","✔ Aplicar valores")
    y3 := y2 + 36
    g.Add("Text","x" x0 " y" (y3 + 4),"Desplazar TODOS los puntos:   ΔX")
    dx := g.Add("Edit","x" (x0 + 215) " y" y3 " w58","0")
    g.Add("Text","x" (x0 + 285) " y" (y3 + 4),"ΔY")
    dy := g.Add("Edit","x" (x0 + 310) " y" y3 " w58","0")
    bDelta := g.Add("Button","x" (x0 + 380) " y" (y3 - 1) " w100","Aplicar Δ")
    y4 := y3 + 34
    g.Add("Text","x" x0 " y" (y4 + 4),"📐 Paneles CSP:")
    bLN1 := g.Add("Button","x" (x0 + 100) " y" y4 " w110","💾 Modo 1 (Norm)")
    bLE1 := g.Add("Button","x" (x0 + 216) " y" y4 " w110","💾 Modo 2 (Enf)")
    bLA1 := g.Add("Button","x" (x0 + 332) " y" y4 " w85","▶ Aplicar")
    bTog1 := g.Add("Button","x" (x0 + 423) " y" y4 " w155","🎯 Alternar (1 ⇄ 2)")
    bLN1.OnEvent("Click",(*) => _CapturarLayout("Normal"))
    bLE1.OnEvent("Click",(*) => _CapturarLayout("Enfoque"))
    bLA1.OnEvent("Click",(*) => _AplicarLayoutPaneles(enfoque.activo ? "Enfoque" : "Normal"))
    bTog1.OnEvent("Click",(*) => AccionEnfoque())
    ; ---------------- Pestaña 2: eventos / HUD ----------------
    tb.UseTab(2)
    g.Add("Text","x" x0 " y48 w590 h34","Elige para cada aviso su formato (Moderno/Bruto/Desactivado), prioridad (Alta, Media, Baja) y opacidad (100%, 70%, 40%).")
    lvEv := g.Add("ListView","x" x0 " y88 w590 r14 +Multi NoSortHdr Grid",["Acción (evento)","Formato","Prioridad","Opacidad"])
    for ev in evs
        lvEv.Add("",ev[2],"","","")
    lvEv.ModifyCol(1,275)
    lvEv.ModifyCol(2,95)
    lvEv.ModifyCol(3,110)
    lvEv.ModifyCol(4,90)
    lvEv.GetPos(&ex1,&ey1,&ew1,&eh1)
    yb2 := ey1 + eh1 + 10
    g.Add("Text","x" x0 " y" (yb2 + 4),"Formato:")
    ddF := g.Add("DropDownList","x" (x0 + 56) " y" yb2 " w105 Choose1",["Moderno","Bruto","Desactivado"])
    g.Add("Text","x" (x0 + 158) " y" (yb2 + 4),"Prioridad:")
    ddZ := g.Add("DropDownList","x" (x0 + 216) " y" yb2 " w100 Choose3",["Alta","Media","Baja"])
    g.Add("Text","x" (x0 + 322) " y" (yb2 + 4),"Opacidad:")
    ddOp := g.Add("DropDownList","x" (x0 + 378) " y" yb2 " w105 Choose2",["100% (Máx)","70% (Medio)","40% (Bajo)"])
    bEvProbar := g.Add("Button","x" (x0 + 490) " y" (yb2 - 1) " w95","🔔 Probar")
    g.Add("Text","x" x0 " y" (yb2 + 42) " w590 h44 cGray","Se guarda al instante en [HudEventos" PERFIL "] de posiciones_gui.ini. El motor de avisos las lee con HudConfigEvento('evento') y ObtenerRango('HUD_Alta').")
    ; ---------------- Pestaña 3: sistema y perfiles ----------------
    tb.UseTab(3)
    xc := x0 + 215
    y := 52
    g.Add("Text","x" x0 " y" (y + 4),"Perfil de equipo:")
    ddl := g.Add("DropDownList","x" xc " y" y " w230 Choose" PERFIL,PERFILES)
    y += 40
    g.Add("Text","x" x0 " y" (y + 4),"Escala de botones (%):")
    eEsc := g.Add("Edit","x" xc " y" y " w60",Round(ESC * 100))
    g.Add("Text","x" (xc + 72) " y" (y + 4),"(se aplica al guardar)")
    y += 36
    g.Add("Text","x" x0 " y" (y + 4),"Escala de avisos (%):")
    eEscAv := g.Add("Edit","x" xc " y" y " w60",Round(AVISO_ESC * 100))
    g.Add("Text","x" (xc + 72) " y" (y + 4),"(HUD, mini-textos)")
    y += 46
    g.Add("Text","x" x0 " y" (y + 5),"📌 Botones del script:")
    bMover := g.Add("Button","x" xc " y" y " w150",panelBlk.locked ? "🔓 Mover botones" : "🔒 Fijar botones")
    bReub := g.Add("Button","x" (xc + 156) " y" y " w150","↺ Reubicar botones")
    y += 40
    g.Add("Text","x" x0 " y" (y + 5),"📌 Paneles de CSP:")
    bLN := g.Add("Button","x" xc " y" y " w110","💾 Normal")
    bLE := g.Add("Button","x" (xc + 116) " y" y " w120","💾 Enfoque")
    bLA := g.Add("Button","x" (xc + 242) " y" y " w90","▶ Aplicar")
    y += 46
    g.Add("Text","x" x0 " y" (y + 4),"Opacidad desliz. horizontal (%):")
    eAlpha := g.Add("Edit","x" xc " y" y " w60",Round(ESTAB_ALPHA_H / 2.55))
    g.Add("Text","x" (xc + 72) " y" (y + 4),"(ancha = horizontal)")
    y += 36
    g.Add("Text","x" x0 " y" (y + 4),"Opacidad desliz. de enfoque (%):")
    eAlphaF := g.Add("Edit","x" xc " y" y " w60",Round(ESTAB_ALPHA_F / 2.55))
    y += 40
    g.Add("GroupBox","x" x0 " y" y " w590 h108","🧩 Botón HUB — Embeber botones (acceso directo por clic derecho)")
    g.Add("Text","x" (x0 + 15) " y" (y + 24),"Fila 1:")
    chkL := g.Add("CheckBox","x" (x0 + 65) " y" (y + 24) " Checked" (hubGui.embebidos.Has("lock") && hubGui.embebidos["lock"]?1:0),"Bloquear")
    chkL.OnEvent("Click",(*) => _MenuToggleEmbebido("lock"))
    chkF := g.Add("CheckBox","x" (x0 + 155) " y" (y + 24) " Checked" (hubGui.embebidos.Has("frente") && hubGui.embebidos["frente"]?1:0),"Frente")
    chkF.OnEvent("Click",(*) => _MenuToggleEmbebido("frente"))
    chkP := g.Add("CheckBox","x" (x0 + 230) " y" (y + 24) " Checked" (hubGui.embebidos.Has("puntos") && hubGui.embebidos["puntos"]?1:0),"Calibrador")
    chkP.OnEvent("Click",(*) => _MenuToggleEmbebido("puntos"))
    chkE := g.Add("CheckBox","x" (x0 + 320) " y" (y + 24) " Checked" (hubGui.embebidos.Has("estab") && hubGui.embebidos["estab"]?1:0),"Estabilizador")
    chkE.OnEvent("Click",(*) => _MenuToggleEmbebido("estab"))
    chkR := g.Add("CheckBox","x" (x0 + 430) " y" (y + 24) " Checked" (hubGui.embebidos.Has("reload") && hubGui.embebidos["reload"]?1:0),"Recargar")
    chkR.OnEvent("Click",(*) => _MenuToggleEmbebido("reload"))

    g.Add("Text","x" (x0 + 15) " y" (y + 60),"Fila 2:")
    chkDS := g.Add("CheckBox","x" (x0 + 65) " y" (y + 60) " Checked" (hubGui.embebidos.Has("ds") && hubGui.embebidos["ds"]?1:0),"Slider")
    chkDS.OnEvent("Click",(*) => _MenuToggleEmbebido("ds"))
    chkCC := g.Add("CheckBox","x" (x0 + 155) " y" (y + 60) " Checked" (hubGui.embebidos.Has("cc") && hubGui.embebidos["cc"]?1:0),"Color")
    chkCC.OnEvent("Click",(*) => _MenuToggleEmbebido("cc"))
    chkAR := g.Add("CheckBox","x" (x0 + 230) " y" (y + 60) " Checked" (hubGui.embebidos.Has("ar") && hubGui.embebidos["ar"]?1:0),"Acceso R.")
    chkAR.OnEvent("Click",(*) => _MenuToggleEmbebido("ar"))
    chkHC := g.Add("CheckBox","x" (x0 + 320) " y" (y + 60) " Checked" (hubGui.embebidos.Has("hc") && hubGui.embebidos["hc"]?1:0),"Hist. Color")
    chkHC.OnEvent("Click",(*) => _MenuToggleEmbebido("hc"))
    chkFL := g.Add("CheckBox","x" (x0 + 430) " y" (y + 60) " Checked" (hubGui.embebidos.Has("flip") && hubGui.embebidos["flip"]?1:0),"Voltear")
    chkFL.OnEvent("Click",(*) => _MenuToggleEmbebido("flip"))
    chkEN := g.Add("CheckBox","x" (x0 + 510) " y" (y + 60) " Checked" (hubGui.embebidos.Has("enfoque") && hubGui.embebidos["enfoque"]?1:0),"Enfoque")
    chkEN.OnEvent("Click",(*) => _MenuToggleEmbebido("enfoque"))
    ; ---------------- Pestaña 4: paleta de temas ----------------
    tb.UseTab(4)
    g.Add("Text","x" x0 " y48 w590 h34","Selecciona la paleta de colores y estilos para los botones del script, colores de acento y avisos en pantalla.")
    g.Add("Text","x" x0 " y95 w590 h26 cGray","Tema activo actualmente: " _Tema("meta","nombre","Oscuro"))
    bAbrirTema := g.Add("Button","x" x0 " y130 w220 h36","🎨 Abrir Selector de Temas")
    bAbrirTema.OnEvent("Click",(*) => _AbrirSelectorTema())
    tb.UseTab(0)
    st := g.Add("Text","x10 y558 w620 h34","")
    bOk := g.Add("Button","x10 y598 w145 Default","💾 Guardar y cerrar")
    bRei := g.Add("Button","x160 y598 w140","🔄 Reiniciar script")
    bTemaBar := g.Add("Button","x306 y598 w150","🎨 Paleta de temas")
    bTemaBar.OnEvent("Click",(*) => _AbrirSelectorTema())
    ptsEd.g := g
    ptsEd.lv := lv
    ptsEd.bVer := bVer
    ptsEd.eX := eX
    ptsEd.eY := eY
    ptsEd.eW := eW
    ptsEd.eH := eH
    ptsEd.dx := dx
    ptsEd.dy := dy
    ptsEd.eEsc := eEsc
    ptsEd.eEscAv := eEscAv
    ptsEd.eAlpha := eAlpha
    ptsEd.eAlphaF := eAlphaF
    ptsEd.st := st
    ptsEd.lvEv := lvEv
    ptsEd.ddF := ddF
    ptsEd.ddZ := ddZ
    ptsEd.ddOp := ddOp
    ptsEd.sel := 0
    ptsEd.evSel := 0
    st.Value := "Perfil activo: " PERFILES[PERFIL] ". Selecciona una zona."
    lv.OnEvent("ItemSelect",_PtsSel)
    lv.OnEvent("DoubleClick",(*) => _PtsDibujarSel(false))
    bDib.OnEvent("Click",(*) => _PtsDibujarSel(false))
    bCad.OnEvent("Click",(*) => _PtsDibujarSel(true))
    bVer.OnEvent("Click",_PtsToggleVerZonas)
    bDef.OnEvent("Click",_PtsDefecto)
    bAp.OnEvent("Click",_PtsAplicarCampos)
    bDelta.OnEvent("Click",_PtsDesplazar)
    lvEv.OnEvent("ItemSelect",_PtsEvSel)
    ddF.OnEvent("Change",_PtsEvCambio)
    ddZ.OnEvent("Change",_PtsEvCambio)
    ddOp.OnEvent("Change",_PtsEvCambio)
    bEvProbar.OnEvent("Click",_PtsEvProbar)
    ddl.OnEvent("Change",_PtsCambiarPerfil)
    bMover.OnEvent("Click",(ctrl,*) => _PtsMoverBotones(ctrl))
    bReub.OnEvent("Click",_PtsReubicar)
    bLN.OnEvent("Click",(*) => _CapturarLayout("Normal"))
    bLE.OnEvent("Click",(*) => _CapturarLayout("Enfoque"))
    bLA.OnEvent("Click",(*) => _AplicarLayoutPaneles(enfoque.activo ? "Enfoque" : "Normal"))
    eAlpha.OnEvent("Change",_PtsAlphaChange)
    eAlphaF.OnEvent("Change",_PtsAlphaFChange)
    bRei.OnEvent("Click",_PtsReiniciar)
    bOk.OnEvent("Click",_PtsCerrar)
    g.OnEvent("Close",_PtsCerrar)
    g.OnEvent("Escape",_PtsCerrar)
    g.Show("AutoSize")
    _PtsRefrescar()
    _PtsEvFilas()
    lv.Modify(1,"Select Focus")
    _PtsSel(lv,1,true)
    lvEv.Modify(1,"Select Focus")
    _PtsEvSel(lvEv,1,true)
}
; ===== Catálogo de zonas (todo en función con static: el código global de aquí no se auto-ejecuta) =====
_PtsZonaDefs() {
    static defs := 0
    if IsObject(defs)
        return defs
    defs := []
    Loop 3
        defs.Push({k:"IzqB" A_Index,n:"Panel izq · B" A_Index,t:"caja",p:3 + (A_Index - 1) * 4,zi:A_Index,lado:"izq",c:"2ECC71"})
    Loop 3
        defs.Push({k:"DerB" A_Index,n:"Panel der · B" A_Index,t:"caja",p:15 + (A_Index - 1) * 4,zi:A_Index,lado:"der",c:"3498DB"})
    defs.Push({k:"Historial",n:"Franja de historial",t:"hist",c:"E67E22"})
    defs.Push({k:"ToggleIzq",n:"Ocultar/mostrar panel izq (P1)",t:"punto",p:1,c:"E74C3C"})
    defs.Push({k:"ToggleDer",n:"Ocultar/mostrar panel der (P2)",t:"punto",p:2,c:"E74C3C"})
    defs.Push({k:"ZonaSegura",n:"Zona segura del cursor (P29)",t:"punto",p:29,c:"F1C40F"})
    defs.Push({k:"Estab",n:"Deslizador de estabilización",t:"estab",c:ESTAB_COLOR})
    defs.Push({k:"EstabFoco",n:"Deslizador de enfoque (Shift+E)",t:"estabF",c:"FF8800"})
    defs.Push({k:"HUD_Alta",n:"Aviso HUD · Zona 1 (Alta)",t:"hud",c:"FF4D6D"})
    defs.Push({k:"HUD_Media",n:"Aviso HUD · Zona 2 (Media)",t:"hud",c:"FFB703"})
    defs.Push({k:"HUD_Baja",n:"Aviso HUD · Zona 3 (Baja)",t:"hud",c:"9B59B6"})
    return defs
}
_PtsDefPorClave(k) {
    for d in _PtsZonaDefs() {
        if (d.k = k)
            return d
    }
    return 0
}
_PtsEventosDefs() {
    static evs := 0
    if IsObject(evs)
        return evs
    evs := [
        ["pluma", "Plumilla / Pincel Tinta (Q)"],
        ["aerografo", "Aerógrafo Principal (W)"],
        ["aerografo_alpha", "Aerógrafo Alpha Borrador (W rápido)"],
        ["pincel_suave", "Pincel Suave (Alt + Q)"],
        ["pincel_duro", "Pincel Duro (Pen + Q)"],
        ["difu_mixer", "Difuminador Mezclador (Pen + W)"],
        ["opc_presion", "Opacidad por Presión (Alt + W)"],
        ["borrador", "Borrador de Capas (E)"],
        ["borrador_suave", "Borrador Suave (Soft Eraser 2)"],
        ["borrador_lazo", "Borrador de Lazo (Pen + E)"],
        ["smudge", "Dedo / Smudge (P)"],
        ["smear", "Smear Mezcla (Smear 1 y 2)"],
        ["color_mix", "Mezcla de Color (D)"],
        ["color_primario", "Color Primario (Q rápido frontal)"],
        ["color_secundario", "Color Secundario (Q rápido alterno)"],
        ["color_alpha", "Alpha Transparente (C)"],
        ["relleno", "Bote de Pintura / Relleno (V)"],
        ["lazo", "Herramienta Lazo"],
        ["seleccion", "Selección Marquee (M)"],
        ["area_color", "Área con Color (S rápido)"],
        ["deseleccion", "Deselección (Ctrl + D)"],
        ["reseleccion", "Reselección (Ctrl + Shift + D)"],
        ["inv_seleccion", "Invertir Selección (Ctrl + Shift + I)"],
        ["shift_sostenido", "Shift Sostenido / Regla Recta (Pen + F)"],
        ["flip_horizontal", "Volteo Horizontal del Lienzo (Space)"],
        ["rotar_lienzo", "Rotación de Lienzo (R)"],
        ["zoom_lienzo", "Zoom de Lienzo (Z)"],
        ["regla_ocultar", "Ocultar / Mostrar Reglas (!T / T)"],
        ["capa_visibilidad", "Visibilidad de Capa Activa"],
        ["capa_buscar", "Buscar Capas (1/3)"],
        ["capa_color", "Cambiar Color de Capa (2/3)"],
        ["capa_borrar_color", "Borrar Color de Capa (3/3)"],
        ["capa_referencia", "Capa de Referencia (Ref Layer)"],
        ["guardar", "Guardar Archivo .clip (Ctrl + S)"],
        ["deshacer", "Deshacer (Ctrl + Z)"],
        ["rehacer", "Rehacer (Ctrl + Y)"],
        ["copiar", "Copiar al Portapapeles (Ctrl + C)"],
        ["enfoque", "Modo Enfoque / Plegar Paneles (Tab / Shift + Esc)"],
        ["hover_paneles", "Hover de Paneles Desplegables (+W)"],
        ["history_lock", "Bloqueo de Franja Historial"],
        ["bloque_gui", "Fijar / Mover Botones del Companion"],
        ["gui_frente", "Botones al Frente / Solo en CSP"],
        ["estab_slider", "Deslizador de Estabilización"],
        ["estab_sync", "Sincronización de Estabilizador"],
        ["layout", "Guardar / Aplicar Layout de Paneles"],
        ["reload", "Recargar Script"]
    ]
    return evs
}
; ===== API pública para el motor de avisos (Claude 2 puede adoptarla sin tocar esta zona) =====
ObtenerRango(nombre) {
    global PERFIL
    v := IniRead(_PosGuiIniPath(),"Rangos" PERFIL,nombre,"")
    m := []
    if (v != "" && RegExMatch(v,"^\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*$",&m))
        return {x:Integer(m[1]),y:Integer(m[2]),w:Integer(m[3]),h:Integer(m[4])}
    return 0
}
HudConfigEvento(ev) {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "HudEventos" PERFIL
    f := StrLower(IniRead(ini,sec,"formato_" ev,"moderno"))
    z := StrLower(IniRead(ini,sec,"zona_" ev,"baja"))
    op := Trim(IniRead(ini,sec,"opacidad_" ev,""))
    if (f = "desactivado" || f = "ninguno" || f = "off" || f = "sin gui")
        f := "desactivado"
    else if (f != "bruto")
        f := "moderno"
    if (z != "alta" && z != "media")
        z := "baja"
    if (op != "100" && op != "70" && op != "40")
        op := (z = "alta") ? "70" : "70"
    return {formato:f,zona:z,opacidad:Integer(op)}
}
; ===== Lectura / escritura de zonas =====
_PtsEstabRect(foco) {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "Estab_p" PERFIL
    p := foco ? "f" : ""
    x := IniRead(ini,sec,p "x","")
    y := IniRead(ini,sec,p "y","")
    w := IniRead(ini,sec,p "w","")
    h := IniRead(ini,sec,p "h","")
    if (IsInteger(x) && IsInteger(y) && IsInteger(w) && IsInteger(h))
        return {x:Integer(x),y:Integer(y),w:Integer(w),h:Integer(h)}
    return {x:"",y:"",w:"",h:""}
}
_PtsRectDe(d) {
    global PUNTOS,ZONAS
    t := d.t
    if (t = "caja") {
        zs := (d.lado = "izq") ? ZONAS.izq : ZONAS.der
        z := zs[d.zi]
        return {x:z.x1,y:z.y1,w:z.x2 - z.x1 + 1,h:z.y2 - z.y1 + 1}
    }
    if (t = "hist") {
        z := ZONAS.hist
        return {x:z.x1,y:z.y1,w:z.x2 - z.x1 + 1,h:z.y2 - z.y1 + 1}
    }
    if (t = "punto") {
        rg := ObtenerRango(d.k)
        if (IsObject(rg) && IsInteger(rg.w) && rg.w > 0 && IsInteger(rg.h) && rg.h > 0)
            return rg
        return {x:PUNTOS[d.p][1],y:PUNTOS[d.p][2],w:"",h:""}
    }
    if (t = "estab" || t = "estabF")
        return _PtsEstabRect(t = "estabF")
    r := ObtenerRango(d.k)
    return IsObject(r) ? r : {x:"",y:"",w:"",h:""}
}
_PtsAplicarZona(d,r) {
    global PUNTOS,HIST_ALTO,PERFIL
    t := d.t
    msg := ""
    if (t = "caja") {
        if (r.w < 6 || r.h < 6) {
            ptsEd.st.Value := "Rango demasiado pequeño (mín. 6×6 px)."
            return false
        }
        x2 := r.x + r.w - 1
        y2 := r.y + r.h - 1
        esq := [[r.x,r.y],[x2,r.y],[r.x,y2],[x2,y2]]
        for k,c in esq {
            PUNTOS[d.p + k - 1][1] := c[1]
            PUNTOS[d.p + k - 1][2] := c[2]
        }
        msg := r.w "×" r.h " en (" r.x "," r.y ")"
    } else if (t = "hist") {
        if (r.w < 6 || r.h < 1) {
            ptsEd.st.Value := "Rango de historial demasiado pequeño."
            return false
        }
        PUNTOS[27][1] := r.x
        PUNTOS[27][2] := r.y
        PUNTOS[28][1] := r.x + r.w - 1
        PUNTOS[28][2] := r.y
        HIST_ALTO := Max(0,r.h - 1)
        msg := r.w "×" r.h " en (" r.x "," r.y ")"
    } else if (t = "punto") {
        w := (IsInteger(r.w) && r.w > 0) ? r.w : 0
        h := (IsInteger(r.h) && r.h > 0) ? r.h : 0
        px := (w > 0) ? (r.x + w // 2) : r.x
        py := (h > 0) ? (r.y + h // 2) : r.y
        PUNTOS[d.p][1] := px
        PUNTOS[d.p][2] := py
        if (w > 0 && h > 0)
            IniWrite(r.x "," r.y "," w "," h,_PosGuiIniPath(),"Rangos" PERFIL,d.k)
        else
            IniWrite(px "," py,_PosGuiIniPath(),"Rangos" PERFIL,d.k)
        msg := (w > 0) ? (w "×" h " en (" r.x "," r.y ")") : ("(" px "," py ")")
    } else if (t = "estab") {
        if !_EstabTamanoValido(r.w,r.h) {
            ptsEd.st.Value := "Zona demasiado pequeña (mín. 14 px de grosor y 60 de largo)."
            return false
        }
        if !_EstabAplicarRect(r.x,r.y,r.w,r.h) {
            ini := _PosGuiIniPath()
            sec := "Estab_p" PERFIL
            IniWrite(r.x,ini,sec,"x")
            IniWrite(r.y,ini,sec,"y")
            IniWrite(r.w,ini,sec,"w")
            IniWrite(r.h,ini,sec,"h")
        }
        msg := r.w "×" r.h " (" ((r.w > r.h) ? "horizontal" : "vertical") ")"
    } else if (t = "estabF") {
        if !_EstabTamanoValido(r.w,r.h) {
            ptsEd.st.Value := "Zona demasiado pequeña (mín. 14 px de grosor y 60 de largo)."
            return false
        }
        _EstabFocoGuardarRect(r.x,r.y,r.w,r.h)
        msg := r.w "×" r.h " (" ((r.w > r.h) ? "horizontal" : "vertical") "). Aparece con Shift+E"
        try _EstabFocoPrevisualizar()
    } else {
        if (r.w < 6 || r.h < 6) {
            ptsEd.st.Value := "Rango demasiado pequeño (mín. 6×6 px)."
            return false
        }
        IniWrite(r.x "," r.y "," r.w "," r.h,_PosGuiIniPath(),"Rangos" PERFIL,d.k)
        msg := r.w "×" r.h " en (" r.x "," r.y ")"
    }
    _PtsRefrescar()
    ptsEd.st.Value := d.n " guardado: " msg
    _SonarUI("calib")
    return true
}
_RgGuardarMirror() {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "Rangos" PERFIL
    IniWrite("x,y,ancho,alto en px de pantalla virtual (puntos: x,y). Derivado de P1..P32; HUD_Alta y HUD_Media son propios.",ini,sec,"_formato")
    for d in _PtsZonaDefs() {
        if (d.t = "estab" || d.t = "estabF" || d.t = "hud")
            continue
        r := _PtsRectDe(d)
        if (d.t = "punto")
            v := r.x "," r.y
        else
            v := r.x "," r.y "," r.w "," r.h
        IniWrite(v,ini,sec,d.k)
    }
}
; ===== Dibujo con lápiz =====
_PtsDibujarRango(texto,color := "9A7BFF",permitirPunto := false) {
    if (ptsEd.dibujando)
        return 0
    ptsEd.dibujando := true
    ov := 0
    tip := 0
    tipTxt := 0
    pv := 0
    ok := false
    cancelado := false
    x0 := 0
    y0 := 0
    rx := 0
    ry := 0
    rw := 0
    rh := 0
    try {
        try ptsEd.g.Hide()
        vx := SysGet(76)
        vy := SysGet(77)
        vw := SysGet(78)
        vh := SysGet(79)
        ov := Gui("+AlwaysOnTop -Caption +ToolWindow -DPIScale","")
        ov.BackColor := "0B0B14"
        ov.Show("x" vx " y" vy " w" vw " h" vh)
        WinSetTransparent(80,"ahk_id " ov.Hwnd)
        mon := ObtenerMonitorCSP()
        tip := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale","")
        tip.BackColor := "1E1E2E"
        tip.SetFont("s11 bold cWhite","Segoe UI")
        tipTxt := tip.AddText("x12 y8 w900 h26 Center",texto)
        tip.Show("x" (mon.x + (mon.w - 924) // 2) " y" (mon.y + 40) " w924 h42 NoActivate")
        cur := Buffer(8,0)
        t0 := A_TickCount
        while !GetKeyState("LButton","P") {
            if (GetKeyState("Escape","P") || A_TickCount - t0 > 60000) {
                cancelado := true
                break
            }
            Sleep(10)
        }
        if !cancelado {
            DllCall("GetCursorPos","Ptr",cur)
            x0 := NumGet(cur,0,"int")
            y0 := NumGet(cur,4,"int")
            pv := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale","")
            pv.BackColor := color
            pv.Show("x" x0 " y" y0 " w4 h4 NoActivate")
            WinSetTransparent(150,"ahk_id " pv.Hwnd)
            rx := x0
            ry := y0
            rw := 4
            rh := 4
            ultW := -1
            ultH := -1
            while GetKeyState("LButton","P") {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                rx := Min(x0,mx)
                ry := Min(y0,my)
                rw := Max(4,Abs(mx - x0))
                rh := Max(4,Abs(my - y0))
                DllCall("SetWindowPos","Ptr",pv.Hwnd,"Ptr",-1,"int",rx,"int",ry,"int",rw,"int",rh,"uint",0x0010)
                if (rw != ultW || rh != ultH) {
                    ultW := rw
                    ultH := rh
                    tipTxt.Value := texto "   ·   " rw " × " rh
                }
                if GetKeyState("Escape","P") {
                    cancelado := true
                    break
                }
                Sleep(8)
            }
            if !cancelado
                ok := true
        }
    } finally {
        for gg in [pv,tip,ov] {
            if IsObject(gg)
                try gg.Destroy()
        }
        ptsEd.dibujando := false
    }
    KeyWait("Escape","T1")
    try ptsEd.g.Show()
    if !ok
        return 0
    if (permitirPunto && rw <= 8 && rh <= 8)
        return {x:x0,y:y0,w:0,h:0}
    return {x:rx,y:ry,w:rw,h:rh}
}
_PtsDibujarSel(encadenar := false) {
    defs := _PtsZonaDefs()
    i := ptsEd.sel
    if (i < 1 || i > defs.Length) {
        ptsEd.st.Value := "Selecciona primero una zona en la lista."
        return
    }
    Loop {
        d := defs[i]
        if (d.t = "punto")
            txt := "✏ " d.n "  ·  haz clic en el punto (o arrastra una caja)  ·  Esc = cancelar"
        else
            txt := "✏ " d.n "  ·  arrastra el lápiz para dibujar el rango  ·  Esc = cancelar"
        r := _PtsDibujarRango(txt,d.c,d.t = "punto")
        if !IsObject(r) {
            ptsEd.st.Value := "Dibujo cancelado."
            break
        }
        okz := _PtsAplicarZona(d,r)
        if (!okz || !encadenar || i >= defs.Length)
            break
        i += 1
        ptsEd.sel := i
        try ptsEd.lv.Modify(i,"Select Focus Vis")
    }
}
; ===== Tabla de zonas =====
_PtsCamposDe(i) {
    defs := _PtsZonaDefs()
    if (i < 1 || i > defs.Length)
        return
    d := defs[i]
    r := _PtsRectDe(d)
    ptsEd.eX.Value := r.x
    ptsEd.eY.Value := r.y
    ptsEd.eW.Value := r.w
    ptsEd.eH.Value := r.h
    esPunto := (d.t = "punto")
    ptsEd.eW.Enabled := !esPunto
    ptsEd.eH.Enabled := !esPunto
}
_PtsSel(ctrl,item,selected) {
    if (!selected || item < 1)
        return
    ptsEd.sel := item
    _PtsCamposDe(item)
    d := _PtsZonaDefs()[item]
    ptsEd.st.Value := d.n " — " ((d.t = "punto") ? "punto" : "rango") ". Dibuja con el lápiz o escribe los valores."
}
_PtsAplicarCampos(*) {
    defs := _PtsZonaDefs()
    i := ptsEd.sel
    if (i < 1 || i > defs.Length)
        return
    d := defs[i]
    x := Trim(ptsEd.eX.Value)
    y := Trim(ptsEd.eY.Value)
    w := Trim(ptsEd.eW.Value)
    h := Trim(ptsEd.eH.Value)
    if (!IsInteger(x) || !IsInteger(y)) {
        ptsEd.st.Value := "X e Y deben ser enteros."
        return
    }
    if (d.t != "punto" && (!IsInteger(w) || !IsInteger(h))) {
        ptsEd.st.Value := "Ancho y Alto deben ser enteros."
        return
    }
    r := {x:Integer(x),y:Integer(y),w:(IsInteger(w) ? Integer(w) : 0),h:(IsInteger(h) ? Integer(h) : 0)}
    _PtsAplicarZona(d,r)
}
_PtsRefrescar() {
    RecalcularZonas()
    for i,d in _PtsZonaDefs() {
        r := _PtsRectDe(d)
        ptsEd.lv.Modify(i,"",d.n,(d.t = "punto") ? "Punto" : "Rango",r.x,r.y,r.w,r.h)
    }
    if (ptsEd.sel >= 1)
        _PtsCamposDe(ptsEd.sel)
}
_PtsDesplazar(*) {
    dx := Trim(ptsEd.dx.Value)
    dy := Trim(ptsEd.dy.Value)
    if (!IsInteger(dx) || !IsInteger(dy)) {
        ptsEd.st.Value := "ΔX y ΔY deben ser enteros."
        return
    }
    dx := Integer(dx)
    dy := Integer(dy)
    for p in PUNTOS {
        p[1] += dx
        p[2] += dy
    }
    _PtsRefrescar()
    ptsEd.dx.Value := "0"
    ptsEd.dy.Value := "0"
    ptsEd.st.Value := "Desplazados: ΔX=" dx " ΔY=" dy
}
_PtsDefecto(*) {
    global HIST_ALTO,PUNTOS
    ptsEd.g.Opt("+OwnDialogs")
    if (MsgBox("¿Restablecer todos los puntos de este perfil a los valores por defecto?","Por defecto","YesNo Icon?") != "Yes")
        return
    PUNTOS := PuntosPorDefecto()
    HIST_ALTO := 104
    _PtsRefrescar()
    ptsEd.st.Value := "Cargados los rangos por defecto (se guardan con 💾)."
}
; ===== Eventos / HUD =====
_PtsZonaTxt(z) {
    return (z = "alta") ? "Alta" : ((z = "media") ? "Media" : "Baja")
}
_PtsEvLeer() {
    ptsEd.cfg := Map()
    for ev in _PtsEventosDefs() {
        c := HudConfigEvento(ev[1])
        ptsEd.cfg[ev[1]] := {f:c.formato,z:c.zona,op:c.opacidad}
    }
}
_PtsEvGuardar(k,f,z,op) {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "HudEventos" PERFIL
    IniWrite(f,ini,sec,"formato_" k)
    IniWrite(z,ini,sec,"zona_" k)
    IniWrite(op,ini,sec,"opacidad_" k)
    ptsEd.cfg[k] := {f:f,z:z,op:op}
}
_PtsEvFilas() {
    for i,ev in _PtsEventosDefs() {
        c := ptsEd.cfg[ev[1]]
        ptsEd.lvEv.Modify(i,"",ev[2],StrTitle(c.f),_PtsZonaTxt(c.z),c.op "%")
    }
}
_PtsEvObtenerSeleccionados(lv) {
    filas := []
    row := 0
    Loop {
        row := lv.GetNext(row)
        if (!row)
            break
        filas.Push(row)
    }
    return filas
}
_PtsEvSel(ctrl,item,selected) {
    if (!selected || item < 1)
        return
    ptsEd.evSel := item
    filas := _PtsEvObtenerSeleccionados(ctrl)
    if (filas.Length > 1) {
        ptsEd.st.Value := filas.Length " eventos seleccionados. Cambia formato, prioridad u opacidad para aplicarlo a todos."
        return
    }
    c := ptsEd.cfg[_PtsEventosDefs()[item][1]]
    ptsEd.ddF.Choose((c.f = "desactivado") ? 3 : ((c.f = "bruto") ? 2 : 1))
    ptsEd.ddZ.Choose((c.z = "alta") ? 1 : ((c.z = "media") ? 2 : 3))
    opIdx := (c.op = 100) ? 1 : ((c.op = 40) ? 3 : 2)
    ptsEd.ddOp.Choose(opIdx)
}
_PtsEvCambio(*) {
    filas := _PtsEvObtenerSeleccionados(ptsEd.lvEv)
    if (filas.Length = 0 && ptsEd.evSel >= 1)
        filas := [ptsEd.evSel]
    if (filas.Length = 0)
        return
    f := (ptsEd.ddF.Value = 3) ? "desactivado" : ((ptsEd.ddF.Value = 2) ? "bruto" : "moderno")
    z := ["alta","media","baja"][Max(1,ptsEd.ddZ.Value)]
    op := [100,70,40][Max(1,ptsEd.ddOp.Value)]
    for row in filas {
        ev := _PtsEventosDefs()[row]
        _PtsEvGuardar(ev[1],f,z,op)
    }
    _PtsEvFilas()
    if (filas.Length = 1) {
        ev := _PtsEventosDefs()[filas[1]]
        ptsEd.st.Value := ev[2] ": " StrTitle(f) " · " _PtsZonaTxt(z) " (" op "%)"
    } else {
        ptsEd.st.Value := filas.Length " eventos actualizados en conjunto: " StrTitle(f) " · " _PtsZonaTxt(z) " (" op "%)"
    }
}
_PtsEvProbar(*) {
    filas := _PtsEvObtenerSeleccionados(ptsEd.lvEv)
    i := (filas.Length > 0) ? filas[1] : ptsEd.evSel
    if (i < 1 || i > _PtsEventosDefs().Length)
        return
    ev := _PtsEventosDefs()[i]
    c := ptsEd.cfg[ev[1]]
    if (c.f = "desactivado") {
        ToolTip("🔇 Evento DESACTIVADO (sin GUI en pantalla)")
        SetTimer(() => ToolTip(), -1500)
        return
    }
    zNum := (c.z = "alta") ? 1 : ((c.z = "media") ? 2 : 3)
    nombre := Trim(RegExReplace(ev[2],"\s*\(.*\)\s*$"))
    try MostrarAvisoUI(c.f, nombre, "EVENTO: " StrUpper(ev[1]), zNum, "00E5FF", 2000, c.op)
}
; ===== Sistema y perfiles =====
_PtsAlphaChange(*) {
    global ESTAB_ALPHA_H,PERFIL
    v := Trim(ptsEd.eAlpha.Value)
    if (!IsInteger(v) || Integer(v) < 10 || Integer(v) > 100)
        return
    ESTAB_ALPHA_H := Round(Integer(v) * 2.55)
    IniWrite(Integer(v),_PosGuiIniPath(),"Estab_p" PERFIL,"alphaH")
    _EstabAlpha(false)
}
_PtsAlphaFChange(*) {
    global ESTAB_ALPHA_F,PERFIL
    v := Trim(ptsEd.eAlphaF.Value)
    if (!IsInteger(v) || Integer(v) < 10 || Integer(v) > 100)
        return
    ESTAB_ALPHA_F := Round(Integer(v) * 2.55)
    IniWrite(Integer(v),_PosGuiIniPath(),"Estab_p" PERFIL,"alphaF")
    if estabGui.foco
        _EstabAlpha(false)
}
_PtsReiniciar(*) {
    GuardarPuntos()
    _RgGuardarMirror()
    ToolTip("🔄 Reiniciando script…")
    Sleep(250)
    Reload()
}
_PtsMoverBotones(ctrl) {
    _ToggleBloqueo()
    ctrl.Text := panelBlk.locked ? "🔓 Mover botones" : "🔒 Fijar botones"
}
_PtsReubicar(*) {
    ReubicarBotones()
    ptsEd.st.Value := "Botones reubicados para este perfil."
}
ReubicarBotones() {
    mon := ObtenerMonitorCSP()
    F := 0x0001 | 0x0004 | 0x0010
    ancho := _E(104) * 4 + _E(31) * 2 + PANEL_GAP * 5
    x0 := mon.x + (mon.w - ancho) // 2
    y0 := mon.y + Round(mon.h * 0.02) + 42 + 4
    sx := x0
    for g in [dsGui,ccGui,arGui,lockGui,frenteGui,estabBtnGui] {
        if !IsObject(g.g)
            continue
        DllCall("SetWindowPos","Ptr",g.g.Hwnd,"Ptr",0,"int",sx,"int",y0,"int",0,"int",0,"uint",F)
        WinGetPos(&gx,&gy,&gw,&gh,"ahk_id " g.g.Hwnd)
        sx += gw + PANEL_GAP
    }
    if (IsObject(estabGui.g) && !estabGui.horiz) {
        WinGetPos(&lkX,&lkY,&lkW,&lkH,"ahk_id " lockGui.g.Hwnd)
        ex := Min(lkX + lkW + PANEL_GAP,mon.x + mon.w - _E(220))
        DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",0,"int",ex,"int",lkY,"int",0,"int",0,"uint",F)
    }
    WinGetPos(&gx,&gy,&gw,&dsH,"ahk_id " dsGui.g.Hwnd)
    hcY := y0 + dsH + PANEL_GAP
    DllCall("SetWindowPos","Ptr",hcGui.g.Hwnd,"Ptr",0,"int",x0,"int",hcY,"int",0,"int",0,"uint",F)
    WinGetPos(&gx,&gy,&gw,&hcH,"ahk_id " hcGui.g.Hwnd)
    ry := hcY + hcH + PANEL_GAP
    DllCall("SetWindowPos","Ptr",reloadGui.g.Hwnd,"Ptr",0,"int",x0,"int",ry,"int",0,"int",0,"uint",F)
    WinGetPos(&gx,&gy,&rw,&rh,"ahk_id " reloadGui.g.Hwnd)
    DllCall("SetWindowPos","Ptr",puntosGui.g.Hwnd,"Ptr",0,"int",x0 + rw + PANEL_GAP,"int",ry,"int",0,"int",0,"uint",F)
    GuardarPosicionGUI("PanelBlock",dsGui.g.Hwnd)
    GuardarPosicionGUI("Slider",dsGui.g.Hwnd)
    GuardarPosicionGUI("Circle",ccGui.g.Hwnd)
    GuardarPosicionGUI("Quick",arGui.g.Hwnd)
    GuardarPosicionGUI("Lock",lockGui.g.Hwnd)
    GuardarPosicionGUI("Frente",frenteGui.g.Hwnd)
    GuardarPosicionGUI("EstabBtn",estabBtnGui.g.Hwnd)
    GuardarPosicionGUI("HC",hcGui.g.Hwnd)
    _GuardarOffsetHC()
    GuardarPosicionGUI("Reload",reloadGui.g.Hwnd)
    GuardarPosicionGUI("PuntosBtn",puntosGui.g.Hwnd)
    GuardarPosicionGUI("Estab",estabGui.g.Hwnd)
}
_PtsCambiarPerfil(ctrl,*) {
    nuevo := ctrl.Value
    if (nuevo < 1 || nuevo = PERFIL)
        return
    GuardarPuntos(false)
    _RgGuardarMirror()
    ini := _PosGuiIniPath()
    IniWrite(nuevo,ini,"Perfil","actual")
    IniWrite(_FirmaMonitores(),ini,"Perfil","ultimaFirma")
    OcultarZonasCalibracion()
    ToolTip("🔄 Perfil: " PERFILES[nuevo])
    Sleep(300)
    Reload()
}
_PtsCerrar(*) {
    if (ptsEd.dibujando)
        return
    GuardarPuntos()
    _RgGuardarMirror()
    OcultarZonasCalibracion()
    recargar := false
    try {
        v := Trim(ptsEd.eEsc.Value)
        if (IsNumber(v) && Number(v) >= 40 && Number(v) <= 200 && Abs(Number(v) - ESC * 100) >= 0.5) {
            IniWrite(Round(Number(v)),_PosGuiIniPath(),"Puntos" PERFIL,"escala")
            recargar := true
        }
    }
    try {
        v := Trim(ptsEd.eEscAv.Value)
        if (IsNumber(v) && Number(v) >= 40 && Number(v) <= 250 && Abs(Number(v) - AVISO_ESC * 100) >= 0.5) {
            IniWrite(Round(Number(v)),_PosGuiIniPath(),"Puntos" PERFIL,"escalaAvisos")
            recargar := true
        }
    }
    try ptsEd.g.Destroy()
    ptsEd.g := 0
    ptsEd.sel := 0
    if (recargar) {
        ToolTip("🔄 Aplicando escala…")
        Sleep(250)
        Reload()
    }
    _SonarUI("calib")
}
; ===== Vista previa de zonas (misma firma) =====
_PtsToggleVerZonas(*) {
    if (ptsEd.ovl.Length > 0)
        OcultarZonasCalibracion()
    else
        MostrarZonasCalibracion(0)
}
MostrarZonasCalibracion(ms := 0) {
    OcultarZonasCalibracion()
    for i, z in ZONAS.izq
        ptsEd.ovl.Push(_CrearRectOverlay(z.x1,z.y1,z.x2 - z.x1 + 1,z.y2 - z.y1 + 1,"2ECC71","IZQ B" i))
    for i, z in ZONAS.der
        ptsEd.ovl.Push(_CrearRectOverlay(z.x1,z.y1,z.x2 - z.x1 + 1,z.y2 - z.y1 + 1,"3498DB","DER B" i))
    h := ZONAS.hist
    ptsEd.ovl.Push(_CrearRectOverlay(h.x1,h.y1,h.x2 - h.x1 + 1,h.y2 - h.y1 + 1,"E67E22","HISTORIAL"))
    nombresHud := Map("HUD_Alta","ZONA 1 · ALTA","HUD_Media","ZONA 2 · MEDIA","HUD_Baja","ZONA 3 · BAJA","Estab","ESTABILIZADOR","EstabFoco","ESTAB FOCO")
    for k in ["HUD_Alta","HUD_Media","HUD_Baja","Estab","EstabFoco"] {
        d := _PtsDefPorClave(k)
        if !IsObject(d)
            continue
        r := _PtsRectDe(d)
        if (IsInteger(r.x) && IsInteger(r.y) && IsInteger(r.w) && IsInteger(r.h) && r.w > 0 && r.h > 0)
            ptsEd.ovl.Push(_CrearRectOverlay(r.x,r.y,r.w,r.h,d.c,nombresHud.Has(k) ? nombresHud[k] : d.n))
    }
    ptsP := Map(1,"P1",2,"P2",29,"P29")
    for i in [1,2,29] {
        col := (i = 29) ? "F1C40F" : "E74C3C"
        lbl := ptsP.Has(i) ? ptsP[i] : ("P" i)
        dClv := (i = 1) ? "ToggleIzq" : ((i = 2) ? "ToggleDer" : "ZonaSegura")
        d := _PtsDefPorClave(dClv)
        r := IsObject(d) ? _PtsRectDe(d) : 0
        if (IsObject(r) && IsInteger(r.w) && r.w > 0 && IsInteger(r.h) && r.h > 0)
            ptsEd.ovl.Push(_CrearRectOverlay(r.x,r.y,r.w,r.h,col,lbl))
        else
            ptsEd.ovl.Push(_CrearRectOverlay(PUNTOS[i][1] - 5,PUNTOS[i][2] - 5,10,10,col,lbl))
    }
    if (ms > 0)
        SetTimer(OcultarZonasCalibracion,-ms)
    if (IsObject(ptsEd) && HasProp(ptsEd,"bVer") && IsObject(ptsEd.bVer))
        ptsEd.bVer.Text := "❌ Ocultar zonas"
}
OcultarZonasCalibracion() {
    try SetTimer(OcultarZonasCalibracion,0)
    for g in ptsEd.ovl {
        try {
            if IsObject(g)
                g.Destroy()
        }
    }
    ptsEd.ovl := []
    if (IsObject(ptsEd) && HasProp(ptsEd,"bVer") && IsObject(ptsEd.bVer))
        ptsEd.bVer.Text := "👁 Ver zonas"
}
_CrearRectOverlay(x,y,w,h,color,texto := "") {
    ow := Max(w,4)
    oh := Max(h,4)
    g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale","")
    g.BackColor := color
    if (texto != "") {
        g.SetFont("s8 bold","Segoe UI")
        tw := Max(ow,28)
        th := Max(oh,16)
        tx := (ow - tw) // 2
        ty := (oh - th) // 2
        g.Add("Text","x" tx " y" ty " w" tw " h" th " BackgroundTrans cFFFFFF +0x200 Center",texto)
    }
    g.Show("x" x " y" y " w" ow " h" oh " NoActivate")
    WinSetTransparent(160,g)
    return g
}
_SetIcono(ctrl,nombre,esON := false) {
    static ultima := Map()
    if !IsObject(ctrl)
        return
    ruta := _RutaIcono(nombre)
    if (ruta != "") {
        if (ultima.Get(ctrl,"") = ruta)
            return
        try {
            ctrl.Value := ruta
            ultima[ctrl] := ruta
        }
        return
    }
    try ultima.Delete(ctrl)
    cod := _Glifo(nombre)
    if cod
        _Glifizar(ctrl,cod,esON)
}
_Glifizar(ctrl,cod,esON) {
    if !IsObject(ctrl)
        return false
    try {
        ctrl.Value := Chr(cod)
        ctrl.SetFont("s" _E(12) " c" _ColorIcono(esON),"Segoe Fluent Icons")
        return true
    }
    return false
}
_ColorIcono(esON) {
    ; El icono va siempre un punto por encima del label: FFFFFF en ON para que
    ; un glifo fino de ~15 px se lea sobre 636D83; icon.off (B2B2B2 por defecto)
    ; en OFF: legible sobre surface.off y distinto del ON de un vistazo.
    return esON ? "FFFFFF" : _Tema("color","icon.off","B2B2B2")
}
_Glifo(nombre) {
    static mapa := Map(
        "slider_on",0xE9E9,  "slider_off",0xE9E9,
        "circle_on",0xE790,  "circle_off",0xE790,
        "quick_on",0xE71D,   "quick_off",0xE71D,
        "hist_on",0xE81C,    "hist_off",0xE81C,
        "lock_closed",0xE72E,"lock_open",0xE785,
        "pin_on",0xE718,     "pin_off",0xE77A,
        "calib",0xE707,      "reload_g",0xE72C
    )
    return mapa.Has(nombre) ? mapa[nombre] : 0
}
_RutaIcono(nombre) {
    ; Respaldo real de iconos: PNG sueltos en disco. Si algun dia aparecen,
    ; se usan sin tocar codigo. La maquinaria base64 que habia aqui era un
    ; placeholder vacio que siempre devolvia false (se retiro en la ola 7;
    ; sigue en el .bak de esa ola si hiciera falta).
    arch := "csp2_" nombre ".png"
    ruta := A_ScriptDir "\iconos\" arch
    if FileExist(ruta)
        return ruta
    suelto := A_ScriptDir "\" arch
    if FileExist(suelto)
        return suelto
    return ""
}
; === F1-BEGIN ===
; F1: tema. Sin globales (lo posterior al primer #HotIf no ejecuta asignaciones globales).
_Tema(seccion,clave,defecto := "") {
    static cache := Map(), iniTema := A_ScriptDir "\theme.ini"
    if (seccion = "*") {   ; P3: _TemaRecargar() vacia la cache (selector de paleta)
        cache.Clear()
        return ""
    }
    k := seccion "|" clave
    if cache.Has(k)
        return cache[k]
    v := defecto
    try {
        leido := Trim(IniRead(iniTema,seccion,clave,""))
        if (leido != "" && _TemaValido(seccion,leido,defecto))
            v := (seccion = "color") ? StrUpper(leido) : leido
    }
    cache[k] := v
    return v
}
_TemaValido(seccion,v,defecto) {
    if (seccion = "color")
        return RegExMatch(v,"^[0-9A-Fa-f]{6}$") > 0
    if IsInteger(defecto)
        return IsInteger(v) && Integer(v) >= 0 && Integer(v) <= (seccion = "alpha" ? 255 : 4096)
    return !RegExMatch(v,"[\x3B\r\n]")
}
_FuenteInstalada(nombre) {
    static cache := Map()
    if cache.Has(nombre)
        return cache[nombre]
    hallada := false
    for raiz in ["HKLM","HKCU"] {
        if hallada
            break
        try {
            Loop Reg raiz "\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts","V" {
                if (InStr(A_LoopRegName,nombre) = 1) {
                    hallada := true
                    break
                }
            }
        }
    }
    cache[nombre] := hallada
    return hallada
}
_TemaFuente(rol := "texto") {
    if (rol = "iconos")
        cadena := ["Segoe Fluent Icons","Segoe MDL2 Assets"]
    else if (rol = "valor")
        cadena := [_Tema("type","family.value","Cascadia Mono"),"Consolas","Segoe UI"]
    else
        cadena := [_Tema("type","family","Segoe UI"),"Segoe UI"]
    for nombre in cadena {
        if _FuenteInstalada(nombre)
            return nombre
    }
    return "Segoe UI"
}
_RolDeHex(hex) {
    static m := Map(
        "00E5FF","info","1C6EA4","info","1A5276","info","1A2E5C","info",
        "44DD88","ok","1E8449","ok","27AE60","ok","51D67B","ok",
        "1A5C2A","ok","32CD32","ok","2ECC71","ok","FF6B00","warn",
        "FF8C42","warn","AA8844","warn","FFAA33","warn","FF6F61","warn",
        "FF4444","danger","C0392B","danger","E74C3C","danger","922B21","danger",
        "9A7BFF","estab","AA44FF","estab","6C3483","estab","1A1A2E","neutral",
        "888888","neutral","555555","neutral","9AA7C7","neutral","2B3B32","neutral",
        "222222","neutral","EEEEEE","neutral","424949","neutral"
    )
    h := StrUpper(hex)
    return m.Has(h) ? m[h] : ""
}
; Identidad hasta que theme.ini tenga [fx] roles = 1. Los "neutral" nunca se mapean (EEEEEE es fondo claro).
_AvisoColor(hex) {
    if (_Tema("fx","roles","0") != "1")
        return hex
    rol := _RolDeHex(hex)
    tokens := Map("info","accent.info","ok","accent.success","warn","accent.warn","danger","accent.danger","estab","accent.estab")
    return (rol != "" && tokens.Has(rol)) ? _Tema("color",tokens[rol],hex) : hex
}
; === F1-END ===
; === F2-BEGIN ===
_AlphaTema(clave, defecto) {
    v := _Tema("alpha", clave, String(defecto))
    return (IsInteger(v) && Integer(v) >= 0 && Integer(v) <= 255) ? Integer(v) : defecto
}
; Redondeo por región (sin DWM): esquinas limpias y SIN drop shadow.
; Mantiene el nombre y la clave "fx/corners" para no tocar los puntos de llamada.
;   corners: 0/otro = sin cambios | 1 = cuadrado | 2 = redondeo normal | 3 = redondeo pequeño
_DwmRedondear(hwnd) {
    v := _Tema("fx", "corners", "0")
    if !(IsInteger(v) && Integer(v) >= 1 && Integer(v) <= 3)
        return false
    v := Integer(v)

    ; Anular cualquier sombra residual del frame DWM (atributo 2 = NCRENDERING_POLICY, 1 = DISABLED)
    buf := Buffer(4, 0)
    NumPut("int", 1, buf)
    DllCall("dwmapi\DwmSetWindowAttribute", "Ptr", hwnd, "UInt", 2, "Ptr", buf, "UInt", 4)

    ; v=1 → quitar región (cuadrado)
    if (v = 1) {
        DllCall("SetWindowRgn", "Ptr", hwnd, "Ptr", 0, "Int", true)
        return true
    }

    ; Radio en px; el 3er/4to parámetro de CreateRoundRectRgn es el DIÁMETRO (2*radio)
    radio := (v = 2) ? 6 : 3
    GetWindowRectSize(hwnd, &w, &h)
    if (w <= 0 || h <= 0)
        return false

    ; right/bottom son exclusivos → +1
    hRgn := DllCall("gdi32\CreateRoundRectRgn"
        , "Int", 0, "Int", 0, "Int", w + 1, "Int", h + 1
        , "Int", radio * 2, "Int", radio * 2, "Ptr")
    if !hRgn
        return false

    ; Tras SetWindowRgn el sistema es dueño de hRgn: NO llamar DeleteObject
    return DllCall("SetWindowRgn", "Ptr", hwnd, "Ptr", hRgn, "Int", true) != 0
}

GetWindowRectSize(hwnd, &w, &h) {
    rc := Buffer(16, 0)
    if !DllCall("GetWindowRect", "Ptr", hwnd, "Ptr", rc) {
        w := h := 0
        return
    }
    w := NumGet(rc, 8, "Int") - NumGet(rc, 0, "Int")
    h := NumGet(rc, 12, "Int") - NumGet(rc, 4, "Int")
}
; D7 (chip interior) cerrado en la ola 7: el redondeo se hace con _DwmRedondear sobre
; la ventana, no con regiones en controles hijos. PillRegion() se retiro por no tener
; ningun consumidor (0 referencias) y no ser fiable en hijos (spike ola 0).
; === F2-END ===
; === F3-BEGIN ===
; F3: el slider del panel se pinta con GDI+ sobre el propio cliente: píldora hundida,
;     relleno de valor y knob con borde, todo con antialias real. Los únicos hijos son
;     valorTxt y grip, que se repintan tras el canvas.
;     Se dibuja a demanda con GetDC (valor, bloqueo, visibilidad, foco) y se rehace
;     cuando algo cambia; sin WM_PAINT (ver la nota de la ola 7 arriba). Coste ~34 ms.
;     El panel se repinta con _EstabDibujar() tras cada cambio de estado.
_EstabGdipIniciar() {
    static iniciado := false
    if iniciado
        return
    info := Buffer(A_PtrSize = 8 ? 24 : 16,0)
    NumPut("uint",1,info,0)
    tok := 0
    if (DllCall("gdiplus\GdiplusStartup","ptr*", &tok,"ptr",info,"ptr",0,"int") = 0)
        iniciado := true
}
_ArgbDeHex(hex,alfa) => (alfa << 24) | Integer("0x" hex)
_EstabPildora(x,y,an,al,radio) {
    ruta := 0
    DllCall("gdiplus\GdipCreatePath","int",0,"ptr*", &ruta,"int")
    d := radio * 2.0
    DllCall("gdiplus\GdipAddPathArc","ptr",ruta,"float",x,"float",y,"float",d,"float",d,"float",180,"float",90,"int")
    DllCall("gdiplus\GdipAddPathArc","ptr",ruta,"float",x + an - d,"float",y,"float",d,"float",d,"float",270,"float",90,"int")
    DllCall("gdiplus\GdipAddPathArc","ptr",ruta,"float",x + an - d,"float",y + al - d,"float",d,"float",d,"float",0,"float",90,"int")
    DllCall("gdiplus\GdipAddPathArc","ptr",ruta,"float",x,"float",y + al - d,"float",d,"float",d,"float",90,"float",90,"int")
    DllCall("gdiplus\GdipClosePathFigure","ptr",ruta,"int")
    return ruta
}
_EstabRellenar(gfx,ruta,hex,alfa := 255) {
    pincel := 0
    DllCall("gdiplus\GdipCreateSolidFill","uint",_ArgbDeHex(hex,alfa),"ptr*", &pincel,"int")
    DllCall("gdiplus\GdipFillPath","ptr",gfx,"ptr",pincel,"ptr",ruta,"int")
    DllCall("gdiplus\GdipDeleteBrush","ptr",pincel,"int")
}
_EstabTrazar(gfx,ruta,hex,grosor) {
    lapiz := 0
    DllCall("gdiplus\GdipCreatePen1","uint",_ArgbDeHex(hex,255),"float",grosor,"int",2,"ptr*", &lapiz,"int")
    DllCall("gdiplus\GdipDrawPath","ptr",gfx,"ptr",lapiz,"ptr",ruta,"int")
    DllCall("gdiplus\GdipDeletePen","ptr",lapiz,"int")
}
_EstabPanelPintar(gfx) {
    global estabGui, panelBlk, ESTAB_COLOR
    static fam := 0, fnt := 0, fmt := 0, fntTam := 0, rc := Buffer(16,0)
    val := estabGui.dibV
    if (val < 0)
        val := estabGui.valor
    val := Min(100,Max(0,Integer(val)))
    tx := Float(estabGui.trackX)
    ty := Float(estabGui.trackY)
    tw := Float(estabGui.trackW)
    th := Float(estabGui.trackH)
    bo := Float(estabGui.knobSize)
    plano := estabGui.horiz ? th : tw
    radio := plano / 2.0
    acento := _Tema("color","accent.estab",ESTAB_COLOR)
    surf := panelBlk.locked ? _Tema("color","surface.estabLocked","2B2B2B") : _Tema("color","surface.estabOpen","3A4260")
    bw := Float(_Tema("metric","estab.borderW","2"))
    estabGui.g.GetClientPos(,, &cw, &ch)
    DllCall("gdiplus\GdipGraphicsClear","ptr",gfx,"uint",_ArgbDeHex(_Tema("color","surface.estabEdge","15151B"),255),"int")
    ruta := _EstabPildora(bw,bw,cw - 2 * bw,ch - 2 * bw,8.0)
    _EstabRellenar(gfx,ruta,surf)
    DllCall("gdiplus\GdipDeletePath","ptr",ruta,"int")
    ruta := _EstabPildora(tx,ty + 1.0,tw,th,radio)
    _EstabRellenar(gfx,ruta,_Tema("color","track.pillOff","6A6A6A"),150)
    DllCall("gdiplus\GdipDeletePath","ptr",ruta,"int")
    ruta := _EstabPildora(tx,ty,tw,th,radio)
    _EstabRellenar(gfx,ruta,_Tema("color","track.off","3A3A45"))
    _EstabTrazar(gfx,ruta,_Tema("color","track.groove","14141A"),1.0)
    DllCall("gdiplus\GdipDeletePath","ptr",ruta,"int")
    largo := Round((estabGui.horiz ? tw : th) * val / 100.0)
    if (largo >= 2) {
        rr := Min(largo / 2.0,radio)
        ruta := estabGui.horiz ? _EstabPildora(tx,ty,largo,th,rr) : _EstabPildora(tx,ty + th - largo,tw,largo,rr)
        _EstabRellenar(gfx,ruta,acento)
        DllCall("gdiplus\GdipDeletePath","ptr",ruta,"int")
    }
    kx := estabGui.horiz ? (tx + tw * val / 100.0) : (tx + tw / 2.0)
    ky := estabGui.horiz ? (ty + th / 2.0) : (ty + th - th * val / 100.0)
    rw := Max(2.0,Min(3.0,bo * 0.07))
    dd := bo - 2.0
    sh := Max(1.0,bo * 0.045)
    ruta := _EstabPildora(kx - dd / 2.0,ky - dd / 2.0 + sh,dd,dd,dd / 2.0)
    _EstabRellenar(gfx,ruta,_Tema("color","knob.shadow","000000"),110)
    DllCall("gdiplus\GdipDeletePath","ptr",ruta,"int")
    ruta := _EstabPildora(kx - dd / 2.0,ky - dd / 2.0,dd,dd,dd / 2.0)
    _EstabRellenar(gfx,ruta,acento)
    DllCall("gdiplus\GdipDeletePath","ptr",ruta,"int")
    cara := dd - 2.0 * rw
    ruta := _EstabPildora(kx - cara / 2.0,ky - cara / 2.0,cara,cara,cara / 2.0)
    _EstabRellenar(gfx,ruta,_Tema("color","knob.face","FFFFFF"))
    DllCall("gdiplus\GdipDeletePath","ptr",ruta,"int")
    if (bo >= 30) {
        ; La cifra va dentro del knob en las DOS orientaciones. Antes solo se
        ; pintaba en vertical y en horizontal el numero vivia en valorTxt, que
        ; podia quedar oculto: la franja de Shift+E salia con circulo y sin cifra.
        ; Tamaño proporcional al disco: 36 px -> 11 (igual que antes), 55 -> 17,
        ; 78 -> 23. Se recrea la fuente solo cuando cambia el tamaño.
        tam := Max(9,Round(bo * 0.30))
        if (!fnt || tam != fntTam) {
            if (!fam)
                DllCall("gdiplus\GdipCreateFontFamilyFromName","str","Segoe UI","ptr",0,"ptr*", &fam,"int")
            if fnt
                DllCall("gdiplus\GdipDeleteFont","ptr",fnt,"int")
            DllCall("gdiplus\GdipCreateFont","ptr",fam,"float",tam,"int",1,"int",2,"ptr*", &fnt,"int")
            fntTam := tam
        }
        if (!fmt) {
            DllCall("gdiplus\GdipCreateStringFormat","int",0x5000,"ushort",0,"ptr*", &fmt,"int")
            DllCall("gdiplus\GdipSetStringFormatAlign","ptr",fmt,"int",1,"int")
            DllCall("gdiplus\GdipSetStringFormatLineAlign","ptr",fmt,"int",1,"int")
        }
        txt := val >= 100 ? "100" : val "%"
        NumPut("float",kx - cara / 2.0,"float",ky - cara / 2.0 + 0.5,"float",cara,"float",cara,rc)
        DllCall("gdiplus\GdipSetTextRenderingHint","ptr",gfx,"int",3,"int")
        pincel := 0
        DllCall("gdiplus\GdipCreateSolidFill","uint",_ArgbDeHex(_Tema("color","knob.text","23232B"),255),"ptr*", &pincel,"int")
        DllCall("gdiplus\GdipDrawString","ptr",gfx,"str",txt,"int",-1,"ptr",fnt,"ptr",rc,"ptr",fmt,"ptr",pincel,"int")
        DllCall("gdiplus\GdipDeleteBrush","ptr",pincel,"int")
    }
}
_EstabDibujar() {
    global estabGui
    if !IsObject(estabGui.g)
        return
    hwnd := estabGui.g.Hwnd
    if !DllCall("IsWindowVisible","ptr",hwnd)
        return
    estabGui.g.GetClientPos(,, &cw, &ch)
    if (cw <= 0 || ch <= 0)
        return
    hdc := DllCall("user32\GetDC","ptr",hwnd,"ptr")
    ; Doble bufer (offscreen bitmap): dibuja en memoria y transfiere con BitBlt instantaneo (0.1 ms)
    ; Elimina por completo el parpadeo causado por GdipGraphicsClear sobre el HDC visible
    memDC := DllCall("gdi32\CreateCompatibleDC","ptr",hdc,"ptr")
    hbm := DllCall("gdi32\CreateCompatibleBitmap","ptr",hdc,"int",cw,"int",ch,"ptr")
    obm := DllCall("gdi32\SelectObject","ptr",memDC,"ptr",hbm,"ptr")
    gfx := 0
    if (DllCall("gdiplus\GdipCreateFromHDC","ptr",memDC,"ptr*", &gfx,"int") = 0) {
        DllCall("gdiplus\GdipSetSmoothingMode","ptr",gfx,"int",4,"int")
        _EstabPanelPintar(gfx)
        DllCall("gdiplus\GdipDeleteGraphics","ptr",gfx,"int")
        DllCall("gdi32\BitBlt","ptr",hdc,"int",0,"int",0,"int",cw,"int",ch,"ptr",memDC,"int",0,"int",0,"uint",0x00CC0020)
    }
    DllCall("gdi32\SelectObject","ptr",memDC,"ptr",obm,"ptr")
    DllCall("gdi32\DeleteObject","ptr",hbm)
    DllCall("gdi32\DeleteDC","ptr",memDC)
    DllCall("user32\ReleaseDC","ptr",hwnd,"ptr",hdc,"int")
    DllCall("user32\ValidateRect","ptr",hwnd,"ptr",0,"int")
}
; _EstabOnPaint se retiro en la ola 7 (D): nunca se ejecutaba (ESTAB_REPINTADO := false).
; El codigo del handler se conserva en el .bak-ola7 si hubiera que recuperar WM_PAINT.
; === F3-END ===

; === P3-PALETA-BEGIN ===
; P3: Selector de paletas y temas armónicos para CSP Companion.
; Incluye 5 perfiles pre-diseñados (con réplica 1:1 de Clip Studio Paint).
; Guarda automáticamente en theme.ini y refresca todas las interfaces en vivo.

_TemaRecargar() => _Tema("*","*")

_TemaSelEst() {
    static est := {g:0, st:0}
    return est
}

_TemaPerfiles() {
    return [
        {
            nombre: "1. CSP Réplica Nativa (Oscuro CSP)",
            desc: "Idéntico a los paneles, barras y botones activos de Clip Studio Paint",
            swatches: ["636C82", "474747", "C8CEDE", "9A7BFF", "363636"],
            tokens: Map(
                "surface.on", "636C82",
                "surface.off", "474747",
                "surface.reload", "3B7A4B",
                "accent.estabSoft", "C8CEDE",
                "track.pillOff", "5A5A5A",
                "accent.estab", "9A7BFF",
                "text.primary", "FFFFFF",
                "text.idle", "B2B2B2",
                "surface.estabOpen", "363636",
                "surface.estabLocked", "282828",
                "track.off", "3A3A3A",
                "icon.off", "B8B8B8"
            )
        },
        {
            nombre: "2. Grafito Carbón (Minimalismo)",
            desc: "Tonos neutros puros sin tintes de color para máxima concentración",
            swatches: ["525252", "333333", "999999", "CCCCCC", "2A2A2A"],
            tokens: Map(
                "surface.on", "525252",
                "surface.off", "333333",
                "surface.reload", "405948",
                "accent.estabSoft", "999999",
                "track.pillOff", "454545",
                "accent.estab", "CCCCCC",
                "text.primary", "F0F0F0",
                "text.idle", "8A8A8A",
                "surface.estabOpen", "2A2A2A",
                "surface.estabLocked", "202020",
                "track.off", "333333",
                "icon.off", "8A8A8A"
            )
        },
        {
            nombre: "3. Slate Blue / Studio Pro (Wacom)",
            desc: "Azul pizarra digital moderno inspirado en herramientas de ilustración",
            swatches: ["4E6982", "343B47", "7AA2F7", "7DCFFF", "2A313D"],
            tokens: Map(
                "surface.on", "4E6982",
                "surface.off", "343B47",
                "surface.reload", "2E6B4F",
                "accent.estabSoft", "7AA2F7",
                "track.pillOff", "465162",
                "accent.estab", "7DCFFF",
                "text.primary", "FFFFFF",
                "text.idle", "A0AEC0",
                "surface.estabOpen", "2A313D",
                "surface.estabLocked", "1E232B",
                "track.off", "3B4452",
                "icon.off", "A0AEC0"
            )
        },
        {
            nombre: "4. OLED Alto Contraste",
            desc: "Negros profundos y barras luminosas para pantallas oscuras o dibujo con luz solar",
            swatches: ["737B8C", "1E1E1E", "E6EDF8", "B388FF", "141414"],
            tokens: Map(
                "surface.on", "737B8C",
                "surface.off", "1E1E1E",
                "surface.reload", "2E7D32",
                "accent.estabSoft", "E6EDF8",
                "track.pillOff", "3A3A3A",
                "accent.estab", "B388FF",
                "text.primary", "FFFFFF",
                "text.idle", "CCCCCC",
                "surface.estabOpen", "141414",
                "surface.estabLocked", "0A0A0A",
                "track.off", "2A2A2A",
                "icon.off", "CCCCCC"
            )
        },
        {
            nombre: "5. Sepia / Warm Paper (Estudio)",
            desc: "Tonos tierra orgánicos que descansan la vista emulando papel tradicional",
            swatches: ["6B5E57", "423B38", "D4B996", "E09F67", "36302D"],
            tokens: Map(
                "surface.on", "6B5E57",
                "surface.off", "423B38",
                "surface.reload", "556B2F",
                "accent.estabSoft", "D4B996",
                "track.pillOff", "524944",
                "accent.estab", "E09F67",
                "text.primary", "FFF8F0",
                "text.idle", "B8ABA0",
                "surface.estabOpen", "36302D",
                "surface.estabLocked", "292422",
                "track.off", "3D3734",
                "icon.off", "B8ABA0"
            )
        }
    ]
}

_AbrirSelectorTema() {
    est := _TemaSelEst()
    if IsObject(est.g) {
        try {
            est.g.Show()
            return
        }
        est.g := 0
    }
    ventana := Gui("+AlwaysOnTop -MaximizeBox","🎨 Paletas de Tema — Clip Studio Companion")
    ventana.SetFont("s9","Segoe UI")
    ventana.Add("Text","xm w520 cGray","Elige un perfil de color armónico. Se guarda en theme.ini y se aplica al instante:")

    perfiles := _TemaPerfiles()
    for idx, p in perfiles {
        ventana.SetFont("s10 bold")
        ventana.Add("Text","xm y+14 w320",p.nombre)
        ventana.SetFont("s8 cGray")
        ventana.Add("Text","xm y+1 w320",p.desc)
        ventana.SetFont("s9 norm")

        swX := 330, swY := "yp-16"
        for hex in p.swatches {
            sw := ventana.Add("Progress","x" swX " " swY " w22 h26 +Border c" hex " Background" hex)
            sw.Value := 100
            swX += 25
            swY := "yp"
        }

        btn := ventana.Add("Button","x465 yp w80 h26","Aplicar")
        btn.OnEvent("Click",_TemaSelAplicarPerfil.Bind(p))
    }

    est.st := ventana.Add("Text","xm y+18 w545 h22 c007ACC","")
    btnCerrar := ventana.Add("Button","xm y+6 w120 h28 Default","Cerrar")
    btnCerrar.OnEvent("Click",_TemaSelCerrar)
    ventana.OnEvent("Close",_TemaSelCerrar)
    ventana.OnEvent("Escape",_TemaSelCerrar)
    est.g := ventana
    ventana.Show("AutoSize")
}

_TemaSelCerrar(*) {
    est := _TemaSelEst()
    ventana := est.g
    est.g := 0
    if IsObject(ventana)
        try ventana.Destroy()
}

_TemaSelAplicarPerfil(perfil, *) {
    est := _TemaSelEst()
    iniPath := A_ScriptDir "\theme.ini"
    try {
        for clave, hex in perfil.tokens {
            IniWrite(hex, iniPath, "color", clave)
        }
    } catch {
        try est.st.Value := "⚠ Error al escribir en theme.ini"
        return
    }
    _TemaRecargar()
    _TemaRefrescarPaneles()
    try est.st.Value := "✔ Paleta aplicada: " perfil.nombre
}

_TemaRefrescarPaneles() {
    for fnPanel in [ActualizarDsGUI,ActualizarCcGUI,ActualizarArGUI,ActualizarHCGUI,ActualizarLockGUI,ActualizarFrenteGUI,ActualizarEstabBtnGUI] {
        try fnPanel()
    }
    try reloadGui.g.BackColor := _Tema("color","surface.reload","3B7A4B")
    try puntosGui.g.BackColor := _Tema("color","surface.off","424242")
    try ActualizarEstabGUI(-1,true)
}
; === P3-PALETA-END ===

; === STAB-UNIVERSAL-BEGIN ===
Stab_ResetUniversal(herramienta := "", forzar := false) {
    global stabU, Q, estabGui, STAB_RESET_FISICO, STAB_RESET_DELAY_MS, ESTAB_MAX, ESTAB_MIN
    ; Misma herramienta (doble toque de w, q repetida) -> no reiniciar
    if (!forzar && herramienta != "" && herramienta = stabU.tool)
        return
    stabU.tool := herramienta
    ; El estado del toggle (0 = baja, 1 = alta) se preserva segun el valor actual
    Q.estadoEstab := (estabGui.valor >= (ESTAB_MAX + ESTAB_MIN) / 2) ? 1 : 0
    estabGui.sincronizado := false
    ; Herramientas sin estabilizador en CSP (ej: lazo 's') quedan exentas de emitir teclas
    if (STAB_RESET_FISICO && herramienta != "s")
        SetTimer(_Stab_ResetFisico, -STAB_RESET_DELAY_MS)   ; debounce
}
_Stab_ValorUniversal(id) {
    global STAB_POR_HERRAMIENTA, estabGui
    ; Si la herramienta tiene un override explicito se usa; sino se preserva el valor universal activo (ej: 80)
    v := STAB_POR_HERRAMIENTA.Has(id) ? STAB_POR_HERRAMIENTA[id] : estabGui.valor
    return Max(0, Min(100, Integer(v)))
}
_Stab_ResetFisico() {
    global stabU, estabGui, stylus
    if stabU.ocupado {
        stabU.rearmar := true
        return
    }
    if !WinActive("ahk_exe CLIPStudioPaint.exe")
        return
    if estabGui.arrastrando {
        SetTimer(_Stab_ResetFisico, -150)
        return
    }
    if (stabU.tool = "s")
        return
    stabU.ocupado := true
    target := _Stab_ValorUniversal(stabU.tool)
    alt := stylus.altActive
    ok := false
    try {
        if alt
            SendEvent("{Alt up}")
        ok := _EstabEmitir("j", 100, 5) && (target <= 0 || _EstabEmitir("-", target, 5))
    } finally {
        _AltRestaurar(alt)
        stabU.ocupado := false
    }
    if ok {
        estabGui.valor := target
        estabGui.previsto := target
        estabGui.sincronizado := true
        stabU.syncTick := A_TickCount
        ActualizarEstabGUI(-1, true)
        _GuardarValorEstab()
    }
    if stabU.rearmar {
        stabU.rearmar := false
        SetTimer(_Stab_ResetFisico, -STAB_RESET_DELAY_MS)
    }
}
; === STAB-UNIVERSAL-END ===
