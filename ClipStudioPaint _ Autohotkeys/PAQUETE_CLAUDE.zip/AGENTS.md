# Proyecto AHK — Clip Studio Paint

Script principal: `XxxPPEN_a16pg2_displayAS_secondary.ahk` (AutoHotkey v2).
Perfiles/calibración: `posiciones_gui.ini`.
Reglas originales: `PureRef/Reglas_PureRef.md`.

## Reglas obligatorias

- **Zero-rewrite**: nunca reescribir ni reestructurar el script completo.
  Solo tocar las líneas exactas del bloque afectado.
- **Respaldo**: crear un `.bak` antes de guardar cualquier cambio.
- **Validar siempre** antes de entregar:
  ```powershell
  & "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" /validate "<archivo>.ahk"
  ```
  Código de salida `0` = sintaxis correcta.
- **Aislar por `#HotIf`**: CSP (`ahk_exe CLIPStudioPaint.exe`) y PureRef
  (`ahk_exe PureRef.exe`) no deben cruzar pulsaciones.
- Cada combinación con el lápiz (`~RButton & tecla`) debe marcar
  `stylus.comboUsado := true`.

## Módulos

- `XxxPPEN_...ahk`: lienzo, tableta, dial, pinceles y paneles de CSP.
- `PureRef_layout.ahk`: paneles/zoom de PureRef. **No está en esta carpeta**
  (el script principal lo busca por título de ventana).

## Notas de revisión (2026-11-04)

- El script valida con AutoHotkey 2.0.26 (`/validate` → exit 0).
- Faltan assets referenciados: `sonidos\`, `iconos\` y `PureRef_layout.ahk`.
- `_IconosB64()` está vacío: los botones no muestran icono.
- Añadir `#Warn` al desarrollar para detectar variables globales mal declaradas.
