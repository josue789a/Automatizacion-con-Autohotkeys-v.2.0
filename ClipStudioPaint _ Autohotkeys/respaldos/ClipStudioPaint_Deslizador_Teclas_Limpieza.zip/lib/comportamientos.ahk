; ═══════════ ④ COMPORTAMIENTOS (Fases C–E) ═══════════
_CompInit() {
    global COMP
    COMP := {filas: [], bloques: [], abierta: "", panel: 0, lblEv: 0, glob: [], globAbierta: false, lblGlob: 0}
}
; Registra un control de «Globales» con su desplazamiento (dy, px base) respecto a la cabecera
_CompGlobAdd(c, dy) {
    COMP.glob.Push({c: c, dy: dy})
    return c
}
; Alto de «Globales» abierto (px base): deslizador y enfoque (sin visibilidad ni clic).
_CompGlobH() => 100
_CompGlobToggle(*) {
    COMP.globAbierta := !COMP.globAbierta
    COMP.lblGlob.Text := "🌐 Globales (todo el script) " (COMP.globAbierta ? "▾" : "▸")
    _AccRelayout()
}
; Registra un control extra dentro de un bloque del acordeón (se muestra/oculta con el bloque).
_CompBloqueAddExtra(id, ctrl, h := 24) {
    global COMP
    bl := _CompBloqueDe(id)
    if (!bl)
        return ctrl
    if (!bl.HasOwnProp("ctrlsExtra"))
        bl.ctrlsExtra := []
    bl.ctrlsExtra.Push({c: ctrl, h: h})
    return ctrl
}
; Cabecera de sub-bloque (mini-acordeón). Sus filas se muestran/ocultan en _CompPos.
_CompBloqueNuevo(id, titulo, yDis, abierto := false) {
    global ACC, COMP
    g := ACC.g, x0 := ACC.x0, uiP := ACC.uiP
    hdr := _R(g.Add("Text", uiP.Call(x0 + 14, yDis, 678, 22) . " +0x200 +0x100", ""))
    hdr.SetFont("bold")
    hdr.Text := titulo " " (abierto ? "▾" : "▸")
    hdr.OnEvent("Click", _CompBloqueToggle.Bind(id))
    COMP.bloques.Push({id: id, titulo: titulo, hdr: hdr, abierto: abierto})
    return hdr
}
_CompBloqueDe(id) {
    global COMP
    for bl in COMP.bloques
        if (bl.id = id)
            return bl
    return 0
}
_CompBloqueToggle(id, *) {
    global COMP
    bl := _CompBloqueDe(id)
    if (!bl)
        return
    bl.abierto := !bl.abierto
    bl.hdr.Text := bl.titulo " " (bl.abierto ? "▾" : "▸")
    if (!bl.abierto && COMP.abierta != "") {     ; cerrar el bloque cierra la tarjeta que contenía
        fa := _CompFilaDe(COMP.abierta)
        if (fa && fa.bloque = id)
            COMP.abierta := ""
    }
    _CompTextos()
    _AccRelayout()
}
; ── E2: opacidad/borde por evento (Bloque 1). Sin clave en el ini = comportamiento de hoy ──
_CompIni(key, campo, idEv, reset := false) {          ; lectura cacheada (el loop de hover la llama cada tick)
    static cache := Map()
    if (reset) {
        cache.Clear()
        return ""
    }
    k := key "_" campo "_" idEv
    if (!cache.Has(k))
        cache[k] := IniRead(_PosGuiIniPath(), "Particularidades", k, "")
    return cache[k]
}
_CompOp(key, campo, idEv, def) {                      ; opacidad Win32 0-255
    v := _CompIni(key, campo, idEv)
    return (IsInteger(v) && Integer(v) >= 1 && Integer(v) <= 255) ? Integer(v) : def
}
_CompBorde(key, idEv, def) {
    v := _CompIni(key, "borde", idEv)
    return (v = "") ? def : (v = "1")
}
_CompDefOp(key, campo) {
    if (key = "pildora")
        return _AlphaTema("pill", 235)
    return (campo = "op_rep") ? 5 : 255
}
_CompE2Activo(idEv) {                                 ; eventos con runtime cableado (E2b añade más)
    return InStr("|panel_ds|panel_cc|history_lock|gui_frente|estab_slider|reload|", "|" idEv "|") > 0
}
_CompAplicarVivo(key, idEv) {
    global dsGui, colorV, ccGui, colorCC, lockGui, hist, frenteGui, estabBtnGui, reloadGui
    _CompIni("", "", "", true)                        ; invalida la caché
    if (idEv = "panel_ds") {
        if (key = "pildora") {
            try WinSetTransparent(_CompOp("pildora", "op_rep", idEv, _AlphaTema("pill", 235)), dsGui.g)
        } else if (key = "hover") {
            act := colorV.dsVis
            try WinSetTransparent(_CompOp("hover", act ? "op_act" : "op_rep", idEv, act ? 255 : 5), "ahk_id " colorV.dsID)
        }
    } else if (idEv = "panel_cc") {
        if (key = "pildora") {
            try WinSetTransparent(_CompOp("pildora", "op_rep", idEv, _AlphaTema("pill", 235)), ccGui.g)
        } else if (key = "hover") {
            act := colorCC.dsVis
            try WinSetTransparent(_CompOp("hover", act ? "op_act" : "op_rep", idEv, act ? 255 : 5), "ahk_id " colorCC.id)
        }
    } else if (idEv = "history_lock") {
        if (key = "pildora") {
            act := (IsSet(hist) && HasProp(hist, "abierto") && hist.abierto)
            try WinSetTransparent(_CompOp("pildora", act ? "op_act" : "op_rep", idEv, _AlphaTema("pill", 235)), lockGui.g)
        }
    } else if (idEv = "gui_frente") {
        if (key = "pildora") {
            try WinSetTransparent(_CompOp("pildora", "op_rep", idEv, _AlphaTema("pill", 235)), frenteGui.g)
        }
    } else if (idEv = "estab_slider") {
        if (key = "pildora") {
            try WinSetTransparent(_CompOp("pildora", "op_rep", idEv, _AlphaTema("pill", 235)), estabBtnGui.g)
        }
    } else if (idEv = "reload") {
        if (key = "pildora") {
            try WinSetTransparent(_CompOp("pildora", "op_rep", idEv, _AlphaTema("pill", 235)), reloadGui.g)
        }
    }
}
_CompModGuardar(key, campo, idEv, ctrl) {
    v := Trim(ctrl.Value)
    if (campo = "ms" && (!IsInteger(v) || Integer(v) < 50 || Integer(v) > 2000))
        return                                        ; inválido: no persiste
    if (campo = "a" && v != "" && idEv != "") {       ; A igual al atajo base = heredado: se guarda vacío
        baseA := IniRead(_PosGuiIniPath(), "Remapeos", "atajo_" idEv, _PtsEvAtajoDefault(idEv))
        if (v = baseA)
            v := ""
    }
    IniWrite(v, _PosGuiIniPath(), "Particularidades", key "_" campo "_" idEv)
    _CompAplicarVivo(key, idEv)                       ; solo invalida la caché
}

_CompHeredadoPintar(cmp, *) {
    if !IsObject(cmp.eA)
        return
    v := Trim(cmp.eA.Value)
    cmp.eA.SetFont((cmp.baseA != "" && v = cmp.baseA) ? "cGray" : "cDefault")
}

_CompReqBRefrescar(cmp, *) {
    if IsObject(cmp.lblReqB)
        cmp.lblReqB.Visible := (cmp.eB.Enabled && Trim(cmp.eB.Value) = "")
}

_CompMsIcono(cmp, *) {
    if !IsObject(cmp.lblMs) || !IsObject(cmp.eMs)
        return
    v := Trim(cmp.eMs.Value)
    if (v != "" && (!IsInteger(v) || Integer(v) < 50 || Integer(v) > 2000)) {
        cmp.lblMs.Text := "⚠ Rango 50–2000 ms"
        cmp.lblMs.SetFont("cRed")
    } else if (v = "" || v = "250") {
        cmp.lblMs.Text := "⏱ 250 ms (predeterminado)"
        cmp.lblMs.SetFont("cGray")
    } else {
        cmp.lblMs.Text := "✎ personalizado (def. 250)"
        cmp.lblMs.SetFont("cDefault")
    }
}

_CompSliderLeer(campo) {                                ; E4
    global PERFIL, ESTAB_ALPHA_H, ESTAB_ALPHA_F
    v := IniRead(_PosGuiIniPath(), "Estab_p" PERFIL, campo, "")
    if (v != "")
        return v
    if (campo = "tecla_bajar")
        return "j"
    if (campo = "tecla_subir")
        return "-"
    if (campo = "snaps")
        return "7,15,35,55,75"
    return Round((campo = "alphaH" ? ESTAB_ALPHA_H : ESTAB_ALPHA_F) / 2.55)
}

_CompSliderVerificarTeclas(cmp) {
    if (!IsObject(cmp) || !HasProp(cmp, "eBajar") || !HasProp(cmp, "eSubir"))
        return
    baj := Trim(cmp.eBajar.Value)
    sub := Trim(cmp.eSubir.Value)
    faltan := (baj = "" || sub = "")
    if (HasProp(cmp, "lblReqTeclas") && IsObject(cmp.lblReqTeclas))
        cmp.lblReqTeclas.Visible := faltan
    if (HasProp(cmp, "otrosCtrls") && IsObject(cmp.otrosCtrls)) {
        for c in cmp.otrosCtrls {
            try c.Enabled := !faltan
        }
    }
}

_CompSnapsPintar(eSnaps, malIdx) {                      ; rojo solo en la caja inválida con texto; las demás en color normal
    for i, esn in eSnaps {
        esn.Opt((malIdx = i && Trim(esn.Value) != "") ? "cFF4D4D" : "cDefault")
        esn.Redraw()
    }
}

_CompSliderGuardar(campo, ctrl) {                       ; E4
    global PERFIL, ESTAB_ALPHA_H, ESTAB_ALPHA_F, ESTAB_MARCAS_C
    if (campo = "tecla_bajar" || campo = "tecla_subir") {
        v := Trim(ctrl.Value)
        IniWrite(v, _PosGuiIniPath(), "Estab_p" PERFIL, campo)
        f := _CompFilaDe("slider")
        if (f && IsObject(f.campos))
            _CompSliderVerificarTeclas(f.campos)
        return
    }
    if (campo = "snaps") {
        f := _CompFilaDe("slider")
        if (!f || !IsObject(f.campos) || !f.campos.HasProp("eSnaps"))
            return
        snapsArr := []
        ant := 0
        malIdx := 0
        for i, esn in f.campos.eSnaps {
            v := Trim(esn.Value)
            if (!IsInteger(v) || Integer(v) < 0 || Integer(v) > 100 || Integer(v) <= ant) {
                malIdx := i                           ; primer inválido: orden estrictamente creciente
                break
            }
            snapsArr.Push(Integer(v))
            ant := Integer(v)
        }
        _CompSnapsPintar(f.campos.eSnaps, malIdx)
        if (malIdx)
            return
        if (snapsArr.Length = 5) {
            strSnaps := snapsArr[1] "," snapsArr[2] "," snapsArr[3] "," snapsArr[4] "," snapsArr[5]
            IniWrite(strSnaps, _PosGuiIniPath(), "Estab_p" PERFIL, "snaps")
            if IsSet(ESTAB_MARCAS_C)
                ESTAB_MARCAS_C := snapsArr            ; actualiza en vivo
            _SonarUI("slider", snapsArr[1])
        }
        return
    }
    v := StrReplace(Trim(ctrl.Value), " ")
    if (!IsInteger(v) || Integer(v) < 10 || Integer(v) > 100)
        return
    IniWrite(v, _PosGuiIniPath(), "Estab_p" PERFIL, campo)
    if (campo = "alphaH")
        ESTAB_ALPHA_H := Round(Integer(v) * 2.55)
    else
        ESTAB_ALPHA_F := Round(Integer(v) * 2.55)
}

_CompCampoCambio(key, campo, ctrl, *) {
    global COMP
    if (HasProp(COMP, "cargando") && COMP.cargando)
        return
    idEv := _PtsSndIdEv()
    if (idEv = "")
        return
    if (campo = "snaps" || campo = "alphaH" || campo = "alphaF" || campo = "tecla_bajar" || campo = "tecla_subir") {   ; E4
        _CompSliderGuardar(campo, ctrl)
        return
    }
    if (campo = "a" || campo = "b" || campo = "ms") {   ; E3
        _CompModGuardar(key, campo, idEv, ctrl)
        return
    }
    if (!_CompE2Activo(idEv) && !_PtsEvEsCustom(_PosGuiIniPath(), idEv))
        return
    ini := _PosGuiIniPath(), sec := "Particularidades"
    k := key "_" campo "_" idEv
    if (campo = "borde") {
        IniWrite(ctrl.Value ? "1" : "0", ini, sec, k)
    } else {
        v := Trim(ctrl.Value)
        if (!IsInteger(v) || Integer(v) < 1 || Integer(v) > 100)
            return                                    ; inválido: no persiste (patrón de _PtsAlphaChange)
        IniWrite(Round(Integer(v) * 2.55), ini, sec, k)
    }
    _CompAplicarVivo(key, idEv)
}
_CompCargarCampos(idEv) {                             ; se llama al seleccionar evento
    global COMP
    if (!IsSet(COMP) || !IsObject(COMP) || !HasProp(COMP, "filas"))
        return
    COMP.cargando := true
    try {
        for f in COMP.filas {
            c := f.campos
            if (!IsObject(c))
                continue
            if (HasProp(c, "sld")) {                          ; E4
                on := (idEv != "" && f.cb.Enabled)
                c.eBajar.Enabled := on
                c.eBajar.Value := on ? _CompSliderLeer("tecla_bajar") : ""
                c.eSubir.Enabled := on
                c.eSubir.Value := on ? _CompSliderLeer("tecla_subir") : ""
                rawSnaps := _CompSliderLeer("snaps")
                p := StrSplit(rawSnaps, ",")
                if (c.HasProp("eSnaps")) {
                    for i, esn in c.eSnaps {
                        esn.Value := (on && i <= p.Length) ? p[i] : ""
                    }
                }
                c.eAH.Value := on ? _CompSliderLeer("alphaH") : ""
                c.eAF.Value := on ? _CompSliderLeer("alphaF") : ""
                _CompSliderVerificarTeclas(c)
                continue
            }
            if (HasProp(c, "mod")) {                      ; E3
                on := (idEv != "" && f.cb.Enabled)
                c.eA.Enabled := on
                valA := _CompIni(f.key, "a", idEv)
                baseA := ""
                if (idEv != "") {
                    baseA := IniRead(_PosGuiIniPath(), "Remapeos", "atajo_" idEv, _PtsEvAtajoDefault(idEv))
                    if (baseA = "—")
                        baseA := ""
                }
                if (valA = "" && idEv != "")
                    valA := baseA
                c.baseA := on ? baseA : ""
                c.eA.Value := on ? valA : ""
                _CompHeredadoPintar(c)
                c.eB.Enabled := on
                valB := _CompIni(f.key, "b", idEv)
                c.eB.Value := on ? valB : ""
                if (c.HasProp("lblReqB") && IsObject(c.lblReqB))
                    c.lblReqB.Visible := (on && f.key = "toggle" && valB = "")
                if (IsObject(c.eMs)) {
                    c.eMs.Enabled := on
                    ms := on ? _CompIni(f.key, "ms", idEv) : ""
                    c.eMs.Value := on ? (ms = "" ? "250" : ms) : ""
                    _CompMsIcono(c)
                }
                continue
            }
            if (!HasProp(c, "eRep") || !IsObject(c.eRep))
                continue
            on := (idEv != "" && (_CompE2Activo(idEv) || _PtsEvEsCustom(_PosGuiIniPath(), idEv)) && f.cb.Enabled)
            c.eRep.Enabled := on
            c.eRep.Value := on ? Round(_CompOp(f.key, "op_rep", idEv, _CompDefOp(f.key, "op_rep")) / 2.55) : ""
            if (IsObject(c.eAct)) {
                c.eAct.Enabled := on
                c.eAct.Value := on ? Round(_CompOp(f.key, "op_act", idEv, _CompDefOp(f.key, "op_act")) / 2.55) : ""
            }
            if (IsObject(c.cbB)) {
                c.cbB.Enabled := on
                c.cbB.Value := (on && _CompBorde(f.key, idEv, true)) ? 1 : 0
            }
        }
    } finally {
        COMP.cargando := false
    }
}

; Crea fila (checkbox + ⚙ + motivo) y su tarjeta. Devuelve el checkbox.
_CompFila(key, texto, yDis, lineas, bloque := "b1", pend := false, campos := "") {
    global ACC, COMP
    g := ACC.g, x0 := ACC.x0, uiP := ACC.uiP
    cb   := _R(g.Add("CheckBox", uiP.Call(x0 + 14,  yDis + 1, 230, 22), texto))
    gear := _R(g.Add("Text",     uiP.Call(x0 + 250, yDis + 1, 84,  22) . " +0x200 +0x100", "⚙ Ajustes ▸"))
    why  := _R(g.Add("Text",     uiP.Call(x0 + 340, yDis + 1, 352, 22) . " +0x200 cGray", ""))
    card := {ctrls: [], alto: 6 + 22 * lineas.Length}
    for i, t in lineas
        card.ctrls.Push(_R(g.Add("Text", uiP.Call(x0 + 34, yDis + 2, 656, 20) . " +0x200" . (i = 1 ? "" : " cGray"), t)))
    card.filas := Map()                              ; índice de ctrl -> fila visual (varios ctrls pueden compartir fila)
    cmp := false
    if (campos = "slider") {                                ; E4: deslizador virtual
        n := lineas.Length
        cmp := {eRep: "", eAct: "", cbB: "", sld: true, eBajar: "", eSubir: "", lblReqTeclas: "", eSnaps: [], eAH: "", eAF: "", bZona: "", bZonaF: "", otrosCtrls: []}
        ; Fila 1: Teclas obligatorias que suben y bajan
        card.ctrls.Push(_R(g.Add("Text", uiP.Call(x0 + 34, yDis + 2, 94, 20) . " +0x200", "Bajar estab (A):")))
        cmp.eBajar := _R(g.Add("Edit", uiP.Call(x0 + 130, yDis + 2, 70, 20), ""))
        _KgAttach(cmp.eBajar, (*) => _CompSliderVerificarTeclas(cmp))
        card.ctrls.Push(cmp.eBajar)
        card.ctrls.Push(_R(g.Add("Text", uiP.Call(x0 + 214, yDis + 2, 94, 20) . " +0x200", "Subir estab (B):")))
        cmp.eSubir := _R(g.Add("Edit", uiP.Call(x0 + 310, yDis + 2, 70, 20), ""))
        _KgAttach(cmp.eSubir, (*) => _CompSliderVerificarTeclas(cmp))
        card.ctrls.Push(cmp.eSubir)
        cmp.lblReqTeclas := _R(g.Add("Text", uiP.Call(x0 + 392, yDis + 2, 280, 20) . " +0x200 cRed", "⚠️ Teclas obligatorias"))
        card.ctrls.Push(cmp.lblReqTeclas)
        card.filas[n + 1] := n + 1, card.filas[n + 2] := n + 1
        card.filas[n + 3] := n + 1, card.filas[n + 4] := n + 1
        card.filas[n + 5] := n + 1

        ; Fila 2: Snap points
        txtSn := _R(g.Add("Text", uiP.Call(x0 + 34, yDis + 2, 112, 20) . " +0x200", "Snap P1 ▸ P5 (%):"))
        card.ctrls.Push(txtSn), cmp.otrosCtrls.Push(txtSn)
        card.filas[n + 6] := n + 2
        Loop 5 {
            esn := _R(g.Add("Edit", uiP.Call(x0 + 150 + (A_Index - 1) * 44, yDis + 2, 38, 20) . " Number Limit3", ""))
            cmp.eSnaps.Push(esn), cmp.otrosCtrls.Push(esn)
            cueSnap := "P" A_Index
            SendMessage(0x1501, 1, StrPtr(cueSnap), esn)
            card.ctrls.Push(esn)
            card.filas[n + 6 + A_Index] := n + 2
            esn.OnEvent("Change", _CompCampoCambio.Bind(key, "snaps"))
        }

        ; Fila 3: Opacidades
        txtAH := _R(g.Add("Text", uiP.Call(x0 + 34, yDis + 2, 112, 20) . " +0x200", "Hover (reposo) %:"))
        cmp.otrosCtrls.Push(txtAH), card.ctrls.Push(txtAH)
        cmp.eAH := _R(g.Add("Edit", uiP.Call(x0 + 150, yDis + 2, 48, 20), ""))
        cmp.otrosCtrls.Push(cmp.eAH), card.ctrls.Push(cmp.eAH)
        txtAF := _R(g.Add("Text", uiP.Call(x0 + 256, yDis + 2, 112, 20) . " +0x200", "Focus (activo) %:"))
        cmp.otrosCtrls.Push(txtAF), card.ctrls.Push(txtAF)
        cmp.eAF := _R(g.Add("Edit", uiP.Call(x0 + 372, yDis + 2, 48, 20), ""))
        cmp.otrosCtrls.Push(cmp.eAF), card.ctrls.Push(cmp.eAF)
        card.filas[n + 12] := n + 3, card.filas[n + 13] := n + 3
        card.filas[n + 14] := n + 3, card.filas[n + 15] := n + 3

        ; Fila 4: Botones para dibujar
        bZona := _R(g.Add("Button", uiP.Call(x0 + 34, yDis + 2, 160, 22), "✏ Dibujar deslizador"))
        bZonaF := _R(g.Add("Button", uiP.Call(x0 + 204, yDis + 2, 180, 22), "✏ Dibujar enfoque (Shift+E)"))
        bZona.OnEvent("Click", (*) => _PtsDibujarZonaEstab(false))
        bZonaF.OnEvent("Click", (*) => _PtsDibujarZonaEstab(true))
        cmp.bZona := bZona, cmp.bZonaF := bZonaF
        cmp.otrosCtrls.Push(bZona), cmp.otrosCtrls.Push(bZonaF)
        card.ctrls.Push(bZona), card.ctrls.Push(bZonaF)
        card.filas[n + 16] := n + 4, card.filas[n + 17] := n + 4

        card.alto := 6 + 22 * (n + 4)
        cmp.eBajar.OnEvent("Change", _CompCampoCambio.Bind(key, "tecla_bajar"))
        cmp.eSubir.OnEvent("Change", _CompCampoCambio.Bind(key, "tecla_subir"))
        cmp.eAH.OnEvent("Change", _CompCampoCambio.Bind(key, "alphaH"))
        cmp.eAF.OnEvent("Change", _CompCampoCambio.Bind(key, "alphaF"))
    } else if (campos = "quick" || campos = "toggle") {     ; E3: modulación de tecla
        n := lineas.Length
        cmp := {eRep: "", eAct: "", cbB: "", mod: true, eA: "", eB: "", eMs: "", lblReqB: "", lblMs: "", baseA: ""}
        et := (campos = "quick") ? ["Toque corto (A):", "Toque largo (B):"] : ["Tecla A:", "Tecla B:"]
        card.ctrls.Push(_R(g.Add("Text", uiP.Call(x0 + 34, yDis + 2, 112, 20) . " +0x200", et[1])))
        cmp.eA := _R(g.Add("Edit", uiP.Call(x0 + 150, yDis + 2, 90, 20), ""))
        card.ctrls.Push(cmp.eA)
        card.ctrls.Push(_R(g.Add("Text", uiP.Call(x0 + 256, yDis + 2, 112, 20) . " +0x200", et[2])))
        cmp.eB := _R(g.Add("Edit", uiP.Call(x0 + 372, yDis + 2, 90, 20), ""))
        card.ctrls.Push(cmp.eB)
        card.filas[n + 1] := n + 1, card.filas[n + 2] := n + 1
        card.filas[n + 3] := n + 1, card.filas[n + 4] := n + 1
        m := n + 4
        if (campos = "toggle") {
            cmp.lblReqB := _R(g.Add("Text", uiP.Call(x0 + 470, yDis + 2, 160, 20) . " +0x200 cRed", "⚠️ Requiere Tecla B"))
            cmp.lblReqB.Visible := false
            card.ctrls.Push(cmp.lblReqB)
            card.filas[m + 1] := n + 1
            m++
        }
        nFilas := 1
        if (campos = "quick") {
            card.ctrls.Push(_R(g.Add("Text", uiP.Call(x0 + 34, yDis + 2, 112, 20) . " +0x200", "Umbral (ms):")))
            cmp.eMs := _R(g.Add("Edit", uiP.Call(x0 + 150, yDis + 2, 54, 20) . " Number Limit4", ""))
            card.ctrls.Push(cmp.eMs)
            cmp.lblMs := _R(g.Add("Text", uiP.Call(x0 + 214, yDis + 2, 230, 20) . " +0x200 cGray", "⏱ 250 ms (predeterminado)"))
            card.ctrls.Push(cmp.lblMs)
            card.filas[m + 1] := n + 2, card.filas[m + 2] := n + 2, card.filas[m + 3] := n + 2
            nFilas := 2
        }
        card.alto := 6 + 22 * (n + nFilas)
        cmp.eA.OnEvent("Change", _CompCampoCambio.Bind(key, "a"))
        cmp.eA.OnEvent("Change", _CompHeredadoPintar.Bind(cmp))
        cmp.eB.OnEvent("Change", _CompCampoCambio.Bind(key, "b"))
        if (campos = "toggle")
            cmp.eB.OnEvent("Change", _CompReqBRefrescar.Bind(cmp))
        if (IsObject(cmp.eMs)) {
            cmp.eMs.OnEvent("Change", _CompCampoCambio.Bind(key, "ms"))
            cmp.eMs.OnEvent("Change", _CompMsIcono.Bind(cmp))
        }
    } else if (campos = "rango") {                          ; Dibujo directo de zona
        n := lineas.Length
        cmp := {btnDib: ""}
        btnDib := _R(g.Add("Button", uiP.Call(x0 + 34, yDis + 2, 180, 22), "✏ Dibujar zona / rango"))
        btnDib.OnEvent("Click", (*) => _PtsDibujarZonaEvento(key))
        cmp.btnDib := btnDib
        card.ctrls.Push(btnDib)
        card.filas[n + 1] := n + 1
        card.alto := 6 + 22 * (n + 1)
    } else if (campos != "") {                              ; E2: "rep" [+ " act"] [+ " borde"]
        n := lineas.Length
        cmp := {eRep: "", eAct: "", cbB: ""}
        card.ctrls.Push(_R(g.Add("Text", uiP.Call(x0 + 34, yDis + 2, 118, 20) . " +0x200", "Opacidad reposo (%):")))
        cmp.eRep := _R(g.Add("Edit", uiP.Call(x0 + 156, yDis + 2, 48, 20), ""))
        card.ctrls.Push(cmp.eRep)
        card.filas[n + 1] := n + 1, card.filas[n + 2] := n + 1
        m := n + 2
        if (InStr(campos, "act")) {
            card.ctrls.Push(_R(g.Add("Text", uiP.Call(x0 + 220, yDis + 2, 118, 20) . " +0x200", "Opacidad activo (%):")))
            cmp.eAct := _R(g.Add("Edit", uiP.Call(x0 + 342, yDis + 2, 48, 20), ""))
            card.ctrls.Push(cmp.eAct)
            card.filas[m + 1] := n + 1, card.filas[m + 2] := n + 1
            m += 2
        }
        nFilas := 1
        if (InStr(campos, "borde")) {
            cmp.cbB := _R(g.Add("CheckBox", uiP.Call(x0 + 34, yDis + 2, 230, 20), "Borde"))
            card.ctrls.Push(cmp.cbB)
            card.filas[m + 1] := n + 2
            nFilas := 2
        }
        card.alto := 6 + 22 * (n + nFilas)
        cmp.eRep.OnEvent("Change", _CompCampoCambio.Bind(key, "op_rep"))
        if (IsObject(cmp.eAct))
            cmp.eAct.OnEvent("Change", _CompCampoCambio.Bind(key, "op_act"))
        if (IsObject(cmp.cbB))
            cmp.cbB.OnEvent("Click", _CompCampoCambio.Bind(key, "borde"))
    }
    COMP.filas.Push({key: key, bloque: bloque, pend: pend, cb: cb, gear: gear, why: why, card: card, campos: cmp})
    if (pend) {                                      ; fila reservada: visible pero inerte hasta su fase
        cb.Enabled := false
        gear.Text := ""
        why.Text := "Próximamente"
    }
    cb.OnEvent("Click", _CompCbClick.Bind(key))     ; se ejecuta ANTES del handler existente (_PtsEvPartToggle)
    gear.OnEvent("Click", _CompGear.Bind(key))
    return cb
}
_CompFilaDe(key) {
    global COMP
    for f in COMP.filas
        if (f.key = key)
            return f
    return 0
}
_CompAlto() {
    global ACC, COMP
    h := _AccPx(42) + COMP.bloques.Length * _AccPx(24)
    for bl in COMP.bloques {
        if (!bl.abierto)
            continue
        for fi in COMP.filas
            if (fi.bloque = bl.id)
                h += _AccPx(24)
        if (bl.HasOwnProp("ctrlsExtra")) {
            for ex in bl.ctrlsExtra
                h += _AccPx(ex.h)
        }
    }
    f := COMP.abierta != "" ? _CompFilaDe(COMP.abierta) : 0
    if (f)
        h += _AccPx(f.card.alto)
    if (HasProp(COMP, "lblGlob") && IsObject(COMP.lblGlob))
        h += _AccPx(COMP.globAbierta ? _CompGlobH() : 24)
    return Min(h + ACC.pad, Max(_AccPx(120), _AccDisponible() - _AccY0() - 3 * _AccPx(30)))
}
_CompPos(y, yTop := 0, yBottom := 99999) {   ; y = tope del panel; recorta visibilidad al viewport
    global COMP
    vis := (cy, ch := 20) => (cy >= yTop && cy + _AccPx(ch) <= yBottom)
    COMP.lblEv.Move(, y + _AccPx(24))
    COMP.lblEv.Visible := vis(y + _AccPx(24), 20)
    ry := y + _AccPx(44)
    for bl in COMP.bloques {
        bl.hdr.Move(, ry), bl.hdr.Visible := vis(ry, 22)
        ry += _AccPx(24)
        for f in COMP.filas {
            if (f.bloque != bl.id)
                continue
            if (!bl.abierto) {                       ; bloque colapsado: todo oculto
                f.cb.Visible := false, f.gear.Visible := false, f.why.Visible := false
                for c in f.card.ctrls
                    c.Visible := false
                continue
            }
            f.cb.Move(, ry + _AccPx(1)),   f.cb.Visible := vis(ry + _AccPx(1), 22)
            f.gear.Move(, ry + _AccPx(1)), f.gear.Visible := vis(ry + _AccPx(1), 22)
            f.why.Move(, ry + _AccPx(1)),  f.why.Visible := vis(ry + _AccPx(1), 22)
            ry += _AccPx(24)
            abre := (COMP.abierta = f.key)
            for i, c in f.card.ctrls {
                if (abre) {
                    cy := ry + _AccPx(2 + ((f.card.filas.Has(i) ? f.card.filas[i] : i) - 1) * 20)
                    c.Move(, cy)
                    c.Visible := vis(cy, 20)
                } else
                    c.Visible := false
            }
            if (abre)
                ry += _AccPx(f.card.alto)
        }
        if (bl.HasOwnProp("ctrlsExtra")) {
            for ex in bl.ctrlsExtra {
                if (!bl.abierto) {
                    ex.c.Visible := false
                    continue
                }
                ex.c.Move(, ry + _AccPx(1))
                ex.c.Visible := vis(ry + _AccPx(1), ex.h)
                ry += _AccPx(ex.h)
            }
        }
    }
    if (HasProp(COMP, "lblGlob") && IsObject(COMP.lblGlob)) {
        COMP.lblGlob.Move(, ry)
        COMP.lblGlob.Visible := vis(ry, 22)
        for it in COMP.glob {
            if (COMP.globAbierta) {
                cy := ry + _AccPx(it.dy)
                it.c.Move(, cy)
                it.c.Visible := vis(cy, 24)
            } else
                it.c.Visible := false
        }
    }
}
_CompTextos() {
    global COMP
    idEv := _PtsSndIdEv()
    caps := _PtsEvCaps(idEv)
    for f in COMP.filas {
        if (f.pend) {                                ; reservada: solo informa si aplicará a este evento
            ok := (idEv != "" && caps.%f.key%)
            f.why.Text := idEv = "" ? "Selecciona un evento" : (ok ? "Próximamente" : "No aplica a este evento")
            f.gear.Text := ""
            continue
        }
        ok := (idEv != "" && caps.%f.key%)
        f.why.Text := ok ? "" : (idEv = "" ? "Selecciona un evento" : "No aplica a este evento")
        f.gear.Text := "⚙ Ajustes " (COMP.abierta = f.key ? "▾" : "▸")
    }
}
_CompCbClick(key, ctrl, *) {
    global COMP
    if (ctrl.Value)
        COMP.abierta := key                          ; activar abre su tarjeta (cierra la otra)
    else if (COMP.abierta = key)
        COMP.abierta := ""                           ; desactivar cierra, conserva la config
    _CompTextos()
    _AccRelayout()
}
_CompGear(key, *) {
    global COMP
    f := _CompFilaDe(key)
    if (!f || !f.cb.Enabled)
        return
    COMP.abierta := (COMP.abierta = key) ? "" : key
    _CompTextos()
    _AccRelayout()
}
; Llamado desde _AccRefrescarResumen (cambio de evento): cierra tarjetas de filas que ya no aplican
_CompRefrescar() {
    global COMP
    if (!IsSet(COMP) || !IsObject(COMP) || !COMP.panel)
        return
    idEv := _PtsSndIdEv()
    caps := _PtsEvCaps(idEv)
    antes := COMP.abierta
    if (COMP.abierta != "") {
        f := _CompFilaDe(COMP.abierta)
        if (!f || idEv = "" || !caps.%f.key%)
            COMP.abierta := ""
    }
    _CompTextos()
    if (COMP.abierta != antes)
        _AccRelayout()                               ; solo si cambió el alto
}
