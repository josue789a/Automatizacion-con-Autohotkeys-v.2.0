; ═══════════ ④ COMPORTAMIENTOS (Fases C–E) ═══════════
_CompInit() {
    global COMP
    COMP := {filas: [], abierta: "", panel: 0, lblEv: 0, glob: [], globAbierta: false, lblGlob: 0}
}
; Registra un control de «Globales» con su desplazamiento (dy, px base) respecto a la cabecera
_CompGlobAdd(c, dy) {
    COMP.glob.Push({c: c, dy: dy})
    return c
}
; Alto de «Globales» abierto (px base): 142 de la Fase D + 30 de la fila Visibilidad. Único lugar donde cambia.
_CompGlobH() => 172
_CompGlobToggle(*) {
    COMP.globAbierta := !COMP.globAbierta
    COMP.lblGlob.Text := "🌐 Globales (todo el script) " (COMP.globAbierta ? "▾" : "▸")
    _AccFit()
    _AccRelayout()
}
; Crea fila (checkbox + ⚙ + motivo) y su tarjeta. Devuelve el checkbox.
_CompFila(key, texto, yDis, lineas) {
    global ACC, COMP
    g := ACC.g, x0 := ACC.x0, uiP := ACC.uiP
    cb   := _R(g.Add("CheckBox", uiP.Call(x0 + 14,  yDis + 2, 230, 22), texto))
    gear := _R(g.Add("Text",     uiP.Call(x0 + 250, yDis + 1, 84,  22) . " +0x200 +0x100", "⚙ Ajustes ▸"))
    why  := _R(g.Add("Text",     uiP.Call(x0 + 340, yDis + 1, 352, 22) . " +0x200 cGray", ""))
    card := {ctrls: [], alto: 6 + 22 * lineas.Length}
    for i, t in lineas
        card.ctrls.Push(_R(g.Add("Text", uiP.Call(x0 + 34, yDis + 2, 656, 20) . " +0x200" . (i = 1 ? "" : " cGray"), t)))
    COMP.filas.Push({key: key, cb: cb, gear: gear, why: why, card: card})
    cb.OnEvent("Click", _CompCbClick.Bind(key))     ; se ejecuta ANTES del handler existente (_PtsEvPartToggle)
    gear.OnEvent("Click", _CompGear.Bind(key))
    return cb
}
_CompFilaDe(key) {
    global COMP
    for f in COMP.filas
        if (f.key = key)
            return f
    return 0
}
_CompAlto() {
    global ACC, COMP
    h := _AccPx(48) + COMP.filas.Length * _AccPx(26)
    f := COMP.abierta != "" ? _CompFilaDe(COMP.abierta) : 0
    if (f)
        h += _AccPx(f.card.alto)
    h += _AccPx(COMP.globAbierta ? _CompGlobH() : 26)
    return Min(h + ACC.pad, Max(_AccPx(120), _AccDisponible() - _AccY0() - 3 * _AccPx(30)))
}
_CompPos(y, yTop := 0, yBottom := 99999) {   ; y = tope del panel; recorta visibilidad al viewport
    global COMP
    vis := (cy, ch := 20) => (cy + _AccPx(ch) >= yTop && cy <= yBottom)
    COMP.lblEv.Move(, y + _AccPx(26))
    COMP.lblEv.Visible := vis(y + _AccPx(26))
    ry := y + _AccPx(48)
    for f in COMP.filas {
        f.cb.Move(, ry + _AccPx(2)),   f.cb.Visible := vis(ry + _AccPx(2))
        f.gear.Move(, ry + _AccPx(1)), f.gear.Visible := vis(ry + _AccPx(1))
        f.why.Move(, ry + _AccPx(1)),  f.why.Visible := vis(ry + _AccPx(1))
        ry += _AccPx(26)
        abre := (COMP.abierta = f.key)
        for i, c in f.card.ctrls {
            if (abre) {
                cy := ry + _AccPx(2 + (i - 1) * 22)
                c.Move(, cy)
                c.Visible := vis(cy)
            } else
                c.Visible := false
        }
        if (abre)
            ry += _AccPx(f.card.alto)
    }
    COMP.lblGlob.Move(, ry)
    COMP.lblGlob.Visible := vis(ry)
    for it in COMP.glob {
        if (COMP.globAbierta) {
            cy := ry + _AccPx(it.dy)
            it.c.Move(, cy)
            it.c.Visible := vis(cy, 24)
        } else
            it.c.Visible := false
    }
}
_CompTextos() {
    global COMP
    idEv := _PtsSndIdEv()
    caps := _PtsEvCaps(idEv)
    for f in COMP.filas {
        ok := (idEv != "" && caps.%f.key%)
        f.why.Text := ok ? "" : (idEv = "" ? "Selecciona un evento" : "No aplica a este evento")
        f.gear.Text := "⚙ Ajustes " (COMP.abierta = f.key ? "▾" : "▸")
    }
}
_CompCbClick(key, ctrl, *) {
    global COMP
    if (ctrl.Value)
        COMP.abierta := key                          ; activar abre su tarjeta (cierra la otra)
    else if (COMP.abierta = key)
        COMP.abierta := ""                           ; desactivar cierra, conserva la config
    _CompTextos()
    _AccFit()
    _AccRelayout()
}
_CompGear(key, *) {
    global COMP
    f := _CompFilaDe(key)
    if (!f || !f.cb.Enabled)
        return
    COMP.abierta := (COMP.abierta = key) ? "" : key
    _CompTextos()
    _AccFit()
    _AccRelayout()
}
; Llamado desde _AccRefrescarResumen (cambio de evento): cierra tarjetas de filas que ya no aplican
_CompRefrescar() {
    global COMP
    if (!IsSet(COMP) || !IsObject(COMP) || !COMP.panel)
        return
    idEv := _PtsSndIdEv()
    caps := _PtsEvCaps(idEv)
    antes := COMP.abierta
    if (COMP.abierta != "") {
        f := _CompFilaDe(COMP.abierta)
        if (!f || idEv = "" || !caps.%f.key%)
            COMP.abierta := ""
    }
    _CompTextos()
    if (COMP.abierta != antes)
        _AccRelayout()                               ; solo si cambió el alto
}
