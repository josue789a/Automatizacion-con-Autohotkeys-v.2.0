#Requires AutoHotkey v2.0
; [LIB] calibrador — fuente: XPPEN AHK VERSION ESTABLE.ahk L4601–4883, 4910–5517
; ===== Zonas duales: selector [NORMAL | ENFOQUE] del panel =====
_PtsModoMarcar() {
    global ptsModo,ptsEd,enfoque
    if (!IsObject(ptsModo.btnN) || !IsObject(ptsModo.btnE))
        return
    sel := (ptsModo.sel = 2) ? 2 : 1
    vivo := enfoque.activo ? 2 : 1
    try {
        ptsModo.btnN.Text := ((sel = 1) ? "● " : "○ ") . "NORMAL · Modo 1" . ((vivo = 1) ? "  [activo en CSP]" : "")
        ptsModo.btnE.Text := ((sel = 2) ? "● " : "○ ") . "ENFOQUE · Modo 2" . ((vivo = 2) ? "  [activo en CSP]" : "")
        ptsModo.btnN.SetFont((sel = 1) ? "s9 bold" : "s9 norm")
        ptsModo.btnE.SetFont((sel = 2) ? "s9 bold" : "s9 norm")
    }
    try ptsModo.barN.Value := (sel = 1) ? 100 : 0     ; tira azul bajo el botón elegido
    try ptsModo.barE.Value := (sel = 2) ? 100 : 0
    try ptsEd.g.Title := "📍 Calibración · rangos, avisos y sistema  ·  editando " . ((sel = 2) ? "ENFOQUE · Modo 2" : "NORMAL · Modo 1")
}
PtsModo_Set(m) {
    global ptsModo,ptsEd
    m := (m = 2) ? 2 : 1
    if (ptsModo.sel = m || ptsEd.dibujando || ptsEd.capturando) {
        _PtsModoMarcar()
        return
    }
    ptsModo.edit := true
    _PtsModoCambiar(m)
}
_PtsModoCambiar(m) {
    global ptsModo,ptsEd
    try GuardarPuntos(false)      ; vuelca el modo que se abandona (ptsModo.sel aún es el anterior)
    ptsModo.sel := m
    ptsModo.edit := true
    CargarPuntos()                ; PUNTOS / ZONAS / HIST_ALTO pasan al modo elegido
    _PtsRefrescar()               ; RecalcularZonas + filas del ListView en caliente
    _PtsModoMarcar()
    ; re-selecciona la fila actual para que las cajas X/Y/Ancho/Alto muestren los valores del modo nuevo
    if (IsObject(ptsEd.lv)) {
        r := (IsInteger(ptsEd.sel) && ptsEd.sel > 0) ? Integer(ptsEd.sel) : 1
        try ptsEd.lv.Modify(0,"-Select")
        try ptsEd.lv.Modify(r,"Select Focus Vis")
    }
}
_PtsModoVigilar() {
    global ptsModo,ptsEd
    if (ptsModo.recreando)
        return
    if (!IsObject(ptsEd.g) || ptsEd.g = 0)
        return
    vivo := 0
    try vivo := ptsEd.g.Hwnd ? WinExist("ahk_id " ptsEd.g.Hwnd) : 0
    if (vivo)
        return
    SetTimer(_PtsModoVigilar,0)
    if (!ptsModo.edit)
        return
    try GuardarPuntos(false)
    ptsModo.edit := false
    ptsModo.btnN := 0
    ptsModo.btnE := 0
    CargarPuntos()                ; vuelve al modo vivo de CSP
}
PtsModo_SincronizarCSP() {        ; la llama AccionEnfoque tras conmutar enfoque.activo
    global ptsModo,enfoque
    Critical("On")
    hot := enfoque.activo ? 2 : 1
    if (!ptsModo.edit)
        CargarPuntos()
    else if (ptsModo.sel = hot)
        _PtsModoMarcar()
    else
        _PtsModoCambiar(hot)
    Critical("Off")
}
AbrirPanelPuntos() {
    global PERFIL,PERFILES,ESC,AVISO_ESC,panelBlk,ESTAB_ALPHA_H,ESTAB_ALPHA_F
    if (!ptsModo.recreando) {
        if (IsObject(ptsEd.g) && !ptsModo.edit) {   ; panel oculto/cerrado antes: se reconstruye con el modo vivo
            try ptsEd.g.Destroy()
            ptsEd.g := 0
        }
        ptsModo.sel := enfoque.activo ? 2 : 1
        ptsModo.edit := true
    }
    if IsObject(ptsEd.g) {
        try {
            ptsEd.g.Show()
            return
        }
        ptsEd.g := 0
    }
    defs := _PtsZonaDefs()
    evs := _PtsEventosDefs()
    _PtsEvLeer()
    g := Gui("+AlwaysOnTop","📍 Calibración · rangos, avisos y sistema")
    g.SetFont("s9","Segoe UI")
    tb := g.Add("Tab3","x10 y10 w620 h540",["📐 Zonas y rangos","🔔 Eventos / HUD","⚙ Sistema y perfiles","🎨 Paleta de temas"])
    x0 := 24
    ; ---------------- Pestaña 1: zonas y rangos ----------------
    tb.UseTab(1)
    g.Add("Text","x" x0 " y48 w590 h34","Dibuja cada zona arrastrando el lápiz sobre la pantalla (un clic = punto). Doble toque en una fila = dibujar. Los puntos P1..P32 se recalculan solos para los demás scripts.")
    bModoN := g.Add("Button","x" x0 " y86 w295 h28","")
    bModoE := g.Add("Button","x" (x0 + 295) " y86 w295 h28","")
    ptsModo.btnN := bModoN
    ptsModo.btnE := bModoE
    ptsModo.barN := g.Add("Progress","x" x0 " y114 w295 h4 -Theme c4A90E2 BackgroundF3F3F3",0)
    ptsModo.barE := g.Add("Progress","x" (x0 + 295) " y114 w295 h4 -Theme c4A90E2 BackgroundF3F3F3",0)
    _PtsModoMarcar()
    bModoN.OnEvent("Click",(*) => PtsModo_Set(1))
    bModoE.OnEvent("Click",(*) => PtsModo_Set(2))
    lv := g.Add("ListView","x" x0 " y120 w590 r13 -Multi NoSortHdr Grid",["Zona","Tipo","X","Y","Ancho","Alto"])
    for d in defs
        lv.Add("",d.n,(d.t = "punto") ? "Punto" : "Rango","","","","")
    lv.ModifyCol(1,205)
    lv.ModifyCol(2,60)
    Loop 4
        lv.ModifyCol(2 + A_Index,75)
    lv.GetPos(&lx,&ly,&lw,&lh)
    yb := ly + lh + 10
    bDib := g.Add("Button","x" x0 " y" yb " w150","✏ Dibujar con lápiz")
    bCad := g.Add("Button","x" (x0 + 156) " y" yb " w150","⏩ Dibujar en cadena")
    bVer := g.Add("Button","x" (x0 + 312) " y" yb " w120","👁 Ver zonas")
    bDef := g.Add("Button","x" (x0 + 438) " y" yb " w140","↺ Por defecto")
    y2 := yb + 38
    g.Add("Text","x" x0 " y" (y2 + 4),"X")
    eX := g.Add("Edit","x" (x0 + 18) " y" y2 " w72","")
    g.Add("Text","x" (x0 + 100) " y" (y2 + 4),"Y")
    eY := g.Add("Edit","x" (x0 + 118) " y" y2 " w72","")
    g.Add("Text","x" (x0 + 200) " y" (y2 + 4),"Ancho")
    eW := g.Add("Edit","x" (x0 + 245) " y" y2 " w72","")
    g.Add("Text","x" (x0 + 327) " y" (y2 + 4),"Alto")
    eH := g.Add("Edit","x" (x0 + 357) " y" y2 " w72","")
    bAp := g.Add("Button","x" (x0 + 440) " y" (y2 - 1) " w120","✔ Aplicar valores")
    y3 := y2 + 36
    g.Add("Text","x" x0 " y" (y3 + 4),"Desplazar TODOS los puntos:   ΔX")
    dx := g.Add("Edit","x" (x0 + 215) " y" y3 " w58","0")
    g.Add("Text","x" (x0 + 285) " y" (y3 + 4),"ΔY")
    dy := g.Add("Edit","x" (x0 + 310) " y" y3 " w58","0")
    bDelta := g.Add("Button","x" (x0 + 380) " y" (y3 - 1) " w100","Aplicar Δ")
    y4 := y3 + 34
    g.Add("Text","x" x0 " y" (y4 + 4),"📐 Paneles CSP:")
    bLN1 := g.Add("Button","x" (x0 + 100) " y" y4 " w110","💾 Modo 1 (Norm)")
    bLE1 := g.Add("Button","x" (x0 + 216) " y" y4 " w110","💾 Modo 2 (Enf)")
    bLA1 := g.Add("Button","x" (x0 + 332) " y" y4 " w85","▶ Aplicar")
    bTog1 := g.Add("Button","x" (x0 + 423) " y" y4 " w155","🎯 Alternar (1 ⇄ 2)")
    bLN1.OnEvent("Click",(*) => _CapturarLayout("Normal"))
    bLE1.OnEvent("Click",(*) => _CapturarLayout("Enfoque"))
    bLA1.OnEvent("Click",(*) => _AplicarLayoutPaneles(ptsModo.edit ? ((ptsModo.sel = 2) ? "Enfoque" : "Normal") : (enfoque.activo ? "Enfoque" : "Normal")))
    bTog1.OnEvent("Click",(*) => AccionEnfoque())
    ; ---------------- Pestaña 2: eventos / HUD ----------------
    tb.UseTab(2)
    g.Add("Text","x" x0 " y46 w340 h22","Elige formato, prioridad y opacidad por evento:")
    g.Add("Text","x" (x0 + 345) " y46 w50 h22 Right","Grupo:")
    ddGrupo := g.Add("DropDownList","x" (x0 + 400) " y42 w190 Choose1",["📁 Todos los grupos","Pinceles y Trazos","Borradores y Mezcla","Color y Paleta","Selección","Lienzo y Reglas","Capas y Archivo"])
    lvEv := g.Add("ListView","x" x0 " y70 w590 r11 +Multi NoSortHdr Grid",["Acción (evento)","Grupo","Formato","Prioridad","Opac.","Duración"])
    lvEv.ModifyCol(1,228)
    lvEv.ModifyCol(2,92)
    lvEv.ModifyCol(3,72)
    lvEv.ModifyCol(4,64)
    lvEv.ModifyCol(5,56)
    lvEv.ModifyCol(6,72)
    lvEv.GetPos(&ex1,&ey1,&ew1,&eh1)
    yb2 := ey1 + eh1 + 8
    g.Add("Text","x" x0 " y" (yb2 + 4),"Formato:")
    ddF := g.Add("DropDownList","x" (x0 + 52) " y" yb2 " w88 Choose1",["Moderno","Bruto","Desactivado"])
    g.Add("Text","x" (x0 + 144) " y" (yb2 + 4),"Zona:")
    ddZ := g.Add("DropDownList","x" (x0 + 178) " y" yb2 " w78 Choose3",["Alta","Media","Baja"])
    g.Add("Text","x" (x0 + 260) " y" (yb2 + 4),"Opac:")
    ddOp := g.Add("DropDownList","x" (x0 + 296) " y" yb2 " w82 Choose2",["100% (Máx)","70% (Med)","40% (Bajo)"])
    bEvProbar := g.Add("Button","x" (x0 + 382) " y" (yb2 - 1) " w68","🔔 Probar")
    bEvAnclar := g.Add("Button","x" (x0 + 453) " y" (yb2 - 1) " w66","📌 Anclar")
    bEvReub   := g.Add("Button","x" (x0 + 522) " y" (yb2 - 1) " w68","📍 Reubicar")

    ; Texto / título del evento: editable directamente sin abrir otro panel
    yTxtEv := yb2 + 28
    g.Add("Text","x" x0 " y" (yTxtEv + 4),"Texto evento:")
    eTxtEv := g.Add("Edit","x" (x0 + 82) " y" yTxtEv " w294","")
    bTxtEv := g.Add("Button","x" (x0 + 382) " y" (yTxtEv - 1) " w137","✏ Guardar texto")
    bTxtReset := g.Add("Button","x" (x0 + 522) " y" (yTxtEv - 1) " w68","↺ Reset")
    bTxtEv.OnEvent("Click",_PtsEvTextoGuardar)
    bTxtReset.OnEvent("Click",_PtsEvTextoReset)

    ; Duración propia del evento: vacía = hereda la de su prioridad
    yDurEv := yTxtEv + 28
    g.Add("Text","x" x0 " y" (yDurEv + 4),"Duración (ms):")
    eDurEv := g.Add("Edit","x" (x0 + 82) " y" yDurEv " w60","")
    bDurEv := g.Add("Button","x" (x0 + 148) " y" (yDurEv - 1) " w82","⏱ Aplicar")
    lblDurEfec := g.Add("Text","x" (x0 + 236) " y" (yDurEv + 4) " w354 cGray","Efectiva: —")
    bDurEv.OnEvent("Click",_PtsEvDurAplicar)

    ; Panel de duraciones por prioridad (Alta: 3 ms/300 ms, Media: 5 ms/500 ms, Baja: 4 ms/400 ms)
    yDur := yDurEv + 28
    g.Add("GroupBox","x" x0 " y" yDur " w590 h44","⏱ Duraciones de aviso por prioridad (ms / s):")
    g.Add("Text","x" (x0 + 12) " y" (yDur + 18),"Alta:")
    eDurA := g.Add("Edit","x" (x0 + 44) " y" (yDur + 15) " w52", IniRead(_PosGuiIniPath(),"HudDuraciones" PERFIL,"duracion_alta","300"))
    g.Add("Text","x" (x0 + 104) " y" (yDur + 18),"Media:")
    eDurM := g.Add("Edit","x" (x0 + 148) " y" (yDur + 15) " w52", IniRead(_PosGuiIniPath(),"HudDuraciones" PERFIL,"duracion_media","500"))
    g.Add("Text","x" (x0 + 208) " y" (yDur + 18),"Baja:")
    eDurB := g.Add("Edit","x" (x0 + 244) " y" (yDur + 15) " w52", IniRead(_PosGuiIniPath(),"HudDuraciones" PERFIL,"duracion_baja","400"))
    bDurGuardar := g.Add("Button","x" (x0 + 306) " y" (yDur + 14) " w125","💾 Guardar dur.")
    g.Add("Text","x" (x0 + 438) " y" (yDur + 18) " cGray","(def: 3, 5, 4 ms/s)")
    bDurGuardar.OnEvent("Click", (*) => _GuardarDuracionesHUD(eDurA.Value, eDurM.Value, eDurB.Value))

    g.Add("Text","x" x0 " y" (yDur + 46) " w590 h18 cGray","💡 Edita el texto o duración directamente abajo. Los desactivados bajan al final.")
    stEv := g.Add("Text","x" x0 " y" (yDur + 66) " w590 h26 Background2A2140 cFFFFFF +0x200","▶ Selecciona un evento para ver su atajo real.")
    stEv.SetFont("s9 bold","Segoe UI")
    ; ---------------- Pestaña 3: sistema y perfiles ----------------
    tb.UseTab(3)
    xc := x0 + 215
    y := 52
    g.Add("Text","x" x0 " y" (y + 4),"Perfil de equipo:")
    ddl := g.Add("DropDownList","x" xc " y" y " w230 Choose" PERFIL,PERFILES)
    y += 40
    g.Add("Text","x" x0 " y" (y + 4),"Escala de botones (%):")
    eEsc := g.Add("Edit","x" xc " y" y " w60",Round(ESC * 100))
    g.Add("Text","x" (xc + 72) " y" (y + 4),"(se aplica al guardar)")
    y += 36
    g.Add("Text","x" x0 " y" (y + 4),"Escala de avisos (%):")
    eEscAv := g.Add("Edit","x" xc " y" y " w60",Round(AVISO_ESC * 100))
    g.Add("Text","x" (xc + 72) " y" (y + 4),"(HUD, mini-textos)")
    y += 46
    g.Add("Text","x" x0 " y" (y + 5),"📌 Botones del script:")
    bMover := g.Add("Button","x" xc " y" y " w150",panelBlk.locked ? "🔓 Mover botones" : "🔒 Fijar botones")
    bReub := g.Add("Button","x" (xc + 156) " y" y " w150","↺ Reubicar botones")
    y += 40
    g.Add("Text","x" x0 " y" (y + 5),"📌 Paneles de CSP:")
    bLN := g.Add("Button","x" xc " y" y " w110","💾 Normal")
    bLE := g.Add("Button","x" (xc + 116) " y" y " w120","💾 Enfoque")
    bLA := g.Add("Button","x" (xc + 242) " y" y " w90","▶ Aplicar")
    y += 46
    g.Add("Text","x" x0 " y" (y + 4),"Opacidad desliz. horizontal (%):")
    eAlpha := g.Add("Edit","x" xc " y" y " w60",Round(ESTAB_ALPHA_H / 2.55))
    g.Add("Text","x" (xc + 72) " y" (y + 4),"(ancha = horizontal)")
    y += 36
    g.Add("Text","x" x0 " y" (y + 4),"Opacidad desliz. de enfoque (%):")
    eAlphaF := g.Add("Edit","x" xc " y" y " w60",Round(ESTAB_ALPHA_F / 2.55))
    y += 40
    g.Add("GroupBox","x" x0 " y" y " w590 h108","🧩 Botón HUB — Embeber botones (acceso directo por clic derecho)")
    g.Add("Text","x" (x0 + 15) " y" (y + 24),"Fila 1:")
    chkL := g.Add("CheckBox","x" (x0 + 65) " y" (y + 24) " Checked" (hubGui.embebidos.Has("lock") && hubGui.embebidos["lock"]?1:0),"Bloquear")
    chkL.OnEvent("Click",(*) => _MenuToggleEmbebido("lock"))
    chkF := g.Add("CheckBox","x" (x0 + 155) " y" (y + 24) " Checked" (hubGui.embebidos.Has("frente") && hubGui.embebidos["frente"]?1:0),"Frente")
    chkF.OnEvent("Click",(*) => _MenuToggleEmbebido("frente"))
    chkP := g.Add("CheckBox","x" (x0 + 230) " y" (y + 24) " Checked" (hubGui.embebidos.Has("puntos") && hubGui.embebidos["puntos"]?1:0),"Calibrador")
    chkP.OnEvent("Click",(*) => _MenuToggleEmbebido("puntos"))
    chkE := g.Add("CheckBox","x" (x0 + 320) " y" (y + 24) " Checked" (hubGui.embebidos.Has("estab") && hubGui.embebidos["estab"]?1:0),"Estabilizador")
    chkE.OnEvent("Click",(*) => _MenuToggleEmbebido("estab"))
    chkR := g.Add("CheckBox","x" (x0 + 430) " y" (y + 24) " Checked" (hubGui.embebidos.Has("reload") && hubGui.embebidos["reload"]?1:0),"Recargar")
    chkR.OnEvent("Click",(*) => _MenuToggleEmbebido("reload"))

    g.Add("Text","x" (x0 + 15) " y" (y + 60),"Fila 2:")
    chkDS := g.Add("CheckBox","x" (x0 + 65) " y" (y + 60) " Checked" (hubGui.embebidos.Has("ds") && hubGui.embebidos["ds"]?1:0),"Slider")
    chkDS.OnEvent("Click",(*) => _MenuToggleEmbebido("ds"))
    chkCC := g.Add("CheckBox","x" (x0 + 155) " y" (y + 60) " Checked" (hubGui.embebidos.Has("cc") && hubGui.embebidos["cc"]?1:0),"Color")
    chkCC.OnEvent("Click",(*) => _MenuToggleEmbebido("cc"))
    chkAR := g.Add("CheckBox","x" (x0 + 230) " y" (y + 60) " Checked" (hubGui.embebidos.Has("ar") && hubGui.embebidos["ar"]?1:0),"Acceso R.")
    chkAR.OnEvent("Click",(*) => _MenuToggleEmbebido("ar"))
    chkHC := g.Add("CheckBox","x" (x0 + 320) " y" (y + 60) " Checked" (hubGui.embebidos.Has("hc") && hubGui.embebidos["hc"]?1:0),"Hist. Color")
    chkHC.OnEvent("Click",(*) => _MenuToggleEmbebido("hc"))
    chkFL := g.Add("CheckBox","x" (x0 + 430) " y" (y + 60) " Checked" (hubGui.embebidos.Has("flip") && hubGui.embebidos["flip"]?1:0),"Voltear")
    chkFL.OnEvent("Click",(*) => _MenuToggleEmbebido("flip"))
    chkEN := g.Add("CheckBox","x" (x0 + 510) " y" (y + 60) " Checked" (hubGui.embebidos.Has("enfoque") && hubGui.embebidos["enfoque"]?1:0),"Enfoque")
    chkEN.OnEvent("Click",(*) => _MenuToggleEmbebido("enfoque"))
    yBak := y + 120
    g.Add("GroupBox","x" x0 " y" yBak " w590 h76","🗂 Copia de seguridad de posiciones_gui.ini")
    bBak := g.Add("Button","x" (x0 + 14) " y" (yBak + 26) " w150","💾 Crear backup")
    bRes := g.Add("Button","x" (x0 + 172) " y" (yBak + 26) " w170","↩ Restaurar último")
    lblBak := g.Add("Text","x" (x0 + 352) " y" (yBak + 28) " w226 h42 cGray","Sin backups todavía.")
    bBak.OnEvent("Click",_PtsBackupIni)
    bRes.OnEvent("Click",_PtsRestaurarIni)
    ; ---------------- Pestaña 4: paleta de temas ----------------
    tb.UseTab(4)
    g.Add("Text","x" x0 " y48 w590 h34","Selecciona la paleta de colores y estilos para los botones del script, colores de acento y avisos en pantalla.")
    g.Add("Text","x" x0 " y95 w590 h26 cGray","Tema activo actualmente: " _Tema("meta","nombre","Oscuro"))
    bAbrirTema := g.Add("Button","x" x0 " y130 w220 h36","🎨 Abrir Selector de Temas")
    bAbrirTema.OnEvent("Click",(*) => _AbrirSelectorTema())
    tb.UseTab(0)
    st := g.Add("Text","x10 y558 w620 h34","")
    bOk := g.Add("Button","x10 y598 w145 Default","💾 Guardar y cerrar")
    bRei := g.Add("Button","x160 y598 w140","🔄 Reiniciar script")
    bTemaBar := g.Add("Button","x306 y598 w150","🎨 Paleta de temas")
    bTemaBar.OnEvent("Click",(*) => _AbrirSelectorTema())
    ptsEd.g := g
    ptsEd.lv := lv
    ptsEd.bVer := bVer
    ptsEd.eX := eX
    ptsEd.eY := eY
    ptsEd.eW := eW
    ptsEd.eH := eH
    ptsEd.dx := dx
    ptsEd.dy := dy
    ptsEd.eEsc := eEsc
    ptsEd.eEscAv := eEscAv
    ptsEd.eAlpha := eAlpha
    ptsEd.eAlphaF := eAlphaF
    ptsEd.st := st
    ptsEd.lvEv := lvEv
    ptsEd.ddGrupo := ddGrupo
    ptsEd.mapFilas := []
    ptsEd.ddF := ddF
    ptsEd.ddZ := ddZ
    ptsEd.ddOp := ddOp
    ptsEd.eTxtEv := eTxtEv
    ptsEd.eDurEv := eDurEv
    ptsEd.lblDurEfec := lblDurEfec
    ptsEd.stEv := stEv
    ptsEd.lblBak := lblBak
    ptsEd.bRes := bRes
    ptsEd.bEvAnclar := bEvAnclar
    ptsEd.bEvReub := bEvReub
    ptsEd.bEvReub.Enabled := false
    ptsEd.evAnclado := false
    ptsEd.guiAnclado := 0
    ptsEd.sel := 0
    ptsEd.evSel := 0
    st.Value := "Perfil activo: " PERFILES[PERFIL] ". Selecciona una zona."
    lv.OnEvent("ItemSelect",_PtsSel)
    lv.OnEvent("DoubleClick",(*) => _PtsDibujarSel(false))
    bDib.OnEvent("Click",(*) => _PtsDibujarSel(false))
    bCad.OnEvent("Click",(*) => _PtsDibujarSel(true))
    bVer.OnEvent("Click",_PtsToggleVerZonas)
    bDef.OnEvent("Click",_PtsDefecto)
    bAp.OnEvent("Click",_PtsAplicarCampos)
    bDelta.OnEvent("Click",_PtsDesplazar)
    ddGrupo.OnEvent("Change",(*) => _PtsEvFilas())
    lvEv.OnEvent("ItemSelect",_PtsEvSel)
    lvEv.OnEvent("DoubleClick",_PtsEvDobleClick)
    ddF.OnEvent("Change",_PtsEvCambio)
    ddZ.OnEvent("Change",_PtsEvCambio)
    ddOp.OnEvent("Change",_PtsEvCambio)
    bEvProbar.OnEvent("Click",_PtsEvProbar)
    bEvAnclar.OnEvent("Click",_PtsEvToggleAnclar)
    bEvReub.OnEvent("Click",_PtsEvReubicarZona)
    ddl.OnEvent("Change",_PtsCambiarPerfil)
    bMover.OnEvent("Click",(ctrl,*) => _PtsMoverBotones(ctrl))
    bReub.OnEvent("Click",_PtsReubicar)
    bLN.OnEvent("Click",(*) => _CapturarLayout("Normal"))
    bLE.OnEvent("Click",(*) => _CapturarLayout("Enfoque"))
    bLA.OnEvent("Click",(*) => _AplicarLayoutPaneles(enfoque.activo ? "Enfoque" : "Normal"))
    eAlpha.OnEvent("Change",_PtsAlphaChange)
    eAlphaF.OnEvent("Change",_PtsAlphaFChange)
    bRei.OnEvent("Click",_PtsReiniciar)
    bOk.OnEvent("Click",_PtsCerrar)
    g.OnEvent("Close",_PtsCerrar)
    g.OnEvent("Escape",_PtsCerrar)
    g.Show("AutoSize")
    SetTimer(_PtsModoVigilar,500)
    _PtsRefrescar()
    _PtsEvFilas()
    _PtsBakRefrescar()
    lv.Modify(1,"Select Focus")
    _PtsSel(lv,1,true)
    lvEv.Modify(1,"Select Focus")
    _PtsEvSel(lvEv,1,true)
}
; ===== Catálogo de zonas (todo en función con static: el código global de aquí no se auto-ejecuta) =====
_PtsZonaDefs() {
    static defs := 0
    if IsObject(defs)
        return defs
    defs := []
    Loop 3
        defs.Push({k:"IzqB" A_Index,n:"Panel izq · B" A_Index,t:"caja",p:3 + (A_Index - 1) * 4,zi:A_Index,lado:"izq",c:"2ECC71"})
    Loop 3
        defs.Push({k:"DerB" A_Index,n:"Panel der · B" A_Index,t:"caja",p:15 + (A_Index - 1) * 4,zi:A_Index,lado:"der",c:"3498DB"})
    defs.Push({k:"Historial",n:"Franja de historial",t:"hist",c:"E67E22"})
    defs.Push({k:"ToggleIzq",n:"Ocultar/mostrar panel izq (P1)",t:"punto",p:1,c:"E74C3C"})
    defs.Push({k:"ToggleDer",n:"Ocultar/mostrar panel der (P2)",t:"punto",p:2,c:"E74C3C"})
    defs.Push({k:"ZonaSegura",n:"Zona segura del cursor (P29)",t:"punto",p:29,c:"F1C40F"})
    defs.Push({k:"Estab",n:"Deslizador de estabilización",t:"estab",c:ESTAB_COLOR})
    defs.Push({k:"EstabFoco",n:"Deslizador de enfoque (Shift+E)",t:"estabF",c:"FF8800"})
    defs.Push({k:"HUD_Alta",n:"Aviso HUD · Zona 1 (Alta)",t:"hud",c:"FF4D6D"})
    defs.Push({k:"HUD_Media",n:"Aviso HUD · Zona 2 (Media)",t:"hud",c:"FFB703"})
    defs.Push({k:"HUD_Baja",n:"Aviso HUD · Zona 3 (Baja)",t:"hud",c:"9B59B6"})
    return defs
}
_PtsDefPorClave(k) {
    for d in _PtsZonaDefs() {
        if (d.k = k)
            return d
    }
    return 0
}
_PtsEventosDefs() {
    static evs := 0
    if IsObject(evs)
        return evs
    evs := [
        ["pluma", "Plumilla / Pincel Tinta (Q)", "Pinceles y Trazos"],
        ["aerografo", "Aerógrafo Principal (W)", "Pinceles y Trazos"],
        ["aerografo_alpha", "Aerógrafo Alpha Borrador (W doble → K)", "Pinceles y Trazos"],
        ["pincel_suave", "Pincel Suave (Alt + Q)", "Pinceles y Trazos"],
        ["pincel_duro", "Pincel Duro · Hard Brush (RButton + Q → F6)", "Pinceles y Trazos"],
        ["difu_mixer", "Difuminador Mezclador (RButton + W → Ñ)", "Pinceles y Trazos"],
        ["opc_presion", "Opacidad por Presión (Alt + W → <)", "Pinceles y Trazos"],
        ["borrador", "Borrador de Capas (E)", "Borradores y Mezcla"],
        ["borrador_suave", "Borrador Suave · Soft Eraser (E doble → L)", "Borradores y Mezcla"],
        ["borrador_lazo", "Borrador de Lazo (RButton + E → F12)", "Borradores y Mezcla"],
        ["smudge", "Dedo / Smudge (X alterno → P)", "Borradores y Mezcla"],
        ["smear", "Smear Mezcla (F → B / NumpadEnd)", "Borradores y Mezcla"],
        ["color_mix", "Mezcla de Color (X → D)", "Borradores y Mezcla"],
        ["color_primario", "Color Primario (Q doble)", "Color y Paleta"],
        ["color_secundario", "Color Secundario (Q doble alterno)", "Color y Paleta"],
        ["color_alpha", "Alpha Transparente (K)", "Color y Paleta"],
        ["relleno", "Bote de Pintura / Relleno (RButton + 1 → V)", "Color y Paleta"],
        ["area_color", "Área con Color (S doble)", "Color y Paleta"],
        ["lazo", "Herramienta Lazo (S)", "Selección"],
        ["seleccion", "Selección Marquee (M)", "Selección"],
        ["deseleccion", "Deselección (Ctrl + D)", "Selección"],
        ["reseleccion", "Reselección (Ctrl + Shift + D)", "Selección"],
        ["inv_seleccion", "Invertir Selección (Ctrl + Shift + I)", "Selección"],
        ["shift_sostenido", "Regla Recta · Shift Sostenido (RButton + F)", "Lienzo y Reglas"],
        ["flip_horizontal", "Volteo Horizontal del Lienzo (Space → Alt + G)", "Lienzo y Reglas"],
        ["rotar_lienzo", "Rotación de Lienzo (Z doble → R)", "Lienzo y Reglas"],
        ["zoom_lienzo", "Zoom de Lienzo (Z)", "Lienzo y Reglas"],
        ["regla_ocultar", "Reglas: mostrar / ocultar (RButton + − → T / Alt + T)", "Lienzo y Reglas"],
        ["capa_visibilidad", "Visibilidad de Capa (heredado · Space + E)", "Capas y Archivo"],
        ["capa_ocultar", "Ocultar Capa · Hide Layer (Space + E → Shift + D)", "Capas y Archivo"],
        ["capa_mostrar", "Mostrar Capa · Show Layer (Space + E → Shift + D)", "Capas y Archivo"],
        ["macro_capas", "Ciclo de Macros 1→2→3 (O / −)", "Capas y Archivo"],
        ["mascara_recorte", "Máscara de Capa / Recorte (RButton + S → M)", "Capas y Archivo"],
        ["capa_referencia", "Capa de Referencia · Ref Layer", "Capas y Archivo"],
        ["guardar", "Guardar Archivo .clip (Ctrl + S)", "Capas y Archivo"],
        ["deshacer", "Deshacer (Ctrl + Z)", "Capas y Archivo"],
        ["rehacer", "Rehacer (Ctrl + Y)", "Capas y Archivo"],
        ["copiar", "Copiar al Portapapeles (Ctrl + C)", "Capas y Archivo"],
        ["enfoque", "Modo Enfoque / Plegar Paneles (Tab / Shift + Esc / F3)", "Capas y Archivo"],
        ["hover_paneles", "Hover de Paneles Desplegables (+W)", "Capas y Archivo"],
        ["history_lock", "Bloqueo de Franja Historial", "Capas y Archivo"],
        ["bloque_gui", "Fijar / Mover Botones del Companion", "Capas y Archivo"],
        ["gui_frente", "Botones al Frente / Solo en CSP", "Capas y Archivo"],
        ["estab_slider", "Deslizador de Estabilización", "Capas y Archivo"],
        ["estab_sync", "Sincronización de Estabilizador", "Capas y Archivo"],
        ["layout", "Guardar / Aplicar Layout de Paneles", "Capas y Archivo"],
        ["reload", "Recargar Script", "Capas y Archivo"]
    ]
    return evs
}
; ===== Lectura / escritura de zonas =====
_PtsEstabRect(foco) {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "Estab_p" PERFIL
    p := foco ? "f" : ""
    x := IniRead(ini,sec,p "x","")
    y := IniRead(ini,sec,p "y","")
    w := IniRead(ini,sec,p "w","")
    h := IniRead(ini,sec,p "h","")
    if (IsInteger(x) && IsInteger(y) && IsInteger(w) && IsInteger(h))
        return {x:Integer(x),y:Integer(y),w:Integer(w),h:Integer(h)}
    return {x:"",y:"",w:"",h:""}
}
_PtsRectDe(d) {
    global PUNTOS,ZONAS
    t := d.t
    if (t = "caja") {
        zs := (d.lado = "izq") ? ZONAS.izq : ZONAS.der
        z := zs[d.zi]
        return {x:z.x1,y:z.y1,w:z.x2 - z.x1 + 1,h:z.y2 - z.y1 + 1}
    }
    if (t = "hist") {
        z := ZONAS.hist
        return {x:z.x1,y:z.y1,w:z.x2 - z.x1 + 1,h:z.y2 - z.y1 + 1}
    }
    if (t = "punto") {
        rg := ObtenerRango(d.k)
        if (IsObject(rg) && IsInteger(rg.w) && rg.w > 0 && IsInteger(rg.h) && rg.h > 0)
            return rg
        return {x:PUNTOS[d.p][1],y:PUNTOS[d.p][2],w:"",h:""}
    }
    if (t = "estab" || t = "estabF")
        return _PtsEstabRect(t = "estabF")
    r := ObtenerRango(d.k)
    return IsObject(r) ? r : {x:"",y:"",w:"",h:""}
}
_PtsAplicarZona(d,r) {
    global PUNTOS,HIST_ALTO,PERFIL
    t := d.t
    msg := ""
    if (t = "caja") {
        if (r.w < 6 || r.h < 6) {
            ptsEd.st.Value := "Rango demasiado pequeño (mín. 6×6 px)."
            return false
        }
        x2 := r.x + r.w - 1
        y2 := r.y + r.h - 1
        esq := [[r.x,r.y],[x2,r.y],[r.x,y2],[x2,y2]]
        for k,c in esq {
            PUNTOS[d.p + k - 1][1] := c[1]
            PUNTOS[d.p + k - 1][2] := c[2]
        }
        msg := r.w "×" r.h " en (" r.x "," r.y ")"
    } else if (t = "hist") {
        if (r.w < 6 || r.h < 1) {
            ptsEd.st.Value := "Rango de historial demasiado pequeño."
            return false
        }
        PUNTOS[27][1] := r.x
        PUNTOS[27][2] := r.y
        PUNTOS[28][1] := r.x + r.w - 1
        PUNTOS[28][2] := r.y
        HIST_ALTO := Max(0,r.h - 1)
        msg := r.w "×" r.h " en (" r.x "," r.y ")"
    } else if (t = "punto") {
        w := (IsInteger(r.w) && r.w > 0) ? r.w : 0
        h := (IsInteger(r.h) && r.h > 0) ? r.h : 0
        px := (w > 0) ? (r.x + w // 2) : r.x
        py := (h > 0) ? (r.y + h // 2) : r.y
        PUNTOS[d.p][1] := px
        PUNTOS[d.p][2] := py
        if (w > 0 && h > 0)
            IniWrite(r.x "," r.y "," w "," h,_PosGuiIniPath(),_ZonaSec("Rangos"),d.k)
        else
            IniWrite(px "," py,_PosGuiIniPath(),_ZonaSec("Rangos"),d.k)
        msg := (w > 0) ? (w "×" h " en (" r.x "," r.y ")") : ("(" px "," py ")")
    } else if (t = "estab") {
        if !_EstabTamanoValido(r.w,r.h) {
            ptsEd.st.Value := "Zona demasiado pequeña (mín. 14 px de grosor y 60 de largo)."
            return false
        }
        if !_EstabAplicarRect(r.x,r.y,r.w,r.h) {
            ini := _PosGuiIniPath()
            sec := "Estab_p" PERFIL
            IniWrite(r.x,ini,sec,"x")
            IniWrite(r.y,ini,sec,"y")
            IniWrite(r.w,ini,sec,"w")
            IniWrite(r.h,ini,sec,"h")
        }
        msg := r.w "×" r.h " (" ((r.w > r.h) ? "horizontal" : "vertical") ")"
    } else if (t = "estabF") {
        if !_EstabTamanoValido(r.w,r.h) {
            ptsEd.st.Value := "Zona demasiado pequeña (mín. 14 px de grosor y 60 de largo)."
            return false
        }
        _EstabFocoGuardarRect(r.x,r.y,r.w,r.h)
        msg := r.w "×" r.h " (" ((r.w > r.h) ? "horizontal" : "vertical") "). Aparece con Shift+E"
        try _EstabFocoPrevisualizar()
    } else {
        if (r.w < 6 || r.h < 6) {
            ptsEd.st.Value := "Rango demasiado pequeño (mín. 6×6 px)."
            return false
        }
        IniWrite(r.x "," r.y "," r.w "," r.h,_PosGuiIniPath(),_ZonaSec("Rangos"),d.k)
        msg := r.w "×" r.h " en (" r.x "," r.y ")"
    }
    _PtsRefrescar()
    ptsEd.st.Value := d.n " guardado: " msg
    _SonarUI("calib")
    return true
}
_RgGuardarMirror() {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := _ZonaSec("Rangos")
    IniWrite("x,y,ancho,alto en px de pantalla virtual (puntos: x,y). Derivado de P1..P32; HUD_Alta y HUD_Media son propios.",ini,sec,"_formato")
    for d in _PtsZonaDefs() {
        if (d.t = "estab" || d.t = "estabF" || d.t = "hud")
            continue
        r := _PtsRectDe(d)
        if (d.t = "punto")
            v := r.x "," r.y
        else
            v := r.x "," r.y "," r.w "," r.h
        IniWrite(v,ini,sec,d.k)
    }
}
; ===== Dibujo con lápiz =====
_PtsDibujarRango(texto,color := "9A7BFF",permitirPunto := false) {
    if (ptsEd.dibujando)
        return 0
    ptsEd.dibujando := true
    ov := 0
    tip := 0
    tipTxt := 0
    pv := 0
    ok := false
    cancelado := false
    x0 := 0
    y0 := 0
    rx := 0
    ry := 0
    rw := 0
    rh := 0
    try {
        try ptsEd.g.Hide()
        vx := SysGet(76)
        vy := SysGet(77)
        vw := SysGet(78)
        vh := SysGet(79)
        ov := Gui("+AlwaysOnTop -Caption +ToolWindow -DPIScale","")
        ov.BackColor := "0B0B14"
        ov.Show("x" vx " y" vy " w" vw " h" vh)
        WinSetTransparent(80,"ahk_id " ov.Hwnd)
        mon := ObtenerMonitorCSP()
        tip := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale","")
        tip.BackColor := "1E1E2E"
        tip.SetFont("s11 bold cWhite","Segoe UI")
        tipTxt := tip.AddText("x12 y8 w900 h26 Center",texto)
        tip.Show("x" (mon.x + (mon.w - 924) // 2) " y" (mon.y + 40) " w924 h42 NoActivate")
        cur := Buffer(8,0)
        t0 := A_TickCount
        while !GetKeyState("LButton","P") {
            if (GetKeyState("Escape","P") || A_TickCount - t0 > 60000) {
                cancelado := true
                break
            }
            Sleep(10)
        }
        if !cancelado {
            DllCall("GetCursorPos","Ptr",cur)
            x0 := NumGet(cur,0,"int")
            y0 := NumGet(cur,4,"int")
            pv := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale","")
            pv.BackColor := color
            pv.Show("x" x0 " y" y0 " w4 h4 NoActivate")
            WinSetTransparent(150,"ahk_id " pv.Hwnd)
            rx := x0
            ry := y0
            rw := 4
            rh := 4
            ultW := -1
            ultH := -1
            while GetKeyState("LButton","P") {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                rx := Min(x0,mx)
                ry := Min(y0,my)
                rw := Max(4,Abs(mx - x0))
                rh := Max(4,Abs(my - y0))
                DllCall("SetWindowPos","Ptr",pv.Hwnd,"Ptr",-1,"int",rx,"int",ry,"int",rw,"int",rh,"uint",0x0010)
                if (rw != ultW || rh != ultH) {
                    ultW := rw
                    ultH := rh
                    tipTxt.Value := texto "   ·   " rw " × " rh
                }
                if GetKeyState("Escape","P") {
                    cancelado := true
                    break
                }
                Sleep(8)
            }
            if !cancelado
                ok := true
        }
    } finally {
        for gg in [pv,tip,ov] {
            if IsObject(gg)
                try gg.Destroy()
        }
        ptsEd.dibujando := false
    }
    KeyWait("Escape","T1")
    try ptsEd.g.Show()
    if !ok
        return 0
    if (permitirPunto && rw <= 8 && rh <= 8)
        return {x:x0,y:y0,w:0,h:0}
    return {x:rx,y:ry,w:rw,h:rh}
}
_PtsDibujarSel(encadenar := false) {
    defs := _PtsZonaDefs()
    i := ptsEd.sel
    if (i < 1 || i > defs.Length) {
        ptsEd.st.Value := "Selecciona primero una zona en la lista."
        return
    }
    Loop {
        d := defs[i]
        if (d.t = "punto")
            txt := "✏ " d.n "  ·  haz clic en el punto (o arrastra una caja)  ·  Esc = cancelar"
        else
            txt := "✏ " d.n "  ·  arrastra el lápiz para dibujar el rango  ·  Esc = cancelar"
        r := _PtsDibujarRango(txt,d.c,d.t = "punto")
        if !IsObject(r) {
            ptsEd.st.Value := "Dibujo cancelado."
            break
        }
        okz := _PtsAplicarZona(d,r)
        if (!okz || !encadenar || i >= defs.Length)
            break
        i += 1
        ptsEd.sel := i
        try ptsEd.lv.Modify(i,"Select Focus Vis")
    }
}
; ===== Tabla de zonas =====
_PtsCamposDe(i) {
    defs := _PtsZonaDefs()
    if (i < 1 || i > defs.Length)
        return
    d := defs[i]
    r := _PtsRectDe(d)
    ptsEd.eX.Value := r.x
    ptsEd.eY.Value := r.y
    ptsEd.eW.Value := r.w
    ptsEd.eH.Value := r.h
    esPunto := (d.t = "punto")
    ptsEd.eW.Enabled := !esPunto
    ptsEd.eH.Enabled := !esPunto
}
_PtsSel(ctrl,item,selected) {
    if (!selected || item < 1)
        return
    ptsEd.sel := item
    _PtsCamposDe(item)
    d := _PtsZonaDefs()[item]
    ptsEd.st.Value := d.n " — " ((d.t = "punto") ? "punto" : "rango") ". Dibuja con el lápiz o escribe los valores."
}
_PtsAplicarCampos(*) {
    defs := _PtsZonaDefs()
    i := ptsEd.sel
    if (i < 1 || i > defs.Length)
        return
    d := defs[i]
    x := Trim(ptsEd.eX.Value)
    y := Trim(ptsEd.eY.Value)
    w := Trim(ptsEd.eW.Value)
    h := Trim(ptsEd.eH.Value)
    if (!IsInteger(x) || !IsInteger(y)) {
        ptsEd.st.Value := "X e Y deben ser enteros."
        return
    }
    if (d.t != "punto" && (!IsInteger(w) || !IsInteger(h))) {
        ptsEd.st.Value := "Ancho y Alto deben ser enteros."
        return
    }
    r := {x:Integer(x),y:Integer(y),w:(IsInteger(w) ? Integer(w) : 0),h:(IsInteger(h) ? Integer(h) : 0)}
    _PtsAplicarZona(d,r)
}
_PtsRefrescar() {
    RecalcularZonas()
    for i,d in _PtsZonaDefs() {
        r := _PtsRectDe(d)
        ptsEd.lv.Modify(i,"",d.n,(d.t = "punto") ? "Punto" : "Rango",r.x,r.y,r.w,r.h)
    }
    if (ptsEd.sel >= 1)
        _PtsCamposDe(ptsEd.sel)
}
_PtsDesplazar(*) {
    dx := Trim(ptsEd.dx.Value)
    dy := Trim(ptsEd.dy.Value)
    if (!IsInteger(dx) || !IsInteger(dy)) {
        ptsEd.st.Value := "ΔX y ΔY deben ser enteros."
        return
    }
    dx := Integer(dx)
    dy := Integer(dy)
    for p in PUNTOS {
        p[1] += dx
        p[2] += dy
    }
    _PtsRefrescar()
    ptsEd.dx.Value := "0"
    ptsEd.dy.Value := "0"
    ptsEd.st.Value := "Desplazados: ΔX=" dx " ΔY=" dy
}
_PtsDefecto(*) {
    global HIST_ALTO,PUNTOS
    ptsEd.g.Opt("+OwnDialogs")
    if (MsgBox("¿Restablecer todos los puntos de este perfil a los valores por defecto?","Por defecto","YesNo Icon?") != "Yes")
        return
    PUNTOS := PuntosPorDefecto()
    HIST_ALTO := 104
    _PtsRefrescar()
    ptsEd.st.Value := "Cargados los rangos por defecto (se guardan con 💾)."
}
; ===== Eventos / HUD =====
_GuardarDuracionesHUD(dA, dM, dB) {
    global PERFIL, _gDurCache
    vals := []
    for v in [dA,dM,dB] {
        v := Trim(v)
        if (!IsInteger(v) || Integer(v) < 1 || Integer(v) > 60000) {
            if IsObject(ptsEd.st)
                ptsEd.st.Value := "Duración inválida: enteros de 1 a 60000 ms (3 se lee como 300 ms)."
            return
        }
        n := Integer(v)
        vals.Push((n <= 10) ? n * 100 : n)
    }
    ini := _PosGuiIniPath()
    sec := "HudDuraciones" PERFIL
    IniWrite(vals[1], ini, sec, "duracion_alta")
    IniWrite(vals[2], ini, sec, "duracion_media")
    IniWrite(vals[3], ini, sec, "duracion_baja")
    ; HudDuracionDe() no lee la sección de arriba: lee [HudDuracion<perfil>] con
    ; claves alta|media|baja y sin normalizar, así que aquí se escribe ya en ms.
    for i, clave in ["alta","media","baja"]
        IniWrite(vals[i], ini, "HudDuracion" PERFIL, clave)
    _gDurCache.Clear()
    if IsObject(ptsEd.st)
        ptsEd.st.Value := "⏱ Duraciones guardadas: Alta=" vals[1] "ms, Media=" vals[2] "ms, Baja=" vals[3] "ms"
    if (IsObject(ptsEd.g) && IsObject(ptsEd.lvEv)) {
        _PtsEvFilas()
        _PtsEvDurRefrescar()
    }
}
_PtsDurPropia(id) {
    global PERFIL
    v := Trim(IniRead(_PosGuiIniPath(),"HudEventos" PERFIL,"duracion_" id,""))
    return (IsInteger(v) && Integer(v) > 0) ? String(Integer(v)) : ""
}
_PtsDurEfectiva(id,z) {
    ; HudDuracionDe (core_config) es la que usa el motor, así que la etiqueta muestra
    ; lo que de verdad va a pasar; el resto replica su orden por si aún no está.
    if IsSet(HudDuracionDe) {
        try return HudDuracionDe(id)
    }
    propia := _PtsDurPropia(id)
    if (propia != "") {
        v := Integer(propia)
        return Max(50,(v <= 10) ? v * 100 : v)
    }
    return HudDuracionZona(z)
}
_PtsEvDurAplicar(*) {
    global PERFIL, _gDurCache
    filas := _PtsEvObtenerSeleccionados(ptsEd.lvEv)
    if (filas.Length = 0 && ptsEd.evSel >= 1)
        filas := [ptsEd.evSel]
    if (filas.Length = 0) {
        ptsEd.st.Value := "Selecciona uno o más eventos para fijar su duración."
        return
    }
    v := Trim(ptsEd.eDurEv.Value)
    if (v != "" && (!IsInteger(v) || Integer(v) < 1 || Integer(v) > 60000)) {
        ptsEd.st.Value := "Duración inválida: entero de 1 a 60000 ms, o vacío para heredar de la prioridad."
        return
    }
    if (v != "") {
        ms := Integer(v)
        v := String((ms <= 10) ? ms * 100 : ms)   ; HudDuracionDe no normaliza: se guarda ya en ms
    }
    defs := _PtsEventosDefs()
    ini := _PosGuiIniPath()
    sec := "HudEventos" PERFIL
    n := 0
    for row in filas {
        if !ptsEd.mapFilas.Has(row)
            continue
        IniWrite(v,ini,sec,"duracion_" defs[ptsEd.mapFilas[row]][1])
        n += 1
    }
    _gDurCache.Clear()
    _PtsEvFilas()
    _PtsEvDurRefrescar()
    ptsEd.st.Value := (v = "") ? ("Duración propia borrada en " n " evento(s): heredan de su prioridad.") : ("Duración guardada: " v " ms en " n " evento(s).")
    _SonarUI("calib")
}
_PtsEvDobleClick(ctrl, rowNumber) {
    global PERFIL, _gDurCache
    if (rowNumber < 1 || !ptsEd.mapFilas.Has(rowNumber))
        return
    defs := _PtsEventosDefs()
    ev := defs[ptsEd.mapFilas[rowNumber]]
    idEv := ev[1]
    nomEv := ev[2]
    c := ptsEd.cfg[idEv]
    durPropia := _PtsDurPropia(idEv)
    durEfec := _PtsDurEfectiva(idEv, c.z)

    txtActual := (durPropia != "") ? (durPropia " ms (individual)") : (durEfec " ms (heredada de " _PtsZonaTxt(c.z) ")")
    ib := InputBox(
        "Modificar duración individual para:`n`n" nomEv "`n`n• Actual: " txtActual "`n• Ingresa duración en ms (ej: 300, 500, o 3 para 300 ms)`n• Deja vacío para HEREDAR de la prioridad estándar.",
        "⏱ Duración individual — " nomEv,
        "w400 h240",
        durPropia != "" ? durPropia : durEfec
    )
    if (ib.Result != "OK")
        return

    v := Trim(ib.Value)
    if (v != "") {
        if (!IsNumber(v) || v * 1 < 1 || v * 1 > 60000) {
            MsgBox("Duración inválida: ingresa un número de 1 a 60000 ms.", "Calibrador", "Icon! 0x40000")
            return
        }
        ms := Integer(v)
        v := String((ms <= 10 && ms > 0) ? ms * 100 : ms)
    }

    ini := _PosGuiIniPath()
    sec := "HudEventos" PERFIL
    IniWrite(v, ini, sec, "duracion_" idEv)
    _gDurCache.Clear()
    _PtsEvFilas()
    _PtsEvDurRefrescar()
    _SonarUI("calib")
    ptsEd.st.Value := (v = "") ? ("Duración propia eliminada para " nomEv " (hereda de prioridad).") : ("Duración fijada a " v " ms para " nomEv ".")
}
_PtsEvDurRefrescar() {
    if (!IsObject(ptsEd.g) || !ptsEd.mapFilas.Has(ptsEd.evSel))
        return
    ev := _PtsEventosDefs()[ptsEd.mapFilas[ptsEd.evSel]]
    c := ptsEd.cfg[ev[1]]
    propia := _PtsDurPropia(ev[1])
    ptsEd.eDurEv.Value := propia
    efectiva := _PtsDurEfectiva(ev[1],c.z)
    ; Sin clave zona_<id> en el ini, HudDuracionDe cae en el defecto del evento y no
    ; en la prioridad: decir "heredada de Baja" ahí sería mentira.
    origen := (propia != "") ? "propia del evento" : ((efectiva = HudDuracionZona(c.z)) ? "heredada de " _PtsZonaTxt(c.z) : "por defecto del evento")
    ptsEd.lblDurEfec.Value := "Efectiva: " efectiva " ms · " origen
    filas := _PtsEvObtenerSeleccionados(ptsEd.lvEv)
    if (filas.Length > 1)
        ptsEd.stEv.Value := "▶ " filas.Length " eventos seleccionados  ·  " StrTitle(c.f) " · " _PtsZonaTxt(c.z) " · " c.op "% · " efectiva " ms"
    else
        ptsEd.stEv.Value := "▶ " ev[2] "  ·  " StrTitle(c.f) " · " _PtsZonaTxt(c.z) " · " c.op "% · " efectiva " ms"
}
_PtsZonaTxt(z) {
    return (z = "alta") ? "Alta" : ((z = "media") ? "Media" : "Baja")
}
_PtsNomEvento(idEv) {
    global PERFIL
    try {
        txt := IniRead(_PosGuiIniPath(), "HudTextos" PERFIL, "texto_" idEv, "")
        if (txt != "")
            return txt
    }
    for ev in _PtsEventosDefs() {
        if (ev[1] = idEv)
            return ev[2]
    }
    return idEv
}
_PtsEvTextoGuardar(*) {
    global PERFIL
    filas := _PtsEvObtenerSeleccionados(ptsEd.lvEv)
    row := (filas.Length > 0) ? filas[1] : ptsEd.evSel
    if (row < 1 || !ptsEd.mapFilas.Has(row))
        return
    idxReal := ptsEd.mapFilas[row]
    ev := _PtsEventosDefs()[idxReal]
    idEv := ev[1]
    nuevoTxt := Trim(ptsEd.eTxtEv.Value)
    if (nuevoTxt = "")
        nuevoTxt := ev[2]
    IniWrite(nuevoTxt, _PosGuiIniPath(), "HudTextos" PERFIL, "texto_" idEv)
    _PtsEvFilas()
    if (ptsEd.evAnclado)
        _PtsMostrarGuiAnclado(row)
    _SonarUI("calib")
    ptsEd.st.Value := "Texto guardado para '" idEv "': " nuevoTxt
}
_PtsEvTextoReset(*) {
    global PERFIL
    filas := _PtsEvObtenerSeleccionados(ptsEd.lvEv)
    row := (filas.Length > 0) ? filas[1] : ptsEd.evSel
    if (row < 1 || !ptsEd.mapFilas.Has(row))
        return
    idxReal := ptsEd.mapFilas[row]
    ev := _PtsEventosDefs()[idxReal]
    idEv := ev[1]
    try IniDelete(_PosGuiIniPath(), "HudTextos" PERFIL, "texto_" idEv)
    ptsEd.eTxtEv.Value := ev[2]
    _PtsEvFilas()
    if (ptsEd.evAnclado)
        _PtsMostrarGuiAnclado(row)
    _SonarUI("calib")
    ptsEd.st.Value := "Texto restaurado al original: " ev[2]
}
_PtsEvLeer() {
    ptsEd.cfg := Map()
    for ev in _PtsEventosDefs() {
        c := HudConfigEvento(ev[1])
        ptsEd.cfg[ev[1]] := {f:c.formato,z:c.zona,op:c.opacidad}
    }
}
_PtsEvGuardar(k,f,z,op) {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "HudEventos" PERFIL
    IniWrite(f,ini,sec,"formato_" k)
    IniWrite(z,ini,sec,"zona_" k)
    IniWrite(op,ini,sec,"opacidad_" k)
    ptsEd.cfg[k] := {f:f,z:z,op:op}
}
_PtsEvFilas() {
    defs := _PtsEventosDefs()
    selIds := []
    for row in _PtsEvObtenerSeleccionados(ptsEd.lvEv) {
        if (ptsEd.mapFilas.Has(row))
            selIds.Push(defs[ptsEd.mapFilas[row]][1])
    }
    ptsEd.lvEv.Delete()
    ptsEd.mapFilas := []
    filtroGrupo := (IsObject(ptsEd.ddGrupo) && ptsEd.ddGrupo.Value > 1) ? ptsEd.ddGrupo.Text : ""
    orden := []
    for i, ev in defs {
        if (ptsEd.cfg[ev[1]].f != "desactivado")
            orden.Push(i)
    }
    for i, ev in defs {
        if (ptsEd.cfg[ev[1]].f = "desactivado")
            orden.Push(i)
    }
    for i in orden {
        ev := defs[i]
        grp := (ev.Length >= 3) ? ev[3] : "General"
        if (filtroGrupo != "" && grp != filtroGrupo)
            continue
        c := ptsEd.cfg[ev[1]]
        propia := _PtsDurPropia(ev[1])
        durTxt := (propia != "") ? propia " ms" : "(" _PtsDurEfectiva(ev[1],c.z) ")"
        nomEv := _PtsNomEvento(ev[1])
        ptsEd.mapFilas.Push(i)
        ptsEd.lvEv.Add("", nomEv, grp, StrTitle(c.f), _PtsZonaTxt(c.z), c.op "%", durTxt)
    }
    primera := 0
    for row, idxReal in ptsEd.mapFilas {
        for sid in selIds {
            if (sid = defs[idxReal][1]) {
                ptsEd.lvEv.Modify(row,(primera = 0) ? "Select Focus Vis" : "Select")
                if (primera = 0)
                    primera := row
                break
            }
        }
    }
    if (primera > 0)
        ptsEd.evSel := primera
}
_PtsEvObtenerSeleccionados(lv) {
    filas := []
    row := 0
    Loop {
        row := lv.GetNext(row)
        if (!row)
            break
        filas.Push(row)
    }
    return filas
}
_PtsEvSel(ctrl,item,selected) {
    if (!selected || item < 1 || !ptsEd.mapFilas.Has(item))
        return
    ptsEd.evSel := item
    idxReal := ptsEd.mapFilas[item]
    idEv := _PtsEventosDefs()[idxReal][1]
    if (IsObject(ptsEd) && HasProp(ptsEd, "eTxtEv") && IsObject(ptsEd.eTxtEv))
        ptsEd.eTxtEv.Value := _PtsNomEvento(idEv)
    filas := _PtsEvObtenerSeleccionados(ctrl)
    if (filas.Length > 1) {
        ptsEd.st.Value := filas.Length " eventos seleccionados. Cambia formato, prioridad u opacidad para aplicarlo a todos."
        _PtsEvDurRefrescar()
        return
    }
    c := ptsEd.cfg[_PtsEventosDefs()[idxReal][1]]
    ptsEd.ddF.Choose((c.f = "desactivado") ? 3 : ((c.f = "bruto") ? 2 : 1))
    ptsEd.ddZ.Choose((c.z = "alta") ? 1 : ((c.z = "media") ? 2 : 3))
    opIdx := (c.op = 100) ? 1 : ((c.op = 40) ? 3 : 2)
    ptsEd.ddOp.Choose(opIdx)
    _PtsEvDurRefrescar()
    if (ptsEd.evAnclado)
        _PtsMostrarGuiAnclado(item)
}
_PtsEvCambio(*) {
    filas := _PtsEvObtenerSeleccionados(ptsEd.lvEv)
    if (filas.Length = 0 && ptsEd.evSel >= 1)
        filas := [ptsEd.evSel]
    if (filas.Length = 0)
        return
    f := (ptsEd.ddF.Value = 3) ? "desactivado" : ((ptsEd.ddF.Value = 2) ? "bruto" : "moderno")
    z := ["alta","media","baja"][Max(1,ptsEd.ddZ.Value)]
    op := [100,70,40][Max(1,ptsEd.ddOp.Value)]
    defs := _PtsEventosDefs()
    evNom := ""
    for row in filas {
        if (ptsEd.mapFilas.Has(row)) {
            idxReal := ptsEd.mapFilas[row]
            ev := defs[idxReal]
            _PtsEvGuardar(ev[1],f,z,op)
            if (evNom = "")
                evNom := ev[2]
        }
    }
    _PtsEvFilas()
    _PtsEvDurRefrescar()
    if (filas.Length = 1 && evNom != "") {
        ptsEd.st.Value := evNom ": " StrTitle(f) " · " _PtsZonaTxt(z) " (" op "%)"
    } else {
        ptsEd.st.Value := filas.Length " eventos actualizados en conjunto: " StrTitle(f) " · " _PtsZonaTxt(z) " (" op "%)"
    }
}
_PtsEvProbar(*) {
    filas := _PtsEvObtenerSeleccionados(ptsEd.lvEv)
    row := (filas.Length > 0) ? filas[1] : ptsEd.evSel
    if (row < 1 || !ptsEd.mapFilas.Has(row))
        return
    idxReal := ptsEd.mapFilas[row]
    ev := _PtsEventosDefs()[idxReal]
    c := ptsEd.cfg[ev[1]]
    zNum := (c.z = "alta") ? 1 : ((c.z = "media") ? 2 : 3)
    tit := Trim(RegExReplace(ev[2],"\s*\(.*\)\s*$"))
    durPrueba := Max(1500, _PtsDurEfectiva(ev[1], c.z))
    colAcento := (ev[1] = "color_primario") ? "00E5FF" : ((zNum = 1) ? "FF6F61" : ((zNum = 2) ? "00E5FF" : "9A7BFF"))
    MostrarAvisoUI(c.f, tit, (zNum = 3 ? "" : "PRUEBA"), zNum, colAcento, durPrueba, c.op)
    _SonarFast(ev[1])
}
_PtsOcultarGuiAnclado() {
    if (IsObject(ptsEd) && HasProp(ptsEd, "guiAnclado") && IsObject(ptsEd.guiAnclado)) {
        try ptsEd.guiAnclado.Destroy()
        ptsEd.guiAnclado := 0
    }
    if (IsObject(ptsEd) && HasProp(ptsEd, "evAnclado")) {
        ptsEd.evAnclado := false
        if (HasProp(ptsEd, "bEvAnclar") && IsObject(ptsEd.bEvAnclar))
            ptsEd.bEvAnclar.Text := "📌 Anclar"
        if (HasProp(ptsEd, "bEvReub") && IsObject(ptsEd.bEvReub))
            ptsEd.bEvReub.Enabled := false
    }
}
_PtsMostrarGuiAnclado(row) {
    global AVISO_ESC
    if (row < 1 || !ptsEd.mapFilas.Has(row))
        return false
    idxReal := ptsEd.mapFilas[row]
    ev := _PtsEventosDefs()[idxReal]
    c := ptsEd.cfg[ev[1]]
    if (c.f = "desactivado") {
        ptsEd.st.Value := "El evento '" ev[2] "' está en formato Desactivado (sin HUD). Cámbialo a Moderno o Bruto para anclar."
        return false
    }
    zNum := (c.z = "alta") ? 1 : ((c.z = "media") ? 2 : 3)
    tit := Trim(RegExReplace(_PtsNomEvento(ev[1]),"\s*\(.*\)\s*$"))
    colAcento := (ev[1] = "color_primario") ? "00E5FF" : ((zNum = 1) ? "FF6F61" : ((zNum = 2) ? "00E5FF" : "9A7BFF"))
    claveRango := (zNum = 1) ? "HUD_Alta" : ((zNum = 2) ? "HUD_Media" : "HUD_Baja")

    if (IsObject(ptsEd) && HasProp(ptsEd, "guiAnclado") && IsObject(ptsEd.guiAnclado)) {
        try ptsEd.guiAnclado.Destroy()
        ptsEd.guiAnclado := 0
    }

    w := Round(240 * AVISO_ESC)
    h := Round(72  * AVISO_ESC)
    px := "", py := ""
    ; Rango individual del evento manda por sobre la zona genérica
    rgEv := _HudRangoEv(ev[1])
    if (IsObject(rgEv) && IsInteger(rgEv.w) && IsInteger(rgEv.h) && rgEv.w >= 40 && rgEv.h >= 20) {
        w := Round(rgEv.w), h := Round(rgEv.h)
        px := Round(rgEv.x), py := Round(rgEv.y)
    } else {
        rg := ObtenerRango(claveRango)
        if (IsObject(rg) && IsInteger(rg.w) && IsInteger(rg.h) && rg.w >= 40 && rg.h >= 20) {
            w := Round(rg.w), h := Round(rg.h)
            px := Round(rg.x), py := Round(rg.y)
        }
    }
    if (px = "" || py = "") {
        p := _CalcularPosicionZona(zNum, w, h)
        px := p.x, py := p.y
    }

    g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale", "HUD_Anclado_Calibrador")
    if (c.f = "bruto") {
        g.BackColor := "1A1A1A"
        g.MarginX := 0
        g.MarginY := 0
        alpha := (c.op <= 40) ? 102 : ((c.op <= 70) ? 178 : 235)
        WinSetTransparent(alpha, g)
        barH := Max(2, Round(3 * AVISO_ESC))
        lblY := Round(4 * AVISO_ESC)
        lblH := Max(16, h - barH - lblY - Round(3 * AVISO_ESC))
        fSize := Max(7, Min(28, Round(h * 0.22)))
        lbl := g.Add("Text", Format("x0 y{} w{} h{} cFFFFFF +0x200 +0x4000 Center", lblY, w, lblH), tit)
        lbl.SetFont("s" fSize " bold", "Segoe UI")
        bar := g.Add("Progress", Format("x0 y{} w{} h{}", h - barH, w, barH))
        bar.Opt("c" colAcento)
        bar.Value := 100
    } else {
        grande := (h >= 90)
        brazo := grande ? 16 : 10
        grosor := grande ? 3 : 2
        g.BackColor := "12141A"
        g.MarginX := 0
        g.MarginY := 0
        alpha := (c.op <= 40) ? 102 : ((c.op <= 70) ? 178 : 255)
        WinSetTransparent(alpha, g)
        xr := w - brazo, yb := h - brazo
        xr2 := w - grosor, yb2 := h - grosor
        bgC := "Background" colAcento
        g.Add("Text", Format("x0 y0 w{} h{} {}", brazo, grosor, bgC))
        g.Add("Text", Format("x0 y0 w{} h{} {}", grosor, brazo, bgC))
        g.Add("Text", Format("x{} y0 w{} h{} {}", xr, brazo, grosor, bgC))
        g.Add("Text", Format("x{} y0 w{} h{} {}", xr2, grosor, brazo, bgC))
        g.Add("Text", Format("x0 y{} w{} h{} {}", yb2, brazo, grosor, bgC))
        g.Add("Text", Format("x0 y{} w{} h{} {}", yb, grosor, brazo, bgC))
        g.Add("Text", Format("x{} y{} w{} h{} {}", xr, yb2, brazo, grosor, bgC))
        g.Add("Text", Format("x{} y{} w{} h{} {}", xr2, yb, grosor, brazo, bgC))
        mbw := Max(30, Round(w * 0.30))
        g.Add("Text", Format("x{} y{} w{} h3 {}", (w - mbw) // 2, h - 7, mbw, bgC))
        tSize := Max(10, Min(36, Round(h * 0.16)))
        sSize := grande ? 10 : 8
        tAlto := tSize * 2
        tY := (h - tAlto) // 2 + 8
        ancho := Max(40, w - 24)
        g.SetFont("s" sSize " bold c9AA7C7", "Segoe UI")
        g.Add("Text", Format("x12 y{} w{} h18 Center BackgroundTrans +0x200 +0x4000", Max(4, tY - 18), ancho), "📌 ANCLADO · " StrUpper(_PtsZonaTxt(c.z)))
        g.SetFont("s" tSize " bold cFFFFFF", "Segoe UI")
        g.Add("Text", Format("x12 y{} w{} h{} Center BackgroundTrans +0x200 +0x4000", tY, ancho, tAlto), tit)
    }
    g.Show(Format("x{} y{} w{} h{} NoActivate", px, py, w, h))
    ptsEd.guiAnclado := g
    ptsEd.evAnclado := true
    ptsEd.bEvAnclar.Text := "📌 Quitar"
    ptsEd.bEvReub.Enabled := true
    ptsEd.st.Value := "HUD de " tit " ANCLADO indefinidamente. '📍 Reubicar' accionado para calibrar con el lápiz."
    return true
}
_PtsEvToggleAnclar(*) {
    if (ptsEd.evAnclado) {
        _PtsOcultarGuiAnclado()
        ptsEd.st.Value := "HUD desanclado de pantalla."
        _SonarUI("calib")
        return
    }
    filas := _PtsEvObtenerSeleccionados(ptsEd.lvEv)
    row := (filas.Length > 0) ? filas[1] : ptsEd.evSel
    if (row < 1 || !ptsEd.mapFilas.Has(row))
        return
    if _PtsMostrarGuiAnclado(row)
        _SonarUI("calib")
}
_PtsEvReubicarZona(*) {
    if (!ptsEd.evAnclado) {
        ptsEd.st.Value := "Primero ancla el HUD con '📌 Anclar' para reubicarlo."
        return
    }
    filas := _PtsEvObtenerSeleccionados(ptsEd.lvEv)
    row := (filas.Length > 0) ? filas[1] : ptsEd.evSel
    if (row < 1 || !ptsEd.mapFilas.Has(row))
        return
    idxReal := ptsEd.mapFilas[row]
    ev := _PtsEventosDefs()[idxReal]
    idEv := ev[1]
    tit := Trim(RegExReplace(_PtsNomEvento(idEv),"\s*\(.*\)\s*$"))

    r := _PtsDibujarRango("Dibuja la nueva posición exclusiva para: " tit, "00E5FF", false)
    if (!r)
        return

    global AVISO_ESC, PERFIL
    anchoMin := Round(240 * AVISO_ESC)
    altoMin  := Round(72  * AVISO_ESC)
    fw := (r.w < 60) ? anchoMin : r.w
    fh := (r.h < 24) ? altoMin  : r.h

    ini := _PosGuiIniPath()
    sec := _ZonaSec("Rangos")
    ; Guarda el rango exclusivo de este evento (prevalece sobre la zona)
    IniWrite(Format("{},{},{},{}", r.x, r.y, fw, fh), ini, sec, "HUD_ev_" . idEv)
    CargarPuntos()

    _PtsMostrarGuiAnclado(row)
    _SonarUI("calib")
    ptsEd.st.Value := "Evento '" tit "' reubicado a (" r.x ", " r.y ") " fw "x" fh " px (ubicación guardada)."
}
; ===== Sistema y perfiles =====
_PtsAlphaChange(*) {
    global ESTAB_ALPHA_H,PERFIL
    v := Trim(ptsEd.eAlpha.Value)
    if (!IsInteger(v) || Integer(v) < 10 || Integer(v) > 100)
        return
    ESTAB_ALPHA_H := Round(Integer(v) * 2.55)
    IniWrite(Integer(v),_PosGuiIniPath(),"Estab_p" PERFIL,"alphaH")
    _EstabAlpha(false)
}
_PtsAlphaFChange(*) {
    global ESTAB_ALPHA_F,PERFIL
    v := Trim(ptsEd.eAlphaF.Value)
    if (!IsInteger(v) || Integer(v) < 10 || Integer(v) > 100)
        return
    ESTAB_ALPHA_F := Round(Integer(v) * 2.55)
    IniWrite(Integer(v),_PosGuiIniPath(),"Estab_p" PERFIL,"alphaF")
    if estabGui.foco
        _EstabAlpha(false)
}
_PtsReiniciar(*) {
    GuardarPuntos()
    _RgGuardarMirror()
    ToolTip("🔄 Reiniciando script…")
    Sleep(250)
    Reload()
}
_PtsMoverBotones(ctrl) {
    _ToggleBloqueo()
    ctrl.Text := panelBlk.locked ? "🔓 Mover botones" : "🔒 Fijar botones"
}
_PtsReubicar(*) {
    ReubicarBotones()
    ptsEd.st.Value := "Botones reubicados para este perfil."
}
ReubicarBotones() {
    mon := ObtenerMonitorCSP()
    F := 0x0001 | 0x0004 | 0x0010
    ancho := _E(104) * 4 + _E(31) * 2 + PANEL_GAP * 5
    x0 := mon.x + (mon.w - ancho) // 2
    y0 := mon.y + Round(mon.h * 0.02) + 42 + 4
    sx := x0
    for g in [dsGui,ccGui,arGui,lockGui,frenteGui,estabBtnGui] {
        if !IsObject(g.g)
            continue
        DllCall("SetWindowPos","Ptr",g.g.Hwnd,"Ptr",0,"int",sx,"int",y0,"int",0,"int",0,"uint",F)
        WinGetPos(&gx,&gy,&gw,&gh,"ahk_id " g.g.Hwnd)
        sx += gw + PANEL_GAP
    }
    if (IsObject(estabGui.g) && !estabGui.horiz) {
        WinGetPos(&lkX,&lkY,&lkW,&lkH,"ahk_id " lockGui.g.Hwnd)
        ex := Min(lkX + lkW + PANEL_GAP,mon.x + mon.w - _E(220))
        DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",0,"int",ex,"int",lkY,"int",0,"int",0,"uint",F)
    }
    WinGetPos(&gx,&gy,&gw,&dsH,"ahk_id " dsGui.g.Hwnd)
    hcY := y0 + dsH + PANEL_GAP
    DllCall("SetWindowPos","Ptr",hcGui.g.Hwnd,"Ptr",0,"int",x0,"int",hcY,"int",0,"int",0,"uint",F)
    WinGetPos(&gx,&gy,&gw,&hcH,"ahk_id " hcGui.g.Hwnd)
    ry := hcY + hcH + PANEL_GAP
    DllCall("SetWindowPos","Ptr",reloadGui.g.Hwnd,"Ptr",0,"int",x0,"int",ry,"int",0,"int",0,"uint",F)
    WinGetPos(&gx,&gy,&rw,&rh,"ahk_id " reloadGui.g.Hwnd)
    DllCall("SetWindowPos","Ptr",puntosGui.g.Hwnd,"Ptr",0,"int",x0 + rw + PANEL_GAP,"int",ry,"int",0,"int",0,"uint",F)
    GuardarPosicionGUI("PanelBlock",dsGui.g.Hwnd)
    GuardarPosicionGUI("Slider",dsGui.g.Hwnd)
    GuardarPosicionGUI("Circle",ccGui.g.Hwnd)
    GuardarPosicionGUI("Quick",arGui.g.Hwnd)
    GuardarPosicionGUI("Lock",lockGui.g.Hwnd)
    GuardarPosicionGUI("Frente",frenteGui.g.Hwnd)
    GuardarPosicionGUI("EstabBtn",estabBtnGui.g.Hwnd)
    GuardarPosicionGUI("HC",hcGui.g.Hwnd)
    _GuardarOffsetHC()
    GuardarPosicionGUI("Reload",reloadGui.g.Hwnd)
    GuardarPosicionGUI("PuntosBtn",puntosGui.g.Hwnd)
    GuardarPosicionGUI("Estab",estabGui.g.Hwnd)
}
_PtsUltimoBackupIni() {
    mejor := "", t := 0
    Loop Files A_ScriptDir "\posiciones_gui_*.bak.ini" {
        ; FileCopy hereda la fecha del original, así que dos copias seguidas empatan
        ; al segundo. El sello del nombre sí es el instante real de la copia.
        fm := Integer(A_LoopFileTimeModified)
        if RegExMatch(A_LoopFileName,"^posiciones_gui_(\d{8})_(\d{6})\.bak\.ini$",&m)
            fm := Integer(m[1] m[2])
        if (fm > t) {
            t := fm
            mejor := A_LoopFilePath
        }
    }
    if (mejor = "")
        return 0
    return {ruta:mejor,nombre:SubStr(mejor,StrLen(A_ScriptDir) + 2),tick:t}
}
_PtsSelloLibre() {
    sello := FormatTime(,"yyyyMMdd_HHmmss")
    if FileExist(A_ScriptDir "\posiciones_gui_" sello ".bak.ini") {
        Sleep(1000 - Mod(A_MSec,1000) + 10)   ; dos clics en el mismo segundo no deben pisarse
        sello := FormatTime(,"yyyyMMdd_HHmmss")
    }
    return sello
}
_PtsBakRefrescar() {
    if (!IsObject(ptsEd.g) || !IsObject(ptsEd.lblBak))
        return
    b := _PtsUltimoBackupIni()
    if IsObject(b) {
        ptsEd.lblBak.Value := "Último: " b.nombre "`n" FormatTime(b.tick,"dd/MM/yyyy HH:mm:ss")
        ptsEd.bRes.Enabled := true
    } else {
        ptsEd.lblBak.Value := "Sin backups todavía."
        ptsEd.bRes.Enabled := false
    }
}
_PtsBackupIni(*) {
    ini := _PosGuiIniPath()
    if !FileExist(ini) {
        ptsEd.st.Value := "⚠ No existe posiciones_gui.ini: no hay nada que respaldar."
        return
    }
    sello := _PtsSelloLibre()
    dest := A_ScriptDir "\posiciones_gui_" sello ".bak.ini"
    try {
        FileCopy(ini,dest)
    } catch as e {
        ptsEd.st.Value := "⚠ Backup fallido: " e.Message
        return
    }
    _PtsBakRefrescar()
    ptsEd.st.Value := "💾 Backup creado: posiciones_gui_" sello ".bak.ini"
    _SonarUI("calib")
}
_PtsRestaurarIni(*) {
    b := _PtsUltimoBackupIni()
    if !IsObject(b) {
        ptsEd.st.Value := "No hay ningún posiciones_gui_*.bak.ini en la carpeta del script."
        return
    }
    ptsEd.g.Opt("+OwnDialogs")
    if (MsgBox("¿Restaurar " b.nombre "?`n`nAntes se guardará una copia del estado actual (para poder deshacer) y el script se reiniciará.","Restaurar backup","YesNo Icon?") != "Yes")
        return
    ini := _PosGuiIniPath()
    sello := _PtsSelloLibre()
    try {
        FileCopy(ini,A_ScriptDir "\posiciones_gui_" sello ".bak.ini")
        FileCopy(b.ruta,ini,1)
    } catch as e {
        ptsEd.st.Value := "⚠ Restauración fallida: " e.Message
        return
    }
    ; Sin GuardarPuntos: los puntos en memoria son los viejos y pisarían el ini restaurado.
    ToolTip("↩ Backup restaurado: " b.nombre)
    Sleep(250)
    Reload()
}
_PtsCambiarPerfil(ctrl,*) {
    nuevo := ctrl.Value
    if (nuevo < 1 || nuevo = PERFIL)
        return
    GuardarPuntos(false)
    _RgGuardarMirror()
    ini := _PosGuiIniPath()
    IniWrite(nuevo,ini,"Perfil","actual")
    IniWrite(_FirmaMonitores(),ini,"Perfil","ultimaFirma")
    OcultarZonasCalibracion()
    ToolTip("🔄 Perfil: " PERFILES[nuevo])
    Sleep(300)
    Reload()
}
_PtsCerrar(*) {
    if (ptsEd.dibujando)
        return
    _PtsOcultarGuiAnclado()
    GuardarPuntos()
    _RgGuardarMirror()
    OcultarZonasCalibracion()
    recargar := false
    try {
        v := Trim(ptsEd.eEsc.Value)
        if (IsNumber(v) && Number(v) >= 40 && Number(v) <= 200 && Abs(Number(v) - ESC * 100) >= 0.5) {
            IniWrite(Round(Number(v)),_PosGuiIniPath(),"Puntos" PERFIL,"escala")
            recargar := true
        }
    }
    try {
        v := Trim(ptsEd.eEscAv.Value)
        if (IsNumber(v) && Number(v) >= 40 && Number(v) <= 250 && Abs(Number(v) - AVISO_ESC * 100) >= 0.5) {
            IniWrite(Round(Number(v)),_PosGuiIniPath(),"Puntos" PERFIL,"escalaAvisos")
            recargar := true
        }
    }
    SetTimer(_PtsModoVigilar,0)
    ptsModo.edit := false
    ptsModo.btnN := 0
    ptsModo.btnE := 0
    CargarPuntos()
    try ptsEd.g.Destroy()
    ptsEd.g := 0
    ptsEd.sel := 0
    if (recargar) {
        ToolTip("🔄 Aplicando escala…")
        Sleep(250)
        Reload()
    }
    _SonarUI("calib")
}
; ===== Vista previa de zonas (misma firma) =====
_PtsToggleVerZonas(*) {
    if (ptsEd.ovl.Length > 0)
        OcultarZonasCalibracion()
    else
        MostrarZonasCalibracion(0)
}
MostrarZonasCalibracion(ms := 0) {
    OcultarZonasCalibracion()
    for i, z in ZONAS.izq
        ptsEd.ovl.Push(_CrearRectOverlay(z.x1,z.y1,z.x2 - z.x1 + 1,z.y2 - z.y1 + 1,"2ECC71","IZQ B" i))
    for i, z in ZONAS.der
        ptsEd.ovl.Push(_CrearRectOverlay(z.x1,z.y1,z.x2 - z.x1 + 1,z.y2 - z.y1 + 1,"3498DB","DER B" i))
    h := ZONAS.hist
    ptsEd.ovl.Push(_CrearRectOverlay(h.x1,h.y1,h.x2 - h.x1 + 1,h.y2 - h.y1 + 1,"E67E22","HISTORIAL"))
    nombresHud := Map("HUD_Alta","ZONA 1 · ALTA","HUD_Media","ZONA 2 · MEDIA","HUD_Baja","ZONA 3 · BAJA","Estab","ESTABILIZADOR","EstabFoco","ESTAB FOCO")
    for k in ["HUD_Alta","HUD_Media","HUD_Baja","Estab","EstabFoco"] {
        d := _PtsDefPorClave(k)
        if !IsObject(d)
            continue
        r := _PtsRectDe(d)
        if (IsInteger(r.x) && IsInteger(r.y) && IsInteger(r.w) && IsInteger(r.h) && r.w > 0 && r.h > 0)
            ptsEd.ovl.Push(_CrearRectOverlay(r.x,r.y,r.w,r.h,d.c,nombresHud.Has(k) ? nombresHud[k] : d.n))
    }
    ptsP := Map(1,"P1",2,"P2",29,"P29")
    for i in [1,2,29] {
        col := (i = 29) ? "F1C40F" : "E74C3C"
        lbl := ptsP.Has(i) ? ptsP[i] : ("P" i)
        dClv := (i = 1) ? "ToggleIzq" : ((i = 2) ? "ToggleDer" : "ZonaSegura")
        d := _PtsDefPorClave(dClv)
        r := IsObject(d) ? _PtsRectDe(d) : 0
        if (IsObject(r) && IsInteger(r.w) && r.w > 0 && IsInteger(r.h) && r.h > 0)
            ptsEd.ovl.Push(_CrearRectOverlay(r.x,r.y,r.w,r.h,col,lbl))
        else
            ptsEd.ovl.Push(_CrearRectOverlay(PUNTOS[i][1] - 5,PUNTOS[i][2] - 5,10,10,col,lbl))
    }
    if (ms > 0)
        SetTimer(OcultarZonasCalibracion,-ms)
    if (IsObject(ptsEd) && HasProp(ptsEd,"bVer") && IsObject(ptsEd.bVer))
        ptsEd.bVer.Text := "❌ Ocultar zonas"
}
OcultarZonasCalibracion() {
    try SetTimer(OcultarZonasCalibracion,0)
    for g in ptsEd.ovl {
        try {
            if IsObject(g)
                g.Destroy()
        }
    }
    ptsEd.ovl := []
    if (IsObject(ptsEd) && HasProp(ptsEd,"bVer") && IsObject(ptsEd.bVer))
        ptsEd.bVer.Text := "👁 Ver zonas"
}
_CrearRectOverlay(x,y,w,h,color,texto := "") {
    ow := Max(w,4)
    oh := Max(h,4)
    g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale","")
    g.BackColor := color
    if (texto != "") {
        g.SetFont("s8 bold","Segoe UI")
        tw := Max(ow,28)
        th := Max(oh,16)
        tx := (ow - tw) // 2
        ty := (oh - th) // 2
        g.Add("Text","x" tx " y" ty " w" tw " h" th " BackgroundTrans cFFFFFF +0x200 Center",texto)
    }
    g.Show("x" x " y" y " w" ow " h" oh " NoActivate")
    WinSetTransparent(160,g)
    return g
}
