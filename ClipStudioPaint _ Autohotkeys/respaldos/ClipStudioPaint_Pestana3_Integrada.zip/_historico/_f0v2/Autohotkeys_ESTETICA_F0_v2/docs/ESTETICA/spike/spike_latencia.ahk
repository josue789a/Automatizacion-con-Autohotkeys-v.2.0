#Requires AutoHotkey v2.0
#SingleInstance Force
; =====================================================================
; spike_latencia.ahk  -  FASE 0: latencias base (I13) + mapa de anclas
;
; NO modifica el .ahk de produccion (se verifica hash antes y despues).
; NO se incluye en el .ahk real. Corre SIN elevar.
;
; Que hace:
;   1. Lee el .ahk canonico, comprueba SHA-256 y numero de lineas.
;      Si no coinciden con lo esperado: se detiene (CONTEXTO 0: parar y avisar).
;   2. Escribe anclas_canonico.txt: linea de definicion y numero de usos de
;      cada funcion relevante (+ marcas de los hallazgos abiertos del PLAN).
;   3. Construye una copia desechable en %TEMP%\latencia_f0\ con la
;      elevacion de las lineas 3-6 anulada (solo en la copia), hotkeys
;      suspendidos (Suspend(1)) y un medidor inyectado al final.
;   4. /validate de la copia.
;   5. SOLO con --ejecutar: lanza la copia (las GUIs PARPADEAN unos 3 s,
;      como el modo carga del arnes), mide MostrarHUD, MostrarMiniTexto y
;      ActualizarEstabGUI (N llamadas, mediana/p95/max con QPC) y escribe
;      latencia_base.txt. NUNCA llama _EstabEmitir ni nada de input.
;
; Uso (PowerShell, sin elevar, NO mientras dibujas):
;   AutoHotkey64.exe spike_latencia.ahk                 -> pasos 1-4 (seco)
;   AutoHotkey64.exe spike_latencia.ahk --ejecutar      -> todo
; Opciones: --prod=RUTA  --n=20  --forzar (ignora hash/lineas, NO recomendado)
;
; Si el bloque de elevacion no es el esperado (if !A_IsAdmin { Run ExitApp }
; en las lineas 3-6) se aborta y se vuelcan las primeras 10 lineas: en ese
; caso medir con el arnes pruebas.ps1 -Modo carga y pegar el inyectable.
; =====================================================================
DllCall("user32\SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
SetWorkingDir(A_ScriptDir)

HASH_ESPERADO := "CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E"
LINEAS_ESPERADAS := 3917
PROD := A_ScriptDir "\..\..\..\XxxPPEN_a16pg2_displayAS_secondary.ahk"
N := 20
EJECUTAR := false
FORZAR := false
for a in A_Args {
    if (a = "--ejecutar")
        EJECUTAR := true
    else if (a = "--forzar")
        FORZAR := true
    else if (SubStr(a, 1, 7) = "--prod=")
        PROD := SubStr(a, 8)
    else if (SubStr(a, 1, 4) = "--n=")
        N := Max(5, Integer(SubStr(a, 5)))
}

REPTXT := ""
Principal()
ExitApp()

Principal() {
    if A_IsAdmin {
        Fin("Este script debe correr SIN elevar (no hace falta admin).", 1)
    }
    if !FileExist(PROD)
        Fin("No existe el .ahk canonico: " PROD "`nUsa --prod=RUTA", 1)
    PROD_R := PROD
    Loop Files, PROD_R
        PROD_R := A_LoopFileFullPath

    ; ---- 1. Verificacion de la fuente de verdad ----
    h0 := Hash(PROD_R)
    txt := FileRead(PROD_R, "UTF-8")
    lineas := StrSplit(txt, "`n", "`r")
    nl := lineas.Length
    if (nl > 0 && lineas[nl] = "")
        nl -= 1
    Rep("Archivo: " PROD_R)
    Rep("SHA-256: " h0)
    Rep("Lineas: " nl " (esperadas " LINEAS_ESPERADAS ")")
    ok := (StrUpper(h0) = HASH_ESPERADO) && (nl = LINEAS_ESPERADAS)
    Rep("Coincide con el canonico: " (ok ? "SI" : "NO"))
    if (!ok && !FORZAR) {
        Guardar("latencia_base.txt")
        Fin("El archivo NO coincide con el canonico (hash/lineas). Parar y avisar antes de seguir.`nDetalle en latencia_base.txt", 2)
    }

    ; ---- 2. Mapa de anclas por nombre de funcion ----
    anclas := MapaAnclas(lineas)
    Rep("")
    Rep("Anclas escritas en anclas_canonico.txt")

    ; ---- 3. Copia desechable ----
    for i in [3, 4, 5, 6] {
        if (i > lineas.Length)
            Fin("El archivo tiene menos de 6 lineas.", 3)
    }
    if !(RegExMatch(lineas[3], "i)^\s*if\s*(!|not\s+)\s*A_IsAdmin") && Trim(lineas[6]) = "}" && InStr(lineas[4] lineas[5], "RunAs")) {
        v := ""
        Loop Min(10, lineas.Length)
            v .= A_Index ": " lineas[A_Index] "`n"
        Rep("Bloque de elevacion NO reconocido. Primeras lineas:`n" v)
        Guardar("latencia_base.txt")
        Fin("Bloque de elevacion no reconocido en lineas 3-6. No se construye la copia.`nVer latencia_base.txt", 3)
    }
    dir := A_Temp "\latencia_f0"
    DirCreate(dir)
    copia := dir "\prueba_latencia.ahk"
    salida := dir "\salida_latencia.txt"
    errf := dir "\stderr_latencia.txt"
    try FileDelete(salida)
    try FileDelete(errf)

    llamadas := Map()
    for nombre in ["MostrarHUD", "MostrarMiniTexto", "ActualizarEstabGUI"] {
        if !anclas.Has(nombre) || anclas[nombre].lin = 0 {
            Rep("AVISO: " nombre " no se encontro en el canonico, no se medira.")
            continue
        }
        llamadas[nombre] := ArmarLlamada(nombre, anclas[nombre].firma)
        Rep(nombre "(" anclas[nombre].firma ")  ->  " llamadas[nombre])
    }

    nuevo := []
    for i, l in lineas {
        if (i = 3) {
            nuevo.Push("; [spike_latencia] elevacion anulada SOLO en esta copia (lineas 3-6 originales)")
        } else if (i >= 4 && i <= 6) {
            nuevo.Push("; [spike_latencia] linea " i " original anulada")
            if (i = 6) {
                nuevo.Push("Suspend(1)")
                nuevo.Push('_LatHb("autoexec: Suspend + timer registrados")')
                nuevo.Push("SetTimer(_LatBase, -2500)")
            }
        } else {
            nuevo.Push(l)
        }
    }
    cuerpo := ""
    for l in nuevo
        cuerpo .= l "`r`n"
    cuerpo .= Inyectable(llamadas, N, salida)
    try FileDelete(copia)
    f := FileOpen(copia, "w", "UTF-8")
    f.Write(cuerpo)
    f.Close()
    Rep("Copia desechable: " copia)

    ; ---- 4. /validate de la copia ----
    codV := RunWait('"' A_AhkPath '" /validate "' copia '"', , "Hide")
    Rep("/validate de la copia: exit " codV)
    if (codV != 0) {
        Guardar("latencia_base.txt")
        Fin("La copia no pasa /validate (exit " codV "). Ver latencia_base.txt", 4)
    }

    if !EJECUTAR {
        Rep("")
        Rep("Modo seco: no se ejecuto la copia. Repite con --ejecutar (las GUIs parpadean ~3 s).")
        Guardar("latencia_base.txt")
        Fin("Pasos 1-4 OK (modo seco). Anclas y resumen en la carpeta del script.", 0)
    }

    ; ---- 5. Ejecutar la copia con watchdog ----
    Rep("")
    Rep("Ejecutando la copia (N=" N ")...")
    hbq := dir "\heartbeat_latencia.txt"
    try FileDelete(hbq)
    pid := 0
    Run(A_ComSpec ' /c ""' A_AhkPath '" /ErrorStdOut "' copia '" > "' errf '" 2>&1"', , "Hide", &pid)
    ProcessWaitClose(pid, 45)
    if ProcessExist(pid) {
        RunWait("taskkill /PID " pid " /T /F", , "Hide")
        Rep("WATCHDOG: la copia excedio 45 s y se cerro (solo su arbol de procesos).")
    }
    if FileExist(salida)
        Rep("`n" FileRead(salida, "UTF-8"))
    else
        Rep("La copia no escribio salida. Revisa " errf)
    if FileExist(hbq)
        Rep("Latido de la copia (A_TickCount | etapa):`n" FileRead(hbq, "UTF-8"))
    if FileExist(errf) {
        e := Trim(FileRead(errf, "UTF-8"))
        if (e != "")
            Rep("stderr de la copia:`n" e)
    }
    h1 := Hash(PROD_R)
    Rep("`nProduccion intacta: " (h0 = h1 ? "SI (hash igual antes y despues)" : "NO !!! (hash cambio)"))
    Guardar("latencia_base.txt")
    Fin("Listo. Resultado en latencia_base.txt (pegar en RESULTADOS.md).", 0)
}

Rep(t) {
    global REPTXT
    REPTXT .= t "`r`n"
}

Guardar(nombre) {
    ruta := A_ScriptDir "\" nombre
    try FileDelete(ruta)
    FileAppend(REPTXT, ruta, "UTF-8")
}

Fin(msg, cod) {
    MsgBox(msg, "spike_latencia", cod = 0 ? "Iconi" : "Icon!")
    ExitApp(cod)
}

Hash(ruta) {
    tmp := A_Temp "\latencia_hash.txt"
    try FileDelete(tmp)
    RunWait(A_ComSpec ' /c certutil -hashfile "' ruta '" SHA256 > "' tmp '"', , "Hide")
    r := ""
    try r := FileRead(tmp)
    arr := StrSplit(r, "`n", "`r")
    if (arr.Length >= 2)
        return StrUpper(StrReplace(Trim(arr[2]), " "))
    return "NO_CALCULADO"
}

; ---------------------------------------------------------------------
; Mapa de anclas: definicion (primera linea) y usos por nombre
; ---------------------------------------------------------------------
MapaAnclas(lineas) {
    nombres := ["_FadeAlpha", "_LimpiarAvisos", "_LimpiarGUIs", "MostrarHUD", "MostrarMiniTexto", "MostrarBadgeCombo"
        , "MostrarTooltipToggle", "MostrarIconoHerramienta", "MostrarMiniGUI", "_OcultarHUDSi", "Sanar"
        , "IniciarDsGUI", "IniciarCcGUI", "IniciarArGUI", "IniciarHCGUI", "IniciarLockGUI", "IniciarFrenteGUI"
        , "IniciarEstabBtnGUI", "IniciarEstabGUI", "ActualizarEstabGUI", "_EstabCalcular", "_EstabLayout"
        , "_EstabKnobRegion", "_EstabRegion", "_EstabEmitir", "_EstabEnviarDelta", "IniciarReloadGUI"
        , "IniciarPuntosGUI", "_SetIcono", "_RutaIcono", "_IconosB64", "_PosGuiIniPath", "_AnclaBloquePaneles"
        , "AbrirPanelPuntos", "_ArrastrarPanelBloque", "MostrarGUIEnfoque", "IniciarDialGUI"]
    res := Map()
    for n in nombres
        res[n] := {lin: 0, usos: 0, firma: ""}
    for i, l in lineas {
        for n in nombres {
            if RegExMatch(l, "i)^\s*" n "\s*\(([^)]*)\)\s*(\{|=>)", &m) {
                if (res[n].lin = 0) {
                    res[n].lin := i
                    res[n].firma := Trim(m[1])
                }
            }
            if RegExMatch(l, "i)(?<![\w])" n "(?![\w])")
                res[n].usos += 1
        }
    }
    marcas := Map("-2247 (ancla fija de avisos)", "-2247", "ancho HUD fijo 208*AVISO_ESC", "208 * AVISO_ESC", "PUNTOS[30]", "PUNTOS[30]")
    cuenta := Map()
    for k, v in marcas
        cuenta[k] := {lin: 0, n: 0}
    for i, l in lineas {
        for k, v in marcas {
            if InStr(l, v) {
                cuenta[k].n += 1
                if (cuenta[k].lin = 0)
                    cuenta[k].lin := i
            }
        }
    }
    s := "Anclas del canonico (linea de definicion | usos totales por nombre)`r`n"
    s .= "Lineas: " lineas.Length "`r`n`r`n"
    for n in nombres
        s .= Format("{:-28}  def={:5}  usos={:4}  ({})", n, res[n].lin, res[n].usos, res[n].firma) "`r`n"
    s .= "`r`nMarcas de hallazgos del PLAN (primera linea | apariciones)`r`n"
    for k, v in cuenta
        s .= Format("{:-34}  linea={:5}  n={:3}", k, v.lin, v.n) "`r`n"
    s .= "`r`nLectura: _FadeAlpha usos=0 -> I12 sin objeto. _LimpiarAvisos def>0 -> D2 cerrada.`r`n"
    ruta := A_ScriptDir "\anclas_canonico.txt"
    try FileDelete(ruta)
    FileAppend(s, ruta, "UTF-8")
    return res
}

; ---------------------------------------------------------------------
; Arma la expresion de llamada a partir de la firma real
; ---------------------------------------------------------------------
ArmarLlamada(nombre, firma) {
    if (Trim(firma) = "")
        return nombre "()"
    args := []
    for p in StrSplit(firma, ",") {
        p := Trim(p)
        p := RegExReplace(p, "^[&*]+")
        opc := InStr(p, ":=") > 0
        nom := StrLower(Trim(RegExReplace(p, "\s*:=.*$")))
        v := ""
        if RegExMatch(nom, "(txt|texto|text|msg|mensaje)")
            v := '"LAT"'
        else if RegExMatch(nom, "(col|color|hex|clr)")
            v := '"00E5FF"'
        else if RegExMatch(nom, "^(ms|dur|duracion|tiempo|time|delay)")
            v := "60"
        if (v = "") {
            if opc
                break
            v := "0"
        }
        args.Push(v)
    }
    s := ""
    for i, v in args
        s .= (i > 1 ? ", " : "") v
    return nombre "(" s ")"
}

; ---------------------------------------------------------------------
; Codigo que se anade al final de la copia (plantilla; ``n = `n en la copia)
; ---------------------------------------------------------------------
Inyectable(llamadas, n, salida) {
    medir := ""
    for nombre, expr in llamadas
        medir .= '    out .= _LatMedir("' nombre '", () => ' expr ', ' n ')' "`r`n"
    c := "
(
; ===== inyectado por spike_latencia.ahk (solo en la copia) =====
_LatHb(t) {
    try FileAppend(A_TickCount " | " t "`r`n", "@@HB@@", "UTF-8")
}
_LatQPC() {
    static f := 0
    if !f
        DllCall("kernel32\QueryPerformanceFrequency", "int64*", &f)
    cc := 0
    DllCall("kernel32\QueryPerformanceCounter", "int64*", &cc)
    return cc * 1000 / f
}
_LatMedir(nombre, fn, n) {
    _LatHb("empieza " nombre)
    ts := []
    err := 0
    ult := ""
    try {
        fn.Call()
    } catch as e0 {
        err += 1
        ult := e0.Message
    }
    Loop n {
        t0 := _LatQPC()
        try {
            fn.Call()
        } catch as e1 {
            err += 1
            ult := e1.Message
        }
        ts.Push(_LatQPC() - t0)
        Sleep(15)
    }
    Loop ts.Length - 1 {
        i := A_Index + 1
        v := ts[i]
        j := i - 1
        while (j >= 1 && ts[j] > v) {
            ts[j + 1] := ts[j]
            j -= 1
        }
        ts[j + 1] := v
    }
    m := ts.Length // 2
    med := (Mod(ts.Length, 2) = 0) ? (ts[m] + ts[m + 1]) / 2 : ts[m + 1]
    p95 := ts[Max(1, Ceil(ts.Length * 0.95))]
    return "| " nombre " | " ts.Length " | " Round(med, 3) " | " Round(p95, 3) " | " Round(ts[ts.Length], 3) " | " err " " ult " |``n"
}
_LatBase() {
    _LatHb("_LatBase entro (timer disparado)")
    out := "Latencias base (ms, QPC, copia esteril)``n"
    out .= "| Funcion | N | mediana | p95 | max | errores |``n"
    out .= "|---|---|---|---|---|---|``n"
@@MEDIR@@
    out .= "``nCriterio I13: cada funcion estetica nueva debe sumar <= ~2 ms sobre estas medianas.``n"
    try FileDelete("@@SALIDA@@")
    FileAppend(out, "@@SALIDA@@", "UTF-8")
    _LatHb("salida escrita")
    ExitApp()
}
)"
    hb := StrReplace(salida, "salida_latencia.txt", "heartbeat_latencia.txt")
    c := StrReplace(c, "@@MEDIR@@", RTrim(medir, "`r`n"))
    c := StrReplace(c, "@@SALIDA@@", salida)
    c := StrReplace(c, "@@HB@@", hb)
    return "`r`n" c "`r`n"
}
