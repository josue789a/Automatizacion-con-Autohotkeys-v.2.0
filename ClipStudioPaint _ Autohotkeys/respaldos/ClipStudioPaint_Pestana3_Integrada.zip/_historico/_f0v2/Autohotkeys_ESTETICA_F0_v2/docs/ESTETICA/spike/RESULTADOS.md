# RESULTADOS - Fase 0

Fecha: ____  Windows (build): ____  Monitores / DPI: ____  AHK: ____

## 1. Reconciliación (spike_latencia.ahk, modo seco)

- SHA-256 y líneas coinciden con el canónico: [ ] sí  [ ] no
- `anclas_canonico.txt` revisado (V0):
  - `_FadeAlpha` usos: ____  -> I12 / D1: ____
  - `_LimpiarAvisos` def: ____ / `_LimpiarGUIs` usos: ____  -> D2: ____
  - `208 * AVISO_ESC`: ____ / `-2247`: ____ / `PUNTOS[30]`: ____  -> D3: ____

## 2. Log pegado de spike_resultados.txt / spike_resultados_oculto.txt

```text

```

## 3. Observaciones **por captura** (R3: el HR no cuenta)

Archivos de captura: ____________________

| Criterio | A Region | B DWM+alfa | C DWM | D Acrylic | E GDI+ ULW |
|---|---|---|---|---|---|
| Esquinas AA (75 / 100 / 150 %) | | | | | |
| Borde de 1 px no deseado | | | | | |
| Texto nítido | | | | | |
| Foco conservado | | | | | |
| Click-through OK | | | | | |
| Redibujo pill (ms) | | | | | |
| 2.º monitor / DPI | | | | | |

### Keycaps y slider (solo A y E)

| Criterio | A Region | E GDI+ ULW |
|---|---|---|
| Esquinas de keycap | | |
| Knob (circularidad / AA) | | |
| Parpadeo al mover el slider | | |
| Dígitos tabulares (mono) | | |
| Redibujo keycaps (ms) | | |
| Redibujo slider (ms) | | |

## 4. Latencias base (latencia_base.txt)

| Función | N | mediana (ms) | p95 | máx | errores |
|---|---|---|---|---|---|
| MostrarHUD | | | | | |
| MostrarMiniTexto | | | | | |
| ActualizarEstabGUI | | | | | |

## 5. Glifos aprobados (código -> uso)

| Uso | Código | Fuente |
|---|---|---|
| slider | | |
| circle | | |
| quick | | |
| history | | |
| lock / unlock | | |
| pin / unpin | | |
| calib | | |
| reload | | |

## 6. Decisiones

D4 (técnica de render): [ ] GDI+ ULW   [ ] Region   [ ] Mixta: ____
Motivo (citar capturas):

D6 (`text.primary`): [ ] FFFFFF   [ ] E8ECF4
