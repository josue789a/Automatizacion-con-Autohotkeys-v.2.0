# README-SPIKE - Fase 0 (galeria.ahk v2 + spike_latencia.ahk)

**No tocan el `.ahk` real, no piden UAC, no registran hotkeys.** Ambos corren **sin elevar**.
`galeria.ahk` se escribió sin runtime de AutoHotkey: el primer paso es siempre `/validate` y la prueba `--oculto`.

## A. galeria.ahk

### 1. Validar y prueba oculta (sin ventanas a la vista)

```powershell
cd docs\ESTETICA\spike
& "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" /validate galeria.ahk      # exit 0
& "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" galeria.ahk --oculto      # ~5 s, exit 0 = sin errores
Get-Content .\spike_resultados_oculto.txt
```

`--oculto`: ventanas fuera de pantalla, sin panel de control, recorre 75/100/150 %, simula clics y mide redibujos, guarda el log y sale. Los errores van a stderr. Si falla, pegar el mensaje en `RESULTADOS.md` y traerlo al chat.

### 2. Sesión visual (parpadea: no hacerlo mientras dibujas)

1. Ejecutar `galeria.ahk` (doble clic, sin elevar). Opcional: `--tema=RUTA\theme.ini` (si no, busca `theme.ini` hacia arriba).
2. Probar escala 75 / 100 / 150, **fondo** (oscuro / medio / claro / color), **monitor** (incluido el secundario) y **Texto** (`theme.ini` frente a `E8ECF4`).
3. Clic en cada pill y keycap: alterna ON/OFF. Clic en un slider: mueve el valor. Cada redibujo se mide en el log.
4. Marcar *Click-through* y *NoActivate* y leer el `ExStyle` en el log.
5. Marcar *Alfa 235 también en C y D* para repetir la comparación en igualdad de condiciones.
6. **Captura PNG** en cada combinación relevante (se guarda junto al script como `captura_<escala>_<fondo>_m<monitor>_<hora>.png`).
7. *Rejilla de glifos*: anotar qué códigos se ven bien (cuadrito = no existe en tu fuente).
8. El log se guarda **siempre al cerrar** en `spike_resultados.txt` (también con el botón *Guardar log*).

## B. Qué mirar

| Criterio | Cómo se juzga |
|---|---|
| Esquinas con antialias | **Captura** a 150 % sobre fondo claro y oscuro (escalones = no AA) |
| Borde de 1 px no deseado | Línea clara/oscura alrededor (típica de DWM) |
| Texto nítido sobre fondo translúcido | Comparar B (lavado) frente a E (opaco) |
| Keycaps y knob | A: esquinas escalonadas, knob circular sin AA, parpadeo al mover. E: AA, hairline |
| Efecto backdrop (D) | Solo si build >= 22621; fijarse en fringes negros del texto |
| Foco | Línea `Foco tras Show NoActivate` |
| Click-through / NoActivate | Líneas `ExStyle=` |
| Costo de redibujo | `redibujo (...): X ms`. Meta para E: **< 2 ms** |
| 2.º monitor / DPI | El log indica el DPI efectivo del monitor; mismo radio visual |

> **Regla R3: un HR = 0x00000000 no prueba nada.** DWM devuelve OK y relee "redondeado" aunque la ventana layered siga con esquinas rectas. D4 se decide **mirando las capturas**.

## C. Regla de decisión (se rellena en RESULTADOS.md)

| Si... | Entonces |
|---|---|
| E: AA correcto en captura, redibujo < 2 ms, foco conservado, click-through OK | **Técnica = GDI+ ULW** para pills, avisos y slider |
| E falla o > 2 ms | **Region** (estado actual) + mejoras de color/tipografía/glifos solamente |
| D funciona sin fringes y sin robar foco | Opcional: acrylic en avisos (no en pills) |

DWM (B/C) queda descartado para ventanas layered (CONTRA-EVAL M4); B y C se conservan solo como control visual.

## D. spike_latencia.ahk (latencias base + anclas)

```powershell
cd docs\ESTETICA\spike
AutoHotkey64.exe spike_latencia.ahk                # seco: hash, lineas, anclas, copia, /validate. Sin ventanas
AutoHotkey64.exe spike_latencia.ahk --ejecutar     # ademas lanza la copia: las GUIs parpadean ~3 s
```

- Por defecto busca el `.ahk` en `..\..\..\XxxPPEN_a16pg2_displayAS_secondary.ahk` (`--prod=RUTA` para otra).
- **Se detiene** si el hash o el número de líneas no coinciden con el canónico (3.917 / `CEF745C7...A983E`), salvo `--forzar`.
- Genera `anclas_canonico.txt` (línea de definición y usos de cada función; marcas de los hallazgos abiertos): sirve para cumplir la regla V0 del PLAN.
- La copia (en `%TEMP%\latencia_f0\`) anula **solo ahí** la elevación de las líneas 3-6, suspende los hotkeys y mide N=20 llamadas por función (mediana, p95, máx). **Nunca** llama a `_EstabEmitir` ni a nada de input.
- Si el bloque de elevación no es el esperado, aborta y vuelca las primeras 10 líneas.
- Watchdog de 45 s que cierra **solo el árbol de procesos de la copia** (por PID, nunca por nombre). Verifica el hash de producción al terminar.
- Resultado en `latencia_base.txt` (pegar en `RESULTADOS.md`).

## E. Límites

- Pills sin `Segoe UI Variable`: se usa `Segoe UI` en todas las técnicas para comparar igual.
- A-D usan controles de AHK (como hoy); E dibuja todo con GDI+, sin controles hijos: el hit-test y el arrastre se resuelven en el propio hwnd.
- No prueba hover de paneles CSP, `BlockInput` ni inyección de teclas (manual, fuera del spike).
- Las llamadas de `spike_latencia.ahk` se arman con la firma real leída del canónico; si una firma lleva parámetros no reconocibles recibe `0` y los errores se cuentan en la columna *errores*.
