#Requires AutoHotkey v2.0
#SingleInstance Force
; =====================================================================
; galeria.ahk  -  FASE 0 (spike estetico)  -  v2
; Script AUTONOMO. No toca ni incluye el .ahk real.
;   - SIN elevacion (no pedir admin), SIN hotkeys, SIN SendInput/BlockInput.
;   - Se cierra solo a los 10 min o con el boton Cerrar. El log se guarda
;     SIEMPRE al salir (spike_resultados.txt).
;   - Argumentos:  --oculto        ventanas fuera de pantalla, sin panel,
;                                  simula clics, guarda log y sale (exit 0/1)
;                  --tema=RUTA     theme.ini explicito (si no, busca hacia arriba)
;
; Compara 5 tecnicas de render sobre TRES elementos:
;   pill (112x28), keycaps (150x32), slider (220x30)
;   A  Region          SetWindowRgn (lo que hay hoy: sin antialias)
;   B  DWM + alfa      esquinas DWM + WinSetTransparent(235)
;   C  DWM opaco       esquinas DWM sin transparencia (control)
;   D  Acrylic         DWM backdrop (Win11 22H2+, build 22621)
;   E  GDI+ + ULW      alfa por pixel, esquinas AA, texto nitido
; Keycaps y slider solo en A y E (DWM esta descartado para ventanas
; layered, ver CONTRA-EVAL-F0 M4; los demas no aportan evidencia nueva).
;
; REGLA DE DECISION: un HR = 0x00000000 NO prueba nada. DWM devuelve OK y
; las esquinas pueden seguir rectas. D4 se firma SOLO por captura de
; pantalla (boton Captura).
;
; Reglas de estilo del proyecto: sin comentarios en la misma linea de un
; valor de .ini (M1) y sin espacio+punto y coma dentro de literales (M5).
; =====================================================================
DllCall("user32\SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
SetWorkingDir(A_ScriptDir)
CoordMode("Mouse", "Screen")

OCULTO := false
CAPTURAS := false
TEMA_RUTA_ARG := ""
for a in A_Args {
    if (a = "--oculto")
        OCULTO := true
    else if (a = "--capturas") {
        OCULTO := true
        CAPTURAS := true
    }
    else if (SubStr(a, 1, 7) = "--tema=")
        TEMA_RUTA_ARG := SubStr(a, 8)
}

S := {esc: 1.0, k: 1.0, mon: MonitorGetPrimary(), log: "", ed: 0, ctl: 0, stage: 0, wins: [], porHwnd: Map()
    , gdip: 0, fondoI: 1, ct: 0, na: 0, alfaCD: 0, dpi: A_ScreenDPI / 96, build: 0
    , fIcon: "", fMono: "", fSemi: "", famFallo: Map(), errores: 0, offx: (OCULTO ? -32000 : 0)
    , temaRuta: "", prim: 1}
T := Map()
FONDOS := [["Oscuro", "1B1B1B", "C8C8C8"], ["Medio", "808080", "101010"], ["Claro", "E8E8E8", "202020"], ["Color", "C8553D", "FFFFFF"]]

try S.build := Integer(StrSplit(A_OSVersion, ".")[3])
S.fIcon := _FuenteInstalada("Segoe Fluent Icons") ? "Segoe Fluent Icons" : (_FuenteInstalada("Segoe MDL2 Assets") ? "Segoe MDL2 Assets" : "Segoe UI Symbol")
S.fMono := _FuenteInstalada("Cascadia Mono") ? "Cascadia Mono" : "Consolas"
S.fSemi := _FuenteInstalada("Segoe UI Semibold") ? "Segoe UI Semibold" : "Segoe UI"

_TemaBuscar()
_TemaAplicar()
_GdipIniciar()
OnExit(_AlSalir)
if OCULTO
    OnError(_OnErr)
OnMessage(0x0201, _Click)
if !OCULTO
    _CrearControl()
_LogInicial()
_Reconstruir()
if (OCULTO && !CAPTURAS)
    SetTimer(_AutoOculto, -400)
else if CAPTURAS
    SetTimer(_AutoCapturas, -400)
else
    SetTimer(ExitApp, -600000)
return

; ---------------------------------------------------------------------
; Tema: lee theme.ini si existe. Valor ausente o invalido -> defecto.
; ---------------------------------------------------------------------
_TemaBuscar() {
    cands := []
    if (TEMA_RUTA_ARG != "")
        cands.Push(TEMA_RUTA_ARG)
    for rel in ["\theme.ini", "\..\theme.ini", "\..\..\theme.ini", "\..\..\..\theme.ini"]
        cands.Push(A_ScriptDir rel)
    for p in cands {
        if FileExist(p) {
            S.temaRuta := p
            return
        }
    }
}

_Tema(sec, clave, def) {
    v := def
    if (S.temaRuta != "") {
        try v := IniRead(S.temaRuta, sec, clave, def)
    }
    v := Trim(v)
    if !RegExMatch(v, "^[0-9A-Fa-f]{6}$") {
        _Log("AVISO tema: [" sec "] " clave " = '" v "' no es RRGGBB, se usa " def)
        return def
    }
    return StrUpper(v)
}

_TemaAplicar() {
    T["base"] := _Tema("color", "surface.base", "12141A")
    T["raised"] := _Tema("color", "surface.raised", "1B1E26")
    T["overlay"] := _Tema("color", "surface.overlay", "20242E")
    T["primTema"] := _Tema("color", "text.primary", "FFFFFF")
    T["muted"] := _Tema("color", "text.muted", "8E97A8")
    T["dim"] := _Tema("color", "text.disabled", "5A6273")
    T["info"] := _Tema("color", "accent.info", "00E5FF")
    T["estab"] := _Tema("color", "accent.estab", "9A7BFF")
    T["trackoff"] := _Tema("color", "track.off", "3A3A45")
    T["primary"] := (S.prim = 1) ? T["primTema"] : "E8ECF4"
}

; ---------------------------------------------------------------------
; UI de control
; ---------------------------------------------------------------------
_CrearControl() {
    g := Gui("+AlwaysOnTop", "Galeria F0 v2 - spike estetico")
    g.SetFont("s9", "Segoe UI")
    g.Add("Text", "xm y+6", "Escala %")
    dEsc := g.Add("DropDownList", "x+6 yp-3 w60 Choose2", ["75", "100", "125", "150"])
    g.Add("Text", "x+14 yp+3", "Monitor")
    mons := []
    Loop MonitorGetCount()
        mons.Push(String(A_Index))
    dMon := g.Add("DropDownList", "x+6 yp-3 w50 Choose" S.mon, mons)
    g.Add("Text", "x+14 yp+3", "Fondo")
    nombres := []
    for f in FONDOS
        nombres.Push(f[1])
    dFon := g.Add("DropDownList", "x+6 yp-3 w80 Choose1", nombres)
    g.Add("Text", "x+14 yp+3", "Texto")
    dPri := g.Add("DropDownList", "x+6 yp-3 w90 Choose1", ["theme.ini", "E8ECF4"])
    S.ct := g.Add("Checkbox", "xm y+10", "Click-through (+E0x20)")
    S.na := g.Add("Checkbox", "x+14 yp", "NoActivate (+E0x08000000)")
    S.alfaCD := g.Add("Checkbox", "x+14 yp", "Alfa 235 tambien en C y D")
    bRec := g.Add("Button", "xm y+10 w100", "Reconstruir")
    bGli := g.Add("Button", "x+6 yp w100", "Rejilla glifos")
    bCap := g.Add("Button", "x+6 yp w100", "Captura PNG")
    bGua := g.Add("Button", "x+6 yp w100", "Guardar log")
    bCer := g.Add("Button", "x+6 yp w80", "Cerrar")
    S.ed := g.Add("Edit", "xm y+10 w620 r16 ReadOnly")
    dEsc.OnEvent("Change", _CambiarEsc)
    dMon.OnEvent("Change", _CambiarMon)
    dFon.OnEvent("Change", _CambiarFondo)
    dPri.OnEvent("Change", _CambiarPri)
    S.ct.OnEvent("Click", _AplicarEx)
    S.na.OnEvent("Click", _AplicarEx)
    S.alfaCD.OnEvent("Click", _Reconstruir)
    bRec.OnEvent("Click", _Reconstruir)
    bGli.OnEvent("Click", _Glifos)
    bCap.OnEvent("Click", _Captura)
    bGua.OnEvent("Click", _GuardarLog)
    bCer.OnEvent("Click", (*) => ExitApp())
    g.OnEvent("Close", (*) => ExitApp())
    MonitorGetWorkArea(S.mon, &l, &t, &r, &b)
    g.Show("x" (l + 10) " y" (t + 10))
    S.ctl := g
}

_CambiarEsc(ctrl, *) {
    S.esc := Integer(ctrl.Text) / 100
    _Reconstruir()
}

_CambiarMon(ctrl, *) {
    S.mon := ctrl.Value
    MonitorGetWorkArea(S.mon, &l, &t, &r, &b)
    S.ctl.Move(l + 10, t + 10)
    _Reconstruir()
}

_CambiarFondo(ctrl, *) {
    S.fondoI := ctrl.Value
    _Reconstruir()
}

_CambiarPri(ctrl, *) {
    S.prim := ctrl.Value
    _TemaAplicar()
    _Log("Texto primario ahora: " T["primary"])
    _Reconstruir()
}

_Chk(c) => IsObject(c) ? c.Value : 0

_Log(txt) {
    S.log .= txt "`r`n"
    if IsObject(S.ed) {
        S.ed.Value := S.log
        SendMessage(0x115, 7, 0, S.ed)
    }
}

_LogInicial() {
    _Log("=== GALERIA F0 v2 | " FormatTime(, "yyyy-MM-dd HH:mm:ss") " | modo " (OCULTO ? "OCULTO" : "visible") " ===")
    _Log("REGLA: HR 0x00000000 no prueba nada. D4 se firma por CAPTURA, no por este log.")
    _Log("Windows " A_OSVersion " (build " S.build ") | Win11=" (S.build >= 22000 ? "si" : "no") " | backdrop posible=" (S.build >= 22621 ? "si" : "no"))
    _Log("DPI sistema " A_ScreenDPI " (factor " Round(S.dpi, 2) ") | monitores " MonitorGetCount() " | AHK " A_AhkVersion " | admin=" (A_IsAdmin ? "SI (no deberia)" : "no"))
    _Log("GDI+ " (S.gdip ? "ok" : "FALLO"))
    _Log("Tema: " (S.temaRuta != "" ? S.temaRuta : "theme.ini NO encontrado, se usan defectos"))
    _Log("Texto primario en uso: " T["primary"] " (theme.ini dice " T["primTema"] ")")
    for n in ["Segoe Fluent Icons", "Segoe MDL2 Assets", "Segoe UI Variable", "Segoe UI Semibold", "Cascadia Mono", "Consolas"]
        _Log("Fuente " n ": " (_FuenteInstalada(n) ? "instalada" : "NO"))
    _Log("-> iconos: " S.fIcon " | mono: " S.fMono " | semibold: " S.fSemi)
    _Log("")
}

_GuardarLog(*) {
    ruta := A_ScriptDir (OCULTO ? "\spike_resultados_oculto.txt" : "\spike_resultados.txt")
    try FileDelete(ruta)
    try FileAppend(S.log, ruta, "UTF-8")
    _Log("Guardado: " ruta)
}

_OnErr(e, modo) {
    S.errores += 1
    _Log("ERROR: " e.Message " (linea " e.Line ")")
    try FileAppend("ERROR galeria: " e.Message " linea " e.Line "`n", "**")
    return 1
}

; ---------------------------------------------------------------------
; Modo oculto: recorre escalas, simula clics, guarda y sale
; ---------------------------------------------------------------------
_AutoOculto() {
    for esc in [0.75, 1.0, 1.5] {
        S.esc := esc
        _Reconstruir()
        for o in S.wins.Clone() {
            if (o.kind = "slider") {
                _SetSlider(o, 20)
                _SetSlider(o, 80)
            } else {
                _Toggle(o)
                _Toggle(o)
            }
        }
    }
    _Log("=== FIN modo oculto | errores: " S.errores " ===")
    ExitApp(S.errores ? 1 : 0)
}

; ---------------------------------------------------------------------
; Modo capturas: same off-screen-safe rebuild, but windows are placed on a
; real monitor for ~0.5 s each so the platform BitBlt produces valid D4 evidence
; ---------------------------------------------------------------------
_AutoCapturas() {
    S.offx := 0
    prim := MonitorGetPrimary()
    otro := MonitorGetCount() > 1 ? (prim = 1 ? 2 : 1) : prim
    _Log("=== GALERIA F0 v2 | modo CAPTURAS | monprim=" prim " monsec=" otro " ===")
    _Pasar(prim, [0.75, 1.0, 1.5])
    if (otro != prim)
        _Pasar(otro, [1.0])
    _Log("=== FIN capturas | errores: " S.errores " ===")
    ExitApp(S.errores ? 1 : 0)
}

_Pasar(mon, escalas) {
    S.mon := mon
    for esc in escalas {
        S.esc := esc
        for fi in [1, 3] {
            S.fondoI := fi
            _Reconstruir()
            Sleep(400)
            _Captura()
            Sleep(120)
        }
    }
}

; ---------------------------------------------------------------------
; Dpi del monitor elegido (para escala correcta en el 2.o monitor)
; ---------------------------------------------------------------------
_DpiMon(idx) {
    try {
        MonitorGetWorkArea(idx, &l, &t, &r, &b)
        pt := (t << 32) | (l & 0xFFFFFFFF)
        hmon := DllCall("user32\MonitorFromPoint", "int64", pt, "uint", 2, "ptr")
        dx := 96
        dy := 96
        if (DllCall("shcore\GetDpiForMonitor", "ptr", hmon, "int", 0, "uint*", &dx, "uint*", &dy, "int") = 0)
            return dx / 96
    }
    return A_ScreenDPI / 96
}

; ---------------------------------------------------------------------
; Construccion de la galeria
; ---------------------------------------------------------------------
_DestruirTodo() {
    for o in S.wins {
        try o.g.Destroy()
    }
    S.wins := []
    S.porHwnd := Map()
    if IsObject(S.stage) {
        try S.stage.Destroy()
    }
    S.stage := 0
}

_Reconstruir(*) {
    fg0 := WinExist("A")
    _DestruirTodo()
    S.dpi := _DpiMon(S.mon)
    k := S.esc * S.dpi
    S.k := k
    pw := Round(112 * k)
    ph := Round(28 * k)
    kw := Round(150 * k)
    kh := Round(32 * k)
    slw := Round(220 * k)
    slh := Round(30 * k)
    gap := Round(16 * k)
    hdr := Round(24 * k)
    lab := Round(18 * k)
    MonitorGetWorkArea(S.mon, &l, &t, &r, &b)
    sx := l + 10 + S.offx
    sy := t + 10 + S.offx
    if (OCULTO && !CAPTURAS) {
        sx := S.offx
        sy := S.offx
    } else if IsObject(S.ctl) {
        try {
            WinGetPos(&cx, &cy, &cw, &ch, "ahk_id " S.ctl.Hwnd)
            sy := cy + ch + 10
        }
    }
    yP1 := hdr + gap
    yP2 := yP1 + ph + gap
    yK0 := yP2 + ph + gap
    yK := yK0 + lab
    yS0 := yK + kh + gap
    yS := yS0 + lab
    sw := 5 * (pw + gap) + gap
    sh := yS + slh + gap
    fon := FONDOS[S.fondoI]
    st := Gui("-Caption +ToolWindow -DPIScale")
    st.BackColor := fon[2]
    st.MarginX := 0
    st.MarginY := 0
    st.SetFont("s9", "Segoe UI")
    cab := ["A Region", "B DWM + alfa", "C DWM opaco", "D Acrylic", "E GDI+ ULW"]
    for i, n in cab
        st.Add("Text", "x" (gap + (i - 1) * (pw + gap)) " y" Round(4 * k) " w" pw " Center c" fon[3], n)
    st.Add("Text", "x" gap " y" yK0 " w" (sw - 2 * gap) " c" fon[3], "Keycaps: A Region (izq.) | E GDI+ ULW (der.)")
    st.Add("Text", "x" gap " y" yS0 " w" (sw - 2 * gap) " c" fon[3], "Slider (clic = mueve el valor): A Region+Progress (izq.) | E GDI+ ULW (der.)")
    st.Show("x" sx " y" sy " w" sw " h" sh " NoActivate")
    S.stage := st
    _Log("--- Reconstruccion: escala " Round(S.esc * 100) "% | monitor " S.mon " (dpi " Round(S.dpi * 100) "%) | fondo " fon[1] " | pill " pw "x" ph " px ---")
    for i, tp in ["A", "B", "C", "D", "E"] {
        px := sx + gap + (i - 1) * (pw + gap)
        for j, estadoOn in [true, false] {
            py := sy + ((j = 1) ? yP1 : yP2)
            t0 := _QPC()
            o := _CrearPill(tp, px, py, pw, ph, estadoOn)
            if (j = 1)
                _Log(tp " pill: creada en " Round(_QPC() - t0, 1) " ms | " o.info)
        }
    }
    for i, tp in ["A", "E"] {
        t0 := _QPC()
        o := _CrearKeys(tp, sx + gap + (i - 1) * (kw + gap), sy + yK, kw, kh)
        _Log(tp " keycaps: creada en " Round(_QPC() - t0, 1) " ms | " o.info)
        t0 := _QPC()
        o := _CrearSlider(tp, sx + gap + (i - 1) * (slw + gap), sy + yS, slw, slh)
        _Log(tp " slider: creada en " Round(_QPC() - t0, 1) " ms | " o.info)
    }
    fg1 := WinExist("A")
    _Log("Foco tras Show NoActivate: " (fg0 = fg1 ? "conservado" : "CAMBIO (alguna ventana robo el foco)"))
    _AplicarEx()
}

_NuevoGui(tipo) {
    opts := "-Caption +AlwaysOnTop +ToolWindow -DPIScale"
    if (tipo = "E")
        opts .= " +E0x80000"
    g := Gui(opts)
    g.MarginX := 0
    g.MarginY := 0
    return g
}

_Registrar(o) {
    o.hwnd := o.g.Hwnd
    S.porHwnd[o.hwnd] := o
    S.wins.Push(o)
}

; Orden de pintado validado en el spike: BackColor ANTES de Show, alfa DESPUES.
_CrearPill(tipo, x, y, w, h, encendido) {
    k := S.k
    o := {kind: "pill", tipo: tipo, x: x, y: y, w: w, h: h, on: encendido, g: 0, hwnd: 0, ico: 0, lbl: 0, dot: 0, info: "", label: "Slider"}
    g := _NuevoGui(tipo)
    o.g := g
    rad := Round(10 * k)
    if (tipo = "D")
        o.info := _Superficie(g.Hwnd, w, h, rad, "acrylic")
    if (tipo != "E") {
        g.BackColor := (tipo = "D") ? "000000" : (encendido ? T["overlay"] : T["raised"])
        col := encendido ? T["primary"] : T["muted"]
        icoC := encendido ? T["info"] : T["dim"]
        o.ico := g.Add("Text", "x" Round(8 * k) " y0 w" Round(20 * k) " h" h " +0x200 Center BackgroundTrans c" icoC, Chr(0xE9E9))
        o.ico.SetFont("s" Max(8, Round(11 * S.esc)), S.fIcon)
        o.lbl := g.Add("Text", "x" Round(32 * k) " y0 w" Round(56 * k) " h" h " +0x200 BackgroundTrans c" col, o.label)
        o.lbl.SetFont("s" Max(7, Round(10 * S.esc)) " w600", "Segoe UI")
        o.dot := g.Add("Text", "x" (w - Round(22 * k)) " y0 w" Round(14 * k) " h" h " +0x200 Center BackgroundTrans c" icoC, encendido ? Chr(0x25CF) : Chr(0x25CB))
        o.dot.SetFont("s" Max(6, Round(8 * S.esc)), "Segoe UI Symbol")
    }
    g.Show("x" x " y" y " w" w " h" h " NoActivate")
    _Registrar(o)
    switch tipo {
        case "A":
            WinSetTransparent(235, "ahk_id " o.hwnd)
            o.info := _Superficie(o.hwnd, w, h, rad, "region")
        case "B":
            WinSetTransparent(235, "ahk_id " o.hwnd)
            o.info := _Superficie(o.hwnd, w, h, rad, "dwm")
        case "C":
            if _Chk(S.alfaCD)
                WinSetTransparent(235, "ahk_id " o.hwnd)
            o.info := _Superficie(o.hwnd, w, h, rad, "dwm")
            if _Chk(S.alfaCD)
                o.info .= " +alfa"
        case "D":
            if _Chk(S.alfaCD)
                WinSetTransparent(235, "ahk_id " o.hwnd)
            if _Chk(S.alfaCD)
                o.info .= " +alfa"
        case "E":
            o.info := "UpdateLayeredWindow=" _PillULW(o)
    }
    return o
}

_CrearKeys(tipo, x, y, w, h) {
    k := S.k
    o := {kind: "keys", tipo: tipo, x: x, y: y, w: w, h: h, on: true, g: 0, hwnd: 0, c1: 0, c2: 0, lbl: 0, info: ""}
    g := _NuevoGui(tipo)
    o.g := g
    rad := Round(10 * k)
    if (tipo = "A") {
        ch := Round(20 * k)
        cy := Round((h - ch) / 2)
        g.BackColor := T["overlay"]
        o.c1 := g.Add("Text", "x" Round(8 * k) " y" cy " w" Round(40 * k) " h" ch " +0x200 Center Background" T["base"] " c" T["primary"], "Ctrl")
        o.c2 := g.Add("Text", "x" Round(54 * k) " y" cy " w" Round(24 * k) " h" ch " +0x200 Center Background" T["base"] " c" T["primary"], "Z")
        o.lbl := g.Add("Text", "x" Round(88 * k) " y0 w" Round(56 * k) " h" h " +0x200 BackgroundTrans c" T["info"], "REDO")
        o.c1.SetFont("s" Max(7, Round(9 * S.esc)) " w600", S.fMono)
        o.c2.SetFont("s" Max(7, Round(9 * S.esc)) " w600", S.fMono)
        o.lbl.SetFont("s" Max(7, Round(10 * S.esc)) " w600", "Segoe UI")
    }
    g.Show("x" x " y" y " w" w " h" h " NoActivate")
    _Registrar(o)
    if (tipo = "A") {
        WinSetTransparent(235, "ahk_id " o.hwnd)
        i0 := _Superficie(o.hwnd, w, h, rad, "region")
        i1 := _Superficie(o.c1.Hwnd, Round(40 * k), Round(20 * k), Round(6 * k), "region")
        i2 := _Superficie(o.c2.Hwnd, Round(24 * k), Round(20 * k), Round(6 * k), "region")
        o.info := "ventana " i0 " | keycaps " i1
    } else {
        o.info := "UpdateLayeredWindow=" _KeysULW(o)
    }
    return o
}

_SliderGeom(o) {
    k := S.k
    o.tx := Round(12 * k)
    o.tw := o.w - Round(12 * k) - Round(56 * k)
    o.dk := Round(14 * k)
    o.th := Round(6 * k)
}

_CrearSlider(tipo, x, y, w, h) {
    k := S.k
    o := {kind: "slider", tipo: tipo, x: x, y: y, w: w, h: h, on: true, val: 60, g: 0, hwnd: 0, bar: 0, knob: 0, vtxt: 0, info: "", tx: 0, tw: 0, dk: 0, th: 0}
    _SliderGeom(o)
    g := _NuevoGui(tipo)
    o.g := g
    rad := Round(10 * k)
    if (tipo = "A") {
        g.BackColor := T["raised"]
        o.bar := g.Add("Progress", "x" o.tx " y" Round((h - o.th) / 2) " w" o.tw " h" o.th " -Smooth -Theme Range0-100 Background" T["trackoff"] " c" T["estab"], o.val)
        o.knob := g.Add("Text", "x" _KnobX(o) " y" Round((h - o.dk) / 2) " w" o.dk " h" o.dk " Background" T["primary"], "")
        o.vtxt := g.Add("Text", "x" (w - Round(52 * k)) " y0 w" Round(44 * k) " h" h " +0x200 Right BackgroundTrans c" T["primary"], Format("{:3}", o.val))
        o.vtxt.SetFont("s" Max(8, Round(12 * S.esc)) " w600", S.fMono)
    }
    g.Show("x" x " y" y " w" w " h" h " NoActivate")
    _Registrar(o)
    if (tipo = "A") {
        WinSetTransparent(235, "ahk_id " o.hwnd)
        i0 := _Superficie(o.hwnd, w, h, rad, "region")
        i1 := _Superficie(o.knob.Hwnd, o.dk, o.dk, Round(o.dk / 2), "region")
        o.info := "ventana " i0 " | knob " i1 " (circulo sin AA)"
    } else {
        o.info := "UpdateLayeredWindow=" _SliderULW(o)
    }
    return o
}

_KnobX(o) => o.tx + Round((o.tw - o.dk) * o.val / 100)

_ValDesdeX(o, mx) {
    v := Round((mx - o.x - o.tx - o.dk / 2) / (o.tw - o.dk) * 100)
    return Max(0, Min(100, v))
}

; ---------------------------------------------------------------------
; Interaccion y redibujo (con medicion)
; ---------------------------------------------------------------------
_Click(wParam, lParam, msg, hwnd) {
    if !S.porHwnd.Has(hwnd) {
        p := DllCall("user32\GetParent", "ptr", hwnd, "ptr")
        if !S.porHwnd.Has(p)
            return
        hwnd := p
    }
    o := S.porHwnd[hwnd]
    if (o.kind = "slider") {
        MouseGetPos(&mx)
        _SetSlider(o, _ValDesdeX(o, mx))
    } else {
        _Toggle(o)
    }
}

_Toggle(o) {
    o.on := !o.on
    _Redibujar(o)
}

_SetSlider(o, v) {
    o.val := v
    _Redibujar(o)
}

_Redibujar(o) {
    t0 := _QPC()
    if (o.tipo = "E") {
        switch o.kind {
            case "pill":
                _PillULW(o)
            case "keys":
                _KeysULW(o)
            case "slider":
                _SliderULW(o)
        }
    } else {
        switch o.kind {
            case "pill":
                col := o.on ? T["primary"] : T["muted"]
                icoC := o.on ? T["info"] : T["dim"]
                if (o.tipo != "D")
                    o.g.BackColor := o.on ? T["overlay"] : T["raised"]
                o.ico.SetFont("c" icoC)
                o.lbl.SetFont("c" col)
                o.dot.SetFont("c" icoC)
                o.dot.Value := o.on ? Chr(0x25CF) : Chr(0x25CB)
            case "keys":
                o.g.BackColor := o.on ? T["overlay"] : T["raised"]
                fondoCap := o.on ? T["base"] : T["overlay"]
                colCap := o.on ? T["primary"] : T["muted"]
                o.c1.Opt("Background" fondoCap)
                o.c2.Opt("Background" fondoCap)
                o.c1.SetFont("c" colCap)
                o.c2.SetFont("c" colCap)
                o.lbl.SetFont("c" (o.on ? T["info"] : T["dim"]))
            case "slider":
                o.bar.Value := o.val
                o.knob.Move(_KnobX(o))
                o.vtxt.Value := Format("{:3}", o.val)
        }
    }
    _Log(o.tipo " " o.kind " redibujo (" (o.kind = "slider" ? "val " o.val : (o.on ? "ON" : "OFF")) "): " Round(_QPC() - t0, 2) " ms")
}

_AplicarEx(*) {
    vistos := Map()
    for o in S.wins {
        try {
            WinSetExStyle((_Chk(S.ct) ? "+" : "-") "0x20", "ahk_id " o.hwnd)
            WinSetExStyle((_Chk(S.na) ? "+" : "-") "0x08000000", "ahk_id " o.hwnd)
        }
        clave := o.kind o.tipo
        if !vistos.Has(clave) {
            vistos[clave] := 1
            ex := 0
            try ex := WinGetExStyle("ahk_id " o.hwnd)
            _Log(o.tipo " " o.kind " ExStyle=0x" Format("{:X}", ex) " | layered=" ((ex & 0x80000) ? "si" : "no") " | click-through=" ((ex & 0x20) ? "si" : "no") " | noactivate=" ((ex & 0x08000000) ? "si" : "no"))
        }
    }
}

; ---------------------------------------------------------------------
; Captura de la plataforma (evidencia valida para D4)
; ---------------------------------------------------------------------
_Captura(*) {
    if !IsObject(S.stage) || (OCULTO && !CAPTURAS)
        return
    WinGetPos(&x, &y, &w, &h, "ahk_id " S.stage.Hwnd)
    hdcS := DllCall("user32\GetDC", "ptr", 0, "ptr")
    hdc := DllCall("gdi32\CreateCompatibleDC", "ptr", hdcS, "ptr")
    hbm := DllCall("gdi32\CreateCompatibleBitmap", "ptr", hdcS, "int", w, "int", h, "ptr")
    old := DllCall("gdi32\SelectObject", "ptr", hdc, "ptr", hbm, "ptr")
    DllCall("gdi32\BitBlt", "ptr", hdc, "int", 0, "int", 0, "int", w, "int", h, "ptr", hdcS, "int", x, "int", y, "uint", 0x40CC0020)
    DllCall("gdi32\SelectObject", "ptr", hdc, "ptr", old)
    bmp := 0
    DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", hbm, "ptr", 0, "ptr*", &bmp)
    clsid := Buffer(16, 0)
    DllCall("ole32\CLSIDFromString", "str", "{557CF406-1A04-11D3-9A73-0000F81EF32E}", "ptr", clsid)
    ruta := A_ScriptDir "\captura_" Round(S.esc * 100) "_" FONDOS[S.fondoI][1] "_m" S.mon "_" FormatTime(, "HHmmss") ".png"
    st := DllCall("gdiplus\GdipSaveImageToFile", "ptr", bmp, "str", ruta, "ptr", clsid, "ptr", 0, "int")
    DllCall("gdiplus\GdipDisposeImage", "ptr", bmp)
    DllCall("gdi32\DeleteObject", "ptr", hbm)
    DllCall("gdi32\DeleteDC", "ptr", hdc)
    DllCall("user32\ReleaseDC", "ptr", 0, "ptr", hdcS)
    _Log("Captura " (st = 0 ? "guardada" : "FALLO (gdiplus=" st ")") ": " ruta)
}

; ---------------------------------------------------------------------
; Capa L1 de ejemplo: _Superficie(hwnd, w, h, radio, modo)
; El texto devuelto NO es evidencia de que el redondeo se vea.
; ---------------------------------------------------------------------
_Superficie(hwnd, w, h, r, modo) {
    switch modo {
        case "region":
            rgn := DllCall("gdi32\CreateRoundRectRgn", "int", 0, "int", 0, "int", w + 1, "int", h + 1, "int", r * 2, "int", r * 2, "ptr")
            DllCall("user32\SetWindowRgn", "ptr", hwnd, "ptr", rgn, "int", 1)
            return "region aplicada (sin AA)"
        case "dwm":
            a := _Dwm(hwnd, 33, 2)
            b := _Dwm(hwnd, 34, 0xFFFFFFFE)
            return "corner(33)=" _Hr(a) " borde(34)=" _Hr(b) " [HR no prueba nada: ver captura]"
        case "acrylic":
            c := _Dwm(hwnd, 20, 1)
            d := _Dwm(hwnd, 38, 3)
            m := Buffer(16, 255)
            e := "ERR"
            try e := DllCall("dwmapi\DwmExtendFrameIntoClientArea", "ptr", hwnd, "ptr", m, "int")
            return "dark(20)=" _Hr(c) " backdrop(38)=" _Hr(d) " extend=" _Hr(e) " [HR no prueba nada: ver captura]"
    }
    return ""
}

_Dwm(hwnd, attr, val) {
    b := Buffer(4, 0)
    NumPut("UInt", val, b)
    try {
        return DllCall("dwmapi\DwmSetWindowAttribute", "ptr", hwnd, "uint", attr, "ptr", b, "uint", 4, "int")
    } catch {
        return "ERR"
    }
}

_Hr(v) {
    if (v = "ERR")
        return "ERR"
    return Format("hr=0x{:08X}", v & 0xFFFFFFFF)
}

; ---------------------------------------------------------------------
; GDI+ + UpdateLayeredWindow (tecnica E). DIB propio, formato PARGB.
; ---------------------------------------------------------------------
_GdipIniciar() {
    if !DllCall("LoadLibrary", "str", "gdiplus", "ptr")
        return false
    si := Buffer(A_PtrSize = 8 ? 24 : 16, 0)
    NumPut("UInt", 1, si, 0)
    tok := 0
    r := DllCall("gdiplus\GdiplusStartup", "ptr*", &tok, "ptr", si, "ptr", 0, "int")
    if (r = 0)
        S.gdip := tok
    return (r = 0)
}

_AlSalir(*) {
    _GuardarLog()
    if S.gdip {
        try DllCall("gdiplus\GdiplusShutdown", "ptr", S.gdip)
    }
    return 0
}

_Argb(hex, a) => (a << 24) | Integer("0x" hex)

_UlwIni(w, h) {
    c := {w: w, h: h, hdc: 0, hbm: 0, old: 0, bits: 0, bmp: 0, gr: 0}
    bi := Buffer(40, 0)
    NumPut("UInt", 40, "Int", w, "Int", -h, "UShort", 1, "UShort", 32, "UInt", 0, bi)
    bits := 0
    c.hdc := DllCall("gdi32\CreateCompatibleDC", "ptr", 0, "ptr")
    c.hbm := DllCall("gdi32\CreateDIBSection", "ptr", c.hdc, "ptr", bi, "uint", 0, "ptr*", &bits, "ptr", 0, "uint", 0, "ptr")
    c.bits := bits
    c.old := DllCall("gdi32\SelectObject", "ptr", c.hdc, "ptr", c.hbm, "ptr")
    bmp := 0
    gr := 0
    DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", w, "int", h, "int", w * 4, "int", 0xE200B, "ptr", bits, "ptr*", &bmp)
    DllCall("gdiplus\GdipGetImageGraphicsContext", "ptr", bmp, "ptr*", &gr)
    DllCall("gdiplus\GdipSetSmoothingMode", "ptr", gr, "int", 4)
    DllCall("gdiplus\GdipSetTextRenderingHint", "ptr", gr, "int", 4)
    DllCall("gdiplus\GdipGraphicsClear", "ptr", gr, "uint", 0)
    c.bmp := bmp
    c.gr := gr
    return c
}

_UlwFin(c, hwnd, x, y) {
    pt := Buffer(8, 0)
    sz := Buffer(8, 0)
    src := Buffer(8, 0)
    bl := Buffer(4, 0)
    NumPut("int", x, "int", y, pt)
    NumPut("int", c.w, "int", c.h, sz)
    NumPut("UChar", 0, "UChar", 0, "UChar", 255, "UChar", 1, bl)
    ok := DllCall("user32\UpdateLayeredWindow", "ptr", hwnd, "ptr", 0, "ptr", pt, "ptr", sz, "ptr", c.hdc, "ptr", src, "uint", 0, "ptr", bl, "uint", 2, "int")
    DllCall("gdiplus\GdipDeleteGraphics", "ptr", c.gr)
    DllCall("gdiplus\GdipDisposeImage", "ptr", c.bmp)
    DllCall("gdi32\SelectObject", "ptr", c.hdc, "ptr", c.old)
    DllCall("gdi32\DeleteObject", "ptr", c.hbm)
    DllCall("gdi32\DeleteDC", "ptr", c.hdc)
    return ok
}

_GdipRoundPath(x, y, w, h, r) {
    path := 0
    r := Max(0.5, Min(r, w / 2, h / 2))
    DllCall("gdiplus\GdipCreatePath", "int", 0, "ptr*", &path)
    d := r * 2
    DllCall("gdiplus\GdipAddPathArc", "ptr", path, "float", x, "float", y, "float", d, "float", d, "float", 180, "float", 90)
    DllCall("gdiplus\GdipAddPathArc", "ptr", path, "float", x + w - d, "float", y, "float", d, "float", d, "float", 270, "float", 90)
    DllCall("gdiplus\GdipAddPathArc", "ptr", path, "float", x + w - d, "float", y + h - d, "float", d, "float", d, "float", 0, "float", 90)
    DllCall("gdiplus\GdipAddPathArc", "ptr", path, "float", x, "float", y + h - d, "float", d, "float", d, "float", 90, "float", 90)
    DllCall("gdiplus\GdipClosePathFigure", "ptr", path)
    return path
}

_GdipRelleno(gr, path, argb) {
    br := 0
    DllCall("gdiplus\GdipCreateSolidFill", "uint", argb, "ptr*", &br)
    DllCall("gdiplus\GdipFillPath", "ptr", gr, "ptr", br, "ptr", path)
    DllCall("gdiplus\GdipDeleteBrush", "ptr", br)
}

_GdipTrazo(gr, path, argb, ancho) {
    pen := 0
    DllCall("gdiplus\GdipCreatePen1", "uint", argb, "float", ancho, "int", 2, "ptr*", &pen)
    DllCall("gdiplus\GdipDrawPath", "ptr", gr, "ptr", pen, "ptr", path)
    DllCall("gdiplus\GdipDeletePen", "ptr", pen)
}

_GdipElipse(gr, x, y, d, argbRell, argbTrazo := 0, ancho := 1) {
    br := 0
    DllCall("gdiplus\GdipCreateSolidFill", "uint", argbRell, "ptr*", &br)
    DllCall("gdiplus\GdipFillEllipse", "ptr", gr, "ptr", br, "float", x, "float", y, "float", d, "float", d)
    DllCall("gdiplus\GdipDeleteBrush", "ptr", br)
    if argbTrazo {
        pen := 0
        DllCall("gdiplus\GdipCreatePen1", "uint", argbTrazo, "float", ancho, "int", 2, "ptr*", &pen)
        DllCall("gdiplus\GdipDrawEllipse", "ptr", gr, "ptr", pen, "float", x, "float", y, "float", d, "float", d)
        DllCall("gdiplus\GdipDeletePen", "ptr", pen)
    }
}

_FamFallo(fam) {
    if !S.famFallo.Has(fam) {
        S.famFallo[fam] := 1
        _Log("AVISO GDI+: familia '" fam "' no encontrada, se usa Segoe UI")
    }
}

; alin: 0 izquierda, 1 centro, 2 derecha. estilo: 0 normal, 1 negrita.
_GdipTexto(gr, txt, fam, px, argb, x, y, w, h, alin := 0, estilo := 0) {
    ff := 0
    font := 0
    sf := 0
    br := 0
    st := DllCall("gdiplus\GdipCreateFontFamilyFromName", "str", fam, "ptr", 0, "ptr*", &ff, "int")
    if (st != 0 || !ff) {
        _FamFallo(fam)
        ff := 0
        st := DllCall("gdiplus\GdipCreateFontFamilyFromName", "str", "Segoe UI", "ptr", 0, "ptr*", &ff, "int")
        if (st != 0 || !ff)
            return
    }
    DllCall("gdiplus\GdipCreateFont", "ptr", ff, "float", px, "int", estilo, "int", 2, "ptr*", &font)
    DllCall("gdiplus\GdipCreateStringFormat", "int", 0x1000, "int", 0, "ptr*", &sf)
    DllCall("gdiplus\GdipSetStringFormatLineAlign", "ptr", sf, "int", 1)
    DllCall("gdiplus\GdipSetStringFormatAlign", "ptr", sf, "int", alin)
    DllCall("gdiplus\GdipCreateSolidFill", "uint", argb, "ptr*", &br)
    rc := Buffer(16, 0)
    NumPut("float", x, "float", y, "float", w, "float", h, rc)
    DllCall("gdiplus\GdipDrawString", "ptr", gr, "str", txt, "int", -1, "ptr", font, "ptr", rc, "ptr", sf, "ptr", br)
    DllCall("gdiplus\GdipDeleteBrush", "ptr", br)
    DllCall("gdiplus\GdipDeleteStringFormat", "ptr", sf)
    DllCall("gdiplus\GdipDeleteFont", "ptr", font)
    DllCall("gdiplus\GdipDeleteFontFamily", "ptr", ff)
}

_SemiEstilo() => (S.fSemi = "Segoe UI") ? 1 : 0

_PillULW(o) {
    w := o.w
    h := o.h
    k := S.k
    c := _UlwIni(w, h)
    gr := c.gr
    fondo := o.on ? T["overlay"] : T["raised"]
    path := _GdipRoundPath(0.5, 0.5, w - 1, h - 1, 10 * k)
    _GdipRelleno(gr, path, _Argb(fondo, 235))
    _GdipTrazo(gr, path, o.on ? _Argb(T["info"], 90) : _Argb("FFFFFF", 20), 1)
    DllCall("gdiplus\GdipDeletePath", "ptr", path)
    col := o.on ? T["primary"] : T["muted"]
    icoC := o.on ? T["info"] : T["dim"]
    _GdipTexto(gr, Chr(0xE9E9), S.fIcon, 14 * k, _Argb(icoC, 255), 8 * k, 0, 22 * k, h, 1)
    _GdipTexto(gr, o.label, S.fSemi, 13 * k, _Argb(col, 255), 34 * k, 0, 56 * k, h, 0, _SemiEstilo())
    dd := 7 * k
    dx := w - 20 * k
    dy := (h - dd) / 2
    if o.on
        _GdipElipse(gr, dx, dy, dd, _Argb(T["info"], 255))
    else
        _GdipElipse(gr, dx, dy, dd, 0, _Argb(T["dim"], 255), 1.5 * k)
    return _UlwFin(c, o.hwnd, o.x, o.y)
}

_KeysULW(o) {
    w := o.w
    h := o.h
    k := S.k
    c := _UlwIni(w, h)
    gr := c.gr
    fondo := o.on ? T["overlay"] : T["raised"]
    path := _GdipRoundPath(0.5, 0.5, w - 1, h - 1, 10 * k)
    _GdipRelleno(gr, path, _Argb(fondo, 235))
    _GdipTrazo(gr, path, _Argb("FFFFFF", 20), 1)
    DllCall("gdiplus\GdipDeletePath", "ptr", path)
    ch := 20 * k
    cy := (h - ch) / 2
    capF := o.on ? T["base"] : T["overlay"]
    capT := o.on ? T["primary"] : T["muted"]
    for cap in [[8, 40, "Ctrl"], [54, 24, "Z"]] {
        p := _GdipRoundPath(cap[1] * k + 0.5, cy + 0.5, cap[2] * k - 1, ch - 1, 6 * k)
        _GdipRelleno(gr, p, _Argb(capF, 255))
        _GdipTrazo(gr, p, _Argb("FFFFFF", o.on ? 56 : 28), 1)
        DllCall("gdiplus\GdipDeletePath", "ptr", p)
        _GdipTexto(gr, cap[3], S.fMono, 12 * k, _Argb(capT, 255), cap[1] * k, cy, cap[2] * k, ch, 1, 1)
    }
    _GdipTexto(gr, "REDO", S.fSemi, 13 * k, _Argb(o.on ? T["info"] : T["dim"], 255), 88 * k, 0, 56 * k, h, 0, _SemiEstilo())
    return _UlwFin(c, o.hwnd, o.x, o.y)
}

_SliderULW(o) {
    w := o.w
    h := o.h
    k := S.k
    _SliderGeom(o)
    c := _UlwIni(w, h)
    gr := c.gr
    path := _GdipRoundPath(0.5, 0.5, w - 1, h - 1, 10 * k)
    _GdipRelleno(gr, path, _Argb(T["raised"], 235))
    _GdipTrazo(gr, path, _Argb("FFFFFF", 20), 1)
    DllCall("gdiplus\GdipDeletePath", "ptr", path)
    ty := (h - o.th) / 2
    tp := _GdipRoundPath(o.tx, ty, o.tw, o.th, o.th / 2)
    _GdipRelleno(gr, tp, _Argb(T["trackoff"], 255))
    DllCall("gdiplus\GdipDeletePath", "ptr", tp)
    kx := _KnobX(o)
    act := kx + o.dk / 2 - o.tx
    if (act > 1) {
        ap := _GdipRoundPath(o.tx, ty, act, o.th, o.th / 2)
        _GdipRelleno(gr, ap, _Argb(T["estab"], 255))
        DllCall("gdiplus\GdipDeletePath", "ptr", ap)
    }
    _GdipElipse(gr, kx, (h - o.dk) / 2, o.dk, _Argb(T["primary"], 255), _Argb("000000", 60), 1)
    _GdipTexto(gr, Format("{:3}", o.val), S.fMono, 14 * k, _Argb(T["primary"], 255), w - 52 * k, 0, 44 * k, h, 2, 1)
    return _UlwFin(c, o.hwnd, o.x, o.y)
}

; ---------------------------------------------------------------------
; Rejilla de glifos (decision de iconos para la fase 2)
; ---------------------------------------------------------------------
_Glifos(*) {
    static gg := 0
    try gg.Destroy()
    gg := Gui("+AlwaysOnTop", "Rejilla de glifos - " S.fIcon)
    gg.SetFont("s8", "Segoe UI")
    gg.MarginX := 10
    gg.MarginY := 10
    cand := [[0xE713, "settings"], [0xE9E9, "slider?"], [0xE790, "color"], [0xE81C, "history"], [0xE72E, "lock"], [0xE785, "unlock"], [0xE718, "pin"], [0xE77A, "unpin"], [0xE71D, "quick?"], [0xE8AB, "switch"], [0xE71E, "zoom"], [0xE72C, "refresh"], [0xE895, "sync"], [0xE7C9, "?"], [0xE8B9, "?"], [0xE7B3, "?"]]
    for i, c in cand {
        x := 10 + Mod(i - 1, 8) * 84
        y := 10 + ((i - 1) // 8) * 150
        a := gg.Add("Text", "x" x " y" y " w76 h44 Center +0x200 Background" T["overlay"] " c" T["info"], Chr(c[1]))
        a.SetFont("s22", S.fIcon)
        b := gg.Add("Text", "x" x " y+2 w76 h44 Center +0x200 Background" T["raised"] " c" T["dim"], Chr(c[1]))
        b.SetFont("s22", S.fIcon)
        gg.Add("Text", "x" x " y+2 w76 Center", Format("{:04X} {}", c[1], c[2]))
    }
    gg.Show()
    _Log("Rejilla de glifos abierta con fuente: " S.fIcon " (anota los codigos elegidos)")
}

; ---------------------------------------------------------------------
; Utilidades
; ---------------------------------------------------------------------
_QPC() {
    static f := 0
    if !f
        DllCall("kernel32\QueryPerformanceFrequency", "int64*", &f)
    c := 0
    DllCall("kernel32\QueryPerformanceCounter", "int64*", &c)
    return c * 1000 / f
}

_FuenteInstalada(nombre) {
    for raiz in ["HKLM", "HKCU"] {
        try {
            Loop Reg, raiz "\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts", "V" {
                if InStr(A_LoopRegName, nombre)
                    return true
            }
        }
    }
    return false
}
