# CHANGELOG - Fase 0 (v2)

- 2026-11-04: `PLAN-V2.md` rev. 2.1 (I12 reescrito, D2 cerrada, D4 = E vs Region, I15, R1-R5, regla V0). Fuente de verdad fijada (3.917 líneas, SHA CEF745C7...).
- `spike/galeria.ahk` v2: corrige G3-G6 y G8 (HR ya no es evidencia, se añade Captura PNG), ULW con DIB propio en formato PARGB, lee `theme.ini`, keycaps y slider (A y E), modo `--oculto`, log guardado al salir, DPI por monitor.
- `spike/spike_latencia.ahk` nuevo: verifica hash/líneas, genera `anclas_canonico.txt`, copia desechable sin elevación, mide latencias base.
- Qué probar: `/validate` y `--oculto` de ambos scripts; sesión visual con capturas.
- Revertir: no hay nada que revertir (el `.ahk` real no se tocó); borrar los archivos nuevos de `docs\ESTETICA\spike`.
