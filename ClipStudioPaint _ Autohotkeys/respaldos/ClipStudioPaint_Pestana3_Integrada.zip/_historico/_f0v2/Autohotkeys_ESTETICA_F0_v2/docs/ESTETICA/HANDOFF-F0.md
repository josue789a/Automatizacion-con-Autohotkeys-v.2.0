# HANDOFF - Fase 0 (paquete v2)

Un chat nuevo lee **solo**: `CONTEXTO.md` -> `PLAN-V2.md` (rev. 2.1) -> `spike/RESULTADOS.md`.

## Estado

- Fuente de verdad: `Documents\AntiGravity\Autohotkeys\XxxPPEN_a16pg2_displayAS_secondary.ahk`, 3.917 líneas, SHA-256 `CEF745C7685DED9C9BC437FE20CEFFB3688126743A9024D9DE964092EBEA983E`. Desktop se ignora.
- Entregado en v2: `PLAN-V2.md` rev. 2.1, `spike/galeria.ahk` v2, `spike/spike_latencia.ahk`, `spike/README-SPIKE.md`, `spike/RESULTADOS.md` (plantilla), `ROLES_LEGACY.md`, `roles_legacy.ahk`.
- El `.ahk` de producción **no se ha tocado**. `theme.ini` tampoco.
- Los dos scripts nuevos se escribieron **sin runtime de AutoHotkey**: ninguno se ha ejecutado todavía.

## Pendiente del usuario (en este orden, sin elevar)

1. `/validate` de `galeria.ahk` y `spike_latencia.ahk` (exit 0). Si falla, pegar el mensaje.
2. `galeria.ahk --oculto` (exit 0) y revisar `spike_resultados_oculto.txt`.
3. `spike_latencia.ahk` (seco): confirma hash/líneas y genera `anclas_canonico.txt`. Pegar ese archivo para cerrar V0 (D1, D2, D3).
4. `spike_latencia.ahk --ejecutar` (parpadea ~3 s, **no mientras dibujas**): `latencia_base.txt`.
5. Sesión visual de `galeria.ahk` con capturas -> rellenar `RESULTADOS.md` y firmar D4 (y D6).
6. `pruebas.ps1 -Modo parse` y `-Modo esteril` sobre el real: PASS y hash sin cambios.

## Siguiente entregable (F1)

`theme.ini` con bloque `[rol]` + `_Tema()` con validación hex (R1) + detección de fuentes + `roles_legacy.ahk` integrado como bloque nuevo. Sin cambio visual. Respetar R2 (sin ` ;` en literales).
