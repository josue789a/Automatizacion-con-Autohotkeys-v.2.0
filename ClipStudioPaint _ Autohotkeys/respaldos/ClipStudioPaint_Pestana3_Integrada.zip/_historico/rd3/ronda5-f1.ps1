# Ronda 5, item 1 (S1): anexar F1 al ESTABLE real. I1 cero reescritura + I2 backup.
param([switch]$Aplicar)
$ErrorActionPreference = 'Stop'
$dir    = 'C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys'
$est    = Join-Path $dir 'XPPEN AHK VERSION ESTABLE.ahk'
$f1     = Join-Path $dir 'rd3\f1_tema.txt'
$ahk    = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$HASH   = '6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D'
$LINEAS = 3959

$antes = (Get-FileHash $est -Algorithm SHA256).Hash
$prev  = [IO.File]::ReadAllLines($est).Count
"hash previo  : $antes"
"lineas previo: $prev"
if ($antes -ne $HASH -or $prev -ne $LINEAS) { throw 'GUARDA ROMPIDA: el archivo no es el esperado. No se toca nada.' }

if (-not $Aplicar) { 'modo seco: nada escrito. Repite con -Aplicar.'; exit 0 }

$bak = "$est.bak-ola1-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
Copy-Item $est $bak
"backup       : $(Split-Path $bak -Leaf)"

$bruto = [IO.File]::ReadAllText($est)
$nl    = if ($bruto.Contains("`r`n")) { "`r`n" } else { "`n" }
"fin de linea : $(if ($nl -eq "`r`n") { 'CRLF' } else { 'LF' })"
$body = [IO.File]::ReadAllText($f1).TrimEnd("`r", "`n", ' ')
$cuerpo = $body -split "`r?`n"
"bloques F1   : $($cuerpo.Count) lineas, F1-BEGIN=$($cuerpo[0].StartsWith('; === F1-BEGIN')) F1-END=$($cuerpo[-1].StartsWith('; === F1-END'))"

$U8 = New-Object Text.UTF8Encoding($false)
[IO.File]::AppendAllText($est, $nl + $body + $nl, $U8)

$despues = [IO.File]::ReadAllLines($est)
"lineas ahora : $prev -> $($despues.Count)"
$orig = [IO.File]::ReadAllLines($bak)
$eliminadas = 0
for ($i = 0; $i -lt $orig.Count; $i++) { if ($despues[$i] -ne $orig[$i]) { $eliminadas++ } }
"eliminadas   : $eliminadas (las $prev originales byte a byte)"

# /validate sin modal: /ErrorStdOut desvia el error a stderr.
$erri = Join-Path $env:TEMP 'ronda5_validate_err.txt'
$psi  = Start-Process $ahk -ArgumentList '/validate', '/ErrorStdOut', "`"$est`"" -NoNewWindow -Wait -PassThru -RedirectStandardError $erri
"validate     : exit $($psi.ExitCode)"
if (Test-Path $erri) { $e = (Get-Content $erri -Raw); if (-not [string]::IsNullOrWhiteSpace($e)) { 'stderr:'; $e } }

# La guarda real es el contenido, no el recuento: 4040 era el de la ronda 4, que
# arrastraba 2 lineas en blanco del .txt; sin ellas son 4038 y el bloque es el mismo.
$ini = [Array]::IndexOf($despues, '; === F1-BEGIN ===')
$fin = [Array]::IndexOf($despues, '; === F1-END ===')
$pegado = ($ini -ge 0 -and $fin -eq ($ini + $cuerpo.Count - 1))
if ($pegado) {
    for ($i = 0; $i -lt $cuerpo.Count; $i++) { if ($despues[$ini + $i] -ne $cuerpo[$i]) { $pegado = $false; "F1 diferia en la linea $($i + 1)"; break } }
}
"F1 al final  : $($ini + 1)..$($fin + 1)  integro=$pegado  (exigia $($cuerpo.Count) lineas)"
$ok = ($despues.Count -ge $prev + 60 -and $despues.Count -le $prev + 100 -and $eliminadas -eq 0 -and $psi.ExitCode -eq 0 -and $pegado)
if (-not $ok) {
    'ROLLBACK: restaurando desde el backup.'
    Copy-Item $bak $est -Force
    "lineas tras rollback: $([IO.File]::ReadAllLines($est).Count)  hash: $((Get-FileHash $est -Algorithm SHA256).Hash)"
    exit 1
}
'F1 ANEXADO Y VALIDADO.'
"hash nuevo   : $((Get-FileHash $est -Algorithm SHA256).Hash)"
"lineas nuevas: $($despues.Count)"
"theme.ini    : $(Join-Path $dir 'theme.ini') existe=$(Test-Path (Join-Path $dir 'theme.ini'))  sha=$((Get-FileHash (Join-Path $dir 'theme.ini') -Algorithm SHA256).Hash)"
