# PLAN-V2 (rev. 2.1) - Refactor estético

Fecha: 2026-11-04. Sustituye la tabla de olas de `CONTEXTO.md` §6 y a `PLAN-V2.md` rev. 2.0.
Los invariantes **I1-I11** de `CONTEXTO.md` no cambian. Se mantienen I12-I14 (I12 reescrito) y se añaden **I15** y las reglas **R1-R5**.

## 0. Cambios respecto a la rev. 2.0

| # | Cambio | Origen |
|---|---|---|
| 1 | **Fuente de verdad fijada** (§1). Se ignora Desktop. | Usuario, 2026-11-04 |
| 2 | **I12 reescrito**: el único escritor de transparencia sobre HWND de CSP son los bucles `LoopColor*`. | CONTRA-EVAL §5.3 |
| 3 | **D2 cerrada**: desacoplar `enfoque.activo` de la limpieza de avisos. | CONTRA-EVAL §5.4 |
| 4 | **D4 reformulada**: entre GDI+/ULW (E) y Region (A). DWM descartado en ventanas layered. | CONTRA-EVAL M4 |
| 5 | **R1** (M1): prohibido comentario en la misma línea que un valor de `.ini`. | CONTRA-EVAL M1 |
| 6 | **R2** (M5): prohibido ` ;` (espacio + punto y coma) dentro de literales. | CONTRA-EVAL M5 |
| 7 | **R3**: D4 se firma por **captura**, no por log (el HR no prueba nada). | CONTRA-EVAL M4/G8 |
| 8 | **R4**: orden de pintado en ventanas layered: `BackColor` antes de `Show`, alfa después. | CONTRA-EVAL §5.7 |
| 9 | **I15**: el rectángulo exterior de una pill no cambia de tamaño. | CONTRA-EVAL §8.3 |
| 10 | Anclas **solo por nombre de función**; el mapa se genera con `spike/spike_latencia.ahk`. | CONTRA-EVAL §4.1 |
| 11 | G1 y G2 de `galeria.ahk` retirados (medido). G3-G8 corregidos en `galeria.ahk` v2. | CONTRA-EVAL §6 |

## 1. Fuente de verdad y regla V0

- Archivo canónico: `C:\Users\jbard\Documents\AntiGravity\Autohotkeys\XxxPPEN_a16pg2_displayAS_secondary.ahk`
- **3.917 líneas** - SHA-256 `CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E`
- Los árboles de Desktop son backups/iteraciones y **no** se usan.

**Regla V0 (verificación obligatoria contra el canónico).** Varios hallazgos de la rev. 2.0 y de CONTRA-EVAL se midieron sobre copias de 3.958 o 4.017 líneas. Antes de que una fase apoye una decisión en ellos, se confirman contra el canónico con `spike_latencia.ahk` (genera `anclas_canonico.txt`):

| Marca | Qué confirma | Si no coincide |
|---|---|---|
| `_FadeAlpha` usos | I12 / D1 (CONTEXTO §2 lo lista en la línea ~539 del canónico) | Si existe: I12 mantiene **además** "`_FadeAlpha` no se toca" (ver §5) |
| `_LimpiarAvisos` def > 0 | D2 cerrada | Si no existe: D2 vuelve a **abierta** (el hallazgo #1 sería real) |
| `_LimpiarGUIs` usos | hallazgo #1 | idem |
| `208 * AVISO_ESC` | hallazgo #3 | descartar #3 |
| `-2247` / `PUNTOS[30]` | hallazgo #2 / D3 | reevaluar D3 |

Hasta completar V0, D1 y D2 figuran como **cerradas condicionadas**.

## 2. Revisión técnica (hechos medidos)

| # | Hallazgo | Tipo | Fase | Estado |
|---|---|---|---|---|
| 1 | `_LimpiarGUIs()` destruye el HUD y apaga el modo Enfoque | lógica | F3 | **cerrado** si V0 confirma `_LimpiarAvisos` (D2) |
| 2 | HUD y badge en `(-2247, 30)` fijo; MiniTexto/toggle/icono en `PUNTOS[30]` | consistencia | F3 (D3) | abierto, verificar en canónico |
| 3 | HUD con ancho fijo `208 * AVISO_ESC`: textos largos recortados | visual | F3 | abierto, verificar en canónico |
| 4 | Timer de ocultar del HUD no se cancela al reutilizarlo | visual | F3 | abierto |
| 5 | 9 `Picture` vacíos (`iconos\` no existe, `_IconosB64()` vacío) | visual | F2 | abierto |
| 6 | ON/OFF casi iguales (`636D83` vs `424242`) | visual | F2 | abierto |
| 7 | `ESTAB_ALPHA_H 128` lava el número; solo alfa por píxel lo resuelve | visual | F5 | abierto |
| 8 | 58 hex distintos; 33 pasados a avisos; verdes y naranjas inconsistentes | sistema | F1 | abierto |
| 9 | 7 botoneras clonadas + 10 `WM_LBUTTONDOWN` + `if/else` hwnd->acción | estructura | F2 / F6 | abierto |
| 10 | `MostrarBadgeCombo` / `MostrarMiniTexto` crean un `Gui` por llamada | rendimiento | F3 | abierto |
| 11 | `MostrarMiniGUI`: código muerto (0 usos) | limpieza | F3 | verificar |
| 12 | Anclas de `CONTEXTO.md` desfasadas | proceso | F0 | **resuelto**: anclar por función |
| 13 | Emoji en avisos (p. ej. `Sanar()`): fuente de fallback | visual | F1/F2 | abierto |

## 3. Diseño objetivo

1. **Periférico primero**: estado legible de un vistazo; forma (punto lleno/hueco) además de color.
2. **6 roles de color**: `info ok warn danger estab neutral` (`ROLES_LEGACY.md`). El mapa hex-legado -> rol vive dentro de `Mostrar*`: los ~120 call sites no cambian.
3. **2 motores de aviso** (línea simple de ancho automático; combo con keycaps), ventanas persistentes reutilizadas, **una sola ancla** de posición.
4. **Forma**: radio 10 px, borde de 1 px (blanco ~8 %) en vez de sombra.
5. **Tipografía**: 3 niveles; números en mono (`Cascadia Mono` -> `Consolas`), con detección.
6. **Movimiento**: solo opacidad, 120-180 ms, out-cubic; nada en la ruta del lápiz.
7. **Iconos**: glifos (`Segoe Fluent Icons` -> `Segoe MDL2 Assets`), con detección.

## 4. Arquitectura (strangler: envolver, no reescribir)

```text
L3  Adaptadores   IniciarXGUI / ActualizarXGUI / MostrarHUD(texto, hexLegado, ms)   <- firmas intactas, campo .g intacto
L2  Componentes   Pill - Toast - ToastCombo - SliderSkin
L1  Superficie    _Superficie(hwnd, w, h, radio, modo)     <- Region | ULW segun D4 (DWM descartado)
L0  Tema          _Tema() + roles + deteccion de fuentes
```

## 5. Invariantes

| # | Regla |
|---|---|
| I12 (reescrito) | Los bucles `LoopColorV` / `LoopColorCC` / `LoopAccesoRapido` son el **único escritor** de `WinSetTransparent` y de `±0x20` sobre HWND de CSP. Ninguna fase estética escribe transparencia sobre ventanas ajenas fuera de ellos. Si V0 muestra que `_FadeAlpha` existe en el canónico, **tampoco se toca** y el animador nuevo opera solo sobre GUIs propias. |
| I13 | Función estética nueva <= ~2 ms en ruta caliente, medida con QPC contra la línea base de `latencia_base.txt`. |
| I14 | Se conservan las firmas `IniciarXGUI/ActualizarXGUI/_XGUI_WM_LBUTTONDOWN` y el campo `.g` (los usan `Numpad8`, `ResetAlphaStates`, `_MostrarPaneles`, `_TraerPanelesAlFrente`, `_ArrastrarPanelBloque`). |
| I15 (nuevo) | **El rectángulo exterior de una pill no cambia de tamaño** (la calibración de `posiciones_gui.ini` depende de él). Solo cambia el pintado interno: glifo, etiqueta recortada, punto de estado. |

### Reglas de estilo y método

| # | Regla |
|---|---|
| R1 | `theme.ini`: **sin comentarios en la misma línea que un valor** (`IniRead` los mete en el valor) y sin texto tras `]`. Validar `^[0-9A-Fa-f]{6}$` con caída al defecto. Las claves alineadas con espacios **sí** funcionan (medido). |
| R2 | No escribir ` ;` (espacio + punto y coma) dentro de literales en AHK v2.0.26: se toma como comentario y rompe el parseo. Aplica a textos de HUD/avisos y a todo bloque nuevo. Alternativas: `"a;b"`, `"a`; b"`. |
| R3 | **D4 se firma por captura de pantalla.** `DwmSetWindowAttribute` devuelve `S_OK` y relee `2` aunque las esquinas sigan rectas en una ventana layered. Un HR = 0 no prueba nada. |
| R4 | En ventanas layered: `BackColor` **antes** de `Show`, alfa (`WinSetTransparent`) **después**. Las botoneras actuales no lo garantizan: se corrige en F2. |
| R5 | Las anclas de cada edición son **nombres de función**, nunca números de línea. I7 se recalcula contra 3.917 (rango 3.850-4.050). F1 añade un bloque nuevo (~100-140 líneas): si el techo no alcanza, se justifica en el CHANGELOG antes de seguir. |

## 6. Fases

| Fase | Qué hace | Toca (por nombre de función) | Riesgo |
|---|---|---|---|
| **F0** | Reconciliar archivo + anclas (V0); latencias base; `galeria.ahk` v2; firmar D4 por imagen | **nada del `.ahk`** | nulo |
| **F1** | `_Tema()` con validación hex (R1), roles, detección de fuentes. Cero cambio visual | bloque nuevo (`roles_legacy.ahk`) | bajo |
| **F2** | Botoneras: glifo, punto de estado, radio, hairline (I15, R4); cuerpos de `Iniciar/Actualizar` -> `PillCrear/PillEstado` | 7 botoneras, `IniciarReloadGUI`, `IniciarPuntosGUI`, `_SetIcono` | medio |
| **F3** | Avisos: 2 motores, ancho automático, ancla única (D3), timer único; retirar `MostrarMiniGUI`; sin emoji | `MostrarHUD`, `MostrarMiniTexto`, `MostrarBadgeCombo`, `MostrarTooltipToggle`, `MostrarIconoHerramienta`, `_OcultarHUDSi` | bajo-medio |
| **F4** | Animación de opacidad solo en GUIs propias | `_Animar` nuevo | bajo |
| **F5** | Slider: pintado/controles; sin tocar hotkeys, `_EstabEmitir` ni `_EstabEnviarDelta` | creación de controles en `IniciarEstabGUI`, `ActualizarEstabGUI`, `_EstabRegion`, `_EstabKnobRegion` | medio |
| **F6** (opc.) | Panel de calibración oscuro, tabla hwnd->acción, marcos de enfoque | `AbrirPanelPuntos`, `_ArrastrarPanelBloque`, `MostrarGUIEnfoque` | bajo-medio |

### Puerta de cada fase (DoD)

1. `.bak-faseN-<fecha>` antes de la primera edición (I2).
2. Ediciones con anclas únicas por **nombre de función** (I1); nunca `write` ni `replaceAll` sobre el `.ahk`.
3. `pruebas.ps1 -Modo parse` y `-Modo esteril` en PASS (I3, I4). Nunca lanzar el `.ahk` real.
4. Captura de `galeria.ahk`/GUIs frente a la fase anterior.
5. Latencia: ninguna función estética nueva suma > ~2 ms en ruta caliente (I13).
6. Líneas antes -> después dentro de I7 (R5).
7. 5 líneas en `CHANGELOG.md` + lista corta de pruebas manuales con el lápiz.
8. Rollback: `Copy-Item <bak> <archivo> -Force`.

## 7. Decisiones

| ID | Decisión | Estado |
|---|---|---|
| D1 | `_FadeAlpha` fuera del alcance | **cerrada, condicionada a V0** (I12 reescrito cubre ambos casos) |
| D2 | `_LimpiarGUIs()` / `enfoque.activo`: **desacoplar** | **cerrada, condicionada a V0** |
| D3 | Ancla de avisos: `PUNTOS[30]` o `(-2247, 30)` | **abierta** (F3): confirmar si coinciden en tu equipo |
| D4 | Técnica de render | **abierta: E (GDI+/ULW) vs A (Region)**. DWM descartado (M4). La fija `spike/RESULTADOS.md` por captura |
| D5 | Piso de I7 en F2 | **provisional** 3.600 (consolidar clones reduce líneas); confirmar al cerrar F2 |
| D6 | Paleta: `text.primary` = `FFFFFF` o `E8ECF4` | **abierta**: `galeria.ahk` v2 lee `theme.ini` y permite comparar ambos |

## 8. Criterio de salida de F0

- [ ] `anclas_canonico.txt` generado y V0 revisada (D1/D2 confirmadas o reabiertas).
- [ ] `latencia_base.txt` con medianas de `MostrarHUD`, `MostrarMiniTexto`, `ActualizarEstabGUI`.
- [ ] `spike/RESULTADOS.md` completo con **capturas** (A y E, 75/100/150 %, 2.º monitor) y D4 marcada.
- [ ] D6 decidida (o diferida a F1 con constancia).
- [ ] `pruebas.ps1 -Modo parse` y `-Modo esteril` en PASS sobre el real (no debe haber cambiado el hash).
