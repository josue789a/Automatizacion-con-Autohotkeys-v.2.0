# Ronda 4, item 3a: construir spike v3 = copia de Claude + parche T1.1 + huellas _LatHb.
$ErrorActionPreference = 'Stop'
$ahk  = "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"
$src  = "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\spike-parcheado\spike_latencia.ahk"
$out  = "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\spike-v3\spike_latencia.ahk"
New-Item -ItemType Directory -Force (Split-Path $out) | Out-Null

$t = [IO.File]::ReadAllText($src)
$CRLF = [string][char]13 + [string][char]10
"CRLF              : $($t.Contains($CRLF))"
"REP suelto (0)    : $([regex]::Matches($t,'\bREP\b').Count)"
"_LatHb previo (0) : $([regex]::Matches($t,'_LatHb').Count)"

function Sub1([string]$hay, [string]$aguja, [string[]]$nuevo) {
    $n = [regex]::Matches($hay, [regex]::Escape($aguja)).Count
    if ($n -ne 1) { throw "ancla unica esperada, encontrada $n : $aguja" }
    $crlf = [string][char]13 + [string][char]10
    return $hay.Replace($aguja, ($nuevo -join $crlf))
}

# 1) latido en el auto-ejecutable de la copia
$t = Sub1 $t '                nuevo.Push("SetTimer(_LatBase, -2500)")' @(
    '                nuevo.Push(''_LatHb("autoexec: Suspend + timer registrados")'')',
    '                nuevo.Push("SetTimer(_LatBase, -2500)")')
# 2) borrado del fichero de latidos antes de lanzar
$t = Sub1 $t '    pid := 0' @(
    '    hbq := dir "\heartbeat_latencia.txt"',
    '    try FileDelete(hbq)',
    '    pid := 0')
# 3) volcado de los latidos al informe
$t = Sub1 $t '        Rep("La copia no escribio salida. Revisa " errf)' @(
    '        Rep("La copia no escribio salida. Revisa " errf)',
    '    if FileExist(hbq)',
    '        Rep("Latido de la copia (A_TickCount | etapa):`n" FileRead(hbq, "UTF-8"))')
# 4) definicion de _LatHb dentro del inyectable
$t = Sub1 $t '; ===== inyectado por spike_latencia.ahk (solo en la copia) =====' @(
    '; ===== inyectado por spike_latencia.ahk (solo en la copia) =====',
    '_LatHb(t) {',
    '    try FileAppend(A_TickCount " | " t "`r`n", "@@HB@@", "UTF-8")',
    '}')
# 5) latido por funcion medida
$t = Sub1 $t '_LatMedir(nombre, fn, n) {' @('_LatMedir(nombre, fn, n) {', '    _LatHb("empieza " nombre)')
# 6) latidos dentro de _LatBase
$t = Sub1 $t '_LatBase() {' @('_LatBase() {', '    _LatHb("_LatBase entro (timer disparado)")')
$t = Sub1 $t '    FileAppend(out, "@@SALIDA@@", "UTF-8")' @(
    '    FileAppend(out, "@@SALIDA@@", "UTF-8")',
    '    _LatHb("salida escrita")')
# 7) resolucion de @@HB@@
$t = Sub1 $t '    c := StrReplace(c, "@@SALIDA@@", salida)' @(
    '    hb := StrReplace(salida, "salida_latencia.txt", "heartbeat_latencia.txt")',
    '    c := StrReplace(c, "@@SALIDA@@", salida)',
    '    c := StrReplace(c, "@@HB@@", hb)')

"huellas (_LatHb, 7) : $([regex]::Matches($t,'_LatHb').Count)"
[IO.File]::WriteAllText($out, $t, (New-Object Text.UTF8Encoding($false)))

$r = Start-Process $ahk -ArgumentList '/validate', "`"$out`"" -Wait -PassThru
"/validate spike v3 -> exit $($r.ExitCode)   (esperado 0)"
"lineas : $([IO.File]::ReadAllLines($out).Length)"
"sha256 : $((Get-FileHash $out -Algorithm SHA256).Hash)"
