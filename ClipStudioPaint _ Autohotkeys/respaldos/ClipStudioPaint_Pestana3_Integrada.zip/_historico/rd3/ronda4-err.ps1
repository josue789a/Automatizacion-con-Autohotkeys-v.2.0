$ErrorActionPreference = 'Stop'
$copia = Join-Path $env:TEMP 'latencia_f0\prueba_latencia.ahk'
$errf  = Join-Path $env:TEMP 'r4_err.txt'
$outf  = Join-Path $env:TEMP 'r4_out.txt'
Remove-Item $errf, $outf -ErrorAction SilentlyContinue
$p = Start-Process 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe' `
        -ArgumentList '/validate', '/ErrorStdOut', "`"$copia`"" `
        -RedirectStandardError $errf -RedirectStandardOutput $outf `
        -Wait -PassThru -WindowStyle Hidden
"copia : $copia"
"exit  : $($p.ExitCode)"
"stderr:"
if (Test-Path $errf) { $e = (Get-Content $errf -Raw); if ([string]::IsNullOrWhiteSpace($e)) { '  (vacio)' } else { $e } } else { '  (sin archivo)' }
