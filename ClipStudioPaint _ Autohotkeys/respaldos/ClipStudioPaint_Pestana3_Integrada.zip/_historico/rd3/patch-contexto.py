# -*- coding: utf-8 -*-
import sys, hashlib, unicodedata

F = r"C:\Users\jbard\Documents\AntiGravity\Autohotkeys\docs\ESTETICA\CONTEXTO.md"
A = r"C:\Users\jbard\AppData\Local\Temp\ronda5_spike\anclas_canonico.txt"

raw = open(F, "rb").read()
bom = raw[:3] == b"\xef\xbb\xbf"
txt = raw.decode("utf-8-sig").replace("\r\n", "\n")
lines = txt.split("\n")
if lines and lines[-1] == "":
    lines.pop()


def fold(s):
    s = unicodedata.normalize("NFD", s)
    return "".join(c for c in s if unicodedata.category(c) != "Mn").lower()


def one(sub, start=0):
    k = fold(sub)
    hits = [i for i in range(start, len(lines)) if k in fold(lines[i])]
    if len(hits) != 1:
        sys.exit("ANCHOR no univoco (%d): %r" % (len(hits), sub))
    return hits[0]


def rep(i, new):
    lines[i:i + 1] = new


def ins(i, new):
    lines[i:i] = new


# ---- cabecera ----
i = one("- Archivo objetivo:")
rep(i, ["- Archivo objetivo: `XPPEN AHK VERSION ESTABLE.ahk` en "
        "`C:\\Users\\jbard\\Desktop\\AHK-global-main\\ClipStudioPaint _ Autohotkeys\\` "
        "(**3.959 líneas** por `ReadAllLines`). El canónico de "
        "`Documents\\AntiGravity\\Autohotkeys` (3.917) queda como referencia histórica "
        "(T4 en firme)."])

# ---- §0 tabla ----
i = one("| Líneas del `.ahk`")
rep(i, ["| Archivo objetivo | `XPPEN AHK VERSION ESTABLE.ahk` (Desktop\\AHK-global-main\\ClipStudioPaint _ Autohotkeys\\) |",
        "| Líneas del `.ahk` (ReadAllLines) | **3.959** · SHA-256 `6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D` |",
        "| `_EstabEmitir` | l.2909 · `pausa := ESTAB_RITMO`; `ESTAB_RACHA := 10` (l.29), `ESTAB_RITMO := 18` (l.30) |",
        "| Huella `.Show()` del arnés | **29 string / 2 vacías / 3 posicionales** (el canónico de 3.917 daba 31) |"])

i = one("| Prueba de carga |")
rep(i, ["| Prueba de carga | **PASS** sobre ESTABLE+F1 recalibrado: `-Modo esteril` terminó limpio en 2,2 s, stderr 0 bytes, 0 huérfanos |"])
i = one("| Arnés `pruebas.ps1` |")
rep(i, ["| Arnés `pruebas.ps1` | **probado**: `parse` PASS · `esteril` PASS con huella 29/2/3 (recalibrado 2026-11-04; respaldo `pruebas.ps1.bak-ronda4-20261104-232447`) |"])
i = one("| Dial |")
rep(i, ["| Dial | muerto: `IniciarDialGUI() => 0` (l.2230 del ESTABLE) |"])

# ---- invariantes ----
i = one("| I5 |")
lines[i] = lines[i].replace("`_EstabEmitir` (2865)", "`_EstabEmitir` (l.2909 en el ESTABLE)")
i = one("| I7 |")
rep(i, ["| I7 | **Presupuesto por ola**: línea inicial (por `ReadAllLines`, anotada en el CHANGELOG) ±100. Si una ola sale del rango, detenerse y justificarlo. Ola 1: 3.959 → 4.040. |",
        "| I12 | `_FadeAlpha` (l.563) y sus 6 llamadas (en `_SetColorV/_SetColorCC/_SetAR`) no se tocan. El animador nuevo solo opera sobre GUIs propias; nunca recibe el HWND de un panel de CSP. |",
        "| I13 | **a)** ruta de hotkey: función estética nueva ≤ +2 ms sobre la mediana de `latencia_base.txt` (con N ≥ 10, mismas condiciones). **b)** repintado de componente en cambio de estado ≤ 35 ms. D4 sigue sin firmar hasta capturas. |"])

# ---- §2: mapa sustituido por las anclas del ESTABLE ----
a = one("## 2. Mapa del código relevante")
b = one("**Colores hoy hardcodeados**", a)
anclas = open(A, "rb").read().decode("utf-8-sig").replace("\r\n", "\n").rstrip("\n")
lines[a:b] = [
    "## 2. Mapa del código relevante (anclas del ESTABLE, generadas por el spike)",
    "",
    "Números de línea **del ESTABLE de 3.959**. El mapa anterior apuntaba al canónico de",
    "3.917 y estaba desfasado (+25 a +44 líneas según la zona). `usos` = líneas que citan",
    "el nombre, no llamadas.",
    "",
    "```text",
    anclas,
    "```",
    "",
]

# ---- §4.5 nombres reservados ----
i = one("No usar estos nombres para otra cosa")
rep(i, ["`_TemaValido()` · `_TemaFuente()` · `_FuenteInstalada()` · `_RolDeHex()` · "
        "`_AvisoColor()` · `_LimpiarAvisos()` (F3)",
        "No usar estos nombres para otra cosa."])

# ---- §7 deuda ----
i = one("| Dial muerto:")
lines[i] = "| Dial muerto: `IniciarDialGUI() => 0` | 2188 (canónico) / 2230 (ESTABLE) | — |"
ins(i + 1, ["| `_LimpiarGUIs()` llamada desde `MostrarMiniTexto` y `MostrarTooltipToggle` apaga `enfoque.activo` y los marcos | l.1712, l.1759 | 3 (se crea `_LimpiarAvisos`) |",
            "| `MostrarMiniTexto`/`MostrarBadgeCombo`: si una excepción salta entre `Gui()` y la asignación a `floatGui`, la GUI queda huérfana | l.1711-1760 | — (anotado, I8) |"])

# ---- §8 numero obsoleto ----
i = one("3.917 líneas completas")
lines[i] = lines[i].replace("3.917 líneas", "3.959 líneas")

# ---- §9 huella ----
i = one("huella estructural** del script")
assert "posicionales" in lines[i + 1] and "se niega" in lines[i + 1], lines[i:i + 2]
lines[i:i + 2] = ["- **Verifica la huella estructural** del script (`.Show()`: 29 string + 2 vacías +",
                  "  3 posicionales en el ESTABLE; 31/2/3 en el canónico). Si cambia, **se niega a",
                  "  ejecutar** en vez de corromper la copia."]

out = "\n".join(lines) + "\n"
data = out.encode("utf-8")
open(F, "wb").write((b"\xef\xbb\xbf" if bom else b"") + data)
print("lineas:", len(lines))
print("sha256:", hashlib.sha256((b"\xef\xbb\xbf" if bom else b"") + data).hexdigest().upper()[:16])
