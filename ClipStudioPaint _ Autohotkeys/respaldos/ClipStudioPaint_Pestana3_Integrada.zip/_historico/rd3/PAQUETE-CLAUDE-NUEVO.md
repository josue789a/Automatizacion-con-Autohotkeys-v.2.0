# PAQUETE PARA UN CHAT NUEVO DE CLAUDE (2026-11-05 02:10)

Eres un chat **nuevo de Claude** sin memoria ni archivos: todo lo que necesitas esta pegado
aqui. No intentes leer el PC del usuario: no lo ves. Las pruebas ya estan hechas y sus
numeros estan abajo; **no vuelvas a pedirlas**.

## Quien es quien
- **Josue** - ilustrador, dona el PC. Trabaja en Clip Studio Paint con un companion en
  **AutoHotkey v2** que le pinta paneles flotantes (botoneras, HUD, badge, un deslizador de
  estabilizacion) y le reenvia atajos. El archivo vivo es `XPPEN AHK VERSION ESTABLE.ahk`.
- **Qoder** - el agente ejecutor. Corre el runtime real, mide, valida y edita. Escribe los
  informes. Este paquete lo firma el.
- **Tu rol (arquitecto)** - decidir, dictar parches anclados por nombre de funcion y revisar
  los numeros. **No tienes runtime**: todo lo que propongas se ejecuta y se mide aqui, y lo
  que no se pueda medir en este Windows se dice con numbers, no con opinion.

## Estado en una linea
Fase 0 cerrada. **Ola 0 (spike DWM) cerrada con numeros** (seccion 3). Ola 1 (tokens de color)
**lista para dictar**: el cargador `_Tema()` ya esta **dentro del archivo real** y nadie lo llama
todavia. Las olas 2-5 sin empezar.

## Lo que se te pide AHORA (tres cosas, en este orden)
1. **Decidir la forma de la pill** (ola 2), que la ola 0 dejo abierta: un control hijo **no
   puede redondearse** (DWM rechaza el hwnd hijo con ERROR_INVALID_HANDLE), asi que o
   (a) pill = control `Text` con recorte GDI+/Region propio, o (b) pill = **ventana sin caption
   propia** que hereda el arco del sistema gratis. Cuesta (a) ~1 region por repintado y (b)
   15-63 ms por ventana en el arranque y N hwnds mas.
2. **Que hacer con `[radius] sm=6 md=10 lg=14`** del token de tema: el sistema solo ofrece
   recto / ~7-8 px / ~11-13 px. Propon si los tokens se redefinen a esos 3 valores o si se
   declaran solo validos para recortes propios.
3. **Dictar la ola 1** sobre el censo de la seccion 6: 51 literales en las 7 botoneras,
   mapeados 1:1 a los tokens de `theme.ini` (seccion 5). Ancla por nombre de funcion, no por
   numero de linea (I1). Maximo ~100 lineas por ola (I7).

## Reglas del juego (no negociables; estan en I1-I13 de la seccion 2)
- Cualquier edicion del archivo real **reinicia el companion de Josue a los ~2 s** y le corta
  la sesion de dibujo. Las ediciones van **entre sesiones**, con `.bak-olaN-<fecha>` previo.
- El archivo real **no se pega entero jamas**: diffs anclados o la funcion completa.
- Nada de `Sleep` en rutas de input, nada de tocar `#HotIf`, nada de tocar `_FadeAlpha` (I12).
- `theme.ini` y `posiciones_gui.ini` son archivos de usuario: **no se sobreescriben**, se leen.

## Lo que ya esta medido y NO debe volver a proponerse
- Guardar PNG desde GDI+ dentro del proceso AHK: **roto en este PC** (devuelve 10 y deja 0
  bytes en las 4 variantes probadas). La evidencia sale de PowerShell con `System.Drawing`.
- Redondear un **control** con `DwmSetWindowAttribute`: rechazado (`0x80070006`).
- `SetLayeredWindowAttributes` a mano sobre una Gui de AHK: falla (`gle=87`). Usar
  `WinSetTransparent`.
- Usar **PrintWindow como evidencia visual de un fade**: ignora el alfa y el arco (captura
  solida una ventana al 40 %). Sirve para contenido, no para estado de opacidad.
- El techo I13-a "funcion nueva <= 2 ms" **no aplica a crear ventanas** (cuesta 15-63 ms una
  vez); aplica a repintados. `WinSetTransparent` mide **0,0 ms por paso**.

## Como responder
Un solo bloque de texto: (1) la decision de la pill con su justificacion de coste, (2) que
haces con `[radius]`, (3) el parche de la ola 1 en trozos anclados
`ANTES -> DESPUES` por funcion, con el numero de sustituciones esperadas (debe dar 51).
Si necesitas ver codigo que no esta aqui, pide **la funcion por nombre** y Qoder la pega.


---

# SECCION 1 - CONTEXTO del proyecto (CONTEXTO.md verbatim)
# CONTEXTO — Refactor estético (traspaso entre chats)

> **Documento de arranque.** Un chat nuevo debe leer **solo este archivo** más el
> `OLA-N.md` de turno. Todo lo demás es opcional.
>
> Regla de oro: **si no está escrito aquí, no existe.** Las decisiones que no se
> registran se re-discuten y se implementan distinto en cada ola.

- Última actualización: 2026-11-05 (ronda 5 b: **S1 cerrado, F1 anexado al real**, latencias base con 0 errores)
- Proyecto: `C:\Users\jbard\Documents\AntiGravity\Autohotkeys\`
- Archivo objetivo: `XPPEN AHK VERSION ESTABLE.ahk` en `C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\` (**4.038 líneas** por `ReadAllLines`, ya con F1). El canónico de `Documents\AntiGravity\Autohotkeys` (3.917) queda como referencia histórica (T4 en firme).
- Fase: estética AHK, sin segundo proceso. C#/overlays quedan para después.
- Convive con `AGENTS.md` (reglas generales del proyecto). Este documento **no lo
  sustituye**: añade el detalle de la fase estética.

---

## 0. Punto de partida verificado (2026-11-05, no re-verificar)

| Comprobación | Resultado |
|---|---|
| Archivo objetivo | `XPPEN AHK VERSION ESTABLE.ahk` (Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\) |
| Líneas del `.ahk` (ReadAllLines) | **4.038** · SHA-256 `DC012821F6767BEB1F55D2FD2CAC42B853A14B3DBEF269C7FB7A355F1A2FEED5` |
| F1 (`_Tema()` y familia) | **anexado** l.3.960-4.038 (`; === F1-BEGIN ===` … `F1-END`). Backup `XPPEN AHK VERSION ESTABLE.ahk.bak-ola1-20261105-002400`. Fue **append al final**: ninguna línea previa cambió, así que **todas las anclas de §2 siguen valiendo**. Antes: 3.959 · `6375B86D…3A7D`. El bloque anexado son funciones sin llamadas → 0 cambios visuales. |
| Guardas del anexo | 0 líneas originales alteradas (comparación línea a línea con el backup) · `/validate` exit 0 · el intento inicial rechazó el archivo (pedía 4.040 porque el `.txt` arrastraba 2 líneas en blanco) y **el rollback restauró el hash viejo solo**; la guarda buena es «el bloque F1 íntegro al final», no un número. |
| **Efecto de editar el real** | `CheckReload()` detecta el cambio de fecha y **recarga el companion en ~2 s** (medido 2026-11-05: el PID 17336 murió y nacieron 22380 `AutoHotkeyUX` + 12532 `AutoHotkey64`, una sola instancia). Cada ola que edite el ESTABLE corta la sesión de dibujo: **las ediciones se programan entre sesiones, no dentro**. La puerta de pantalla de Josue es para esto, no solo por el parpadeo. |
| `_EstabEmitir` | l.2909 · `pausa := ESTAB_RITMO`; `ESTAB_RACHA := 10` (l.29), `ESTAB_RITMO := 18` (l.30) |
| Huella `.Show()` del arnés | **29 string / 2 vacías / 3 posicionales** (el canónico de 3.917 daba 31) |
| `/validate` | **exit 0** |
| Latencias base (spike v4, N=10, `--ejecutar`, 2026-11-05) | `ActualizarEstabGUI` **1,009 / 1,710 / 1,710** (forzada, 0 errores) · `MostrarHUD` **8,565 / 21,015 / 21,015** (0 errores) · `MostrarMiniTexto` **65,717 / 83,405 / 83,405** (**0 errores**, antes 6 `Invalid option.`). stderr vacío, sin diálogos, producción intacta. |
| I13-b con dato real | El repintado forzado del panel de estabilización cuesta ~1 ms → el techo de 35 ms por componente va sobrado. |
| Instancias AHK | **una sola** del companion (PID 17336, arrancado 04/11 23:35:15). Los otros 8 procesos son utilidades ajenas (`Mouse.ahk`, `_AHK_AutoManager.ahk`, `Download videos.ahk`, `PureRef_layout.ahk`, `python_ahk_v2.ahk`; estos tres últimos dobles). No había nada que cerrar. |
| Prueba de carga | **PASS** sobre ESTABLE+F1 recalibrado: `-Modo esteril` terminó limpio en 2,2 s, stderr 0 bytes, 0 huérfanos |
| `theme.ini` | **dos copias**: `Documents\AntiGravity\Autohotkeys\theme.ini` (la original) y, desde 2026-11-05, `ClipStudioPaint _ Autohotkeys\theme.ini` **junto al ESTABLE**, que es donde `_Tema()` lo busca (`A_ScriptDir`). SHA-256 idéntico en las dos: `19bf8517…012d66`. Inerte hasta que una ola llame a `_Tema()`. |
| Carpeta `iconos\` | **no existe** |
| `_IconosB64()` | vacío (`return Map()`) |
| Import keys del `.ini` con puntos (`surface.off`) | **leídas correctamente** por `IniRead` |
| Dial | muerto: `IniciarDialGUI() => 0` (l.2230 del ESTABLE) |
| Arnés `pruebas.ps1` | **probado**: `parse` PASS · `esteril` PASS con huella 29/2/3 (recalibrado 2026-11-04; respaldo `pruebas.ps1.bak-ronda4-20261104-232447`) |

Cualquier desviación de esta tabla en un chat nuevo = el archivo cambió desde
entonces: **parar y avisar** antes de editar.

---

## 1. Invariantes (no negociables)

| # | Regla |
|---|---|
| I1 | **Zero-rewrite.** Solo se tocan las líneas exactas del bloque indicado. Prohibido reescribir el archivo con `write`; usar `edit` con anclas únicas. |
| I2 | **Respaldo antes de guardar**, una vez por ola: `<archivo>.bak-olaN-YYYYMMDD-HHmmss`. Nunca sobrescribir un `.bak` anterior. |
| I3 | **Validar siempre**: `& "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" /validate "<archivo>.ahk"` → **exit 0**. Sin excepciones. |
| I4 | **Prueba de carga** además del validate (ver §5): exit 0 y sin salida en stderr. |
| I5 | **No tocar** (nunca, en ninguna ola): detección de HWND de paneles de CSP, zonas de hover, `LoopColorV` / `LoopColorCC` / `ChequearZona*`, `WS_EX_TRANSPARENT` (`+0x20`), `WS_EX_NOACTIVATE` (`+E0x08000000`), click-through, `BlockInput`, `_EstabEmitir` (l.2909 en el ESTABLE) y sus constantes de timing. |
| I6 | **No tocar los `#HotIf`** ni reordenar hotkeys. |
| I7 | **Presupuesto por ola**: línea inicial (por `ReadAllLines`, anotada en el CHANGELOG) ±100. Si una ola sale del rango, detenerse y justificarlo. Ola 1: base 3.959; **F1 anexado deja 4.038** (+79, dentro del presupuesto; los 4.040 que figuraban eran 2 líneas en blanco de sobra del `.txt`). |
| I12 | `_FadeAlpha` (l.563) y sus 6 llamadas (en `_SetColorV/_SetColorCC/_SetAR`) no se tocan. El animador nuevo solo opera sobre GUIs propias; nunca recibe el HWND de un panel de CSP. |
| I13 | **a)** ruta de hotkey: función estética nueva ≤ +2 ms sobre la mediana de `latencia_base.txt` (con N ≥ 10, mismas condiciones). **b)** repintado de componente en cambio de estado ≤ 35 ms. D4 sigue sin firmar hasta capturas. |
| I8 | **No arreglar bugs colaterales** que la ola no pida (ver §7). Se anotan, no se corrigen. |
| I9 | Si un cambio estético obliga a tocar §I5, **el cambio está mal planteado**. Parar y consultar. |
| I10 | `posiciones_gui.ini` está en **UTF-16**. Ninguna ola estética debe escribirlo. |
| I11 | **La elevación de las líneas 3-6 es intencional y NO se toca.** El driver de la XP-Pen y el cambio de perfiles (CSP ↔ otras apps) la necesitan para funcionar sin errores. El arnés de pruebas la anula **solo en la copia desechable**, nunca en producción. Tampoco quitar `#SingleInstance Force` (línea 2). |

---

## 2. Mapa del código relevante (anclas del ESTABLE, generadas por el spike)

Números de línea **del ESTABLE** (mapa generado sobre los 3.959 pre-F1). El anexo de
F1 es `append` al final (l.3.960-4.038), así que **ninguna de estas anclas se
desplaza**. El mapa anterior apuntaba al canónico de
3.917 y estaba desfasado (+25 a +44 líneas según la zona). `usos` = líneas que citan
el nombre, no llamadas.

```text
Anclas del canonico (linea de definicion | usos totales por nombre)
Lineas: 3959

_FadeAlpha                    def=  563  usos=   7  (hwnd,hasta,pasos := 6,delayMs := 10)
_LimpiarAvisos                def=    0  usos=   0  ()
_LimpiarGUIs                  def= 1542  usos=   4  ()
MostrarHUD                    def= 1610  usos=  69  (texto,colorBarra := "00E5FF",duracion := 1200)
MostrarMiniTexto              def= 1711  usos=  33  (texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")
MostrarBadgeCombo             def= 1564  usos=   5  (comboText,toolText,colorAcento := "00E5FF",duracion := 2200)
MostrarTooltipToggle          def= 1758  usos=   5  (titulo,simbolo,color)
MostrarIconoHerramienta       def= 1663  usos=   3  (tipo,duracion := 700)
MostrarMiniGUI                def= 1738  usos=   1  (texto,colorHex := "222222",duracion := 1200)
_OcultarHUDSi                 def= 1647  usos=   2  (hwnd)
Sanar                         def=    0  usos=   0  ()
IniciarDsGUI                  def= 2247  usos=   3  ()
IniciarCcGUI                  def= 2281  usos=   3  ()
IniciarArGUI                  def= 2328  usos=   3  ()
IniciarHCGUI                  def= 2375  usos=   3  ()
IniciarLockGUI                def= 2422  usos=   3  ()
IniciarFrenteGUI              def= 2469  usos=   3  ()
IniciarEstabBtnGUI            def= 2524  usos=   3  ()
IniciarEstabGUI               def= 2585  usos=   3  ()
ActualizarEstabGUI            def= 2742  usos=   9  (v := -1,forzar := false)
_EstabCalcular                def= 2679  usos=   3  (w,h)
_EstabLayout                  def= 2705  usos=   6  (w,h)
_EstabKnobRegion              def= 2724  usos=   2  ()
_EstabRegion                  def= 2733  usos=   6  (w,h)
_EstabEmitir                  def= 2909  usos=   5  (tecla,n,pausa := ESTAB_RITMO)
_EstabEnviarDelta             def= 2921  usos=   5  (nuevo)
IniciarReloadGUI              def= 3181  usos=   2  ()
IniciarPuntosGUI              def= 3376  usos=   2  ()
_SetIcono                     def= 3910  usos=  17  (ctrl,nombre)
_RutaIcono                    def= 3916  usos=   2  (nombre)
_IconosB64                    def= 3953  usos=   3  ()
_PosGuiIniPath                def= 2061  usos=  31  ()
_AnclaBloquePaneles           def= 2088  usos=   8  ()
AbrirPanelPuntos              def= 3440  usos=   3  ()
_ArrastrarPanelBloque         def= 2109  usos=   8  (hwndClick,lParam,guiObj)
MostrarGUIEnfoque             def= 1926  usos=   2  ()
IniciarDialGUI                def= 2230  usos=   2  ()

Marcas de hallazgos del PLAN (primera linea | apariciones)
-2247 (ancla fija de avisos)        linea= 1576  n=  2
PUNTOS[30]                          linea= 1679  n=  2
ancho HUD fijo 208*AVISO_ESC        linea= 1620  n=  1

```

**Colores hoy hardcodeados** (sustituir por tokens en la ola que corresponda):
`00E5FF` `FF4444` `44DD88` `FF6B00` `12141A` `1a1a1a` `181818` `222222` `EEEEEE`
`1F4D3A` `1A5276` `1E8449` `D92B2B` `B4C0DE` `636D83` `424242` `3A4260` `3A3A45`
`2B2B2B` `FFFFFF` `8E9AA0` `6A6A6A` `B2B2B2`

**Iconos referenciados (14):** `slider_on/off` `circle_on/off` `quick_on/off`
`hist_on/off` `lock_closed/open` `pin_on/off` `calib` `reload_g`.
Carpeta `iconos\` **no existe** y `_IconosB64()` está vacío → hoy los `Picture` se
pintan en blanco.

---

## 3. Limitaciones técnicas aceptadas (por qué se ve "a Windows")

1. `WinSetTransparent` = alpha **uniforme** de toda la ventana → el texto se lava
   junto con el fondo (`ESTAB_ALPHA_H 128` deja el número casi ilegible).
2. `SetWindowRgn` = esquinas **sin antialias** (2680, 2689, 1646). Escalonadas a 1,5×/2×.
3. Los controles `Progress` / `Text` no saben redondear. El knob es un `Text`
   blanco recortado con elipse (2594 + 2680).
4. No hay transiciones: `Show()` / `Hide()` secos en HUD, badge, tooltips.
5. Todo es `Segoe UI bold 9`. Sin jerarquía tipográfica.
6. Emoji como iconos (`🔍 ↻ ⚙ 🎯 🎚 ◢`) → tamaño/baseline inconsistentes, no se tiñen.
7. **Confirmado por la ola 0 (§4.6):** el arco con antialias de DWM **solo aplica a la
   ventana de nivel superior** (3 radios fijos), nunca a un control hijo — los items 2 y 3
   siguen siendo válidos para pills/tracks/knobs.

---

## 4. Decisiones cerradas (no re-discutir)

### 4.1 Formato de tema: **INI**, no JSON
`theme.ini` junto al script. Motivo: AHK v2 tiene `IniRead` nativo y **no** tiene
parser JSON. Cero dependencias, editable a mano, apto para el futuro Centro de Control.

- Ruta: `A_ScriptDir "\theme.ini"`.
- Si el archivo falta o la clave no existe → **valor por defecto hardcodeado**.
  Un tema roto jamás debe dejar la UI sin color. (Invariante de robustez.)
- Colores en formato `RRGGBB` **sin** `#`.
- API: `_Tema(seccion, clave, defecto)` con caché en un `Map` para no leer disco
  en cada repintado.

### 4.2 Capturar primero, afinar después
La ola 1 mapea **1:1 los hex actuales** a tokens. El reajuste de paleta (sustituir
`FFFFFF` por `E8ECF4`, unificar los tres negros) ocurre en la ola 2 **con prueba
visual**. Nunca cambiar valor y mecanismo en el mismo paso.

### 4.3 Tokens (nombres definitivos)

```ini
[color]
surface.base     = 12141A
surface.raised   = 1B1E26
surface.overlay  = 20242E
surface.off      = 424242
surface.on       = 636D83
text.primary     = FFFFFF
text.idle        = B2B2B2      ; captura 1:1 del label OFF
text.muted       = 8E97A8
text.disabled    = 5A6273
accent.info      = 00E5FF
accent.success   = 44DD88
accent.warn      = FF6B00
accent.danger    = FF4444
accent.estab     = 9A7BFF
accent.estabSoft = B4C0DE      ; captura 1:1 de la barra ON
track.off        = 3A3A45
track.pillOff    = 6A6A6A      ; captura 1:1 de la barra OFF

[alpha]
pill = 235
badge = 230
hud = 215
mini = 200
icono = 185

[radius]        ; px lógicos, escalar con _E()
sm = 6
md = 10
lg = 14

[type]
family       = Segoe UI
family.value = Cascadia Mono   ; fallback: Consolas
size.caption = 9
size.body    = 11
size.value   = 13

[motion]        ; ms
fast = 120
base = 180
slow = 240
```

Easing único: **out-cubic** → `t' = 1 - (1-t)^3`.

### 4.4 Iconos: fuente de iconos, no PNG
Sustituir `Picture` + PNG por un control `Text` con fuente de glifos:
`Segoe Fluent Icons` (Win11) con fallback a `Segoe MDL2 Assets` (Win10).
Monocromo, se tiñe con el color del texto, escala sin assets, elimina el bug de
los cuadros blancos y hace innecesario `_IconosB64()`.

- **El mapa de glifos se elige visualmente en la ola 2**, renderizando una rejilla
  de candidatos. No fijar códigos a ciegas aquí.
- Candidatos de partida (verificar): `E713` settings · `E9E9` slider · `E790` color ·
  `E81C` history · `E72E` lock · `E785` unlock · `E718` pin · `E77A` unpin ·
  `E71D` quick access · `E8AB` switch.

### 4.5 Nombres nuevos reservados
`_Tema()` · `_RepintarPill()` · `PillDef()` · `PillCrear()` · `PillEstado()` ·
`_Animar()` · `_AnimTick()` · `_Glifo()` · `_DwmRedondear()` · `_DwmFondo()`
`_TemaValido()` · `_TemaFuente()` · `_FuenteInstalada()` · `_RolDeHex()` · `_AvisoColor()` · `_LimpiarAvisos()` (F3)
No usar estos nombres para otra cosa.

### 4.6 Ola 0 cerrada: lo que DWM da en este PC (medido 2026-11-05)

| Pregunta | Respuesta medida |
|---|---|
| ¿Redondea las ventanas sin caption? | **Sí por defecto** (attr 33 leído = 2). Con `33=1` salen escuadradas → el atributo manda. |
| Radios disponibles | **Solo 3**: recto · `33=3` ROUNDSMALL ≈ **7-8 px** · `33=2` ROUND ≈ **11-13 px**. No hay radio a elección. |
| ¿El alfa rompe el arco? | **No.** Con `WinSetTransparent` a 235/128/40 el atributo sigue en 2 y la roja al 50 % conserva el arco (fondo hasta d2, color desde d3). **El fade de `_FadeAlpha` no hay que hornearlo.** |
| `SetLayeredWindowAttributes` a mano | **Falla** sobre una Gui de AHK con `WS_EX_LAYERED` (rc=0, `gle=87`). Usar `WinSetTransparent` (pone él el ex-style: `0x88 → 0x80088`). |
| Backdrop acrylic (attr 38) | Se pone y **persiste** (leído 3 tras 1 s). **Sin la hoja de vidrio no se ve**; con ella el centro pasa de `26,26,46` a `237,237,255`. |
| D4 `PrintWindow` | `pw=1`, **nunca negro**, en las 11 ventanas (layered incluidas). **No reproduce el arco** y **ignora el alfa** (alfa 40 se captura sólido). El backdrop solo entra con `flags=2`. |
| ¿Arco por **control**? | **No.** El `Text` hijo rechaza el atributo (`0x80070006 ERROR_INVALID_HANDLE`) y su esquina pinta hasta d0. **Pills/tracks/knobs necesitan GDI+/Region o ser ventanas propias.** |
| Coste (I13) | Crear+mostrar+atributos: **15-63 ms por ventana** (una vez, en arranque). `WinSetTransparent`: **0,0 ms por paso**. I13-a (≤2 ms) **no aplica a crear ventanas**, solo a repintar. |

Consecuencias para las olas: la **4** y la **5** heredan el arco gratis (y durante el fade);
la **2** arrastra la decisión abierta de si una pill es un control (GDI+ obligatorio) o una
ventana (arco gratis, pero +N ventanas); `[radius] sm/md/lg` **no es implementable** como
tokens de sistema — solo tiene sentido para recortes propios. `+Border` dibuja 1 px gris en
la esquina: para paneles redondeados conviene `-Border`.

---

## 5. Protocolo de cierre de ola (Definition of Done)

1. `.bak` creado **antes** de la primera edición: `XxxPPEN_...ahk.bak-olaN-<fecha>`.
2. Ediciones con `edit` (anclas únicas). Nunca `write` sobre el `.ahk`.
3. **Validar y probar con el arnés, nunca a mano:**
   ```powershell
   cd docs\ESTETICA
   .\pruebas.ps1 -Modo parse       # /validate sobre el real: 0 ventanas, 0 UAC, 0.1 s
   .\pruebas.ps1 -Modo esteril     # copia desechable: sin UAC, hotkeys suspendidos,
                                   # GUIs ocultas, errores a stderr, watchdog, ~1 s
   ```
   Requisito: `RESULTADO: PASS` en ambos. El arnés ya comprueba exit code, stderr,
   huérfanos y que el archivo real quede intacto (hash).

   **Nunca** lanzar el `.ahk` real para "probar que arranca": pide UAC por diseño
   (§I11), registra hotkeys y puede dejar procesos elevados huérfanos imposibles de
   cerrar sin admin. El arnés existe exactamente para evitar eso.

   **Modo `carga`** (GUIs visibles, sin UAC): solo si estás dispuesto a que
   parpadeen ~1 s. Para pruebas de input real con el lápiz: `-Modo carga` **no** basta,
   hay que ejecutar el script real y eso es una prueba manual deliberada, nunca
   durante el flujo de dibujo.
4. Conteo de líneas dentro de §I7. Reportar `antes → después`.
5. 5 líneas en `CHANGELOG.md` (qué cambió, qué probar, cómo revertir).
6. Marcar la ola como `hecho` en la tabla de §6.

**Revertir:** `Copy-Item "<archivo>.bak-olaN-<fecha>" "<archivo>" -Force`
(una ola = un `.bak`, así se puede volver a la ola anterior sin perder las demás).

---

## 6. Índice de olas

| Ola | Objetivo | Toca | Riesgo | Estado |
|---|---|---|---|---|
| **0** | Spike DWM: ¿esquinas AA / backdrop funcionan en este Windows? | nada del script | nulo | **`HECHO 2026-11-05`** — ver §4.6 y `ClipStudioPaint _ Autohotkeys\rd3\ola0-dwm\OLA0-RESULTADO.md` |
| **1** | `theme.ini` + cargador `_Tema()` + tokens **solo** en las 7 botoneras (colores, sin estructura) | 2205-2530 | bajo | `pendiente` |
| **2** | Componente `Pill*` único + fuente de iconos + reajuste de paleta | 2205-2530 + 3139/3334 | medio | `pendiente` |
| **3** | Animador no bloqueante + entrada/salida de HUD/badge + `_FadeAlpha` sin `Sleep` | 539, 1528-1755 | bajo-medio | `pendiente` |
| **4** | Slider: knob AA, track redondeado, dígitos tabulares, interpolación de valor | 2544-2727 | medio | `pendiente` |
| **5** | HUD/badge unificados + posición calculada (mata `x := -2247`) | 1528-1755 | bajo | `pendiente` |

Dependencias: **0 → 1 → 2** en serie. **0 está cerrada (§4.6)**, así que la serie arranca
en la 1. 3 puede ir en paralelo a 2 (bloques
distintos) pero **no** en el mismo chat. 4 depende de 0 (para el redondeo: **resuelto, DWM
lo da gratis y el alfa no lo rompe**) y de 3
(para el animador). 5 depende de 3.

**Paralelismo:** solo artefactos independientes (`theme.ini`, mapa de glifos,
documentación). Nunca dos chats editando el `.ahk` a la vez.

> Los rangos de la columna **Toca** son líneas del canónico (3.917). Para editar,
> anclar siempre por nombre de función y leer la numeración real en §2.

---

## 7. Deuda conocida — NO tocar salvo que la ola lo pida

| Bug | Línea | Ola que lo cubre |
|---|---|---|
| `x := -2247, y := 30` hardcodeado en HUD/badge → fuera de pantalla en otro monitor | 1540-1541, 1582-1583 | 5 |
| `MostrarBadgeCombo` no limpia `floatGui.badge` al ocultar (fuga) | 1568-1573 | 5 |
| Carrera de timers en `_OcultarHUDSi` (no revalida `A_TickCount`) | 1611-1614 | 5 |
| `_FadeAlpha` con `Sleep` en rutas de input (posible micro-tirón) | 539-555 | 3 |
| `_IconosB64()` vacío y `iconos\` inexistente → `Picture` en blanco | 3911, 3874 | 2 |
| Falta `global PUNTOS` en `_PtsDefecto` | ~3693 | — (fuera de alcance) |
| Falta `global HIST_ALTO` en `_PtsAltoChange` | ~3649 | — (fuera de alcance) |
| `Ctrl+G` con ruta `C:\Users\JOSUE\...` hardcodeada | ~119 | — (fuera de alcance) |
| Dial muerto: `IniciarDialGUI() => 0` | 2188 (canónico) / 2230 (ESTABLE) | — |
| `_LimpiarGUIs()` llamada desde `MostrarMiniTexto` y `MostrarTooltipToggle` apaga `enfoque.activo` y los marcos | l.1712, l.1759 | 3 (se crea `_LimpiarAvisos`) |
| `MostrarMiniTexto`/`MostrarBadgeCombo`: si una excepción salta entre `Gui()` y la asignación a `floatGui`, la GUI queda huérfana | l.1711-1760 | — (anotado, I8) |

---

## 8. Reglas de edición (para el chat ejecutor)

- Antes de editar: `grep` del bloque y `read` con `offset`/`limit`. **No leer las
  4.038 líneas completas** salvo en la ola 2.
- Un `edit` por unidad lógica (una botonera, una función). Validar al terminar el
  bloque, no al terminar la ola, si la ola tiene más de 5 ediciones.
- Si un `edit` falla por ancla ambigua: **ampliar el ancla**, nunca usar
  `replaceAll` en este archivo (los bloques clonados lo hacen catastrófico).
- Prohibido `Set-Content` / `Out-File` sobre el `.ahk` (rompe el encoding).
- Al reportar: `líneas antes → después`, `validate: exit 0`, y qué probar a mano.

---

## 9. Arnés de pruebas (no invasivo)

`docs/ESTETICA/pruebas.ps1` — **única forma autorizada de ejecutar el script**.
Existe porque el script pide elevación en las líneas 3-6 y crea ~10 GUIs en el
auto-ejecutable: lanzarlo "para ver si arranca" interrumpe el dibujo.

| Modo | Qué hace | UAC | Ventanas | Duración |
|---|---|---|---|---|
| `parse` | `/validate` sobre el **real** | no | 0 | ~0.1 s |
| `esteril` | copia en `%TEMP%` con elevación anulada, `Suspend(1)`, todas las GUIs ocultas, errores a stderr | **no** | 0 | ~1 s |
| `carga` | igual, pero con GUIs visibles (parpadean) | no | ~10 | ~1 s |
| `info` | diagnóstico de procesos AutoHotkey vivos / huérfanos / elevados | no | 0 | instantáneo |

Garantías del arnés:
- **Nunca** modifica el `.ahk` real (verifica el SHA-256 antes y después).
- **Verifica la huella estructural** del script (`.Show()`: 29 string + 2 vacías +
  3 posicionales en el ESTABLE; 31/2/3 en el canónico). Si cambia, **se niega a
  ejecutar** en vez de corromper la copia.
- **Watchdog**: mata el proceso si excede `-TimeoutSeg` (default 30).
- **Detección de huérfanos**: compara PIDs antes/después y avisa con el comando
  `Stop-Process` exacto.
- Encoding preservado: lee y escribe UTF-8 **sin BOM** vía .NET
  (`Get-Content` de PowerShell 5.1 corrompe los emojis).

### 9.1 Elevación: intencional en producción, anulada en pruebas

Las líneas 3-6 (`Run('*RunAs ...')` + `ExitApp()`) **existen por una razón**:
el driver XP-Pen necesita privilegios para cambiar de perfil entre CSP y otras
apps sin fallar. **No es un bug y no se elimina.** Ver §I11.

El coste de esa decisión es que el script de producción corre elevado, y eso tiene
tres consecuencias operativas:

1. **No se puede ejecutar "para probar".** Cada arranque pide UAC e interrumpe el
   dibujo. Para eso está el arnés: la copia desechable corre **sin elevación**
   (basta para validar sintaxis, construcción de GUIs, lectura de config y DllCalls
   de pintado; lo único que no cubre es `BlockInput`, que solo actúa en hotkeys).
2. **Los procesos elevados no se pueden inspeccionar ni cerrar sin admin.** El
   2026-11-04 había 3 procesos elevados del 2-nov vivos, uno con 2,5 h de CPU.
   `-Modo info` los marca como "línea de comandos ilegible".
3. **No hay conflicto entre producción y prueba**, aunque ambas sean elevadas:
   `#SingleInstance Force` empareja por **nombre de archivo**, y la copia se llama
   `prueba_esteril.ahk`. Verificado empíricamente: el PID de producción sobrevivió
   a varias corridas del arnés.

**Nunca matar procesos AHK a ciegas.** `Stop-Process -Name AutoHotkey64` cerraría
también la producción. Confirmar PID por PID con el usuario.

**Nota para la fase de producto:** un shell C# sin elevar no puede hablar por named
pipe con un motor elevado (UIPI / integridad). Ese día habrá que decidir entre
elevar también el shell o partir el motor en dos procesos. No es problema ahora.

### 9.3 Qué necesita elevación y qué no

**Las pruebas NO necesitan admin.** Verificado empíricamente: `-Modo esteril` y
`-Modo parse` pasan con shell estándar (`JOSUE\jbard`, sin elevar), stderr vacío.

| Tarea | ¿Admin? |
|---|---|
| `/validate` (parse) | **no** |
| Copia estéril: construir GUIs, `DllCall` de pintado (`SetWindowRgn`, `SetWindowPos`, `UpdateLayeredWindow`, `DwmSetWindowAttribute`), leer/escribir INI, enumerar monitores | **no** |
| Leer `theme.ini` / `posiciones_gui.ini` | **no** |
| `BlockInput` (solo dentro de acciones de hotkey) | sí — **nunca se ejercita en pruebas** |
| Inyectar teclas en un CSP elevado (UIPI) | sí — **no se prueba nunca; es manual** |
| Ejecutar el script real para dibujar (olas 3-4) | sí — **lo hace el usuario**, ya es su flujo normal |
| Inspeccionar o cerrar procesos AHK elevados huérfanos | sí — limpieza opcional del usuario |

**Regla:** el agente nunca debe pedir ni recibir un shell elevado. Trabaja sobre
archivos del proyecto (permisos normales) y valida con el arnés sin privilegios.
Elevar el shell del agente solo añadiría riesgo (archivos con dueño equivocado,
ediciones sin control de UAC) sin desbloquear nada del camino crítico.

### 9.2 Lo que el arnés NO puede probar

Nada que requiera el lápiz o CSP real: hover, fade de paneles, inyección de
teclas, timing del estabilizador, `BlockInput`. Eso sigue siendo prueba manual
deliberada, con el usuario mirando, nunca en medio del flujo de dibujo.

**Máquina virtual: no hace falta para esta fase.** El arnés cubre el 80 % de lo que
interrumpe (UAC, ventanas, hotkeys, huérfanos, MsgBox de error). Una VM no tendría
ni CSP ni drivers de la XP-Pen, así que no aportaría nada para lo estético; se
justifica más adelante para instalar/desinstalar/antivirus en fase de producto.

---

# SECCION 2 - OLA 0 cerrada: resultado medido

`OLA0-RESULTADO.md` verbatim - 130 lineas - 9290 bytes - sha256 `52476FB85F428020B0D14369140C444DE5C8F00A432BC0B6FE42AF005044D8DE`

# OLA 0 — spike DWM: resultado medido (2026-11-05, AHK 2.0.26, Windows 11 build 26200)

Ninguna línea del ESTABLE se tocó. El ESTABLE sigue en 4.038 líneas /
`DC012821F6767BEB1F55D2FD2CAC42B853A14B3DBEF269C7FB7A355F1A2FEED5`.

El probe son 11 ventanas que se autodestruyen (`NoActivate`, no roban el foco), con
veredicto por **pixeles de pantalla** (`foto.ps1`) y por **PrintWindow** (`pw.ps1`).

## Respuesta corta

| Pregunta | Veredicto | Evidencia |
|---|---|---|
| ¿DWM redondea las ventanas **sin caption**? | **Sí, por defecto.** `corner.antes = 0` y al leerlo da `2` (ROUND). Con `33=1` (DONOTROUND) la ventana sale **escuadra**: la esquina llega hasta d1 y d0 es el borde gris. El atributo manda. | 8-rojo-donotround |
| ¿Qué radio real da? | **ROUND ≈ 11-13 px**, **ROUNDSMALL ≈ 7-8 px**, DONOTROUND = recto. **Solo hay 3 opciones**, no hay radio a elección. | ajuste `r=(dx+dy)+√(2·dx·dy)` sobre las filas 1,2,4 |
| ¿El **alfa** rompe el redondeo? | **No.** Con `WinSetTransparent` (235, 128 y 40) el atributo sigue en `2` tras 1 s y en la ventana roja al 50 % el arco se ve igual: fondo hasta d2, rojo desde d3. **El fade de `_FadeAlpha` no necesita hornear nada.** | 5, 6, 7 |
| ¿`SetLayeredWindowAttributes` a mano? | **Falla** sobre una Gui de AHK que ya trae `WS_EX_LAYERED`: devuelve 0 con `gle=87` (ERROR_INVALID_PARAMETER). `WinSetTransparent` sí funciona y pone el ex-style él solo (`0x88 → 0x80088`). | 4 vs 5/6/7 |
| ¿Backdrop del sistema (acrylic)? | **Se pone y persiste**: `38=3` → lectura `3` tras 1 s. **Pero no se ve sin la hoja de vidrio** (`DwmExtendFrameIntoClientArea` con márgenes −1): el centro pasa de `26,26,46` a `237,237,255`. | 3 |
| **D4** — ¿`PrintWindow` devuelve negro? | **No, nunca.** `pw=1` y pinta contenido en las 11 ventanas, incluidas layered y alfa. **Dos limites**: (a) **no reproduce el arco** (siempre sale escuadrada), (b) **ignora el alfa**: la 6 con alfa 40 se captura sólida `26,26,46` y la 7 al 128 sale `255,0,0`. Con `flags=2` (RENDERFULLCONTENT) **sí entra el backdrop**; con `flags=0` el acrylic sale oscuro. | pw.ps1 |
| ¿Se puede redondear **un control** (pill/slider)? | **No.** `DwmSetWindowAttribute` sobre el hwnd de un `Text` hijo contesta **-2147024890 = 0x80070006 (ERROR_INVALID_HANDLE)** y el pixel de su esquina está rojo hasta d0. **DWM solo recorta ventanas de nivel superior.** | 11 |
| Coste por ventana (I13) | Crear+mostrar+atributos+lecturas: **15-63 ms** (una vez, en el arranque). `WinSetTransparent`: **0,0 ms por paso** (un primer paso de 15 ms que no se repite). Lectura/escritura de atributos DWM: dentro del rango anterior. | `t=` en cada línea |

## Lo que esto cambia en el plan

1. **Ola 4 (slider) y ola 5 (HUD/badge): el redondeo de la ventana es gratis.** No hace
   falta GDI+ ni `SetWindowRgn` para la silueta del panel, **tampoco durante el fade**.
2. **Pills, tracks y knobs NO son ventanas**: son controles hijo, y DWM los rechaza. Si se
   quieren esquinas en una pill, el coste es GDI+/Region por control (lo que ya hace
   `galeria.ahk` l.388-438) **o** convertir la pill en su propia ventana `SysMetadataToolTip`
   /`Gui` sin caption (que sí hereda el arco, pero son N ventanas más en el arranque).
   Decisión pendiente para Claude.
3. **`[radius] sm=6 md=10 lg=14` no es implementable como está.** DWM ofrece ~7 px y
   ~12 px y nada intermedio. Los tokens de radio solo significan algo para el recorte
   propio (GDI+), no para lo que entrega el sistema.
4. **+Border interfiere con el arco en la esquina**: el pixel d0 de la ventana escuadrada es
   `100,100,100` (el borde), no el color de la ventana. Para paneles redondeados conviene
   `-Border` y dejar que el arco haga de borde.
5. **La evidencia visual del parpadeo tiene que ser captura de pantalla, no PrintWindow**:
   PrintWindow ignora el alfa y el arco, así que un PNG de PrintWindow **miente** sobre el
   estado de un panel a media opacidad.

## Números crudos

Pixeles de pantalla, diagonal desde el vértice del frame (`<VENT` = coincide con el centro
de la propia ventana, `<FONDO` = coincide con el escritorio 24 px fuera):

```
2-sin-caption      d0=(24,26,25) d1=(24,26,25) d2=(51,56,82) d3=(26,26,46)<VENT  -> redondeada, d=3
3-acrylic          d0=(24,26,25) d1=(24,26,25) d2=(51,52,52) d3=(237,237,255)<VENT -> acrylic visible y redondeada
4-layered          d0=(24,26,25) d1=(24,26,25) d2=(51,52,52) d3=(26,26,46)<VENT  -> layered + arco
5-transp-235       d0=(32,34,32)<FONDO d1=<FONDO d2=(54,55,54) d3=(26,27,45)<VENT -> alfa 235 + arco
6-transp-40        señal 12 por canal contra el fondo: INDETERMINADA por pixeles
                    (atributo si: corner=2 tras 1 s, ex=0x80088)
7-rojo-128         d0=(21,23,22)<FONDO d1=<FONDO d2=(36,37,37) d3=(140,12,12)<VENT
                    radio: fila1 dx=8 r=13 | fila2 dx=5 r=11,5 | fila4 dx=3 r=11,9
8-rojo-DONOTROUND  d0=(100,100,100) d1=(255,0,0)<VENT -> ESCUADRA (control del metodo, funciona)
9-rojo-ROUNDSMALL  d0=<FONDO d1=(61,61,60) d2=(255,0,0)<VENT   radio: fila1 dx=4 r=7,8 | fila2 dx=2 r=6,8
10-rojo-ROUND      d0,d1=(23,25,24) d2=(50,52,51) d3=(255,0,0)<VENT  radio: 13 / 11,5 / 11,9
11-hijo-text       d0=(255,0,0)<VENT en todas las filas -> CUADRADA, atributo rechazado
```

PrintWindow (`pw.ps1`, C# `System.Drawing`, flags 0 y 2):

```
2-sin-caption   f0 pw=1 esq=[100,100,100 26,26,46 …] centro=26,26,46
2-sin-caption   f2 pw=1 esq=[100,100,100 26,26,46 …] centro=26,26,46
3-acrylic       f0 centro=26,26,46      <- sin RENDERFULLCONTENT el backdrop NO entra
3-acrylic       f2 centro=237,237,255   <- con flags=2 si
4-layered       f0/f2 pw=1 centro=26,26,46
6-transparente-40  f0/f2 centro=26,26,46  <- alfa 40 capturado SOLIDO
7-rojo-128      f0/f2 centro=255,0,0     <- alfa 128 capturado SOLIDO
```

Atributos por ventana tras 1 s (`corner=33`, `backdrop=38`):

```
post 1: corner=2 backdrop=0     post 7: corner=2 backdrop=0
post 2: corner=2 backdrop=0     post 8: corner=1 backdrop=0   (DONOTROUND pedido)
post 3: corner=2 backdrop=3     post 9: corner=3 backdrop=0   (ROUNDSMALL pedido)
post 4: corner=2 backdrop=0     post 10: corner=2 backdrop=0
post 5: corner=2 backdrop=0     post 11 (hijo): corner=0 backdrop=0
post 6: corner=2 backdrop=0
```

Modo oscuro (`20`) aplicado a las ventanas 1 y 2: `rc=0` en ambas y lectura correcta en 2.
Color de borde (`34`): `rc=0` al escribir pero la **lectura falla** con
`-2147024809 = 0x80070057 (E_INVALIDARG)` → se escribe, no se lee.

## Trampas de AHK encontradas (evitan repetir 2 h de depuración)

- **`MonitorGetCount()`** existe; `MonitorCount()`, `MonitorGetDpi(1)` como se escribieron,
  `MonitorFromPoint` y `MonitorFromWindow` **no**. Una llamada a función inexistente **no**
  salta por stderr: abre un **dialogo modal** (Help / Edit / Reload / Continue) y la corrida
  parece colgada. `chk.ps1` lo detecta con `MainWindowTitle`.
- **Salidas por referencia en AHK v2: `"int*", &v`.** Con `"int*", v` la llamada devuelve
  `0` (éxito) y **lee 0 siempre**. El bloque `A/B/C` del probe es el control que lo prueba:
  B) sin `&` → leido=0; con `&` en la misma ventana → leido=2.
- **Un `Buffer` se pasa por su dirección**: `"ptr", buf`. `"ptr", &buf` da
  `This value of type VarRef has no property named Ptr`.
- **`GdiplusStartupInput` son 24 bytes** en x64 (`uint` version al offset 0); con 20 da rc=2.
- **Los identificadores de AHK no distinguen mayúsculas**: una local `png` dentro de
  `Captura()` chocaba con el global `PNG` y reventaba con *"This local variable has not been
  assigned a value"*; antes, una local `w` chocó con el mapa global `W`
  (*"This value of type Integer has no property named __Item"*). Igual que `REP` vs `Rep()`
  en `spike_latencia.ahk`. **Regla: ninguna local de una función puede llamarse como un
  global, en cualquier mayúscula.**
- **GDI+ no puede guardar imágenes desde el proceso de AHK en este PC**: `GdipSaveImageToFile`
  y `GdipSaveImageToStream` devuelven **10 (OutOfMemory)** y dejan un PNG de 0 bytes en las 4
  variantes probadas (CLSID fijado a mano, `CLSIDFromString`, imagen de `GdipCreateBitmapFromScan0`,
  stream). Diagnóstico completo en `cap_micro.txt` / `run_micro.ps1`. **Por eso la evidencia PNG
  sale de PowerShell** (`pw.ps1` + `Ola0.cs`), no del propio probe.

## Cómo reproducir

```
cd "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\ola0-dwm"
powershell -NoProfile -ExecutionPolicy Bypass -File chk.ps1 -Hasta 0      # validate: exit 0
powershell -NoProfile -ExecutionPolicy Bypass -File foto.ps1 -Monitor 1 -Seg 24   # pixeles + radios
powershell -NoProfile -ExecutionPolicy Bypass -File pw.ps1   -Monitor 1 -Seg 22   # PrintWindow
```

`probe_dwm.txt` / `cap_micro.txt` son `.txt` a propósito: **no debe quedar ningún `.ahk`
ejecutable en esta carpeta** (se doble-clic). El staging se hace en `%TEMP%\ola0_run\`.
`--monitor=2` sigue el pedido pero **hoy el PC solo tiene 1 monitor detectado**
(`monitores : 1   pedido=2`); el probe cae a 1 solo.

## Estado de la ola 0

**CERRADA con números.** Queda una decisión de diseño para Claude (punto 2 de arriba:
pills como controles con GDI+ vs pills como ventanas con arco gratis), y la consecuencia
de que `[radius]` no es configurable. El resto del plan no cambia.


---

## SECCION 3 - theme.ini tal como esta en el disco

`theme.ini` - 55 lineas - sha256 `19BF85178F6F7C0BD31BE5BF439A05F3A1A1814783AB1DA58A774A032F012D66`

```ini
; theme.ini — tokens de diseño (refactor estético)
; Formato: RRGGBB sin '#'. Valores = captura 1:1 de lo que ya pinta el script.
; La afinación de paleta ocurre en la ola 2, con prueba visual.
; Si este archivo falta, el script usa los valores por defecto del código.

[color]
surface.base     = 12141A
surface.raised   = 1B1E26
surface.overlay  = 20242E
surface.off      = 424242
surface.on       = 636D83
text.primary     = FFFFFF
text.idle        = B2B2B2
text.muted       = 8E97A8
text.disabled    = 5A6273
accent.info      = 00E5FF
accent.success   = 44DD88
accent.warn      = FF6B00
accent.danger    = FF4444
accent.estab     = 9A7BFF
accent.estabSoft = B4C0DE
track.off        = 3A3A45
track.pillOff    = 6A6A6A

[alpha]
pill  = 235
badge = 230
hud   = 215
mini  = 200
icono = 185

[radius]
sm = 6
md = 10
lg = 14

[type]
family       = Segoe UI
family.value = Cascadia Mono
size.caption = 9
size.body    = 11
size.value   = 13

[motion]
fast = 120
base = 180
slow = 240
easing = out-cubic

[fx]
; 0 = region (actual) | 1 = DWM corner | 2 = DWM corner + backdrop
; Decidido en la ola 0.
corners  = 0
backdrop = 0
```


---

## SECCION 4 - F1: el bloque `_Tema()` YA APLICADO al real (l.3960-4038)

`f1_tema.txt` - 81 lineas - sha256 `80C118393C16CCBBBCC42C5B79B5030B153D849970EDDA9F2EBE8D833D135B43`

```ahk
; === F1-BEGIN ===
; F1: tema. Sin globales (lo posterior al primer #HotIf no ejecuta asignaciones globales).
_Tema(seccion,clave,defecto := "") {
    static cache := Map(), iniTema := A_ScriptDir "\theme.ini"
    k := seccion "|" clave
    if cache.Has(k)
        return cache[k]
    v := defecto
    try {
        leido := Trim(IniRead(iniTema,seccion,clave,""))
        if (leido != "" && _TemaValido(seccion,leido,defecto))
            v := (seccion = "color") ? StrUpper(leido) : leido
    }
    cache[k] := v
    return v
}
_TemaValido(seccion,v,defecto) {
    if (seccion = "color")
        return RegExMatch(v,"^[0-9A-Fa-f]{6}$") > 0
    if IsInteger(defecto)
        return IsInteger(v) && Integer(v) >= 0 && Integer(v) <= (seccion = "alpha" ? 255 : 4096)
    return !RegExMatch(v,"[\x3B\r\n]")
}
_FuenteInstalada(nombre) {
    static cache := Map()
    if cache.Has(nombre)
        return cache[nombre]
    hallada := false
    for raiz in ["HKLM","HKCU"] {
        if hallada
            break
        try {
            Loop Reg raiz "\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts","V" {
                if (InStr(A_LoopRegName,nombre) = 1) {
                    hallada := true
                    break
                }
            }
        }
    }
    cache[nombre] := hallada
    return hallada
}
_TemaFuente(rol := "texto") {
    if (rol = "iconos")
        cadena := ["Segoe Fluent Icons","Segoe MDL2 Assets"]
    else if (rol = "valor")
        cadena := [_Tema("type","family.value","Cascadia Mono"),"Consolas","Segoe UI"]
    else
        cadena := [_Tema("type","family","Segoe UI"),"Segoe UI"]
    for nombre in cadena {
        if _FuenteInstalada(nombre)
            return nombre
    }
    return "Segoe UI"
}
_RolDeHex(hex) {
    static m := Map(
        "00E5FF","info","1C6EA4","info","1A5276","info","1A2E5C","info",
        "44DD88","ok","1E8449","ok","27AE60","ok","51D67B","ok",
        "1A5C2A","ok","32CD32","ok","2ECC71","ok","FF6B00","warn",
        "FF8C42","warn","AA8844","warn","FFAA33","warn","FF6F61","warn",
        "FF4444","danger","C0392B","danger","E74C3C","danger","922B21","danger",
        "9A7BFF","estab","AA44FF","estab","6C3483","estab","1A1A2E","neutral",
        "888888","neutral","555555","neutral","9AA7C7","neutral","2B3B32","neutral",
        "222222","neutral","EEEEEE","neutral","424949","neutral"
    )
    h := StrUpper(hex)
    return m.Has(h) ? m[h] : ""
}
; Identidad hasta que theme.ini tenga [fx] roles = 1. Los "neutral" nunca se mapean (EEEEEE es fondo claro).
_AvisoColor(hex) {
    if (_Tema("fx","roles","0") != "1")
        return hex
    rol := _RolDeHex(hex)
    tokens := Map("info","accent.info","ok","accent.success","warn","accent.warn","danger","accent.danger","estab","accent.estab")
    return (rol != "" && tokens.Has(rol)) ? _Tema("color",tokens[rol],hex) : hex
}
; === F1-END ===
```


---

## SECCION 5 - censo mecanico de literales de color (generado por `censo.py` sobre el real)

Ola 1 = sustituir **solo** los del rango 2247-2584 (las 7 botoneras: `IniciarDsGUI`
a `IniciarEstabBtnGUI`, cada una con su `Actualizar*GUI` dentro). Son **51**.
El resto del archivo (263 en total, 65 funciones) entra en olas posteriores.

```text
== rango 2247-2584 ==  51 literales unicos
  l.2249  citado     #424242 "424242"         dsGui.g.BackColor := "424242"
  l.2268  texto c    #B4C0DE cB4C0DE          dsGui.barra.Opt("cB4C0DE")
  l.2269  citado     #636D83 "636D83"         dsGui.g.BackColor := "636D83"
  l.2270  texto c    #FFFFFF cFFFFFF          dsGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
  l.2274  texto c    #6A6A6A c6A6A6A          dsGui.barra.Opt("c6A6A6A")
  l.2275  citado     #424242 "424242"         dsGui.g.BackColor := "424242"
  l.2276  texto c    #B2B2B2 cB2B2B2          dsGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
  l.2283  citado     #424242 "424242"         ccGui.g.BackColor := "424242"
  l.2315  texto c    #B4C0DE cB4C0DE          ccGui.barra.Opt("cB4C0DE")
  l.2316  citado     #636D83 "636D83"         ccGui.g.BackColor := "636D83"
  l.2317  texto c    #FFFFFF cFFFFFF          ccGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
  l.2321  texto c    #6A6A6A c6A6A6A          ccGui.barra.Opt("c6A6A6A")
  l.2322  citado     #424242 "424242"         ccGui.g.BackColor := "424242"
  l.2323  texto c    #B2B2B2 cB2B2B2          ccGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
  l.2330  citado     #424242 "424242"         arGui.g.BackColor := "424242"
  l.2362  texto c    #B4C0DE cB4C0DE          arGui.barra.Opt("cB4C0DE")
  l.2363  citado     #636D83 "636D83"         arGui.g.BackColor := "636D83"
  l.2364  texto c    #FFFFFF cFFFFFF          arGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
  l.2368  texto c    #6A6A6A c6A6A6A          arGui.barra.Opt("c6A6A6A")
  l.2369  citado     #424242 "424242"         arGui.g.BackColor := "424242"
  l.2370  texto c    #B2B2B2 cB2B2B2          arGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
  l.2377  citado     #424242 "424242"         hcGui.g.BackColor := "424242"
  l.2409  texto c    #B4C0DE cB4C0DE          hcGui.barra.Opt("cB4C0DE")
  l.2410  citado     #636D83 "636D83"         hcGui.g.BackColor := "636D83"
  l.2411  texto c    #FFFFFF cFFFFFF          hcGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
  l.2415  texto c    #6A6A6A c6A6A6A          hcGui.barra.Opt("c6A6A6A")
  l.2416  citado     #424242 "424242"         hcGui.g.BackColor := "424242"
  l.2417  texto c    #B2B2B2 cB2B2B2          hcGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
  l.2426  citado     #424242 "424242"         lockGui.g.BackColor := "424242"
  l.2455  texto c    #6A6A6A c6A6A6A          lockGui.barra.Opt("c6A6A6A")
  l.2456  citado     #424242 "424242"         lockGui.g.BackColor := "424242"
  l.2459  texto c    #B4C0DE cB4C0DE          lockGui.barra.Opt("cB4C0DE")
  l.2460  citado     #636D83 "636D83"         lockGui.g.BackColor := "636D83"
  l.2466  citado     #2B2B2B "2B2B2B"         try estabGui.g.BackColor := panelBlk.locked ? "2B2B2B" : "3A4260"
  l.2466  citado     #3A4260 "3A4260"         try estabGui.g.BackColor := panelBlk.locked ? "2B2B2B" : "3A4260"
  l.2473  citado     #424242 "424242"         frenteGui.g.BackColor := "424242"
  l.2504  texto c    #B4C0DE cB4C0DE          frenteGui.barra.Opt("cB4C0DE")
  l.2505  citado     #636D83 "636D83"         frenteGui.g.BackColor := "636D83"
  l.2508  texto c    #6A6A6A c6A6A6A          frenteGui.barra.Opt("c6A6A6A")
  l.2509  citado     #424242 "424242"         frenteGui.g.BackColor := "424242"
  l.2522  citado     #44DD88 "44DD88"         MostrarHUD(panelBlk.frente ? "📌 GUI AL FRENTE" : "📌 GUI SOLO EN CSP",panelBlk.frente ? "44
  l.2522  citado     #FF6B00 "FF6B00"         MostrarHUD(panelBlk.frente ? "📌 GUI AL FRENTE" : "📌 GUI SOLO EN CSP",panelBlk.frente ? "44
  l.2526  citado     #424242 "424242"         estabBtnGui.g.BackColor := "424242"
  l.2560  texto c    #B4C0DE cB4C0DE          estabBtnGui.barra.Opt("cB4C0DE")
  l.2561  citado     #636D83 "636D83"         estabBtnGui.g.BackColor := "636D83"
  l.2562  texto c    #FFFFFF cFFFFFF          estabBtnGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
  l.2566  texto c    #6A6A6A c6A6A6A          estabBtnGui.barra.Opt("c6A6A6A")
  l.2567  citado     #424242 "424242"         estabBtnGui.g.BackColor := "424242"
  l.2568  texto c    #B2B2B2 cB2B2B2          estabBtnGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
  l.2583  citado     #44DD88 "44DD88"         MostrarHUD(estabGui.visible ? "🎚 DESLIZADOR VISIBLE" : "🎚 DESLIZADOR OCULTO",estabGui.visi
  l.2583  citado     #FF6B00 "FF6B00"         MostrarHUD(estabGui.visible ? "🎚 DESLIZADOR VISIBLE" : "🎚 DESLIZADOR OCULTO",estabGui.visi

conteo por hex: {'424242': 14, 'B4C0DE': 7, '636D83': 7, 'FFFFFF': 5, '6A6A6A': 7, 'B2B2B2': 5, '2B2B2B': 1, '3A4260': 1, '44DD88': 2, 'FF6B00': 2}
conteo por patron: {'citado': 27, 'texto c': 24}

== TODO el archivo: funciones con literales de color ==
  _RolDeHex                     31   ej. l.4018 #00E5FF
  _DeshacerRehacer              25   ej. l.294 #00E5FF
  _CicloO                       18   ej. l.750 #1A5276
  _EnviarOpacidad               14   ej. l.867 #00E5FF
  ActualizarDsGUI                8   ej. l.2268 #B4C0DE
  ActualizarCcGUI                8   ej. l.2315 #B4C0DE
  ActualizarArGUI                8   ej. l.2362 #B4C0DE
  ActualizarHCGUI                8   ej. l.2409 #B4C0DE
  ActualizarLockGUI              8   ej. l.2455 #6A6A6A
  ActualizarEstabBtnGUI          8   ej. l.2560 #B4C0DE
  ActualizarFrenteGUI            6   ej. l.2504 #B4C0DE
  MostrarZonasCalibracion        6   ej. l.3889 #2ECC71
  _InvSeleccionConGUI            5   ej. l.205 #FF6F61
  _ToggleLayerVis                5   ej. l.536 #FF4444
  IniciarEstabGUI                5   ej. l.2628 #2B2B2B
  AlternarEstabilizacion         4   ej. l.1499 #1A5C2A
  MostrarBadgeCombo              4   ej. l.1564 #00E5FF
  MostrarTooltipToggle           4   ej. l.1763 #1F4D3A
  MostrarGUIEnfoque              4   ej. l.1938 #0077B6
  _PtsDibujarZonaEstab           4   ej. l.3583 #0B0B14
  (autoejecutable/global)        3   ej. l.31 #9A7BFF
  __AltS_SEND_NORMAL             3   ej. l.698 #00E5FF
  IniciarDeteccion               3   ej. l.1142 #44AA66
  __Q_SEND_NORMAL                3   ej. l.1473 #51D67B
  MostrarHUD                     3   ej. l.1610 #00E5FF
  MostrarToolTipZ                3   ej. l.1705 #00E5FF
  _MostrarPaneles                3   ej. l.2039 #FF6B00
  _EstabAplicarValor             3   ej. l.3125 #FF4444
  _ToggleHistorialColor          2   ej. l.176 #44DD88
  __AltX_SEND_NORMAL             2   ej. l.672 #FF8C42
  MostrarIconoHerramienta        2   ej. l.1671 #181818
  MostrarMiniTexto               2   ej. l.1711 #222222
  _OcultarMiniTipSi              2   ej. l.1737 #EEEEEE
  MostrarMiniGUI                 2   ej. l.1738 #222222
  _CapturarLayout                2   ej. l.1921 #44DD88
  _ToggleBloqueo                 2   ej. l.2206 #44DD88
  ActualizarDialGUI              2   ej. l.2238 #00E5FF
  IniciarDsGUI                   2   ej. l.2249 #424242
  IniciarCcGUI                   2   ej. l.2283 #424242
  IniciarArGUI                   2   ej. l.2330 #424242
  IniciarHCGUI                   2   ej. l.2377 #424242
  IniciarLockGUI                 2   ej. l.2426 #424242
  IniciarFrenteGUI               2   ej. l.2473 #424242
  _ToggleFrente                  2   ej. l.2522 #44DD88
  IniciarEstabBtnGUI             2   ej. l.2526 #424242
  _ToggleEstabVisible            2   ej. l.2583 #44DD88
  _EstabGUI_WM_LBUTTONDOWN       2   ej. l.3085 #9A7BFF
  IniciarReloadGUI               2   ej. l.3183 #3B7A4B
  ElegirPerfil                   2   ej. l.3320 #9AA7C7
  IniciarPuntosGUI               2   ej. l.3379 #424242
  _MaskRButton                   1   ej. l.244 #00E5FF
  _ToggleHoverPaneles            1   ej. l.656 #FF6B00
  LoopColorV                     1   ej. l.1272 #44AA66
  LoopColorCC                    1   ej. l.1349 #AA6622
  LoopAccesoRapido               1   ej. l.1424 #AA8844
  _CheckGitDone                  1   ej. l.1529 #44DD88
  MostrarIndicador               1   ej. l.1662 #FF4444
  AccionEnfoque                  1   ej. l.1813 #00E5FF
  _EstabWheelUp                  1   ej. l.2784 #9A7BFF
  _EstabWheelDown                1   ej. l.2788 #9A7BFF
  _EstabAplicarRect              1   ej. l.3007 #9A7BFF
  _EstabGUI_WM_MBUTTONDOWN       1   ej. l.3120 #44DD88
total literales en el archivo: 263
```


---

## SECCION 6 - las 7 botoneras tal como estan (l.2247-2584 del real, con numeracion)

```ahk
 2247  IniciarDsGUI() {
 2248      dsGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
 2249      dsGui.g.BackColor := "424242"
 2250      dsGui.g.MarginX := 0
 2251      dsGui.g.MarginY := 0
 2252      WinSetTransparent(235,dsGui.g)
 2253      dsGui.icono := dsGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20),"")
 2254      dsGui.label := dsGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
 2255      dsGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
 2256      dsGui.barra := dsGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
 2257      OnMessage(0x0201,_DsGUI_WM_LBUTTONDOWN)
 2258      posDs := LeerPosicionGUI("Slider")
 2259      if !(IsObject(posDs) && _PosicionValidaEnPantalla(posDs.x,posDs.y))
 2260          posDs := _AnclaBloquePaneles()
 2261      dsGui.g.Show("x" posDs.x " y" posDs.y " w" _E(104) " h" _E(25) " NoActivate")
 2262      ActualizarDsGUI()
 2263  }
 2264  ActualizarDsGUI() {
 2265      if (colorV.hover) {
 2266          _SetIcono(dsGui.icono,"slider_on")
 2267          dsGui.label.Value := "SLIDER ON"
 2268          dsGui.barra.Opt("cB4C0DE")
 2269          dsGui.g.BackColor := "636D83"
 2270          dsGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
 2271      } else {
 2272          _SetIcono(dsGui.icono,"slider_off")
 2273          dsGui.label.Value := "SLIDER OFF"
 2274          dsGui.barra.Opt("c6A6A6A")
 2275          dsGui.g.BackColor := "424242"
 2276          dsGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
 2277      }
 2278      dsGui.barra.Value := 100
 2279  }
 2280  _DsGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,dsGui)
 2281  IniciarCcGUI() {
 2282      ccGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
 2283      ccGui.g.BackColor := "424242"
 2284      ccGui.g.MarginX := 0
 2285      ccGui.g.MarginY := 0
 2286      WinSetTransparent(235,ccGui.g)
 2287      ccGui.icono := ccGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20),"")
 2288      ccGui.label := ccGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
 2289      ccGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
 2290      ccGui.barra := ccGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
 2291      OnMessage(0x0201,_CcGUI_WM_LBUTTONDOWN)
 2292      posCc := LeerPosicionGUI("Circle")
 2293      if (IsObject(posCc) && _PosicionValidaEnPantalla(posCc.x,posCc.y)) {
 2294          ccX := posCc.x
 2295          ccY := posCc.y
 2296      } else {
 2297          try {
 2298              WinGetPos(&dsX,&dsY,&dsW,&dsH,"ahk_id " dsGui.g.Hwnd)
 2299          } catch {
 2300              ancla := _AnclaBloquePaneles()
 2301              dsX := ancla.x
 2302              dsY := ancla.y
 2303              dsW := _E(104)
 2304          }
 2305          ccX := dsX + dsW + PANEL_GAP
 2306          ccY := dsY
 2307      }
 2308      ccGui.g.Show("x" ccX " y" ccY " w" _E(104) " h" _E(25) " NoActivate")
 2309      ActualizarCcGUI()
 2310  }
 2311  ActualizarCcGUI() {
 2312      if (colorCC.hover) {
 2313          _SetIcono(ccGui.icono,"circle_on")
 2314          ccGui.label.Value := "CIRCLE ON"
 2315          ccGui.barra.Opt("cB4C0DE")
 2316          ccGui.g.BackColor := "636D83"
 2317          ccGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
 2318      } else {
 2319          _SetIcono(ccGui.icono,"circle_off")
 2320          ccGui.label.Value := "CIRCLE OFF"
 2321          ccGui.barra.Opt("c6A6A6A")
 2322          ccGui.g.BackColor := "424242"
 2323          ccGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
 2324      }
 2325      ccGui.barra.Value := 100
 2326  }
 2327  _CcGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,ccGui)
 2328  IniciarArGUI() {
 2329      arGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
 2330      arGui.g.BackColor := "424242"
 2331      arGui.g.MarginX := 0
 2332      arGui.g.MarginY := 0
 2333      WinSetTransparent(235,arGui.g)
 2334      arGui.icono := arGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20),"")
 2335      arGui.label := arGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
 2336      arGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
 2337      arGui.barra := arGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
 2338      OnMessage(0x0201,_ArGUI_WM_LBUTTONDOWN)
 2339      posAr := LeerPosicionGUI("Quick")
 2340      if (IsObject(posAr) && _PosicionValidaEnPantalla(posAr.x,posAr.y)) {
 2341          arX := posAr.x
 2342          arY := posAr.y
 2343      } else {
 2344          try {
 2345              WinGetPos(&ccX,&ccY,&ccW,&ccH,"ahk_id " ccGui.g.Hwnd)
 2346          } catch {
 2347              ancla := _AnclaBloquePaneles()
 2348              ccX := ancla.x + _E(104) + PANEL_GAP
 2349              ccY := ancla.y
 2350              ccW := _E(104)
 2351          }
 2352          arX := ccX + ccW + PANEL_GAP
 2353          arY := ccY
 2354      }
 2355      arGui.g.Show("x" arX " y" arY " w" _E(104) " h" _E(25) " NoActivate")
 2356      ActualizarArGUI()
 2357  }
 2358  ActualizarArGUI() {
 2359      if (ar.hover) {
 2360          _SetIcono(arGui.icono,"quick_on")
 2361          arGui.label.Value := "QUICK ON"
 2362          arGui.barra.Opt("cB4C0DE")
 2363          arGui.g.BackColor := "636D83"
 2364          arGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
 2365      } else {
 2366          _SetIcono(arGui.icono,"quick_off")
 2367          arGui.label.Value := "QUICK OFF"
 2368          arGui.barra.Opt("c6A6A6A")
 2369          arGui.g.BackColor := "424242"
 2370          arGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
 2371      }
 2372      arGui.barra.Value := 100
 2373  }
 2374  _ArGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,arGui)
 2375  IniciarHCGUI() {
 2376      hcGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
 2377      hcGui.g.BackColor := "424242"
 2378      hcGui.g.MarginX := 0
 2379      hcGui.g.MarginY := 0
 2380      WinSetTransparent(235,hcGui.g)
 2381      hcGui.icono := hcGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20),"")
 2382      hcGui.label := hcGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
 2383      hcGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
 2384      hcGui.barra := hcGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
 2385      OnMessage(0x0201,_HCGUI_WM_LBUTTONDOWN)
 2386      posHc := LeerPosicionGUI("HC")
 2387      if (IsObject(posHc) && _PosicionValidaEnPantalla(posHc.x,posHc.y)) {
 2388          x := posHc.x
 2389          y := posHc.y
 2390      } else {
 2391          try {
 2392              WinGetPos(&aX,&aY,,,"ahk_id " dsGui.g.Hwnd)
 2393          } catch {
 2394              ancla := _AnclaBloquePaneles()
 2395              aX := ancla.x
 2396              aY := ancla.y
 2397          }
 2398          off := _HcOffsetBloque()
 2399          x := aX + off.dx
 2400          y := aY + off.dy
 2401      }
 2402      hcGui.g.Show("x" x " y" y " w" _E(104) " h" _E(25) " NoActivate")
 2403      ActualizarHCGUI()
 2404  }
 2405  ActualizarHCGUI() {
 2406      if (hist.modo = 1) {
 2407          _SetIcono(hcGui.icono,"hist_on")
 2408          hcGui.label.Value := "HC ON"
 2409          hcGui.barra.Opt("cB4C0DE")
 2410          hcGui.g.BackColor := "636D83"
 2411          hcGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
 2412      } else {
 2413          _SetIcono(hcGui.icono,"hist_off")
 2414          hcGui.label.Value := "HC OFF"
 2415          hcGui.barra.Opt("c6A6A6A")
 2416          hcGui.g.BackColor := "424242"
 2417          hcGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
 2418      }
 2419      hcGui.barra.Value := 100
 2420  }
 2421  _HCGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,hcGui)
 2422  IniciarLockGUI() {
 2423      global panelBlk
 2424      panelBlk.locked := (IniRead(_PosGuiIniPath(),"PanelBlock","locked","1") = "1")
 2425      lockGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
 2426      lockGui.g.BackColor := "424242"
 2427      lockGui.g.MarginX := 0
 2428      lockGui.g.MarginY := 0
 2429      WinSetTransparent(235,lockGui.g)
 2430      lockGui.icono := lockGui.g.Add("Picture","x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19),"")
 2431      lockGui.barra := lockGui.g.Add("Progress","x0 y" _E(22) " w" _E(31) " h" _E(3))
 2432      OnMessage(0x0201,_LockGUI_WM_LBUTTONDOWN)
 2433      posLock := LeerPosicionGUI("Lock")
 2434      if (IsObject(posLock) && _PosicionValidaEnPantalla(posLock.x,posLock.y)) {
 2435          lockX := posLock.x
 2436          lockY := posLock.y
 2437      } else {
 2438          try {
 2439              WinGetPos(&arX,&arY,&arW,&arH,"ahk_id " arGui.g.Hwnd)
 2440          } catch {
 2441              ancla := _AnclaBloquePaneles()
 2442              arX := ancla.x + 2 * (_E(104) + PANEL_GAP)
 2443              arY := ancla.y
 2444              arW := _E(104)
 2445          }
 2446          lockX := arX + arW + PANEL_GAP
 2447          lockY := arY
 2448      }
 2449      lockGui.g.Show("x" lockX " y" lockY " w" _E(31) " h" _E(25) " NoActivate")
 2450      ActualizarLockGUI()
 2451  }
 2452  ActualizarLockGUI() {
 2453      if (panelBlk.locked) {
 2454          _SetIcono(lockGui.icono,"lock_closed")
 2455          lockGui.barra.Opt("c6A6A6A")
 2456          lockGui.g.BackColor := "424242"
 2457      } else {
 2458          _SetIcono(lockGui.icono,"lock_open")
 2459          lockGui.barra.Opt("cB4C0DE")
 2460          lockGui.g.BackColor := "636D83"
 2461      }
 2462      lockGui.barra.Value := 100
 2463      if IsObject(estabGui.grip)
 2464          estabGui.grip.Visible := !panelBlk.locked
 2465      if IsObject(estabGui.g)
 2466          try estabGui.g.BackColor := panelBlk.locked ? "2B2B2B" : "3A4260"
 2467  }
 2468  _LockGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,lockGui)
 2469  IniciarFrenteGUI() {
 2470      global panelBlk
 2471      panelBlk.frente := (IniRead(_PosGuiIniPath(),"PanelBlock","frente","0") = "1")
 2472      frenteGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
 2473      frenteGui.g.BackColor := "424242"
 2474      frenteGui.g.MarginX := 0
 2475      frenteGui.g.MarginY := 0
 2476      WinSetTransparent(235,frenteGui.g)
 2477      frenteGui.icono := frenteGui.g.Add("Picture","x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19),"")
 2478      frenteGui.barra := frenteGui.g.Add("Progress","x0 y" _E(22) " w" _E(31) " h" _E(3))
 2479      OnMessage(0x0201,_FrenteGUI_WM_LBUTTONDOWN)
 2480      posF := LeerPosicionGUI("Frente")
 2481      if (IsObject(posF) && _PosicionValidaEnPantalla(posF.x,posF.y)) {
 2482          fX := posF.x
 2483          fY := posF.y
 2484      } else {
 2485          try {
 2486              WinGetPos(&lX,&lY,&lW,&lH,"ahk_id " lockGui.g.Hwnd)
 2487          } catch {
 2488              ancla := _AnclaBloquePaneles()
 2489              lX := ancla.x + 3 * (_E(104) + PANEL_GAP)
 2490              lY := ancla.y
 2491              lW := _E(31)
 2492          }
 2493          fX := lX + lW + PANEL_GAP
 2494          fY := lY
 2495      }
 2496      frenteGui.g.Show("x" fX " y" fY " w" _E(31) " h" _E(25) " NoActivate")
 2497      ActualizarFrenteGUI()
 2498  }
 2499  ActualizarFrenteGUI() {
 2500      if !IsObject(frenteGui.icono)
 2501          return
 2502      if panelBlk.frente {
 2503          _SetIcono(frenteGui.icono,"pin_on")
 2504          frenteGui.barra.Opt("cB4C0DE")
 2505          frenteGui.g.BackColor := "636D83"
 2506      } else {
 2507          _SetIcono(frenteGui.icono,"pin_off")
 2508          frenteGui.barra.Opt("c6A6A6A")
 2509          frenteGui.g.BackColor := "424242"
 2510      }
 2511      frenteGui.barra.Value := 100
 2512  }
 2513  _FrenteGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,frenteGui)
 2514  _ToggleFrente() {
 2515      panelBlk.frente := !panelBlk.frente
 2516      IniWrite(panelBlk.frente ? 1 : 0,_PosGuiIniPath(),"PanelBlock","frente")
 2517      ActualizarFrenteGUI()
 2518      if panelBlk.frente {
 2519          _MostrarPaneles()
 2520          _TraerPanelesAlFrente()
 2521      }
 2522      MostrarHUD(panelBlk.frente ? "📌 GUI AL FRENTE" : "📌 GUI SOLO EN CSP",panelBlk.frente ? "44DD88" : "FF6B00",1200)
 2523  }
 2524  IniciarEstabBtnGUI() {
 2525      estabBtnGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
 2526      estabBtnGui.g.BackColor := "424242"
 2527      estabBtnGui.g.MarginX := 0
 2528      estabBtnGui.g.MarginY := 0
 2529      WinSetTransparent(235,estabBtnGui.g)
 2530      estabBtnGui.icono := estabBtnGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20),"")
 2531      estabBtnGui.label := estabBtnGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
 2532      estabBtnGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
 2533      estabBtnGui.barra := estabBtnGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
 2534      OnMessage(0x0201,_EstabBtnGUI_WM_LBUTTONDOWN)
 2535      posB := LeerPosicionGUI("EstabBtn")
 2536      if (IsObject(posB) && _PosicionValidaEnPantalla(posB.x,posB.y)) {
 2537          eX := posB.x
 2538          eY := posB.y
 2539      } else {
 2540          try {
 2541              WinGetPos(&fX,&fY,&fW,&fH,"ahk_id " frenteGui.g.Hwnd)
 2542          } catch {
 2543              ancla := _AnclaBloquePaneles()
 2544              fX := ancla.x + 3 * (_E(104) + PANEL_GAP) + _E(31) + PANEL_GAP
 2545              fY := ancla.y
 2546              fW := _E(31)
 2547          }
 2548          eX := fX + fW + PANEL_GAP
 2549          eY := fY
 2550      }
 2551      estabBtnGui.g.Show("x" eX " y" eY " w" _E(104) " h" _E(25) " NoActivate")
 2552      ActualizarEstabBtnGUI()
 2553  }
 2554  ActualizarEstabBtnGUI() {
 2555      if !IsObject(estabBtnGui.g) || !IsObject(estabBtnGui.label)
 2556          return
 2557      if estabGui.visible {
 2558          _SetIcono(estabBtnGui.icono,"slider_on")
 2559          estabBtnGui.label.Value := "ESTAB ON"
 2560          estabBtnGui.barra.Opt("cB4C0DE")
 2561          estabBtnGui.g.BackColor := "636D83"
 2562          estabBtnGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
 2563      } else {
 2564          _SetIcono(estabBtnGui.icono,"slider_off")
 2565          estabBtnGui.label.Value := "ESTAB OFF"
 2566          estabBtnGui.barra.Opt("c6A6A6A")
 2567          estabBtnGui.g.BackColor := "424242"
 2568          estabBtnGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
 2569      }
 2570      estabBtnGui.barra.Value := 100
 2571  }
 2572  _EstabBtnGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,estabBtnGui)
 2573  _ToggleEstabVisible() {
 2574      global PERFIL
 2575      estabGui.visible := !estabGui.visible
 2576      IniWrite(estabGui.visible ? 1 : 0,_PosGuiIniPath(),"Estab_p" PERFIL,"visible")
 2577      if estabGui.visible {
 2578          _AplicarEstabVisibilidadBase()
 2579          ActualizarEstabGUI()
 2580      } else if (IsObject(estabGui.g) && !estabGui.foco)
 2581          estabGui.g.Hide()
 2582      ActualizarEstabBtnGUI()
 2583      MostrarHUD(estabGui.visible ? "🎚 DESLIZADOR VISIBLE" : "🎚 DESLIZADOR OCULTO",estabGui.visible ? "44DD88" : "FF6B00",1100)
 2584  }
```


---

## MANIFIESTO (sha256 de lo que se uso para armar este paquete)

| archivo | lineas | bytes | sha256 |
|---|---|---|---|
| CONTEXTO.md | 426 | 26145 | `CC60FB1313708AA0B708B5AC02750F2293162DF5C579FD330A51E18195E602E5` |
| OLA0-RESULTADO.md | 131 | 9290 | `52476FB85F428020B0D14369140C444DE5C8F00A432BC0B6FE42AF005044D8DE` |
| censo_color.txt | 121 | 8449 | `3AD11BCA04309B838D2819C93AB987CE884F5DBE4A92D2DFA0C540EAF1A8640A` |
| theme.ini | 55 | 1127 | `19BF85178F6F7C0BD31BE5BF439A05F3A1A1814783AB1DA58A774A032F012D66` |
| f1_tema.txt (bloque F1 aplicado) | 81 | 2877 | `80C118393C16CCBBBCC42C5B79B5030B153D849970EDDA9F2EBE8D833D135B43` |
| probe_dwm.txt (spike ola 0) | 377 | 16709 | `17D6DE508558514AA2F3B1430551F91D7288A4FD76C18E918BCD08A65D072B04` |
| XPPEN AHK VERSION ESTABLE.ahk (real, sin tocar) | 4039 | 134187 | `DC012821F6767BEB1F55D2FD2CAC42B853A14B3DBEF269C7FB7A355F1A2FEED5` |
