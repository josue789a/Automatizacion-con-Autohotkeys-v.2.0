# RESPUESTA RONDA 4 — Josue/Qoder -> Claude 3

Generado 2026-11-04 23:40, desde la maquina de Josue. **Todo el contenido va pegado en este
archivo**: no hace falta ningun adjunto para responder. Si algo no esta aqui, es que no existe.

Arbol de referencia confirmado (tu T4 en firme): **ESTABLE**, 3.959 lineas leidas por
`ReadAllLines`, SHA-256 medido:

- ESTABLE  `6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D`
- canonico `CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E`

Indice de lo que ContestA a tu seccion 6, en tu orden:

| # | Pediste | Estado |
|---|---|---|
| 1 | Salida del comando de tu 2 (las 2 lineas `.Show("...")`) | resuelto, S1 |
| 2 | `-Modo esteril` sobre el ESTABLE con F1 | **PASS**, S2 |
| 3 | Extractos + `Fin()` + lectura de `A_Args` | pegados, S4 |
| 4 | Corrida del paso 4 con huellas | **hecha**, con tabla y 4 hallazgos, S3 |

---

## S1 — Las 2 lineas `.Show("...")` que solo estan en el canonico

Comando ejecutado (tu formula, sobre los dos arboles):

```powershell
Select-String -Path $can,$est -Pattern '\.Show\("'   # + Compare-Object de lineas trimadas
```

Resultado literal:

```text
canonical .Show(" count = 31
estable   .Show(" count = 29

=== SOLO EN CANONICO ===
  estabGui.g.Show("NoActivate")
  estabGui.g.Show("NoActivate")
=== SOLO EN ESTABLE ===
  (ninguna)
```

Ambas son la **misma cadena**, y las dos son del slider, no de avisos ni botoneras. Identificadas
una a una en el canonico:

**a) canonico l.2537 — dentro del toggle de visibilidad del slider.** En el ESTABLE ese bloque se
reescribio para llamar a `_AplicarEstabVisibilidadBase()` (ESTABLE l.1792-1800), que si contiene un
`.Show("NoActivate")` (esa es una de las 29). El diff real:

```text
@@ -2532,9 +2574,8 @@
     estabGui.visible := !estabGui.visible
     IniWrite(estabGui.visible ? 1 : 0,_PosGuiIniPath(),"Estab_p" PERFIL,"visible")
-    if (estabGui.visible && enfoque.activo) {
-        if (IsObject(estabGui.g) && !DllCall("IsWindowVisible","Ptr",estabGui.g.Hwnd))
-            estabGui.g.Show("NoActivate")
+    if estabGui.visible {
+        _AplicarEstabVisibilidadBase()
         ActualizarEstabGUI()
     } else if (IsObject(estabGui.g) && !estabGui.foco)
         estabGui.g.Hide()
```

**b) canonico l.2824 — dentro de `_EstabFocoOcultar()`.** El branch `Show` se elimino y queda solo
el `Hide`:

```text
@@ -2820,9 +2867,7 @@
-    if (enfoque.activo && estabGui.visible)
-        estabGui.g.Show("NoActivate")
-    else
+    if (!enfoque.activo || !estabGui.visible)
         estabGui.g.Hide()
```

Las dos caen en el caso que tu regla autoriza: **codigo reescrito del bloque `rectNormal`/foco**,
no una GUI que el arnes deba ocultar. Verificacion adicional que hice antes de tocar nada: las 3
`.Show("NoActivate")` que quedan en el ESTABLE (l.1796, l.2851, l.2998) cubren los tres caminos por
los que el slider puede volver a verse, y el regex del arnes (`.Show("` -> `.Show("Hide " "`) sigue
aplicandose a las 29. Ninguna GUI escapa a la ocultacion.

Debt funcional anotada (no la toco, I8): en (b) el slider **deja de reaparecer** al salir del foco
si `enfoque.activo && estabGui.visible`; antes se re-mostraba. Es un cambio de conducta del ESTABLE
respecto al canonico, no un error del arnes.

### Recalibracion aplicada

`docs/ESTETICA/pruebas.ps1`, respaldo `pruebas.ps1.bak-ronda4-20261104-232447`. Estado actual:

```powershell
  202| # 3) Ocultar TODAS las GUIs (solo modo estéril).
  203| #    Solo se tocan las llamadas Gui.Show cuyo primer argumento es un string.
  204| #    NO se tocan:
  205| #      - .Show(wx,wy,ww,wh)  -> método propio de la clase de bordes (posiciona, no muestra)
  206| #      - .Show()             -> se tratan aparte, después
  207| if ($Modo -eq 'esteril') {
  208|     $cQuoted = [regex]::Matches($txt, '\.Show\("').Count
  209|     $cEmpty  = [regex]::Matches($txt, '\.Show\(\)').Count
  210|     $cPosic  = [regex]::Matches($txt, '\.Show\([^"\)]').Count
  211| 
  212|     # Huella estructural: si el script cambia, el arnés se niega a ejecutar.
  213|     # 29 y no 31: el árbol de referencia es el ESTABLE (3.958). Las 2 llamadas
  214|     # .Show("NoActivate") de menos son las de XxxPPEN..._secondary.ahk:2537 y :2824,
  215|     # ambas del slider y ambas reescritas (van a _AplicarEstabVisibilidadBase /
  216|     # al branch Hide de _EstabFocoOcultar). Ninguna es de aviso ni de botonera.
  217|     if ($cQuoted -ne 29 -or $cEmpty -ne 2 -or $cPosic -ne 3) {
  218|         $problemas += ("huella .Show() inesperada: string=$cQuoted vacías=$cEmpty posicionales=$cPosic (esperado 29/2/3)")
  219|     } else {
  220|         Ok "huella .Show() verificada: 29 string + 2 vacías + 3 posicionales (intactas)"
  221|     }
  222| 
```

Consecuencia que debes saber: con 29/2/3 el arnes **rechaza el canonico de 3.917**. Es coherente
con T4 (el canonico ya no es la fuente de verdad), pero si alguien apunta `-Raiz` al arbol viejo,
verá un FAIL de huella y no un problema de sintaxis.

---

## S2 — `-Modo esteril` sobre el ESTABLE con el bloque F1: PASS

Escenario: copia del ESTABLE + F1 pegado al final, en `%TEMP%\ronda4_arnes\` (sin espacios, y el
arnes exige el nombre `XxxPPEN_a16pg2_displayAS_secondary.ahk`). El ESTABLE real nunca se toca;
se comprueba su hash antes y despues.

- `lineas    : 4040   (ESTABLE solo = 3959)` — tu presupuesto I7 por ola: inicio 3.959, F1 4.040, +81.
- `sha256` del escenario: `894B4634027FEA278E3353AA544EFD4FCB661BFE243F8BC1A5E2E5AE8BCEC9AB`

Volcado literal de `rd3/ronda4-arnes.log`:

```text
escenario : C:\Users\jbard\AppData\Local\Temp\ronda4_arnes\XxxPPEN_a16pg2_displayAS_secondary.ahk
lineas    : 4040   (ESTABLE solo = 3959)
sha256    : 894B4634027FEA278E3353AA544EFD4FCB661BFE243F8BC1A5E2E5AE8BCEC9AB
config     : posiciones_gui.ini <- C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys
config     : theme.ini <- C:\Users\jbard\Documents\AntiGravity\Autohotkeys

===== pruebas.ps1 -Modo parse  (ESTABLE + F1) =====

== Modo: parse ==
  [--]   script : C:\Users\jbard\AppData\Local\Temp\ronda4_arnes\XxxPPEN_a16pg2_displayAS_secondary.ahk
  [--]   líneas : 4041
  [--]   sha256 : 894B4634027FEA27...

== validate (sin ejecutar el script) ==
  [OK]   exit 0 en 0.13s
  [OK]   archivo intacto

RESULTADO: PASS

===== pruebas.ps1 -Modo esteril (ESTABLE + F1) =====

== Modo: esteril ==
  [--]   script : C:\Users\jbard\AppData\Local\Temp\ronda4_arnes\XxxPPEN_a16pg2_displayAS_secondary.ahk
  [--]   líneas : 4041
  [--]   sha256 : 894B4634027FEA27...

== Construyendo copia desechable ==
  [OK]   elevación desactivada (sin UAC)
  [OK]   hotkeys suspendidos
  [OK]   huella .Show() verificada: 29 string + 2 vacías + 3 posicionales (intactas)
  [OK]   GUIs forzadas a ocultas
  [OK]   ExitApp() añadido
  [--]   config copiada: posiciones_gui.ini
  [--]   config copiada: theme.ini

== validate de la copia ==
  [OK]   la copia es sintácticamente válida

== Ejecutando la copia ==
  [OK]   terminó limpio en 2.2s
  [OK]   sin errores de ejecución (stderr vacío)

== Procesos huérfanos ==
  [OK]   ningún proceso residual

== Integridad ==
  [OK]   archivo real intacto

RESULTADO: PASS

ESTABLE intacto : SI   6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D
exit parse=0  esteril=0
```

**Lee esto como el cierre del bloqueo de F1.** La I4 (prueba de carga) era lo unico que impedía
aplicar el bloque: antes fallaba solo por la huella. Con 29/2/3, `parse` y `esteril` dan PASS y la
copia arranca y termina limpia en 2,2 s con stderr vacio. El test funcional de `_Tema` ya habia
salido 14/14 exacto en la ronda 3.

---

## S3 — Paso 4 con huellas: la tabla existe, y el timer SII dispara

Esto responde a la sospecha de tu ronda ("el timer -2500 de la copia nunca dispara"). **Si dispara.**
Los latidos lo prueban y ademas enseñan 4 cosas que no sabiamos.

### Lo que tuve que arreglar para poder correrlo

1. **La plantilla del inyectable tenia un backtick sin doblar** y por eso la copia nunca cargo.
   La fila de `_LatHb` estaba escrita

   ```ahk
   try FileAppend(A_TickCount " | " t "`r`n", "@@HB@@", "UTF-8")     -> /validate exit 2
   ```

   Dentro del literal `c := "` + `( ... )` + `"`, un backtick se interpreta al parsear el spike y
   se convierte en CR/LF real: la copia salia con la instruccion partida en dos lineas. Error de
   carga exacto:

   ```text
   ...\latencia_f0\prueba_latencia.ahk (3966) : ==> Missing """
        Specifically: try FileAppend(A_TickCount " | " t "
   ```

   Correction de 1 caracter, ya aplicada en el spike v3: `"``r``n"`. Regla para el resto del
   proyecto: **dentro de la plantilla del inyectable, todo backtick va doblado** (`_LatMedir` y
   `_LatBase` ya lo hacian; `_LatHb` era la unica que no).

2. **`--prod` no acepta rutas con espacios** (ya lo avise): `A_Args` parte por espacios y
   `ClipStudioPaint _ Autohotkeys` se rompe en 3 argumentos. Se ensaya el archivo en
   `%TEMP%\ronda4_prod\` con hash identico al real.

3. `--forzar` es obligatorio hasta que el spike apunte al ESTABLE: espera 3.917 lineas y el hash
   `CEF745C7...`; el arbol de referencia es 3.959 / `6375B86D...`. **No** cambie esas constantes
   sin tu visto bueno.

### Spike v3 (tu copia + T1.1 + huellas + backtick)

`rd3/spike-v3/spike_latencia.ahk` — 377 lineas, SHA-256 `59031CD890F786F63E9B3D872F26BF7B1FD347D203D98B7E979896CD0F1EF126`.
Es exactamente el archivo que subiste en `ENTREGA CLAUDE 2`, con tu parche T1.1 aplicado y las 5
llamadas `_LatHb`. En el zip va como `.txt` para que nadie lo ejecute con doble clic (ver S6).

### Latencias base, ESTABLE, N=5 (corrida 23:37)

```text
Latencias base (ms, QPC, copia esteril)
| Funcion | N | mediana | p95 | max | errores |
|---|---|---|---|---|---|
| ActualizarEstabGUI | 5 | 0.020 | 0.042 | 0.042 | 0  |
| MostrarHUD | 5 | 20.313 | 98.171 | 98.171 | 0  |
| MostrarMiniTexto | 5 | 73.130 | 74.780 | 74.780 | 6 Invalid option. |

Criterio I13: cada funcion estetica nueva debe sumar <= ~2 ms sobre estas medianas.
```

Latidos de la copia (`A_TickCount | etapa`):

```text
217941015 | autoexec: Suspend + timer registrados
217943531 | _LatBase entro (timer disparado)
217943531 | empieza ActualizarEstabGUI
217943843 | empieza MostrarHUD
217944281 | empieza MostrarMiniTexto
217944781 | salida escrita
```

Y la verificacion de integridad de esa misma corrida: `Produccion intacta: SI`,
`ESTABLE real intacto: SI`, stderr de la copia **vacio**.

### Los 4 hallazgos, en orden de importancia para ti

**(1) `ActualizarEstabGUI = 0,020 ms` es el guard, no el redibujado.** La llamada armada es
`ActualizarEstabGUI()` con `v = -1, forzar = false`, y ESTABLE l.2748 corta antes de dibujar:

```text
 2747|     sig := estabGui.ancho "x" estabGui.alto "x" estabGui.horiz
 2748|     if (!forzar && v = estabGui.dibV && sig = estabGui.dibG)
 2749|         return
```

Es la razon exacta por la que tu I13-b (nuevo metodo <= 2 ms sobre la base) **no se puede decidir
con este numero**. La base del slider hay que medirla forzando el dibujo (`ActualizarEstabGUI(25,true)`
o alternando `v`), y `ArmarLlamada()` no sabe generar un literal `true`.

**(2) `MostrarMiniTexto` midio 0 llamadas validas: 6 errores `Invalid option.`** Los 6 = warm-up + 5,
o sea todas. Causa: `ArmarLlamada` prueba primero `(txt|texto|text|msg|mensaje)` y despues
`(col|color|hex|clr)`; el parametro `colorTexto` gana el primer patron y recibe `"LAT"`, que acaba
en `g.AddText("c" colorTexto " Center w" ...)` -> opcion de color invalida. Los 73 ms medidos son
el coste de lanzar la excepcion, no la funcion. Fix minimo: invertir el orden de los `if`  (o probar
`^color` antes que `txt`), o anadir una regla explicita `color*` -> hex.

**(3) `MostrarHUD` si es real: mediana 20,3 ms, max 98,2 ms con N=5.** Ojo porque el `Sleep(15)`
entre muestras no evita que se creen y destruyan 6 GUIs; el max de 98 ms es el primer caso o un
pico con recoleccion. Para F2 el numero util es la mediana, y el criterio de 2 ms de I13-a sigue
sin base valida de slider.

**(4) Con N=20 la copia no termino nunca; con N=5 tardo 1,25 s.** Los latidos de la corrida N=20
se detienen en `empieza MostrarMiniTexto` y el watchdog mato el arbol a los 45 s, con stderr
vacio. Con N=5 la misma secuencia cierra con `salida escrita`. La diferencia son 21 GUIs+timers de
`MostrarMiniTexto` en vez de 6; no lo he diagnosticado mas (I8: no toco lo que no me toca).
Sugerencia: N=8 o N=10 como defecto del spike, y no subir de ahi hasta que (2) este arreglado.

---

## S4 — Extractos pedidos, pegados aqui

Origenes: `spike_latencia.ahk` v3 (hash arriba) y `galeria.ahk` de `ENTREGA CLAUDE 2`
(1.030 lineas, SHA `F611A498855E13729FBF4F0D9F9F18B2EDE84DF3E1C6500D4F044766F2A69761`).
Numeracion = linea real del archivo. Nada transcrito a mano.

### `A_Args` — lectura de opciones (l.35-52)

```ahk
   35| HASH_ESPERADO := "CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E"
   36| LINEAS_ESPERADAS := 3917
   37| PROD := A_ScriptDir "\..\..\..\XxxPPEN_a16pg2_displayAS_secondary.ahk"
   38| N := 20
   39| EJECUTAR := false
   40| FORZAR := false
   41| for a in A_Args {
   42|     if (a = "--ejecutar")
   43|         EJECUTAR := true
   44|     else if (a = "--forzar")
   45|         FORZAR := true
   46|     else if (SubStr(a, 1, 7) = "--prod=")
   47|         PROD := SubStr(a, 8)
   48|     else if (SubStr(a, 1, 4) = "--n=")
   49|         N := Max(5, Integer(SubStr(a, 5)))
   50| }
   51| 
   52| REPTXT := ""
```

Aqui es donde tu `ArgsUnidos()` iria INSERT-BEFORE. Reparo que debes saber: en esta version las
constantes `HASH_ESPERADO`/`LINEAS_ESPERADAS` (l.35-36) ya son las reales del canonico, y el bug
`REP`/`Rep` esta resuelto por tu propio T1.1.

### `Fin()` y su entorno (l.188-208)

```ahk
  188| Rep(t) {
  189|     global REPTXT
  190|     REPTXT .= t "`r`n"
  191| }
  192| 
  193| Guardar(nombre) {
  194|     ruta := A_ScriptDir "\" nombre
  195|     try FileDelete(ruta)
  196|     FileAppend(REPTXT, ruta, "UTF-8")
  197| }
  198| 
  199| Fin(msg, cod) {
  200|     MsgBox(msg, "spike_latencia", cod = 0 ? "Iconi" : "Icon!")
  201|     ExitApp(cod)
  202| }
  203| 
  204| Hash(ruta) {
  205|     tmp := A_Temp "\latencia_hash.txt"
  206|     try FileDelete(tmp)
  207|     RunWait(A_ComSpec ' /c certutil -hashfile "' ruta '" SHA256 > "' tmp '"', , "Hide")
  208|     r := ""
```

El `MsgBox` de `Fin()` es lo que bloquea la corrida sin supervision (el proceso queda vivo hasta
que alguien pulsa Aceptar; si ademas lo abre un usuario desde el Explorer, puede quedar elevado e
inmortalizable sin UAC). Mi arnes lo resuelve matando el arbol del spike por PID, pero eso no es
portable: de ahi tu parche `--sinmsg`.

### `Principal()` — generador de la copia (l.89-157)

```ahk
   89|     for i in [3, 4, 5, 6] {
   90|         if (i > lineas.Length)
   91|             Fin("El archivo tiene menos de 6 lineas.", 3)
   92|     }
   93|     if !(RegExMatch(lineas[3], "i)^\s*if\s*(!|not\s+)\s*A_IsAdmin") && Trim(lineas[6]) = "}" && InStr(lineas[4] lineas[5], "RunAs")) {
   94|         v := ""
   95|         Loop Min(10, lineas.Length)
   96|             v .= A_Index ": " lineas[A_Index] "`n"
   97|         Rep("Bloque de elevacion NO reconocido. Primeras lineas:`n" v)
   98|         Guardar("latencia_base.txt")
   99|         Fin("Bloque de elevacion no reconocido en lineas 3-6. No se construye la copia.`nVer latencia_base.txt", 3)
  100|     }
  101|     dir := A_Temp "\latencia_f0"
  102|     DirCreate(dir)
  103|     copia := dir "\prueba_latencia.ahk"
  104|     salida := dir "\salida_latencia.txt"
  105|     errf := dir "\stderr_latencia.txt"
  106|     try FileDelete(salida)
  107|     try FileDelete(errf)
  108| 
  109|     llamadas := Map()
  110|     for nombre in ["MostrarHUD", "MostrarMiniTexto", "ActualizarEstabGUI"] {
  111|         if !anclas.Has(nombre) || anclas[nombre].lin = 0 {
  112|             Rep("AVISO: " nombre " no se encontro en el canonico, no se medira.")
  113|             continue
  114|         }
  115|         llamadas[nombre] := ArmarLlamada(nombre, anclas[nombre].firma)
  116|         Rep(nombre "(" anclas[nombre].firma ")  ->  " llamadas[nombre])
  117|     }
  118| 
  119|     nuevo := []
  120|     for i, l in lineas {
  121|         if (i = 3) {
  122|             nuevo.Push("; [spike_latencia] elevacion anulada SOLO en esta copia (lineas 3-6 originales)")
  123|         } else if (i >= 4 && i <= 6) {
  124|             nuevo.Push("; [spike_latencia] linea " i " original anulada")
  125|             if (i = 6) {
  126|                 nuevo.Push("Suspend(1)")
  127|                 nuevo.Push('_LatHb("autoexec: Suspend + timer registrados")')
  128|                 nuevo.Push("SetTimer(_LatBase, -2500)")
  129|             }
  130|         } else {
  131|             nuevo.Push(l)
  132|         }
  133|     }
  134|     cuerpo := ""
  135|     for l in nuevo
  136|         cuerpo .= l "`r`n"
  137|     cuerpo .= Inyectable(llamadas, N, salida)
  138|     try FileDelete(copia)
  139|     f := FileOpen(copia, "w", "UTF-8")
  140|     f.Write(cuerpo)
  141|     f.Close()
  142|     Rep("Copia desechable: " copia)
  143| 
  144|     ; ---- 4. /validate de la copia ----
  145|     codV := RunWait('"' A_AhkPath '" /validate "' copia '"', , "Hide")
  146|     Rep("/validate de la copia: exit " codV)
  147|     if (codV != 0) {
  148|         Guardar("latencia_base.txt")
  149|         Fin("La copia no pasa /validate (exit " codV "). Ver latencia_base.txt", 4)
  150|     }
  151| 
  152|     if !EJECUTAR {
  153|         Rep("")
  154|         Rep("Modo seco: no se ejecuto la copia. Repite con --ejecutar (las GUIs parpadean ~3 s).")
  155|         Guardar("latencia_base.txt")
  156|         Fin("Pasos 1-4 OK (modo seco). Anclas y resumen en la carpeta del script.", 0)
  157|     }
```

### `Inyectable()` — `_LatHb` / `_LatQPC` / `_LatMedir` / `_LatBase` (l.299-377)

```ahk
  299| }
  300| 
  301| ; ---------------------------------------------------------------------
  302| ; Codigo que se anade al final de la copia (plantilla; ``n = `n en la copia)
  303| ; ---------------------------------------------------------------------
  304| Inyectable(llamadas, n, salida) {
  305|     medir := ""
  306|     for nombre, expr in llamadas
  307|         medir .= '    out .= _LatMedir("' nombre '", () => ' expr ', ' n ')' "`r`n"
  308|     c := "
  309| (
  310| ; ===== inyectado por spike_latencia.ahk (solo en la copia) =====
  311| _LatHb(t) {
  312|     try FileAppend(A_TickCount " | " t "``r``n", "@@HB@@", "UTF-8")
  313| }
  314| _LatQPC() {
  315|     static f := 0
  316|     if !f
  317|         DllCall("kernel32\QueryPerformanceFrequency", "int64*", &f)
  318|     cc := 0
  319|     DllCall("kernel32\QueryPerformanceCounter", "int64*", &cc)
  320|     return cc * 1000 / f
  321| }
  322| _LatMedir(nombre, fn, n) {
  323|     _LatHb("empieza " nombre)
  324|     ts := []
  325|     err := 0
  326|     ult := ""
  327|     try {
  328|         fn.Call()
  329|     } catch as e0 {
  330|         err += 1
  331|         ult := e0.Message
  332|     }
  333|     Loop n {
  334|         t0 := _LatQPC()
  335|         try {
  336|             fn.Call()
  337|         } catch as e1 {
  338|             err += 1
  339|             ult := e1.Message
  340|         }
  341|         ts.Push(_LatQPC() - t0)
  342|         Sleep(15)
  343|     }
  344|     Loop ts.Length - 1 {
  345|         i := A_Index + 1
  346|         v := ts[i]
  347|         j := i - 1
  348|         while (j >= 1 && ts[j] > v) {
  349|             ts[j + 1] := ts[j]
  350|             j -= 1
  351|         }
  352|         ts[j + 1] := v
  353|     }
  354|     m := ts.Length // 2
  355|     med := (Mod(ts.Length, 2) = 0) ? (ts[m] + ts[m + 1]) / 2 : ts[m + 1]
  356|     p95 := ts[Max(1, Ceil(ts.Length * 0.95))]
  357|     return "| " nombre " | " ts.Length " | " Round(med, 3) " | " Round(p95, 3) " | " Round(ts[ts.Length], 3) " | " err " " ult " |``n"
  358| }
  359| _LatBase() {
  360|     _LatHb("_LatBase entro (timer disparado)")
  361|     out := "Latencias base (ms, QPC, copia esteril)``n"
  362|     out .= "| Funcion | N | mediana | p95 | max | errores |``n"
  363|     out .= "|---|---|---|---|---|---|``n"
  364| @@MEDIR@@
  365|     out .= "``nCriterio I13: cada funcion estetica nueva debe sumar <= ~2 ms sobre estas medianas.``n"
  366|     try FileDelete("@@SALIDA@@")
  367|     FileAppend(out, "@@SALIDA@@", "UTF-8")
  368|     _LatHb("salida escrita")
  369|     ExitApp()
  370| }
  371| )"
  372|     c := StrReplace(c, "@@MEDIR@@", RTrim(medir, "`r`n"))
  373|     hb := StrReplace(salida, "salida_latencia.txt", "heartbeat_latencia.txt")
  374|     c := StrReplace(c, "@@SALIDA@@", salida)
  375|     c := StrReplace(c, "@@HB@@", hb)
  376|     return "`r`n" c "`r`n"
  377| }
```

### Lo que pediste de `galeria.ahk` (`_AutoCapturas`, `_Pasar`, `_Ocluyentes`, `_Captura`, `_PosLibre`)

Se perdio como adjunto en la ronda 3; va integro aqui debajo.

### Extractos de la ronda 3 (pedidos 2 y 3)

Generado 2026-11-04 22:46:28. Numeracion = linea real de cada archivo. Nada transcrito a mano.

#### Pedido 2 — galeria.ahk (ENTREGA CLAUDE 2)
Archivo: galeria.ahk · 1030 lineas · SHA f611a498855e13729fbf4f0d9f9f18b2ede84df3e1c6500d4f044766f2a69761

### _AutoCapturas() — l.270-296
```ahk
 270| _AutoCapturas() {
 271|     S.offx := 0
 272|     prim := MonitorGetPrimary()
 273|     otro := (MonitorGetCount() > 1) ? ((prim = 1) ? 2 : 1) : prim
 274|     _Log("=== MODO CAPTURAS | monitor principal " prim " | secundario " otro " ===")
 275|     _Pasar(prim, [0.75, 1.0, 1.5])
 276|     if (otro != prim)
 277|         _Pasar(otro, [1.0, 1.5])
 278|     _Log("=== FIN capturas | errores: " S.errores " ===")
 279|     ExitApp(S.errores ? 1 : 0)
 280| }
 281| 
 282| _Pasar(mon, escalas) {
 283|     S.mon := mon
 284|     for esc in escalas {
 285|         S.esc := esc
 286|         for fi in [1, 3] {
 287|             S.fondoI := fi
 288|             _Reconstruir()
 289|             Sleep(400)
 290|             _Captura()
 291|             Sleep(120)
 292|         }
 293|         if (esc = 1.0) {
 294|             for o in S.wins.Clone() {
 295|                 if (o.kind = "slider")
 296|                     _SetSlider(o, 25)
```

### _Pasar(mon, escalas) — el barrido real, l.282-304
```ahk
 282| _Pasar(mon, escalas) {
 283|     S.mon := mon
 284|     for esc in escalas {
 285|         S.esc := esc
 286|         for fi in [1, 3] {
 287|             S.fondoI := fi
 288|             _Reconstruir()
 289|             Sleep(400)
 290|             _Captura()
 291|             Sleep(120)
 292|         }
 293|         if (esc = 1.0) {
 294|             for o in S.wins.Clone() {
 295|                 if (o.kind = "slider")
 296|                     _SetSlider(o, 25)
 297|                 else
 298|                     _Toggle(o)
 299|             }
 300|             Sleep(200)
 301|         }
 302|     }
 303| }
 304| 
```

### _DescVentana(hw) + _Ocluyentes(x,y,w,h) — l.305-350
```ahk
 305| _DescVentana(hw) {
 306|     if !hw
 307|         return "(ninguna)"
 308|     cls := ""
 309|     exe := ""
 310|     try cls := WinGetClass("ahk_id " hw)
 311|     try exe := WinGetProcessName("ahk_id " hw)
 312|     return exe " [" cls "]"
 313| }
 314| 
 315| ; Ventanas ajenas, visibles y siempre-visibles (topmost) que tapan el rectangulo.
 316| ; Solo las topmost pueden cubrir al stage, que tambien es topmost.
 317| _Ocluyentes(x, y, w, h) {
 318|     res := []
 319|     propios := Map()
 320|     for o in S.wins
 321|         propios[o.hwnd] := 1
 322|     if IsObject(S.stage)
 323|         propios[S.stage.Hwnd] := 1
 324|     for hw in WinGetList() {
 325|         if propios.Has(hw)
 326|             continue
 327|         try {
 328|             if !(WinGetExStyle("ahk_id " hw) & 0x8)
 329|                 continue
 330|             if (WinGetMinMax("ahk_id " hw) = -1)
 331|                 continue
 332|             cls := WinGetClass("ahk_id " hw)
 333|             if (cls = "Shell_TrayWnd" || cls = "Shell_SecondaryTrayWnd")
 334|                 continue
 335|             WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hw)
 336|         } catch {
 337|             continue
 338|         }
 339|         if (wx < x + w && wx + ww > x && wy < y + h && wy + wh > y)
 340|             res.Push(_DescVentana(hw) " " ww "x" wh " en " wx "," wy)
 341|     }
 342|     return res
 343| }
 344| 
 345| _PosLibre(sw, sh, l, t, r, b) {
 346|     cands := []
 347|     if (POS_X != "")
 348|         cands.Push([POS_X, POS_Y])
 349|     cands.Push([l + 10, t + 10], [r - sw - 10, t + 10], [l + 10, b - sh - 10], [r - sw - 10, b - sh - 10], [l + (r - l - sw) // 2, t + (b - t - sh) // 2])
 350|     mejor := cands[1]
```

### _Captura(*) — BitBlt del DC de pantalla + marca _OCLUIDA, l.699-731
```ahk
 699| _Captura(*) {
 700|     if !IsObject(S.stage) || (OCULTO && !CAPTURAS)
 701|         return
 702|     WinGetPos(&x, &y, &w, &h, "ahk_id " S.stage.Hwnd)
 703|     ocl := _Ocluyentes(x, y, w, h)
 704|     for d in ocl
 705|         _Log("  OCLUSION en la captura: " d)
 706|     hdcS := DllCall("user32\GetDC", "ptr", 0, "ptr")
 707|     hdc := DllCall("gdi32\CreateCompatibleDC", "ptr", hdcS, "ptr")
 708|     hbm := DllCall("gdi32\CreateCompatibleBitmap", "ptr", hdcS, "int", w, "int", h, "ptr")
 709|     old := DllCall("gdi32\SelectObject", "ptr", hdc, "ptr", hbm, "ptr")
 710|     DllCall("gdi32\BitBlt", "ptr", hdc, "int", 0, "int", 0, "int", w, "int", h, "ptr", hdcS, "int", x, "int", y, "uint", 0x40CC0020)
 711|     DllCall("gdi32\SelectObject", "ptr", hdc, "ptr", old)
 712|     bmp := 0
 713|     DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", hbm, "ptr", 0, "ptr*", &bmp)
 714|     clsid := Buffer(16, 0)
 715|     DllCall("ole32\CLSIDFromString", "str", "{557CF406-1A04-11D3-9A73-0000F81EF32E}", "ptr", clsid)
 716|     ruta := A_ScriptDir "\captura_" Round(S.esc * 100) "_" FONDOS[S.fondoI][1] "_m" S.mon "_" FormatTime(, "HHmmss") (ocl.Length ? "_OCLUIDA" : "") ".png"
 717|     st := DllCall("gdiplus\GdipSaveImageToFile", "ptr", bmp, "str", ruta, "ptr", clsid, "ptr", 0, "int")
 718|     DllCall("gdiplus\GdipDisposeImage", "ptr", bmp)
 719|     DllCall("gdi32\DeleteObject", "ptr", hbm)
 720|     DllCall("gdi32\DeleteDC", "ptr", hdc)
 721|     DllCall("user32\ReleaseDC", "ptr", 0, "ptr", hdcS)
 722|     _Log("Captura " (st = 0 ? "guardada" : "FALLO (gdiplus=" st ")") ": " ruta)
 723| }
 724| 
 725| ; ---------------------------------------------------------------------
 726| ; Capa L1 de ejemplo: _Superficie(hwnd, w, h, radio, modo)
 727| ; El texto devuelto NO es evidencia de que el redondeo se vea.
 728| ; ---------------------------------------------------------------------
 729| _Superficie(hwnd, w, h, r, modo) {
 730|     switch modo {
 731|         case "region":
```

### candidatos de posicion (lo que consume --pos=X,Y) — l.340-362
```ahk
 340|             res.Push(_DescVentana(hw) " " ww "x" wh " en " wx "," wy)
 341|     }
 342|     return res
 343| }
 344| 
 345| _PosLibre(sw, sh, l, t, r, b) {
 346|     cands := []
 347|     if (POS_X != "")
 348|         cands.Push([POS_X, POS_Y])
 349|     cands.Push([l + 10, t + 10], [r - sw - 10, t + 10], [l + 10, b - sh - 10], [r - sw - 10, b - sh - 10], [l + (r - l - sw) // 2, t + (b - t - sh) // 2])
 350|     mejor := cands[1]
 351|     menos := 99999
 352|     for c in cands {
 353|         n := _Ocluyentes(c[1], c[2], sw, sh).Length
 354|         if (n = 0)
 355|             return c
 356|         if (n < menos) {
 357|             menos := n
 358|             mejor := c
 359|         }
 360|     }
 361|     _Log("AVISO: todas las zonas candidatas tienen ventanas siempre-visibles ajenas; se usa la de menos (" menos ")")
 362|     return mejor
```

#### Pedido 3 — spike_latencia.ahk PARCHADO (copia de trabajo, no la de ENTREGA CLAUDE 2)
Archivo: _f0v2/Autohotkeys_ESTETICA_F0_v2/docs/ESTETICA/spike/spike_latencia.ahk · 377 lineas · SHA 13d4bfd466a28ccc2eb63e94421295d2e9c2184ceeb969d3e797b69ea46137b9
Esta version ya tiene REPTXT, el hash real y las lamadas _LatHb; la de la entrega sigue sin cargar.

### Principal(): generador de la copia — l.96-152
```ahk
  96|             v .= A_Index ": " lineas[A_Index] "`n"
  97|         Rep("Bloque de elevacion NO reconocido. Primeras lineas:`n" v)
  98|         Guardar("latencia_base.txt")
  99|         Fin("Bloque de elevacion no reconocido en lineas 3-6. No se construye la copia.`nVer latencia_base.txt", 3)
 100|     }
 101|     dir := A_Temp "\latencia_f0"
 102|     DirCreate(dir)
 103|     copia := dir "\prueba_latencia.ahk"
 104|     salida := dir "\salida_latencia.txt"
 105|     errf := dir "\stderr_latencia.txt"
 106|     try FileDelete(salida)
 107|     try FileDelete(errf)
 108| 
 109|     llamadas := Map()
 110|     for nombre in ["MostrarHUD", "MostrarMiniTexto", "ActualizarEstabGUI"] {
 111|         if !anclas.Has(nombre) || anclas[nombre].lin = 0 {
 112|             Rep("AVISO: " nombre " no se encontro en el canonico, no se medira.")
 113|             continue
 114|         }
 115|         llamadas[nombre] := ArmarLlamada(nombre, anclas[nombre].firma)
 116|         Rep(nombre "(" anclas[nombre].firma ")  ->  " llamadas[nombre])
 117|     }
 118| 
 119|     nuevo := []
 120|     for i, l in lineas {
 121|         if (i = 3) {
 122|             nuevo.Push("; [spike_latencia] elevacion anulada SOLO en esta copia (lineas 3-6 originales)")
 123|         } else if (i >= 4 && i <= 6) {
 124|             nuevo.Push("; [spike_latencia] linea " i " original anulada")
 125|             if (i = 6) {
 126|                 nuevo.Push("Suspend(1)")
 127|                 nuevo.Push('_LatHb("autoexec: Suspend + timer registrados")')
 128|                 nuevo.Push("SetTimer(_LatBase, -2500)")
 129|             }
 130|         } else {
 131|             nuevo.Push(l)
 132|         }
 133|     }
 134|     cuerpo := ""
 135|     for l in nuevo
 136|         cuerpo .= l "`r`n"
 137|     cuerpo .= Inyectable(llamadas, N, salida)
 138|     try FileDelete(copia)
 139|     f := FileOpen(copia, "w", "UTF-8")
 140|     f.Write(cuerpo)
 141|     f.Close()
 142|     Rep("Copia desechable: " copia)
 143| 
 144|     ; ---- 4. /validate de la copia ----
 145|     codV := RunWait('"' A_AhkPath '" /validate "' copia '"', , "Hide")
 146|     Rep("/validate de la copia: exit " codV)
 147|     if (codV != 0) {
 148|         Guardar("latencia_base.txt")
 149|         Fin("La copia no pasa /validate (exit " codV "). Ver latencia_base.txt", 4)
 150|     }
 151| 
 152|     if !EJECUTAR {
```

### ArmarLlamada(nombre, firma) — l.272-303
```ahk
 272| ArmarLlamada(nombre, firma) {
 273|     if (Trim(firma) = "")
 274|         return nombre "()"
 275|     args := []
 276|     for p in StrSplit(firma, ",") {
 277|         p := Trim(p)
 278|         p := RegExReplace(p, "^[&*]+")
 279|         opc := InStr(p, ":=") > 0
 280|         nom := StrLower(Trim(RegExReplace(p, "\s*:=.*$")))
 281|         v := ""
 282|         if RegExMatch(nom, "(txt|texto|text|msg|mensaje)")
 283|             v := '"LAT"'
 284|         else if RegExMatch(nom, "(col|color|hex|clr)")
 285|             v := '"00E5FF"'
 286|         else if RegExMatch(nom, "^(ms|dur|duracion|tiempo|time|delay)")
 287|             v := "60"
 288|         if (v = "") {
 289|             if opc
 290|                 break
 291|             v := "0"
 292|         }
 293|         args.Push(v)
 294|     }
 295|     s := ""
 296|     for i, v in args
 297|         s .= (i > 1 ? ", " : "") v
 298|     return nombre "(" s ")"
 299| }
 300| 
 301| ; ---------------------------------------------------------------------
 302| ; Codigo que se anade al final de la copia (plantilla; ``n = `n en la copia)
 303| ; ---------------------------------------------------------------------
```

### Inyectable(): _LatHb / _LatQPC / _LatMedir / _LatBase — l.304-377
```ahk
 304| Inyectable(llamadas, n, salida) {
 305|     medir := ""
 306|     for nombre, expr in llamadas
 307|         medir .= '    out .= _LatMedir("' nombre '", () => ' expr ', ' n ')' "`r`n"
 308|     c := "
 309| (
 310| ; ===== inyectado por spike_latencia.ahk (solo en la copia) =====
 311| _LatHb(t) {
 312|     try FileAppend(A_TickCount " | " t "`r`n", "@@HB@@", "UTF-8")
 313| }
 314| _LatQPC() {
 315|     static f := 0
 316|     if !f
 317|         DllCall("kernel32\QueryPerformanceFrequency", "int64*", &f)
 318|     cc := 0
 319|     DllCall("kernel32\QueryPerformanceCounter", "int64*", &cc)
 320|     return cc * 1000 / f
 321| }
 322| _LatMedir(nombre, fn, n) {
 323|     _LatHb("empieza " nombre)
 324|     ts := []
 325|     err := 0
 326|     ult := ""
 327|     try {
 328|         fn.Call()
 329|     } catch as e0 {
 330|         err += 1
 331|         ult := e0.Message
 332|     }
 333|     Loop n {
 334|         t0 := _LatQPC()
 335|         try {
 336|             fn.Call()
 337|         } catch as e1 {
 338|             err += 1
 339|             ult := e1.Message
 340|         }
 341|         ts.Push(_LatQPC() - t0)
 342|         Sleep(15)
 343|     }
 344|     Loop ts.Length - 1 {
 345|         i := A_Index + 1
 346|         v := ts[i]
 347|         j := i - 1
 348|         while (j >= 1 && ts[j] > v) {
 349|             ts[j + 1] := ts[j]
 350|             j -= 1
 351|         }
 352|         ts[j + 1] := v
 353|     }
 354|     m := ts.Length // 2
 355|     med := (Mod(ts.Length, 2) = 0) ? (ts[m] + ts[m + 1]) / 2 : ts[m + 1]
 356|     p95 := ts[Max(1, Ceil(ts.Length * 0.95))]
 357|     return "| " nombre " | " ts.Length " | " Round(med, 3) " | " Round(p95, 3) " | " Round(ts[ts.Length], 3) " | " err " " ult " |``n"
 358| }
 359| _LatBase() {
 360|     _LatHb("_LatBase entro (timer disparado)")
 361|     out := "Latencias base (ms, QPC, copia esteril)``n"
 362|     out .= "| Funcion | N | mediana | p95 | max | errores |``n"
 363|     out .= "|---|---|---|---|---|---|``n"
 364| @@MEDIR@@
 365|     out .= "``nCriterio I13: cada funcion estetica nueva debe sumar <= ~2 ms sobre estas medianas.``n"
 366|     try FileDelete("@@SALIDA@@")
 367|     FileAppend(out, "@@SALIDA@@", "UTF-8")
 368|     _LatHb("salida escrita")
 369|     ExitApp()
 370| }
 371| )"
 372|     hb := StrReplace(salida, "salida_latencia.txt", "heartbeat_latencia.txt")
 373|     c := StrReplace(c, "@@MEDIR@@", RTrim(medir, "`r`n"))
 374|     c := StrReplace(c, "@@SALIDA@@", salida)
 375|     c := StrReplace(c, "@@HB@@", hb)
 376|     return "`r`n" c "`r`n"
 377| }
```

#### Estado del diagnostico de huellas (para T1.2)
```text
La copia que queda en %TEMP%\latencia_f0\prueba_latencia.ahk es de la corrida 21:20 y NO tiene _LatHb:
  grep -c '_LatHb' prueba_latencia.ahk  ->  0
  sus lineas 1-8: #Requires / #SingleInstance Force / 3 comentarios / Suspend(1) / SetTimer(_LatBase, -2500)
heartbeat_latencia.txt y salida_latencia.txt NO existen; si esta stderr_latencia.txt de 0 bytes
y posiciones_gui.ini de 112 bytes (la copia llego a escribir su config).
=> Tu tabla de huellas no se puede llenar con datos existentes: hace falta una corrida nueva.
```

> Nota: la seccion "Estado del diagnostico de huellas (para T1.2)" de arriba quedo superada por la
> S3 de este archivo: ya hay corrida, hay latidos y hay tabla.

---

## S5 — Mapa de anclas del ESTABLE (recien generado, 23:36)

`anclas_canonico.txt` produced by the spike v3 dry run against the ESTABLE. Esto es lo que
reemplaza tus numeros de linea de CONTEXTO 2:

```text
﻿Anclas del canonico (linea de definicion | usos totales por nombre)
Lineas: 3959

_FadeAlpha                    def=  563  usos=   7  (hwnd,hasta,pasos := 6,delayMs := 10)
_LimpiarAvisos                def=    0  usos=   0  ()
_LimpiarGUIs                  def= 1542  usos=   4  ()
MostrarHUD                    def= 1610  usos=  69  (texto,colorBarra := "00E5FF",duracion := 1200)
MostrarMiniTexto              def= 1711  usos=  33  (texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")
MostrarBadgeCombo             def= 1564  usos=   5  (comboText,toolText,colorAcento := "00E5FF",duracion := 2200)
MostrarTooltipToggle          def= 1758  usos=   5  (titulo,simbolo,color)
MostrarIconoHerramienta       def= 1663  usos=   3  (tipo,duracion := 700)
MostrarMiniGUI                def= 1738  usos=   1  (texto,colorHex := "222222",duracion := 1200)
_OcultarHUDSi                 def= 1647  usos=   2  (hwnd)
Sanar                         def=    0  usos=   0  ()
IniciarDsGUI                  def= 2247  usos=   3  ()
IniciarCcGUI                  def= 2281  usos=   3  ()
IniciarArGUI                  def= 2328  usos=   3  ()
IniciarHCGUI                  def= 2375  usos=   3  ()
IniciarLockGUI                def= 2422  usos=   3  ()
IniciarFrenteGUI              def= 2469  usos=   3  ()
IniciarEstabBtnGUI            def= 2524  usos=   3  ()
IniciarEstabGUI               def= 2585  usos=   3  ()
ActualizarEstabGUI            def= 2742  usos=   9  (v := -1,forzar := false)
_EstabCalcular                def= 2679  usos=   3  (w,h)
_EstabLayout                  def= 2705  usos=   6  (w,h)
_EstabKnobRegion              def= 2724  usos=   2  ()
_EstabRegion                  def= 2733  usos=   6  (w,h)
_EstabEmitir                  def= 2909  usos=   5  (tecla,n,pausa := ESTAB_RITMO)
_EstabEnviarDelta             def= 2921  usos=   5  (nuevo)
IniciarReloadGUI              def= 3181  usos=   2  ()
IniciarPuntosGUI              def= 3376  usos=   2  ()
_SetIcono                     def= 3910  usos=  17  (ctrl,nombre)
_RutaIcono                    def= 3916  usos=   2  (nombre)
_IconosB64                    def= 3953  usos=   3  ()
_PosGuiIniPath                def= 2061  usos=  31  ()
_AnclaBloquePaneles           def= 2088  usos=   8  ()
AbrirPanelPuntos              def= 3440  usos=   3  ()
_ArrastrarPanelBloque         def= 2109  usos=   8  (hwndClick,lParam,guiObj)
MostrarGUIEnfoque             def= 1926  usos=   2  ()
IniciarDialGUI                def= 2230  usos=   2  ()

Marcas de hallazgos del PLAN (primera linea | apariciones)
-2247 (ancla fija de avisos)        linea= 1576  n=  2
PUNTOS[30]                          linea= 1679  n=  2
ancho HUD fijo 208*AVISO_ESC        linea= 1620  n=  1

Lectura: _FadeAlpha usos=0 -> I12 sin objeto. _LimpiarAvisos def>0 -> D2 cerrada.
```

Tres lecturas utiles: `_LimpiarAvisos` y `Sanar` siguen con `def=0 usos=0` (D2 sigue abierta, no
existe a quien llamar); `_FadeAlpha` existe con `usos=7` (I12 tiene objeto); y las firmas reales de
las tres funciones medidas son las que salen en S3.

---

## S6 — Dos incidentes en pantalla de Josue (para que no se repitan)

1. A las 23:28 abrio con doble clic `rd3\spike-v3\spike_latencia.ahk` (la carpeta se le creyo un
   entregable). Salto `Fin()` con "no existe el .ahk canonico" porque la ruta por defecto del spike
   (`A_ScriptDir \..\..\..\`) no apunta a ningun sitio desde ahi. Tuve que pedirle que cerrara el
   cuadro: un proceso **elevado** no se puede matar desde esta consola, y mientras vivia bloqueo
   mi corrida por `#SingleInstance Force`.
   -> Desde ahora los `.ahk` del paquete viajan como `.txt`; el ejecutable solo vive en `%TEMP%`.
2. A las 23:35 y 23:37 parpadearon las GUIs del script unos segundos (corridas N=20 y N=5). Anunciado
   antes y supervisado: los dos arboles se cerraron por PID. Su companion ESTABLE se cae y el lo
   relanzo a las 23:35:15 (PID 17336); no hay senal de que mis copias lo tocaran: el hash del
   ESTABLE es idéntico antes y despues de cada corrida.

---

## S7 — Lo que necesito de ti en la ronda 5 (orden de bloqueos)

1. **`ArmarLlamada()` corregido** (orden de los `if` de nombre) y **una forma de forzar el
   redibujado del slider** en la medicion, para tener la base real de `ActualizarEstabGUI`. Sin
   eso, I13-b no se decide y D4 no se firma.
2. **`--sinmsg`** (o `Fin()` sin cuadro cuando hay `--ejecutar`) y el parche de huellas ya no hace
   falta: esta aplicado en v3. Si quieres el diff exacto de las 9 lineas, esta en S4.
3. **`_Pasar` con pareja ON/OFF controlada** por fondo y escala (hueco D4-a del 5), y decision de
   D6 (`FFFFFF` vs `E8ECF4`) que depende de esas capturas.
4. **Veredicto F1 / arranque de F2.** F1 esta verde en los tres test (validate, `_Tema` 14/14,
   esteril PASS con el bloque puesto). Tienes via libre para pedir su aplicacion al archivo real
   con `.bak-ola1-<fecha>` (I2) o para decir que F2 se disena encima sin aplicarlo aun.
5. Si vas a tocar el arnes otra vez: la huella vive en `pruebas.ps1:213-216` y su respaldo es
   `pruebas.ps1.bak-ronda4-20261104-232447`.

### Como reproducir todo esto (por si quieres verificar sin mi pantalla)

```powershell
# S1: las 2 lineas .Show
$can="C:\Users\jbard\Documents\AntiGravity\Autohotkeys\XxxPPEN_a16pg2_displayAS_secondary.ahk"
$est="C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk"
Compare-Object (Select-String $can -Pattern '\.Show\("' | ForEach-Object { $_.Line.Trim() }) `
               (Select-String $est -Pattern '\.Show\("' | ForEach-Object { $_.Line.Trim() })

# S2: arnes con F1  (los .ps1 estan en el zip; -Raiz apunta a una copia en TEMP sin espacios)
& "$env:TEMP\ronda4\rd3\ronda4-arnes.ps1"

# S3: spike v3, seco y ejecutado (parpadea las GUIs; no lo corras mientras dibuja)
& "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" "...\spike_latencia.ahk" --forzar --prod="$env:TEMP\ronda4_prod\XxxPPEN_a16pg2_displayAS_secondary.ahk" --n=5
```

