# Ronda 3: (a) parche T1.1 de Claude sobre una copia de trabajo del spike,
#          (b) test F1 de su T3(c) aplicado a una copia del ESTABLE.
$ErrorActionPreference = 'Stop'
$ahk  = "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"
$real = "CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E"

Write-Host "===== (a) T1.1 : REP -> REPTXT + hash real ====="
$dir  = "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\spike-parcheado"
$src  = "C:\Users\jbard\Documents\AntiGravity\Autohotkeys\ENTREGA CLAUDE 2"
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force $dir | Out-Null }
Copy-Item (Join-Path $src "spike_latencia.ahk") $dir -Force
Copy-Item (Join-Path $src "PLAN-V2.md") $dir -Force

function Parchear([string]$p, [scriptblock]$f) {
    $b   = [IO.File]::ReadAllBytes($p)
    $bom = ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF)
    $t   = [IO.File]::ReadAllText($p)
    Copy-Item $p "$p.bak-f0r3-$(Get-Date -f yyyyMMdd-HHmmss)"
    [IO.File]::WriteAllText($p, (& $f $t), (New-Object Text.UTF8Encoding($bom)))
}

$sp = Join-Path $dir "spike_latencia.ahk"
$t  = [IO.File]::ReadAllText($sp)
$nRep  = [regex]::Matches($t, '\bREP\b').Count
$nHash = [regex]::Matches($t, '(?i)CEF745C7[0-9A-F]{56}(?![0-9A-F])').Count
"REP=$nRep (esperado 4)   hash=$nHash (esperado 1)"
if ($nRep -ne 4 -or $nHash -ne 1) { throw "Conteos inesperados: NO se modifica nada." }
Parchear $sp { param($x)
    $x = [regex]::Replace($x, '\bREP\b', 'REPTXT')
    [regex]::Replace($x, '(?i)CEF745C7[0-9A-F]{56}(?![0-9A-F])', $real) }

$pl = Join-Path $dir "PLAN-V2.md"
$nPl = [regex]::Matches([IO.File]::ReadAllText($pl), '(?i)CEF745C7[0-9A-F]{56}(?![0-9A-F])').Count
"PLAN-V2 hash=$nPl (esperado >=1)"
Parchear $pl { param($x) [regex]::Replace($x, '(?i)CEF745C7[0-9A-F]{56}(?![0-9A-F])', $real) }

$r = Start-Process $ahk -ArgumentList '/validate', "`"$sp`"" -Wait -PassThru
"/validate spike_latencia.ahk parcheado -> exit $($r.ExitCode)   (esperado 0)"
Select-String -Path $sp, $pl -Pattern $real -SimpleMatch | Select-Object Filename, LineNumber | Format-Table -AutoSize

Write-Host "===== (b) T3(c) : aplicar F1 a una copia y validar ====="
$prod = "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk"
$copia= Join-Path $env:TEMP "f1_aplicar\copia.ahk"
New-Item -ItemType Directory -Force (Split-Path $copia) | Out-Null
Copy-Item $prod $copia -Force
$h0 = (Get-FileHash $prod -Algorithm SHA256).Hash

$bloque = [IO.File]::ReadAllText("C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\f1_tema.ahk")
$nl     = if ([IO.File]::ReadAllText($copia).Contains("`r`n")) { "`r`n" } else { "`n" }
$bloque = $bloque -replace "`r?`n", $nl
[IO.File]::AppendAllText($copia, $nl + $bloque + $nl, (New-Object Text.UTF8Encoding($false)))

$r = Start-Process $ahk -ArgumentList '/validate', "`"$copia`"" -Wait -PassThru
"validate copia con F1 -> exit $($r.ExitCode)   (esperado 0)"

$a = [IO.File]::ReadAllLines($prod); $b = [IO.File]::ReadAllLines($copia)
"lineas: $($a.Length) -> $($b.Length)"
"eliminadas: " + @(Compare-Object $a $b | Where-Object SideIndicator -eq '<=').Count + "   (esperado 0)"
"h0 = $h0"
"h1 = $((Get-FileHash $prod -Algorithm SHA256).Hash)   (debe ser identico: no se escribe produccion)"

Write-Host "===== (c) test funcional de _Tema ====="
$d = Join-Path $env:TEMP "f1_test"; New-Item -ItemType Directory -Force $d | Out-Null
@'
[color]
surface.base = 12141A
surface.off = ZZZZZZ
surface.on = abcdef
track.off = 3A3A45 ; comentario en la misma linea (R1)
accent.info = 00E5FF
[alpha]
pill = 200
badge = 300
hud = -5
[type]
family.value =
[fx]
roles = 1
'@ | Set-Content (Join-Path $d "theme.ini") -Encoding ASCII
Remove-Item (Join-Path $d "salida.txt") -ErrorAction SilentlyContinue
$txt = [IO.File]::ReadAllText($copia)
$blk = [regex]::Match($txt,'(?s); === F1-BEGIN ===.*; === F1-END ===').Value
"bloque recuperado de la copia: $($blk.Length) chars"
(@'
#Requires AutoHotkey v2.0
__BLK__
o := ""
o .= "base=" _Tema("color","surface.base","000000") "`n"
o .= "off_zzz=" _Tema("color","surface.off","424242") "`n"
o .= "on_lower=" _Tema("color","surface.on","636D83") "`n"
o .= "track_comment=" _Tema("color","track.off","111111") "`n"
o .= "alpha_ok=" _Tema("alpha","pill","235") "`n"
o .= "alpha_300=" _Tema("alpha","badge","230") "`n"
o .= "alpha_neg=" _Tema("alpha","hud","215") "`n"
o .= "alpha_missing=" _Tema("alpha","mini","200") "`n"
o .= "family_empty=" _Tema("type","family.value","Cascadia Mono") "`n"
o .= "rol_info=" _RolDeHex("1c6ea4") "`n"
o .= "rol_unknown=[" _RolDeHex("123456") "]`n"
o .= "aviso_info=" _AvisoColor("1C6EA4") "`n"
o .= "aviso_neutral=" _AvisoColor("EEEEEE") "`n"
o .= "fuente_iconos=" _TemaFuente("iconos") "`n"
FileAppend(o, A_ScriptDir "\salida.txt")
'@).Replace('__BLK__',$blk) | Set-Content (Join-Path $d "t.ahk") -Encoding UTF8
Start-Process $ahk -ArgumentList '/ErrorStdOut', "`"$d\t.ahk`"" -Wait
Write-Host "----- salida.txt -----"
Get-Content (Join-Path $d "salida.txt")
