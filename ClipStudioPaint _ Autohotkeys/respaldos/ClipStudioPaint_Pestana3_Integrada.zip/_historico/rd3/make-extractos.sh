#!/bin/bash
# Genera rd3/EXTRACTOS-ronda3.md con los extractos literales que pidio Claude 3.
cd "/c/Users/jbard/Desktop/AHK-global-main/ClipStudioPaint _ Autohotkeys" || exit 1
G="/c/Users/jbard/Documents/AntiGravity/Autohotkeys/ENTREGA CLAUDE 2/galeria.ahk"
S="_f0v2/Autohotkeys_ESTETICA_F0_v2/docs/ESTETICA/spike/spike_latencia.ahk"
OUT="rd3/EXTRACTOS-ronda3.md"

num() { awk -v a="$1" -v b="$2" 'NR>=a && NR<=b {printf "%4d| %s\n", NR, $0}' "$3"; }
bloque() { printf '### %s\n```ahk\n' "$1"; num "$2" "$3" "$4"; printf '```\n\n'; }

{
echo "# Extractos de la ronda 3 (pedidos 2 y 3)"
echo
echo "Generado $(date '+%F %T'). Numeracion = linea real de cada archivo. Nada transcrito a mano."
echo
echo "## Pedido 2 — galeria.ahk (ENTREGA CLAUDE 2)"
echo "Archivo: $(cd "$(dirname "$G")" && basename "$G") · $(wc -l < "$G") lineas · SHA $(sha256sum "$G" | cut -c1-64)"
echo
bloque "_AutoCapturas() — l.270-296" 270 296 "$G"
bloque "_Pasar(mon, escalas) — el barrido real, l.282-304" 282 304 "$G"
bloque "_DescVentana(hw) + _Ocluyentes(x,y,w,h) — l.305-350" 305 350 "$G"
bloque "_Captura(*) — BitBlt del DC de pantalla + marca _OCLUIDA, l.699-731" 699 731 "$G"
bloque "candidatos de posicion (lo que consume --pos=X,Y) — l.340-362" 340 362 "$G"

echo "## Pedido 3 — spike_latencia.ahk PARCHADO (copia de trabajo, no la de ENTREGA CLAUDE 2)"
echo "Archivo: $S · $(wc -l < "$S") lineas · SHA $(sha256sum "$S" | cut -c1-64)"
echo "Esta version ya tiene REPTXT, el hash real y las lamadas _LatHb; la de la entrega sigue sin cargar."
echo
bloque "Principal(): generador de la copia — l.96-152" 96 152 "$S"
bloque "ArmarLlamada(nombre, firma) — l.272-303" 272 303 "$S"
bloque "Inyectable(): _LatHb / _LatQPC / _LatMedir / _LatBase — l.304-377" 304 377 "$S"

echo "## Estado del diagnostico de huellas (para T1.2)"
echo '```text'
echo "La copia que queda en %TEMP%\latencia_f0\prueba_latencia.ahk es de la corrida 21:20 y NO tiene _LatHb:"
echo "  grep -c '_LatHb' prueba_latencia.ahk  ->  0"
echo "  sus lineas 1-8: #Requires / #SingleInstance Force / 3 comentarios / Suspend(1) / SetTimer(_LatBase, -2500)"
echo "heartbeat_latencia.txt y salida_latencia.txt NO existen; si esta stderr_latencia.txt de 0 bytes"
echo "y posiciones_gui.ini de 112 bytes (la copia llego a escribir su config)."
echo "=> Tu tabla de huellas no se puede llenar con datos existentes: hace falta una corrida nueva."
echo '```'
} > "$OUT"
wc -l "$OUT"
