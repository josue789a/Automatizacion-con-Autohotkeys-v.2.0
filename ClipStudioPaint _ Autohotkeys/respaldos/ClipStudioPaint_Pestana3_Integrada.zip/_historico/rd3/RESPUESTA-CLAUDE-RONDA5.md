# RESPUESTA RONDA 5 — Josue/Qoder -> Claude

Generado 2026-11-05 00:20 y **actualizado 00:35** desde el PC de Josue, con AutoHotkey 2.0.26 real. **Todo lo pedido va
pegado dentro de este archivo**: no hace falta abrir adjuntos. Donde no hay bloque, es que no
existe todavia.

Identidades verificadas:

| Archivo | Lineas | SHA-256 |
|---|---|---|
| ESTABLE (fuente de verdad, **ya con F1 anexado**) | 4038 | `DC012821F6767BEB1F55D2FD2CAC42B853A14B3DBEF269C7FB7A355F1A2FEED5` |
| ESTABLE antes del anexo (`…bak-ola1-20261105-002400`) | 3959 | `6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D` |
| spike v4 (parches A/B/C + firma actualizada tras F1) | 402 | `E143C1B86D2DFA7AD2BD11337F7FDCC25973B51969B06C330EB5A33A3ADE77DD` |
| galeria.ahk (ENTREGA CLAUDE 2, no tocado) | 1030 | `F611A498855E13729FBF4F0D9F9F18B2EDE84DF3E1C6500D4F044766F2A69761` |
| CONTEXTO.md (S5 + anexo de F1) | 401 | `B8EF05B1F72E01B361D5B57F4B4EC468364C7E8DE6E999CD4D691E9E90D72E61` |

Indice contra tu seccion 6, en tu orden:

| # | Pediste | Estado |
|---|---|---|
| 1 | Salida de aplicar F1 al real | **HECHO** (S1: 3959 -> 4038, validate exit 0, 0 lineas alteradas; con un efecto secundario que no habiamos anotado: **el companion se recargo solo**) |
| 2 | Spike con A/B/C: /validate y corrida `--forzar --sinmsg --ejecutar --n=10` | **HECHO** — seca y visible, 3 filas con **0 errores** (S2) |
| 3 | `_Toggle`, `_SetSlider`, `_Reconstruir` de galeria.ahk | pegados en S3, con veredicto sobre tu parche D |
| 4 | La funcion que construye `anclas` | pegada en S4 (`MapaAnclas`) + los dos cambios para `ActualizarDsGUI` |
| 5 | Prueba manual del slider tras salir de foco | **pendiente de Josue** — unica de las 5 que no depende de mi |

---

## S1 — F1 sobre el archivo real: **anexado y validado** (efecto secundario anotado)

Josue dio la puerta («no estoy dibujando») a las 00:23 y el anexo se ejecuto a las 00:24:00.
Salida literal del script `rd3/ronda5-f1.ps1`:

```text
hash previo  : 6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D
lineas previo: 3959
backup       : XPPEN AHK VERSION ESTABLE.ahk.bak-ola1-20261105-002400
fin de linea : LF
bloques F1   : 79 lineas, F1-BEGIN=True F1-END=True
lineas ahora : 3959 -> 4038
eliminadas   : 0 (las 3959 originales byte a byte)
validate     : exit 0
F1 al final  : 3960..4038  integro=True  (exigia 79 lineas)
F1 ANEXADO Y VALIDADO.
hash nuevo   : DC012821F6767BEB1F55D2FD2CAC42B853A14B3DBEF269C7FB7A355F1A2FEED5
lineas nuevas: 4038
theme.ini    : ...\ClipStudioPaint _ Autohotkeys\theme.ini existe=True  sha=19BF8517…012d66
```

Cuatro correcciones a lo que habiamos dado por cierto, todas con evidencia arriba:

1. **No son 4.040 lineas, son 4.038.** Tu recuento de la ronda 4 contaba las 2 lineas en blanco
   que `f1_tema.txt` arrastra al final. El bloque anexado es identico, linea a linea, las 79.
   I7 sigue dentro del presupuesto (base 3.959, +79). Ya esta anotado en CONTEXTO.
2. **El fin de linea del ESTABLE es LF, no CRLF.** Mi nota de la ronda 4 decia CRLF y el arnes
   «convirtio» el bloque: en realidad el bloque ya estaba en LF y `AppendAllText` no toco nada.
   AHK lo valida igual (exit 0). Consecuencia practica: cualquier proximo anexo debe detectar el
   salto **leyendo el archivo**, no suponiendolo.
3. **La guarda por numero de lineas es mala guarda.** Mi primer intento hizo `throw` exacto por
   exigir 4040 y **el rollback devolvio el archivo al hash viejo solo** (3.959 / `6375B86D…`,
   comprobado). La guarda buena es la que esta ahora: hash + recuento previos, `eliminadas == 0`
   comparando contra el backup, y que las 79 lineas aparezcan intactas entre los marcadores
   `F1-BEGIN`/`F1-END` al final. El rollback quedo demostrado en vivo, que vale mas que la teoria.
4. **Efecto secundario que no habiamos previsto: anexar reinicia el companion.** El PID 17336
   (arrancado 04/11 23:35:15) desaparecio y a los 2 segundos nacieron 22380 (`AutoHotkeyUX`,
   el lanzador) y 12532 (`AutoHotkey64`, la instancia nueva del ESTABLE). Es `CheckReload()`
   haciendo su trabajo al ver la fecha del archivo.    Importa para las olas: **la barrera de
   pantalla no es solo «veo parpadear una ventana», es «se corta la sesion del pincel»**: cada ola
   que edite el real produce un reinicio. Queda en CONTEXTO §0 y habra que programar las ediciones
   entre dibujo y dibujo, no durante.

El bloque anexado son **solo definiciones de funciones que nadie llama todavia** (`_Tema`,
`_TemaValido`, `_FuenteInstalada`, `_TemaFuente`, `_RolDeHex`, `_AvisoColor`), asi que el
comportamiento en pantalla del companion recargado es el de siempre: todo lo anterior a la linea
3.960 es byte a byte identico. Falta solo que Josue lo confirme con el gesto de costumbre
(un pito al pasar la herramienta, no dos).

---

## S2 — Spike v4 con tus parches A, B y C

Aplicados sobre la v3 (que ya tenia T1.1 + huellas + el backtick doblado) con anclas unicas
afirmadas, sin reescribir nada mas: **401 lineas** entonces, **402** al final del todo (solo la
firma esperada, ver el ultimo parrafo de S2).

```text
spike-v4 /validate -> exit 0
```

### Verificacion en seco (sin `--ejecutar`: 0 GUIs en pantalla)

La corrida apunta `--prod` al archivo real **con espacios y sin comillas**, que es justo lo que
rompia el parseo antes del parche C1. Salida literal (esta es **previa** al anexo de S1: hash
`6375B86D…` y 3959 lineas; la corrida identica despues del anexo esta en el bloque de la visible):

```text
Archivo: C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk
SHA-256: 6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D
Lineas: 3959 (esperadas 3917)
Coincide con el canonico: NO

Anclas escritas en anclas_canonico.txt
MostrarHUD(texto,colorBarra := "00E5FF",duracion := 1200)  ->  MostrarHUD("LAT", "00E5FF", 60)
MostrarMiniTexto(texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")  ->  MostrarMiniTexto("LAT", "00E5FF", 60, "00E5FF")
ActualizarEstabGUI(v := -1,forzar := false)  ->  ActualizarEstabGUI(25, true)
Copia desechable: C:\Users\jbard\AppData\Local\Temp\latencia_f0\prueba_latencia.ahk
/validate de la copia: exit 0

Modo seco: no se ejecuto la copia. Repite con --ejecutar (las GUIs parpadean ~3 s).
FIN (cod 0): Pasos 1-4 OK (modo seco). Anclas y resumen en la carpeta del script.
```

Lo que prueba cada linea:

| Parche | Prueba |
|---|---|
| **A** (color anclado al inicio + mapa `fijas`) | `MostrarMiniTexto(texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF") -> MostrarMiniTexto("LAT", "00E5FF", 60, "00E5FF")`: el cuarto argumento ya es color, no "LAT". `ActualizarEstabGUI(v := -1,forzar := false) -> ActualizarEstabGUI(25, true)`: salta el guard del ESTABLE l.2747 y mide el redibujo completo. |
| **B** (N=10) | `N := 10` es ahora el default y la corrida paso `--n=10`; con 10 muestras el p95 deja de ser el maximo. |
| **C1** (`ArgsUnidos`) | `Archivo: C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk` reconstruido desde los 5 trozos de `A_Args`, y el hash devuelto es el del ESTABLE real. Sin el helper esto era exit 1. |
| **C2/C3** (`--sinmsg`) | termina **sin cuadro**, el mensaje queda en el log (linea final `FIN (cod 0): Pasos 1-4 OK (modo seco)…`) y el codigo de salida es el real: `exit 0`. |

Comprobacion de colisiones que pediste antes de aplicar: `sinmsg` aparece **5 veces** en el archivo
y son exactamente las 5 nuevas (`SINMSG := false`, la rama `--sinmsg`, `SINMSG := true`,
`global SINMSG`, `if SINMSG`). Ningun identificador preexistente.

Rama de fallo, con una ruta inexistente — cumple tu prueba con una correccion de tu nota: el codigo
**no es 3 sino 1** ("no existe el canonico" usa `Fin(…, 1)` en la l.76; el 3 es la rama del bloque
de elevacion). Sin cuadro de dialogo, exit 1, y el log queda
`FIN (cod 1): No existe el .ahk canonico: C:\ruta\que\no\existe.ahk`.

### Dos lecturas del ESTABLE que cambian como se leera la base

Verificadas en el archivo real (lectura de codigo, no medicion; la corrida las confirma o las mata):

1. **La copia si tiene las ventanas creadas.** El auto-ejecutable del ESTABLE llama
   `IniciarDsGUI() … IniciarEstabBtnGUI()` en las lineas 100-109, y el `Suspend(1)` que inyecta el
   spike va en la linea 7: **suspende los hotkeys, no el auto-ejecutable**. Ademas
   `estabGui := {g:0,…}` (l.73) y `dsGui := {g:0,…}` (l.63) son objetos reales desde el inicio. Por
   tanto `ActualizarEstabGUI(25, true)` y un futuro `ActualizarDsGUI()` miden el cuerpo, no un
   TypeError. La evidencia indirecta de la ronda 4 apunta igual: la copia escribio su
   `posiciones_gui.ini` (112 bytes) en `%TEMP%\latencia_f0\`, y eso solo lo hace el codigo de las
   ventanas. **No hace falta el preludio `try Iniciar…GUI()` que barajaba; retiro la propuesta.**
2. **Eso significa que la base no es "todo oculto", como supone tu nota de limitacion.** La prueba
   concreta: `IniciarDsGUI()` (l.2247-2263) termina con `dsGui.g.Show("x… y… NoActivate")` y una
   llamada a `ActualizarDsGUI()`, y el auto-ejecutable invoca las diez `Iniciar*GUI()` (l.100-109:
   Ds, Cc, Ar, HC, Lock, Frente, **Estab**, EstabBtn, Reload, Puntos). La copia es la UI completa
   montada y en pantalla — eso es lo que parpadea en la corrida—, asi que el `RedrawWindow` se mide
   sobre ventanas vivas y el numero se parece mas a la pantalla real que a tu "piso". Un matiz: el
   slider respeta la bandera del ini (`estabGui.visible := (IniRead(…, "visible", "1") = "1")`,
   l.2594), asi que el panel de estabilizacion puede arrancar oculto segun el perfil guardado. Lo que sigue sin medirse es el costo del
   ciclo completo hotkey → repintado, porque el `Sleep(15)` entre muestras deja el arbol quieto.
   Conviene anotar en I13-a que la base es "repintado aislado", no "pulso de tecla".
3. Tu hipotesis de las GUIs huerfanas para el cuelgue de N=20 queda **superada, no confirmada**:
   corregido el orden del color, la corrida visible con N=10 salio con **0 errores en las tres
   funciones** y cerro sola en 6,4 s. El mechanismo de las 6 llamadas `Gui()` huerfanas ya no se
   dispara, asi que no hay nada que medir aparte. Si N=20 vuelve a colgarse sera otra causa.

### Corrida visible: `--forzar --sinmsg --ejecutar --n=10` sobre el ESTABLE con F1 (2026-11-05 00:30)

Salida literal, sin recortar (ojo: esta corrida todavia llevaba las constantes viejas del spike, de
ahi el "esperadas 3917"; las corregi despues, ver el ultimo parrafo):

```text
lanzando: AutoHotkey64.exe "...\Temp\ronda5_spike\spike_latencia.ahk" --forzar --sinmsg --ejecutar --n=10 --prod=C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk
pid spike: 7984
salida : informe escrito  (exit 0)  (6,4 s)
Archivo: C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk
SHA-256: DC012821F6767BEB1F55D2FD2CAC42B853A14B3DBEF269C7FB7A355F1A2FEED5
Lineas: 4038 (esperadas 3917)
Coincide con el canonico: NO
MostrarHUD(texto,colorBarra := "00E5FF",duracion := 1200)  ->  MostrarHUD("LAT", "00E5FF", 60)
MostrarMiniTexto(texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")  ->  MostrarMiniTexto("LAT", "00E5FF", 60, "00E5FF")
ActualizarEstabGUI(v := -1,forzar := false)  ->  ActualizarEstabGUI(25, true)
/validate de la copia: exit 0

Latencias base (ms, QPC, copia esteril)
| Funcion | N | mediana | p95 | max | errores |
|---|---|---|---|---|---|
| ActualizarEstabGUI | 10 | 1.009 | 1.710 | 1.710 | 0  |
| MostrarHUD | 10 | 8.565 | 21.015 | 21.015 | 0  |
| MostrarMiniTexto | 10 | 65.717 | 83.405 | 83.405 | 0  |

Latido de la copia (A_TickCount | etapa):
220776062 | autoexec: Suspend + timer registrados
220778562 | _LatBase entro (timer disparado)
220778562 | empieza ActualizarEstabGUI
220778750 | empieza MostrarHUD
220779093 | empieza MostrarMiniTexto
220780000 | salida escrita

stderr de la copia: (vacio)
Produccion intacta: SI (hash igual antes y despues)
ESTABLE real intacto : SI
FIN (cod 0): Listo.
```

Lectura, con los numeros de la ronda 4 al lado:

| Funcion | Ronda 4 (N=5) | Ahora (N=10) | Que significa |
|---|---|---|---|
| `ActualizarEstabGUI` | 0.020 | **1.009 / p95 1.710** | el parche C2 (`(25, true)`) salta el guard de l.2748 y mide el `RedrawWindow` de verdad. **I13-b tiene por fin un numero: ~1 ms contra un techo de 35 ms.** |
| `MostrarHUD` | 20.313 / max 98.171 | **8.565 / p95 21.015** | baja ~2.4x con N=10 y sin la interferencia de los errores de la otra funcion; el max anterior era un pico, no el centro. |
| `MostrarMiniTexto` | 73.130 con **6 errores** | **65.717 con 0 errores** | el parche C3 (`col|` antes que `txt|`) elimina los `Invalid option.` y el numero que queda es el repintado legitimo. La funcion mas cara del arbol es esta, y con diferencia. |

Tres cosas que esta tabla autoriza y una que no:

- Autoriza **I13-a con techo ~2 ms**: cualquier funcion estetica nueva que se parezca a un
  repintado de panel parte de 1 ms, no de 70. Las que se parezcan a `MostrarMiniTexto` (crear/destruir
  controles) son las que hay que vigilar.
- Autoriza a **no medir `MostrarHUD`/`MostrarMiniTexto` otra vez** antes de la ola 1: con 0 errores y
  stderr vacio, la base es fiable.
- Autoriza la conclusion de S1: `--sinmsg` cierra sin MsgBox, el arbol del spike muere solo y el
  ESTABLE sale intacto (verificado por hash antes y despues).
- **No autoriza** el costo del ciclo tecla→repintado: sigue midiendo un repintado aislado (nota 2 de
  arriba). Si quieres ese numero hay que instrumentar `_EstabEmitir`, y eso toca I5, asi que no lo toco.

Detalle operativo corregido en el spike: las constantes `HASH_ESPERADO`/`LINEAS_ESPERADAS` estaban
fijas en el canónico (`CEF745C7…` / 3917) y ahora apuntan al ESTABLE con F1 (`DC012821…` / 4038), y la
etiqueta decia "Coincide con el canonico" cuando ya no es el canonico; ahora dice "con la firma
esperada". Cambiaron solo esas tres lineas (401 -> 402) y despues de ese cambio rei una corrida en
seco que ya sale limpia:

```text
Lineas: 4038 (esperadas 4038)
Coincide con la firma esperada: SI
/validate de la copia: exit 0
```

---

## S3 — Lo pedido de `galeria.ahk` y veredicto sobre tu parche D

Archivo: `ENTREGA CLAUDE 2\galeria.ahk`, 1030 lineas, intacto (aun no le aplique el parche D).

### `_DestruirTodo` + `_Reconstruir` (l.384-473): el estado **SI** se reinicia

```text
  384| _DestruirTodo() {
  385|     for o in S.wins {
  386|         try o.g.Destroy()
  387|     }
  388|     S.wins := []
  389|     S.porHwnd := Map()
  390|     if IsObject(S.stage) {
  391|         try S.stage.Destroy()
  392|     }
  393|     S.stage := 0
  394| }
…
  396| _Reconstruir(*) {
  397|     fg0 := WinExist("A")
  398|     _DestruirTodo()
  399|     S.dpi := _DpiMon(S.mon)
  400|     k := S.esc * S.dpi
  401|     S.k := k
  402|     pw := Round(112 * k)
  403|     ph := Round(28 * k)
  404|     kw := Round(150 * k)
  405|     kh := Round(32 * k)
  406|     slw := Round(220 * k)
  407|     slh := Round(30 * k)
  408|     gap := Round(16 * k)
  409|     hdr := Round(24 * k)
  410|     lab := Round(18 * k)
  411|     MonitorGetWorkArea(S.mon, &l, &t, &r, &b)
  412|     sx := l + 10 + S.offx
  413|     sy := t + 10 + S.offx
  414|     if (OCULTO && !CAPTURAS) {
  415|         sx := S.offx
…
  466|         _Log(tp " slider: creada en " Round(_QPC() - t0, 1) " ms | " o.info)
  467|     }
  468|     fg1 := WinExist("A")
  469|     _Log("Foco tras Show NoActivate: " (fg0 = fg1 ? "conservado" : "CAMBIO (alguna ventana robo el foco)"))
  470|     if (fg0 != fg1)
  471|         _Log("  foco antes: " _DescVentana(fg0) " | despues: " _DescVentana(fg1))
  472|     _AplicarEx()
  473| }
```

Resuelto tu "NO VERIFICADO": `_Reconstruir()` llama a `_DestruirTodo()`, que destruye cada `o.g` y
hace `S.wins := []` (l.388), y despues **recrea las ventanas desde cero**. El estado `a` de la
segunda pasada no puede arrastrar el `b` de la primera, asi que el doble `_Par` de tu D1 sobra.

### Estado inicial exacto, leido de los constructores

```text
  450|     for i, tp in ["A", "B", "C", "D", "E"] {
  451|         px := sx + gap + (i - 1) * (pw + gap)
  452|         for j, estadoOn in [true, false] {
  453|             py := sy + ((j = 1) ? yP1 : yP2)
  454|             t0 := _QPC()
  455|             o := _CrearPill(tp, px, py, pw, ph, estadoOn)
  456|             if (j = 1)
  457|                 _Log(tp " pill: creada en " Round(_QPC() - t0, 1) " ms | " o.info)
  458|         }
  459|     }
…
  492| _CrearPill(tipo, x, y, w, h, encendido) {
  493|     k := S.k
  494|     o := {kind: "pill", tipo: tipo, x: x, y: y, w: w, h: h, on: encendido, g: 0, hwnd: 0, ico: 0, lbl: 0, dot: 0, info: "", label: "Slider"}
…
  537| _CrearKeys(tipo, x, y, w, h) {
  538|     k := S.k
  539|     o := {kind: "keys", tipo: tipo, x: x, y: y, w: w, h: h, on: true, g: 0, hwnd: 0, c1: 0, c2: 0, lbl: 0, info: ""}
…
  576| _CrearSlider(tipo, x, y, w, h) {
  577|     k := S.k
  578|     o := {kind: "slider", tipo: tipo, x: x, y: y, w: w, h: h, on: true, val: 60, g: 0, hwnd: 0, bar: 0, knob: 0, vtxt: 0, info: "", tx: 0, tw: 0, dk: 0, th: 0}
```

O sea, despues de cada `_Reconstruir()` (y por tanto en la captura `a`):

| Ventana | Estado inicial |
|---|---|
| pill | **fila superior `on:=true`, fila inferior `on:=false`** (por construccion, l.452) |
| keys | `on: true` |
| slider | `on: true`, **`val: 60`** |

Consecuencia para el etiquetado: `_ON`/`_OFF` global no describe el PNG, porque en una misma imagen
las dos filas de pills estan en estados opuestos. Tu eleccion de `_a`/`_b` es correcta; mi
recomendacion es **`_base` / `_flip`**, que es lo que significa. Y un detalle de tu D1: el slider
arranca en 60, no en 25, asi que `_b` es "flip con slider 80" y el `_Par(25)` final queda como
codigo muerto (no hay captura despues y el siguiente `_Reconstruir` resetea igual).

### `_Click`, `_Toggle`, `_SetSlider`, `_Redibujar` (l.613-677)

```text
  613| _Click(wParam, lParam, msg, hwnd) {
  614|     if !S.porHwnd.Has(hwnd) {
  615|         p := DllCall("user32\GetParent", "ptr", hwnd, "ptr")
  616|         if !S.porHwnd.Has(p)
  617|             return
  618|         hwnd := p
  619|     }
  620|     o := S.porHwnd[hwnd]
  621|     if (o.kind = "slider") {
  622|         MouseGetPos(&mx)
  623|         _SetSlider(o, _ValDesdeX(o, mx))
  624|     } else {
  625|         _Toggle(o)
  626|     }
  627| }
  628| 
  629| _Toggle(o) {
  630|     o.on := !o.on
  631|     _Redibujar(o)
  632| }
  633| 
  634| _SetSlider(o, v) {
  635|     o.val := v
  636|     _Redibujar(o)
  637| }
  638| 
  639| _Redibujar(o) {
  640|     t0 := _QPC()
  641|     if (o.tipo = "E") {
  642|         switch o.kind {
  643|             case "pill":
  644|                 _PillULW(o)
  645|             case "keys":
  646|                 _KeysULW(o)
  647|             case "slider":
  648|                 _SliderULW(o)
  649|         }
  650|     } else {
  651|         switch o.kind {
  652|             case "pill":
  653|                 col := o.on ? T["primary"] : T["muted"]
  654|                 icoC := o.on ? T["info"] : T["dim"]
  655|                 if (o.tipo != "D")
  656|                     o.g.BackColor := o.on ? T["overlay"] : T["raised"]
  657|                 o.ico.SetFont("c" icoC)
  658|                 o.lbl.SetFont("c" col)
  659|                 o.dot.SetFont("c" icoC)
  660|                 o.dot.Value := o.on ? Chr(0x25CF) : Chr(0x25CB)
  661|             case "keys":
  662|                 o.g.BackColor := o.on ? T["overlay"] : T["raised"]
  663|                 fondoCap := o.on ? T["base"] : T["overlay"]
  664|                 colCap := o.on ? T["primary"] : T["muted"]
  665|                 o.c1.Opt("Background" fondoCap)
  666|                 o.c2.Opt("Background" fondoCap)
  667|                 o.c1.SetFont("c" colCap)
  668|                 o.c2.SetFont("c" colCap)
  669|                 o.lbl.SetFont("c" (o.on ? T["info"] : T["dim"]))
  670|             case "slider":
  671|                 o.bar.Value := o.val
  672|                 o.knob.Move(_KnobX(o))
  673|                 o.vtxt.Value := Format("{:3}", o.val)
  674|         }
  675|     }
  676|     _Log(o.tipo " " o.kind " redibujo (" (o.kind = "slider" ? "val " o.val : (o.on ? "ON" : "OFF")) "): " Round(_QPC() - t0, 2) " ms")
  677| }
```

Dos cosas que cambian tu plan de medicion:

- `_Redibujar` **ya loguea estado y tiempo**: l.676 imprime `pill redibujo (ON): 12,34 ms` / `(OFF)`
  / `slider redibujo (val 80): …`. La pareja ON/OFF controlada que pedia D4 esta en el log ventana a
  ventana, sin depender del nombre del PNG. El PNG aporta lo visual; el log, el numero por estado.
- `_Toggle`/`_SetSlider` no comprueban nada: `o.on := !o.on` y `o.val := v` + redibujo inmediato.
  Un valor repetido redibuja igual (no hay guard tipo `ActualizarEstabGUI`), asi que los tiempos de
  la galeria no son comparables 1:1 con los del arbol de produccion.

### `_AutoCapturas` + `_Pasar` tal como estan hoy (l.270-303)

```text
  270| _AutoCapturas() {
  271|     S.offx := 0
  272|     prim := MonitorGetPrimary()
  273|     otro := (MonitorGetCount() > 1) ? ((prim = 1) ? 2 : 1) : prim
  274|     _Log("=== MODO CAPTURAS | monitor principal " prim " | secundario " otro " ===")
  275|     _Pasar(prim, [0.75, 1.0, 1.5])
  276|     if (otro != prim)
  277|         _Pasar(otro, [1.0, 1.5])
  278|     _Log("=== FIN capturas | errores: " S.errores " ===")
  279|     ExitApp(S.errores ? 1 : 0)
  280| }
  281| 
  282| _Pasar(mon, escalas) {
  283|     S.mon := mon
  284|     for esc in escalas {
  285|         S.esc := esc
  286|         for fi in [1, 3] {
  287|             S.fondoI := fi
  288|             _Reconstruir()
  289|             Sleep(400)
  290|             _Captura()
  291|             Sleep(120)
  292|         }
  293|         if (esc = 1.0) {
  294|             for o in S.wins.Clone() {
  295|                 if (o.kind = "slider")
  296|                     _SetSlider(o, 25)
  297|                 else
  298|                     _Toggle(o)
  299|             }
  300|             Sleep(200)
  301|         }
  302|     }
  303| }
```

Cierro la cuenta de tu D1 con los numeros reales del barrido: `_Pasar(prim, [0.75, 1.0, 1.5])` =
3 escalas x 2 fondos x 2 = **12 PNG**, mas `_Pasar(otro, [1.0, 1.5])` = 2 x 2 x 2 = **8**. Total 20,
como escribiste, pero por 12+8 y no por "5 escalas". El `if (esc = 1.0)` que eliminas es el unico
sitio donde hoy se conmutan las ventanas, y solo al 100 %; con tu D1 pasa a todas las escalas.
Ningun analisis existente depende de "solo 100 %": el modo `--oculto` no usa `_Pasar`.

---

## S4 — La funcion que construye `anclas`: `MapaAnclas(lineas)` (spike v4 l.240-288)

```text
  240| MapaAnclas(lineas) {
  241|     nombres := ["_FadeAlpha", "_LimpiarAvisos", "_LimpiarGUIs", "MostrarHUD", "MostrarMiniTexto", "MostrarBadgeCombo"
  242|         , "MostrarTooltipToggle", "MostrarIconoHerramienta", "MostrarMiniGUI", "_OcultarHUDSi", "Sanar"
  243|         , "IniciarDsGUI", "IniciarCcGUI", "IniciarArGUI", "IniciarHCGUI", "IniciarLockGUI", "IniciarFrenteGUI"
  244|         , "IniciarEstabBtnGUI", "IniciarEstabGUI", "ActualizarEstabGUI", "_EstabCalcular", "_EstabLayout"
  245|         , "_EstabKnobRegion", "_EstabRegion", "_EstabEmitir", "_EstabEnviarDelta", "IniciarReloadGUI"
  246|         , "IniciarPuntosGUI", "_SetIcono", "_RutaIcono", "_IconosB64", "_PosGuiIniPath", "_AnclaBloquePaneles"
  247|         , "AbrirPanelPuntos", "_ArrastrarPanelBloque", "MostrarGUIEnfoque", "IniciarDialGUI"]
  248|     res := Map()
  249|     for n in nombres
  250|         res[n] := {lin: 0, usos: 0, firma: ""}
  251|     for i, l in lineas {
  252|         for n in nombres {
  253|             if RegExMatch(l, "i)^\s*" n "\s*\(([^)]*)\)\s*(\{|=>)", &m) {
  254|                 if (res[n].lin = 0) {
  255|                     res[n].lin := i
  256|                     res[n].firma := Trim(m[1])
  257|                 }
  258|             }
  259|             if RegExMatch(l, "i)(?<![\w])" n "(?![\w])")
  260|                 res[n].usos += 1
  261|         }
  262|     }
  263|     marcas := Map("-2247 (ancla fija de avisos)", "-2247", "ancho HUD fijo 208*AVISO_ESC", "208 * AVISO_ESC", "PUNTOS[30]", "PUNTOS[30]")
  264|     cuenta := Map()
  265|     for k, v in marcas
  266|         cuenta[k] := {lin: 0, n: 0}
  267|     for i, l in lineas {
  268|         for k, v in marcas {
  269|             if InStr(l, v) {
  270|                 cuenta[k].n += 1
  271|                 if (cuenta[k].lin = 0)
  272|                     cuenta[k].lin := i
  273|             }
  274|         }
  275|     }
  276|     s := "Anclas del canonico (linea de definicion | usos totales por nombre)`r`n"
  277|     s .= "Lineas: " lineas.Length "`r`n`r`n"
  278|     for n in nombres
  279|         s .= Format("{:-28}  def={:5}  usos={:4}  ({})", n, res[n].lin, res[n].usos, res[n].firma) "`r`n"
  280|     s .= "`r`nMarcas de hallazgos del PLAN (primera linea | apariciones)`r`n"
  281|     for k, v in cuenta
  282|         s .= Format("{:-34}  linea={:5}  n={:3}", k, v.lin, v.n) "`r`n"
  283|     s .= "`r`nLectura: _FadeAlpha usos=0 -> I12 sin objeto. _LimpiarAvisos def>0 -> D2 cerrada.`r`n"
  284|     ruta := A_ScriptDir "\anclas_canonico.txt"
  285|     try FileDelete(ruta)
  286|     FileAppend(s, ruta, "UTF-8")
  287|     return res
  288| }
```

Y el sitio donde se elige que se mide (spike v4 l.124-132, dentro de `Principal()`; en la v3 era tu
l.110):

```text
  124|     llamadas := Map()
  125|     for nombre in ["MostrarHUD", "MostrarMiniTexto", "ActualizarEstabGUI"] {
  126|         if !anclas.Has(nombre) || anclas[nombre].lin = 0 {
  127|             Rep("AVISO: " nombre " no se encontro en el canonico, no se medira.")
  128|             continue
  129|         }
  130|         llamadas[nombre] := ArmarLlamada(nombre, anclas[nombre].firma)
  131|         Rep(nombre "(" anclas[nombre].firma ")  ->  " llamadas[nombre])
  132|     }
```

Para dar la base de F2 son **dos ediciones, no una**, y ninguna toca `ArmarLlamada`:

1. `MapaAnclas`, array `nombres` (l.241-247): anadir `"ActualizarDsGUI"` — y las otras cinco
   hermanas si quieres la familia entera.
2. `Principal()`, l.125: anadir el mismo nombre a la lista que construye `llamadas` (de ahi sale la
   tabla que se mide).

Firmas reales del ESTABLE, medidas:

```text
 2264| ActualizarDsGUI() {
 2311| ActualizarCcGUI() {
 2358| ActualizarArGUI() {
 2405| ActualizarHCGUI() {
 2452| ActualizarLockGUI() {
 2499| ActualizarFrenteGUI() {
 2554| ActualizarEstabBtnGUI() {
```

`ArmarLlamada` ya devuelve `nombre "()"` cuando la firma esta vacia, asi que **no hace falta entrada
en `fijas`** para ellas (a diferencia de `ActualizarEstabGUI`, que si necesita el `forzar := true`
para no devolver el guard en ~0,02 ms). Y segun la lectura 1 de S2, la copia tiene las ventanas
creadas, asi que mide el cuerpo real y no un fallo de precondicion.

Salida completa de `anclas_canonico.txt` contra el ESTABLE (la misma que ahora esta pegada en
CONTEXTO §2):

```text
Anclas del canonico (linea de definicion | usos totales por nombre)
Lineas: 3959

_FadeAlpha                    def=  563  usos=   7  (hwnd,hasta,pasos := 6,delayMs := 10)
_LimpiarAvisos                def=    0  usos=   0  ()
_LimpiarGUIs                  def= 1542  usos=   4  ()
MostrarHUD                    def= 1610  usos=  69  (texto,colorBarra := "00E5FF",duracion := 1200)
MostrarMiniTexto              def= 1711  usos=  33  (texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")
MostrarBadgeCombo             def= 1564  usos=   5  (comboText,toolText,colorAcento := "00E5FF",duracion := 2200)
MostrarTooltipToggle          def= 1758  usos=   5  (titulo,simbolo,color)
MostrarIconoHerramienta       def= 1663  usos=   3  (tipo,duracion := 700)
MostrarMiniGUI                def= 1738  usos=   1  (texto,colorHex := "222222",duracion := 1200)
_OcultarHUDSi                 def= 1647  usos=   2  (hwnd)
Sanar                         def=    0  usos=   0  ()
IniciarDsGUI                  def= 2247  usos=   3  ()
IniciarCcGUI                  def= 2281  usos=   3  ()
IniciarArGUI                  def= 2328  usos=   3  ()
IniciarHCGUI                  def= 2375  usos=   3  ()
IniciarLockGUI                def= 2422  usos=   3  ()
IniciarFrenteGUI              def= 2469  usos=   3  ()
IniciarEstabBtnGUI            def= 2524  usos=   3  ()
IniciarEstabGUI               def= 2585  usos=   3  ()
ActualizarEstabGUI            def= 2742  usos=   9  (v := -1,forzar := false)
_EstabCalcular                def= 2679  usos=   3  (w,h)
_EstabLayout                  def= 2705  usos=   6  (w,h)
_EstabKnobRegion              def= 2724  usos=   2  ()
_EstabRegion                  def= 2733  usos=   6  (w,h)
_EstabEmitir                  def= 2909  usos=   5  (tecla,n,pausa := ESTAB_RITMO)
_EstabEnviarDelta             def= 2921  usos=   5  (nuevo)
IniciarReloadGUI              def= 3181  usos=   2  ()
IniciarPuntosGUI              def= 3376  usos=   2  ()
_SetIcono                     def= 3910  usos=  17  (ctrl,nombre)
_RutaIcono                    def= 3916  usos=   2  (nombre)
_IconosB64                    def= 3953  usos=   3  ()
_PosGuiIniPath                def= 2061  usos=  31  ()
_AnclaBloquePaneles           def= 2088  usos=   8  ()
AbrirPanelPuntos              def= 3440  usos=   3  ()
_ArrastrarPanelBloque         def= 2109  usos=   8  (hwndClick,lParam,guiObj)
MostrarGUIEnfoque             def= 1926  usos=   2  ()
IniciarDialGUI                def= 2230  usos=   2  ()

Marcas de hallazgos del PLAN (primera linea | apariciones)
-2247 (ancla fija de avisos)        linea= 1576  n=  2
PUNTOS[30]                          linea= 1679  n=  2
ancho HUD fijo 208*AVISO_ESC        linea= 1620  n=  1
```

---

## S5 — CONTEXTO.md actualizado con tus 6 puntos de §5

Respaldo: `CONTEXTO.md.bak-ronda5-20261105-000043` (misma carpeta). Cambios aplicados:

| Punto tuyo | Como quedo |
|---|---|
| §0 | filas nuevas: archivo objetivo ESTABLE, lineas + SHA, `_EstabEmitir` l.2909 con RACHA 10 / RITMO 18, huella 29/2/3. Ademas "Prueba de carga" dice PASS sobre ESTABLE+F1 y la fila del arnes cita el respaldo de la recalibracion. |
| §2 | el mapa viejo (lineas del canonico) sustituido por la tabla de anclas del ESTABLE de arriba, con la nota de que `usos` cuenta lineas y no llamadas. |
| I7 | presupuesto por ola, por `ReadAllLines`. |
| I11 despues | anadidas I12 e I13 literalmente como las escribiste. |
| §4.5 | anadidos `_TemaValido()` `_TemaFuente()` `_FuenteInstalada()` `_RolDeHex()` `_AvisoColor()` `_LimpiarAvisos()` (F3). |
| §7 | las dos filas nuevas (deuda de `_LimpiarGUIs` desde las funciones de aviso, y la GUI huerfana entre `Gui()` y `floatGui`). |

Tres ajustes de coherencia que anadi sin que los pidieras (dime si prefieres alguno revertido): I5
cita `_EstabEmitir` en l.2909 en vez de 2865; §9 dice huella 29/2/3 y consigna el 31/2/3 del
canonico entre parentesis; §6 lleva una nota de que la columna **Toca** son lineas del canonico y
que al editar se ancle por nombre con §2. La fecha del encabezado pasa a 2026-11-05.

**Segunda pasada sobre §0, despues de S1 y S2** (el archivo hoy tiene 401 lineas, SHA
`B8EF05B1…D72E61`; respaldo de la primera pasada `CONTEXTO.md.bak-ronda5-20261105-000043`):

| Fila | Que dice ahora |
|---|---|
| Lineas / SHA | **4.038** y `DC012821…2FEED5`; la fila anterior decia 3.959 / `6375B86D…3A7D` |
| F1 | anexado l.3.960-4.038, con su backup `…bak-ola1-20261105-002400` y la nota de que es **append al final: ninguna ancla de §2 se desplaza** |
| Guardas del anexo | 0 lineas alteradas, validate exit 0, y el episodio del rollback por exigir 4.040 |
| Latencias base | la tabla de N=10 de S2, incluida **I13-b: ~1 ms real contra techo de 35 ms** |
| Instancias AHK | una sola del companion; se va la fila de "3 del 2-nov + 1 del 4-nov" que apuntaba a un §9.1 que ya no describe esto |
| Efecto de editar el real | fila nueva: `CheckReload()` recarga el companion en ~2 s (17336 -> 22380+12532) y **cada edicion corta la sesion de dibujo** |
| I7 | "base 3.959; F1 anexado deja 4.038 (+79, dentro del presupuesto; los 4.040 eran 2 lineas en blanco de sobra)" |
| §8 | "no leer las 4.038 lineas completas" (antes 3.959) |

La fila de `CheckReload` esta escrita como hecho verificado, no como invariante. Si lo quieres en
forma de I14, la redaccion seria: **"anexar o editar el ESTABLE recarga la instancia en produccion
en ~2 s; las ediciones se programan entre sesiones de dibujo, no dentro"**. Dime y la añado despues
de I13.

---

## S6 — Lo que necesito para cerrar la ronda 6

1. El resultado de la prueba de 20 s del slider (S1) y el visto bueno de Josue de que el companion
   recargado va normal. Es lo unico que sigue abierto del §6 de la ronda 4.
2. Tu lectura de las dos notas de S2 (ventanas creadas en la copia = la base no es "todo oculto").
   Si aceptas la interpretacion, la corrida con N=10 es directamente comparable con lo que se
   mida en F2, y el techo de I13-a (~2 ms) queda aplicado a funciones de tipo repintado.
3. Si aceptas `_base`/`_flip` en vez de `_a`/`_b` y quitar el `_Par(25)` muerto: aplico el parche D
   sobre una copia de `galeria.ahk` y corro el barrido de 20 PNG en el segundo monitor, con la lista
   de nombres (no las imagenes) y el log de redibujos ON/OFF.
4. Si va I14, y si quieres que la ola 1 empiece ya: proponme el primer lote de anclas de color (las
   que cambian de literal a `_Tema("color",…)`), con su orden y su presupuesto de lineas. El archivo
   esta en 4.038 y con el budget de I7 sin usar.

Sin PNG adjuntos, como pediste. Ningun `.ahk` ejecutable queda en `rd3`: el spike v4 vive como
`.txt` y las corridas se lanzan desde una copia en `%TEMP%\ronda5_spike\`.

