# Extractos de la ronda 3 (pedidos 2 y 3)

Generado 2026-11-04 22:46:28. Numeracion = linea real de cada archivo. Nada transcrito a mano.

## Pedido 2 — galeria.ahk (ENTREGA CLAUDE 2)
Archivo: galeria.ahk · 1030 lineas · SHA f611a498855e13729fbf4f0d9f9f18b2ede84df3e1c6500d4f044766f2a69761

### _AutoCapturas() — l.270-296
```ahk
 270| _AutoCapturas() {
 271|     S.offx := 0
 272|     prim := MonitorGetPrimary()
 273|     otro := (MonitorGetCount() > 1) ? ((prim = 1) ? 2 : 1) : prim
 274|     _Log("=== MODO CAPTURAS | monitor principal " prim " | secundario " otro " ===")
 275|     _Pasar(prim, [0.75, 1.0, 1.5])
 276|     if (otro != prim)
 277|         _Pasar(otro, [1.0, 1.5])
 278|     _Log("=== FIN capturas | errores: " S.errores " ===")
 279|     ExitApp(S.errores ? 1 : 0)
 280| }
 281| 
 282| _Pasar(mon, escalas) {
 283|     S.mon := mon
 284|     for esc in escalas {
 285|         S.esc := esc
 286|         for fi in [1, 3] {
 287|             S.fondoI := fi
 288|             _Reconstruir()
 289|             Sleep(400)
 290|             _Captura()
 291|             Sleep(120)
 292|         }
 293|         if (esc = 1.0) {
 294|             for o in S.wins.Clone() {
 295|                 if (o.kind = "slider")
 296|                     _SetSlider(o, 25)
```

### _Pasar(mon, escalas) — el barrido real, l.282-304
```ahk
 282| _Pasar(mon, escalas) {
 283|     S.mon := mon
 284|     for esc in escalas {
 285|         S.esc := esc
 286|         for fi in [1, 3] {
 287|             S.fondoI := fi
 288|             _Reconstruir()
 289|             Sleep(400)
 290|             _Captura()
 291|             Sleep(120)
 292|         }
 293|         if (esc = 1.0) {
 294|             for o in S.wins.Clone() {
 295|                 if (o.kind = "slider")
 296|                     _SetSlider(o, 25)
 297|                 else
 298|                     _Toggle(o)
 299|             }
 300|             Sleep(200)
 301|         }
 302|     }
 303| }
 304| 
```

### _DescVentana(hw) + _Ocluyentes(x,y,w,h) — l.305-350
```ahk
 305| _DescVentana(hw) {
 306|     if !hw
 307|         return "(ninguna)"
 308|     cls := ""
 309|     exe := ""
 310|     try cls := WinGetClass("ahk_id " hw)
 311|     try exe := WinGetProcessName("ahk_id " hw)
 312|     return exe " [" cls "]"
 313| }
 314| 
 315| ; Ventanas ajenas, visibles y siempre-visibles (topmost) que tapan el rectangulo.
 316| ; Solo las topmost pueden cubrir al stage, que tambien es topmost.
 317| _Ocluyentes(x, y, w, h) {
 318|     res := []
 319|     propios := Map()
 320|     for o in S.wins
 321|         propios[o.hwnd] := 1
 322|     if IsObject(S.stage)
 323|         propios[S.stage.Hwnd] := 1
 324|     for hw in WinGetList() {
 325|         if propios.Has(hw)
 326|             continue
 327|         try {
 328|             if !(WinGetExStyle("ahk_id " hw) & 0x8)
 329|                 continue
 330|             if (WinGetMinMax("ahk_id " hw) = -1)
 331|                 continue
 332|             cls := WinGetClass("ahk_id " hw)
 333|             if (cls = "Shell_TrayWnd" || cls = "Shell_SecondaryTrayWnd")
 334|                 continue
 335|             WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hw)
 336|         } catch {
 337|             continue
 338|         }
 339|         if (wx < x + w && wx + ww > x && wy < y + h && wy + wh > y)
 340|             res.Push(_DescVentana(hw) " " ww "x" wh " en " wx "," wy)
 341|     }
 342|     return res
 343| }
 344| 
 345| _PosLibre(sw, sh, l, t, r, b) {
 346|     cands := []
 347|     if (POS_X != "")
 348|         cands.Push([POS_X, POS_Y])
 349|     cands.Push([l + 10, t + 10], [r - sw - 10, t + 10], [l + 10, b - sh - 10], [r - sw - 10, b - sh - 10], [l + (r - l - sw) // 2, t + (b - t - sh) // 2])
 350|     mejor := cands[1]
```

### _Captura(*) — BitBlt del DC de pantalla + marca _OCLUIDA, l.699-731
```ahk
 699| _Captura(*) {
 700|     if !IsObject(S.stage) || (OCULTO && !CAPTURAS)
 701|         return
 702|     WinGetPos(&x, &y, &w, &h, "ahk_id " S.stage.Hwnd)
 703|     ocl := _Ocluyentes(x, y, w, h)
 704|     for d in ocl
 705|         _Log("  OCLUSION en la captura: " d)
 706|     hdcS := DllCall("user32\GetDC", "ptr", 0, "ptr")
 707|     hdc := DllCall("gdi32\CreateCompatibleDC", "ptr", hdcS, "ptr")
 708|     hbm := DllCall("gdi32\CreateCompatibleBitmap", "ptr", hdcS, "int", w, "int", h, "ptr")
 709|     old := DllCall("gdi32\SelectObject", "ptr", hdc, "ptr", hbm, "ptr")
 710|     DllCall("gdi32\BitBlt", "ptr", hdc, "int", 0, "int", 0, "int", w, "int", h, "ptr", hdcS, "int", x, "int", y, "uint", 0x40CC0020)
 711|     DllCall("gdi32\SelectObject", "ptr", hdc, "ptr", old)
 712|     bmp := 0
 713|     DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", hbm, "ptr", 0, "ptr*", &bmp)
 714|     clsid := Buffer(16, 0)
 715|     DllCall("ole32\CLSIDFromString", "str", "{557CF406-1A04-11D3-9A73-0000F81EF32E}", "ptr", clsid)
 716|     ruta := A_ScriptDir "\captura_" Round(S.esc * 100) "_" FONDOS[S.fondoI][1] "_m" S.mon "_" FormatTime(, "HHmmss") (ocl.Length ? "_OCLUIDA" : "") ".png"
 717|     st := DllCall("gdiplus\GdipSaveImageToFile", "ptr", bmp, "str", ruta, "ptr", clsid, "ptr", 0, "int")
 718|     DllCall("gdiplus\GdipDisposeImage", "ptr", bmp)
 719|     DllCall("gdi32\DeleteObject", "ptr", hbm)
 720|     DllCall("gdi32\DeleteDC", "ptr", hdc)
 721|     DllCall("user32\ReleaseDC", "ptr", 0, "ptr", hdcS)
 722|     _Log("Captura " (st = 0 ? "guardada" : "FALLO (gdiplus=" st ")") ": " ruta)
 723| }
 724| 
 725| ; ---------------------------------------------------------------------
 726| ; Capa L1 de ejemplo: _Superficie(hwnd, w, h, radio, modo)
 727| ; El texto devuelto NO es evidencia de que el redondeo se vea.
 728| ; ---------------------------------------------------------------------
 729| _Superficie(hwnd, w, h, r, modo) {
 730|     switch modo {
 731|         case "region":
```

### candidatos de posicion (lo que consume --pos=X,Y) — l.340-362
```ahk
 340|             res.Push(_DescVentana(hw) " " ww "x" wh " en " wx "," wy)
 341|     }
 342|     return res
 343| }
 344| 
 345| _PosLibre(sw, sh, l, t, r, b) {
 346|     cands := []
 347|     if (POS_X != "")
 348|         cands.Push([POS_X, POS_Y])
 349|     cands.Push([l + 10, t + 10], [r - sw - 10, t + 10], [l + 10, b - sh - 10], [r - sw - 10, b - sh - 10], [l + (r - l - sw) // 2, t + (b - t - sh) // 2])
 350|     mejor := cands[1]
 351|     menos := 99999
 352|     for c in cands {
 353|         n := _Ocluyentes(c[1], c[2], sw, sh).Length
 354|         if (n = 0)
 355|             return c
 356|         if (n < menos) {
 357|             menos := n
 358|             mejor := c
 359|         }
 360|     }
 361|     _Log("AVISO: todas las zonas candidatas tienen ventanas siempre-visibles ajenas; se usa la de menos (" menos ")")
 362|     return mejor
```

## Pedido 3 — spike_latencia.ahk PARCHADO (copia de trabajo, no la de ENTREGA CLAUDE 2)
Archivo: _f0v2/Autohotkeys_ESTETICA_F0_v2/docs/ESTETICA/spike/spike_latencia.ahk · 377 lineas · SHA 13d4bfd466a28ccc2eb63e94421295d2e9c2184ceeb969d3e797b69ea46137b9
Esta version ya tiene REPTXT, el hash real y las lamadas _LatHb; la de la entrega sigue sin cargar.

### Principal(): generador de la copia — l.96-152
```ahk
  96|             v .= A_Index ": " lineas[A_Index] "`n"
  97|         Rep("Bloque de elevacion NO reconocido. Primeras lineas:`n" v)
  98|         Guardar("latencia_base.txt")
  99|         Fin("Bloque de elevacion no reconocido en lineas 3-6. No se construye la copia.`nVer latencia_base.txt", 3)
 100|     }
 101|     dir := A_Temp "\latencia_f0"
 102|     DirCreate(dir)
 103|     copia := dir "\prueba_latencia.ahk"
 104|     salida := dir "\salida_latencia.txt"
 105|     errf := dir "\stderr_latencia.txt"
 106|     try FileDelete(salida)
 107|     try FileDelete(errf)
 108| 
 109|     llamadas := Map()
 110|     for nombre in ["MostrarHUD", "MostrarMiniTexto", "ActualizarEstabGUI"] {
 111|         if !anclas.Has(nombre) || anclas[nombre].lin = 0 {
 112|             Rep("AVISO: " nombre " no se encontro en el canonico, no se medira.")
 113|             continue
 114|         }
 115|         llamadas[nombre] := ArmarLlamada(nombre, anclas[nombre].firma)
 116|         Rep(nombre "(" anclas[nombre].firma ")  ->  " llamadas[nombre])
 117|     }
 118| 
 119|     nuevo := []
 120|     for i, l in lineas {
 121|         if (i = 3) {
 122|             nuevo.Push("; [spike_latencia] elevacion anulada SOLO en esta copia (lineas 3-6 originales)")
 123|         } else if (i >= 4 && i <= 6) {
 124|             nuevo.Push("; [spike_latencia] linea " i " original anulada")
 125|             if (i = 6) {
 126|                 nuevo.Push("Suspend(1)")
 127|                 nuevo.Push('_LatHb("autoexec: Suspend + timer registrados")')
 128|                 nuevo.Push("SetTimer(_LatBase, -2500)")
 129|             }
 130|         } else {
 131|             nuevo.Push(l)
 132|         }
 133|     }
 134|     cuerpo := ""
 135|     for l in nuevo
 136|         cuerpo .= l "`r`n"
 137|     cuerpo .= Inyectable(llamadas, N, salida)
 138|     try FileDelete(copia)
 139|     f := FileOpen(copia, "w", "UTF-8")
 140|     f.Write(cuerpo)
 141|     f.Close()
 142|     Rep("Copia desechable: " copia)
 143| 
 144|     ; ---- 4. /validate de la copia ----
 145|     codV := RunWait('"' A_AhkPath '" /validate "' copia '"', , "Hide")
 146|     Rep("/validate de la copia: exit " codV)
 147|     if (codV != 0) {
 148|         Guardar("latencia_base.txt")
 149|         Fin("La copia no pasa /validate (exit " codV "). Ver latencia_base.txt", 4)
 150|     }
 151| 
 152|     if !EJECUTAR {
```

### ArmarLlamada(nombre, firma) — l.272-303
```ahk
 272| ArmarLlamada(nombre, firma) {
 273|     if (Trim(firma) = "")
 274|         return nombre "()"
 275|     args := []
 276|     for p in StrSplit(firma, ",") {
 277|         p := Trim(p)
 278|         p := RegExReplace(p, "^[&*]+")
 279|         opc := InStr(p, ":=") > 0
 280|         nom := StrLower(Trim(RegExReplace(p, "\s*:=.*$")))
 281|         v := ""
 282|         if RegExMatch(nom, "(txt|texto|text|msg|mensaje)")
 283|             v := '"LAT"'
 284|         else if RegExMatch(nom, "(col|color|hex|clr)")
 285|             v := '"00E5FF"'
 286|         else if RegExMatch(nom, "^(ms|dur|duracion|tiempo|time|delay)")
 287|             v := "60"
 288|         if (v = "") {
 289|             if opc
 290|                 break
 291|             v := "0"
 292|         }
 293|         args.Push(v)
 294|     }
 295|     s := ""
 296|     for i, v in args
 297|         s .= (i > 1 ? ", " : "") v
 298|     return nombre "(" s ")"
 299| }
 300| 
 301| ; ---------------------------------------------------------------------
 302| ; Codigo que se anade al final de la copia (plantilla; ``n = `n en la copia)
 303| ; ---------------------------------------------------------------------
```

### Inyectable(): _LatHb / _LatQPC / _LatMedir / _LatBase — l.304-377
```ahk
 304| Inyectable(llamadas, n, salida) {
 305|     medir := ""
 306|     for nombre, expr in llamadas
 307|         medir .= '    out .= _LatMedir("' nombre '", () => ' expr ', ' n ')' "`r`n"
 308|     c := "
 309| (
 310| ; ===== inyectado por spike_latencia.ahk (solo en la copia) =====
 311| _LatHb(t) {
 312|     try FileAppend(A_TickCount " | " t "`r`n", "@@HB@@", "UTF-8")
 313| }
 314| _LatQPC() {
 315|     static f := 0
 316|     if !f
 317|         DllCall("kernel32\QueryPerformanceFrequency", "int64*", &f)
 318|     cc := 0
 319|     DllCall("kernel32\QueryPerformanceCounter", "int64*", &cc)
 320|     return cc * 1000 / f
 321| }
 322| _LatMedir(nombre, fn, n) {
 323|     _LatHb("empieza " nombre)
 324|     ts := []
 325|     err := 0
 326|     ult := ""
 327|     try {
 328|         fn.Call()
 329|     } catch as e0 {
 330|         err += 1
 331|         ult := e0.Message
 332|     }
 333|     Loop n {
 334|         t0 := _LatQPC()
 335|         try {
 336|             fn.Call()
 337|         } catch as e1 {
 338|             err += 1
 339|             ult := e1.Message
 340|         }
 341|         ts.Push(_LatQPC() - t0)
 342|         Sleep(15)
 343|     }
 344|     Loop ts.Length - 1 {
 345|         i := A_Index + 1
 346|         v := ts[i]
 347|         j := i - 1
 348|         while (j >= 1 && ts[j] > v) {
 349|             ts[j + 1] := ts[j]
 350|             j -= 1
 351|         }
 352|         ts[j + 1] := v
 353|     }
 354|     m := ts.Length // 2
 355|     med := (Mod(ts.Length, 2) = 0) ? (ts[m] + ts[m + 1]) / 2 : ts[m + 1]
 356|     p95 := ts[Max(1, Ceil(ts.Length * 0.95))]
 357|     return "| " nombre " | " ts.Length " | " Round(med, 3) " | " Round(p95, 3) " | " Round(ts[ts.Length], 3) " | " err " " ult " |``n"
 358| }
 359| _LatBase() {
 360|     _LatHb("_LatBase entro (timer disparado)")
 361|     out := "Latencias base (ms, QPC, copia esteril)``n"
 362|     out .= "| Funcion | N | mediana | p95 | max | errores |``n"
 363|     out .= "|---|---|---|---|---|---|``n"
 364| @@MEDIR@@
 365|     out .= "``nCriterio I13: cada funcion estetica nueva debe sumar <= ~2 ms sobre estas medianas.``n"
 366|     try FileDelete("@@SALIDA@@")
 367|     FileAppend(out, "@@SALIDA@@", "UTF-8")
 368|     _LatHb("salida escrita")
 369|     ExitApp()
 370| }
 371| )"
 372|     hb := StrReplace(salida, "salida_latencia.txt", "heartbeat_latencia.txt")
 373|     c := StrReplace(c, "@@MEDIR@@", RTrim(medir, "`r`n"))
 374|     c := StrReplace(c, "@@SALIDA@@", salida)
 375|     c := StrReplace(c, "@@HB@@", hb)
 376|     return "`r`n" c "`r`n"
 377| }
```

## Estado del diagnostico de huellas (para T1.2)
```text
La copia que queda en %TEMP%\latencia_f0\prueba_latencia.ahk es de la corrida 21:20 y NO tiene _LatHb:
  grep -c '_LatHb' prueba_latencia.ahk  ->  0
  sus lineas 1-8: #Requires / #SingleInstance Force / 3 comentarios / Suspend(1) / SetTimer(_LatBase, -2500)
heartbeat_latencia.txt y salida_latencia.txt NO existen; si esta stderr_latencia.txt de 0 bytes
y posiciones_gui.ini de 112 bytes (la copia llego a escribir su config).
=> Tu tabla de huellas no se puede llenar con datos existentes: hace falta una corrida nueva.
```
