import io, sys, hashlib

SRC = "spike-v3/spike_latencia.txt"
DST = "spike-v4/spike_latencia.txt"

raw = open(SRC, "rb").read()
assert raw[:3] != b"\xef\xbb\xbf"
txt = raw.decode("utf-8")
lines = txt.replace("\r\n", "\n").split("\n")
if lines and lines[-1] == "":
    lines.pop()

def find(old, n=1):
    hits = [i for i, l in enumerate(lines) if l == old]
    if len(hits) != n:
        sys.exit("ANCHOR NOT UNIQUE (%d hits): %r" % (len(hits), old))
    return hits[0]

def replace_block(first, last, new):
    global lines
    lines[first:last + 1] = new.split("\n")

# ---- Parche B: N por defecto ----
i = find("N := 20")
replace_block(i, i, "N := 10")

# ---- Parche C1: ArgsUnidos() antes del bloque de opciones ----
i = find('HASH_ESPERADO := "CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E"')
C1 = """; Une los trozos de A_Args partidos por espacios (cuando --prod= viene sin comillas).
ArgsUnidos() {
    r := []
    for a in A_Args {
        if (r.Length = 0 || SubStr(a, 1, 2) = "--")
            r.Push(a)
        else
            r[r.Length] .= " " a
    }
    return r
}
"""
lines[i:i] = C1.split("\n")

# ---- Parche C2: lectura de opciones con --sinmsg ----
a = find("FORZAR := false")
b = find('    else if (SubStr(a, 1, 7) = "--prod=")')
C2 = """FORZAR := false
SINMSG := false
for a in ArgsUnidos() {
    if (a = "--ejecutar")
        EJECUTAR := true
    else if (a = "--forzar")
        FORZAR := true
    else if (a = "--sinmsg")
        SINMSG := true
"""
replace_block(a, b - 1, C2.rstrip("\n"))

# ---- Parche A1: cabecera de ArmarLlamada con llamadas fijas ----
a = find("ArmarLlamada(nombre, firma) {")
b = find("        return nombre \"()\"")
A1 = """ArmarLlamada(nombre, firma) {
    static fijas := Map("ActualizarEstabGUI", "ActualizarEstabGUI(25, true)")
    if fijas.Has(nombre)
        return fijas[nombre]
    if (Trim(firma) = "")
        return nombre "()"
"""
replace_block(a, b, A1.rstrip("\n"))

# ---- Parche A2: el color gana y va anclado al inicio ----
a = find('        if RegExMatch(nom, "(txt|texto|text|msg|mensaje)")')
b = a + 3
old = lines[a:b + 1]
assert old == ['        if RegExMatch(nom, "(txt|texto|text|msg|mensaje)")',
               "            v := '\"LAT\"'",
               '        else if RegExMatch(nom, "(col|color|hex|clr)")',
               "            v := '\"00E5FF\"'"], old
A2 = """        if RegExMatch(nom, "^(col|clr|hex)")
            v := '"00E5FF"'
        else if RegExMatch(nom, "(txt|texto|text|msg|mensaje)")
            v := '"LAT"'
"""
replace_block(a, b, A2.rstrip("\n"))

# ---- Parche C3: Fin() sin MsgBox con --sinmsg ----
a = find("Fin(msg, cod) {")
m = find('    MsgBox(msg, "spike_latencia", cod = 0 ? "Iconi" : "Icon!")')
assert lines[a + 1] == lines[m] and lines[m + 1] == "    ExitApp(cod)" and lines[m + 2] == "}", lines[a:m + 3]
b = m + 2
C3 = """Fin(msg, cod) {
    global SINMSG
    if SINMSG {
        Rep("FIN (cod " cod "): " msg)
        try Guardar("latencia_base.txt")
        ExitApp(cod)
    }
    MsgBox(msg, "spike_latencia", cod = 0 ? "Iconi" : "Icon!")
    ExitApp(cod)
}
"""
replace_block(a, b, C3.rstrip("\n"))

out = "\r\n".join(lines) + "\r\n"
open(DST, "wb").write(out.encode("utf-8"))
res = open(DST, "rb").read()
print("lineas:", len(lines))
print("sha256:", hashlib.sha256(res).hexdigest().upper())
low = "\n".join(lines).lower()
print("colision sinmsg (fuera de C2/C3):", low.count("sinmsg"))
