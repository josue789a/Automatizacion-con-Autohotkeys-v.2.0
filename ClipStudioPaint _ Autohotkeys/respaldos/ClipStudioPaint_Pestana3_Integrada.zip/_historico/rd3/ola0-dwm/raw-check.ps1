param([string]$Archivo = '', [switch]$Correr, [int]$TimeoutSeg = 15)
$ErrorActionPreference = 'Stop'
if (-not $Archivo) { Write-Host 'falta -Archivo'; exit 2 }
$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$sw = if ($Correr) { "/ErrorStdOut `"$Archivo`"" } else { "/validate /ErrorStdOut `"$Archivo`"" }
$p = New-Object System.Diagnostics.Process
$si = $p.StartInfo
$si.FileName = $exe
$si.Arguments = $sw
$si.UseShellExecute = $false
$si.CreateNoWindow = $true
$si.RedirectStandardError = $true
$si.RedirectStandardOutput = $true
[void]$p.Start()
$re = $p.StandardError.ReadToEndAsync()
$ro = $p.StandardOutput.ReadToEndAsync()
$estado = 'salio'
if (-not $p.WaitForExit($TimeoutSeg * 1000)) {
    $estado = "COLGO (matado a los $TimeoutSeg s)"
    try {
        $p.Refresh()
        Write-Host "  ventana viva: [$($p.MainWindowTitle)] (pid $($p.Id))"
    } catch { Write-Host "  (sin MainWindowTitle)" }
    $p.Kill()
}
$err = ''
$out = ''
if ($re.Wait(2000)) { $err = $re.Result }
if ($ro.Wait(2000)) { $out = $ro.Result }
$code = '?'
try { $code = $p.ExitCode } catch { }
Write-Host "$estado exit=$code"
Write-Host "stderr: [$err]"
Write-Host "stdout: [$out]"
