# OLA 2 — la prueba que pidió Claude (región en hijo bajo padre layered)

Medida en el PC de Josue, 2026-11-05, AHK 2.0.26, Windows 10.0.26200, monitor 1 de 1
(1920x1080). Pantalla real, píxel a píxel; nada de PrintWindow (ola 0 demostró que no
reproduce el arco ni el alfa).

## Pregunta y respuesta

> «No hay dato de SetWindowRgn sobre un Text hijo dentro de un padre con WS_EX_LAYERED.
> Antes de generalizar la ola 2, una sola prueba: una pill con región, a alfa 235 y 40,
> mirando el píxel d0 de la esquina. Si el padre layered rompe la región, se pasa a (b)
> solo para esas pills.»

**El padre layered NO rompe la región. Opción (a) confirmada; el plan (b) no hace falta.**

## Diseño

7 padres `-Caption` (sin `+Border`, BackColor `1A1A2E`) × 3 hijos `Text` rojos `FF0000`
de 120x40:

| hijo | qué se le hizo |
|---|---|
| A | `CreateRoundRectRgn(0, 0, w+1, h+1, R, R)` → caja en **coords del propio control** |
| B | `CreateRoundRectRgn(160, 16, 281, 57, R, R)` → caja en **coords del cliente del padre** (lo que documenta MSDN para ventanas hijas) |
| C | sin región → esquina cuadrada de referencia |

Padres: `norm` (sin `WinSetTransparent`, ex-style 0x88), `al255` / `al235` / `al40`
(0x80088, región **antes** del alfa), `al40rec` (alfa 40 + DWM `33=1`, recto) y dos
padres más con el **alfa puesto antes de la región** (`alfa235`, `alfa40`) para cerrar
también el orden de llamadas.

## Resultado — retícula de la esquina superior izquierda (11×11, `#` = rojo del hijo,
## `o` = color del padre, `.` = fuera de la caja; elipse R=16 → radio esperado 8)

```
A-norm                    A-alfa235                 A-alfa40
....ooooooo#              ....ooooooo#              ....ooooooo#
....oooo###               ....oooo###               ....oooo###
....oooo###               ....oooo###               ....oooo###
....oo#oo##               ....oo#oo##               ....oo#oo##
....o###o##     ==        ....o###o##     ==        ....o###o##
....o#o####               ....o#o####               ....o#o####
....o#o##o#               ....o#o##o#               ....o#o##o#
refs hijo(255,0,0)        refs hijo(237,2,2)        refs hijo(61,23,22)
     padre(26,26,46)           padre(26,26,44)           padre(25,27,29)
```

Las tres son **idénticas píxel a píxel**. Con R=8 la forma es la misma y el rojo arranca
en `dx=4`. En la corrida completa (21 hijos) el veredicto automático:

| caso | d0 | rojo en fila 0 desde | centro | abajo-derecha |
|---|---|---|---|---|
| A-norm | PADRE | dx=7 | HIJO | PADRE |
| A-al255 | PADRE | dx=7 | HIJO | PADRE |
| A-al235 | PADRE | dx=7 | HIJO | PADRE |
| A-al40 | PADRE | dx=7 | HIJO | PADRE |
| A-al40 (alfa antes) | PADRE | dx=7 | HIJO | PADRE |
| B (cualquiera) | HIJO | dx=0 | HIJO | HIJO |
| C (sin región) | HIJO | dx=0 | HIJO | HIJO |

## Lo que se decide con esto

1. **Receta válida:** la caja de la región se pasa **en coordenadas del propio control**
   `(0, 0, w+1, h+1)`. La variante "coords del cliente del padre" — la que MSDN describe
   para ventanas hijas — devuelve `SetWindowRgn=1` (éxito) y **no pinta nada**: el control
   sigue cuadrado y entero. Es un *no-op* silencioso, la trampa real de esta prueba:
   `rc=1` no significa nada aquí. Solo el píxel lo dice.
2. **Recorta las cuatro esquinas** (`abajo-derecha = PADRE` con R=16) → es una pill de
   verdad, no dos esquinas redondeadas.
3. **Relación elipse→radio, medida en dos puntos:** `(8,8)` → 4 px, `(16,16)` → 8 px.
   O sea **elipse = 2 × radio**. Por tanto `sm=8 ⇒ (16,16)` y `md=12 ⇒ (24,24)`. El tope
   es alto/2 (con h=40: radio máximo 20). GDI no tiene el límite de 3 valores del arco de
   ventana, así que los tokens `[radius] sm/md` sí tienen sentido para recorte propio.
4. **Coste `t_rgn` = 0,0 ms** por control (4 de 5 llamadas; un *outlier* de 16,0 ms en la
   primera). Frente a los **15-63 ms por ventana** de la opción (b): para 30 pills, (a)
   ≈ 0 ms y (b) ≈ 0,45-1,9 s extra **en cada arranque y en cada recarga del companion**.
   El número de Claude se confirma y la opción (a) gana por coste, no solo por comodidad.
5. **Sigue sin poder pedirse el arco por control:** `DwmSetWindowAttribute(hijo, 33)` =
   `-2147024890` (`0x80070006` ERROR_INVALID_HANDLE) en los 21 hijos. La región es el
   único camino para un control hijo.
6. **Sin antialias**, como declaró Claude: los cortes son duros (`o`/`#` sin puntos
   intermedios). Con radio 8 sobre 40 px de alto se ve aceptable; no hay gradiente.
7. **El alfa del padre no interfiere en ningún orden**: 235 y 40, región antes o después.
   `_FadeAlpha` puede seguir recorriendo los pasos sin tocar la región.

## Límites honestos de la prueba

- Probado con `Gui.AddText` (Static) con `BackgroundFF0000` y una letra de texto, dentro
  de una Gui de AHK `-Caption`. No probado sobre un control propio dibujado a mano.
- La segunda fila de padres (`y=210`) salió **oculta por ventanas de otros programas**:
  esa corrida tiró dos filas sucias (`A-rgn235`, `B-al40` de la fila 2). Las retículas de
  arriba son de la fila `y=60`, sin solapamientos.
- No se midió el repintado del texto con la región puesta (el glifo del hijo se siguió
  pintando dentro del recorte, que es el caso normal de una pill etiquetada).
- El outlier de 16 ms en `t_rgn` no se aisló: si aparece al construir las 30 pills, se
  mide otra vez; no cambia la comparación con 15-63 ms.

## Reproducible

```powershell
cd "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\ola0-dwm"
powershell -NoProfile -ExecutionPolicy Bypass -File .\chk.ps1 -Archivo probe_rgn.txt          # /validate
powershell -NoProfile -ExecutionPolicy Bypass -File .\foto_rgn.ps1 -Seg 24 -R 16              # 5 padres
powershell -NoProfile -ExecutionPolicy Bypass -File .\foto_rgn.ps1 -Seg 24 -R 8               # misma con radio 4
powershell -NoProfile -ExecutionPolicy Bypass -File .\foto_rgn.ps1 -Seg 24 -R 16 -Orden 1 -Esperado 16   # alfa antes de la region
powershell -NoProfile -ExecutionPolicy Bypass -File .\rejilla.ps1 -Nombres 'A-norm,A-alfa235,A-alfa40' -Tam 11
```

Archivos: `probe_rgn.txt` (el probe), `foto_rgn.ps1` (corrida + veredicto automático),
`rejilla.ps1` (retícula de píxeles), `fotos-rgn\*.png` (recortes de esta corrida),
`fotos-rgn-r8\` (la corrida con radio 4), `rejilla_r16.txt`, `rejilla_orden.txt`.
