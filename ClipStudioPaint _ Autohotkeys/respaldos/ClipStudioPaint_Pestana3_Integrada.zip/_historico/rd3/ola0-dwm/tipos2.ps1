param([string]$Ruta = 'C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\ola0-dwm\fotos-rgn\A-norm_izq.png')
Add-Type -AssemblyName System.Drawing
$bmp = [System.Drawing.Bitmap]::FromFile($Ruta)
$W = $bmp.Width
$px = New-Object 'int[]' ($W * $bmp.Height)
Write-Host ('px tipo=' + $px.GetType().FullName + ' len=' + $px.Length + ' W=' + $W)
for ($y = 0; $y -lt $bmp.Height; $y++) {
    for ($x = 0; $x -lt $W; $x++) {
        $c = $bmp.GetPixel($x, $y)
        $px[$y * $W + $x] = $c.R * 65536 + $c.G * 256 + $c.B
    }
}
$vh = $px[13 * $W + 13]
Write-Host ('vh tipo=' + $vh.GetType().FullName + ' val=' + $vh)
$idx = 13 * $W + 13
Write-Host ('idx=' + $idx)
