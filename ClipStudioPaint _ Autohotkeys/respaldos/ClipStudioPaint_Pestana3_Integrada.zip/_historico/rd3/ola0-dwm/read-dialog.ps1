param([int]$Espera = 12)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes, WindowsBase
$ahk = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$probe = Join-Path $env:TEMP 'ola0_dwm\probe_dwm.ahk'
$out = Join-Path $env:TEMP 'ola0_dwm\ola0_dwm.txt'
Remove-Item $out -ErrorAction SilentlyContinue

$p = Start-Process $ahk -ArgumentList "`"$probe`" --secs=3 --monitor=2 --out=$out" -PassThru
"pid: $($p.Id)"
Start-Sleep -Seconds 2

$texto = ''
$ventanas = $null
for ($i = 0; $i -lt $Espera; $i++) {
    $roots = [System.Windows.Automation.AutomationElement]::RootElement.FindAll(
        [System.Windows.Automation.TreeScope]::Children,
        [System.Windows.Automation.PropertyCondition]::new(
            [System.Windows.Automation.AutomationElement]::ProcessIdProperty, $p.Id))
    if ($roots.Count -gt 0) { break }
    Start-Sleep -Milliseconds 700
}
"ventanas del pid: $($roots.Count)"
foreach ($w in $roots) {
    $title = $w.Current.Name
    $cond = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::Text)
    $t = $w.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
    Write-Host "--- ventana: $title ---"
    foreach ($el in $t) { $texto += $el.Current.Name + "`n" }
    $condB = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::Button)
    $b = $w.FindAll([System.Windows.Automation.TreeScope]::Descendants, $condB)
    foreach ($btn in $b) {
        try { $btn.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); "pulsado botones: OK" } catch {}
    }
}
Write-Host ''
Write-Host '==================== texto del cuadro ===================='
if ($texto.Trim()) { $texto } else { '(la ventana no tenia texto: abrio las 4 ventanas y fue OK)' }
Start-Sleep -Seconds 1
if (Get-Process -Id $p.Id -ErrorAction SilentlyContinue) {
    Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
    "probe terminado por el driver"
}
Write-Host '==================== ola0_dwm.txt ===================='
if (Test-Path $out) { Get-Content $out } else { '(no existe: no llego a escribir)' }
