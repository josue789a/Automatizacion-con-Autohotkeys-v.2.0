# pw.ps1 — PrintWindow por hwnd desde PowerShell (GDI+ de AHK no encuentra codificadores:
# todo Save devuelve 10, incluso sobre una imagen creada por el propio GDI+).
# Mide D4: que PrintWindow no devuelva negro, con flags 0 y 2, sobre ventana normal,
# sin caption, con acrylic y layered.
param(
    [int]$Monitor = 1,
    [int]$Seg = 14,
    [switch]$Muestra
)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'Ola0.cs') -ReferencedAssemblies 'System.Drawing.dll', 'System.dll'

$src = Join-Path $PSScriptRoot 'probe_dwm.txt'
$dir = Join-Path $env:TEMP 'ola0_run'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$ahk = Join-Path $dir 'probe_dwm.ahk'
$live = Join-Path $dir 'live.txt'
$U8 = New-Object System.Text.UTF8Encoding($false)
[IO.File]::WriteAllLines($ahk, [IO.File]::ReadAllLines($src), $U8)
if (Test-Path $live) { Remove-Item $live -Force }
$fotos = Join-Path $PSScriptRoot 'fotos'
New-Item -ItemType Directory -Force -Path $fotos | Out-Null

$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$p = New-Object System.Diagnostics.Process
$si = $p.StartInfo
$si.FileName = $exe
$si.Arguments = '/ErrorStdOut "' + $ahk + '" --secs=' + $Seg + ' --out=' + $live + ' --monitor=' + $Monitor
$si.UseShellExecute = $false
$si.CreateNoWindow = $true
$si.RedirectStandardError = $true
[void]$p.Start()
$re = $p.StandardError.ReadToEndAsync()

function Read-Live([string]$ruta) {
    if (-not (Test-Path $ruta)) { return '' }
    try { $fs = [System.IO.File]::Open($ruta, 'Open', 'Read', 'ReadWrite') } catch { return '' }
    $sr = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8)
    $t = $sr.ReadToEnd(); $sr.Close(); $fs.Close()
    return $t
}

$lineas = @()
$limite = (Get-Date).AddSeconds(10)
while ((Get-Date) -lt $limite) {
    $txt = Read-Live $live
    $lineas = @($txt -split "`r?`n" | Where-Object { $_ -match '^\S+\s+hwnd=\d+' })
    if ($lineas.Count -ge 11) { break }
    Start-Sleep -Milliseconds 250
}
Write-Host "ventanas vistas en el log: $($lineas.Count)"

foreach ($ln in $lineas) {
    $n = ($ln -split '\s+')[0]
    $hw = [IntPtr]([int64][regex]::Match($ln, 'hwnd=(\d+)').Groups[1].Value)
    foreach ($fl in 0, 2) {
        $ruta = Join-Path $fotos ('pw-' + $n + '-f' + $fl + '.png')
        try {
            $r = [Ola0]::Captura($hw, $ruta, $fl)
            Write-Host ("  {0,-16} flags={1}  {2}" -f $n, $fl, $r)
        } catch {
            Write-Host ("  {0,-16} flags={1}  EXCEPCION {2}" -f $n, $fl, $_.Exception.Message)
        }
    }
}

Write-Host ''
if (-not $p.WaitForExit(($Seg * 1000))) { $p.Kill(); Write-Host '(probe matado)' }
$e = ''
if ($re.Wait(1500)) { $e = $re.Result }
if ($e) { Write-Host "stderr: $e" }
Write-Host '--- log ---'
Write-Host (Read-Live $live)
if ($Muestra) { Get-ChildItem $fotos -Filter 'pw-*.png' | ForEach-Object { Write-Host ("{0}  {1} B" -f $_.FullName, $_.Length) } }
