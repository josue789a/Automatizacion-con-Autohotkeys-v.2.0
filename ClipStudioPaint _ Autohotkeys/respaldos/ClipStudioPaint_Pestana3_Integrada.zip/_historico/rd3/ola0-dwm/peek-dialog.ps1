$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes, WindowsBase
$procs = Get-Process -Name AutoHotkey* -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 }
"ventanas de AutoHotkey: $($procs.Count)"
foreach ($pr in $procs) {
    $h = $pr.MainWindowHandle
    $sb = New-Object System.Text.StringBuilder
    Add-Type -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern int GetClassName(System.IntPtr h, System.Text.StringBuilder s, int max);
'@ -Name U32 -Namespace Win -ErrorAction SilentlyContinue
    $cls = ''
    try { $b = New-Object System.Text.StringBuilder 256; [Win.U32]::GetClassName($h, $b, 256) | Out-Null; $cls = $b.ToString() } catch { $cls = '?' }
    Write-Host ''
    Write-Host ("=== pid {0}  hwnd {1}  clase [{2}]  titulo [{3}] ===" -f $pr.Id, $h, $cls, $pr.MainWindowTitle)
    try {
        $el = [System.Windows.Automation.AutomationElement]::FromHandle($h)
        $all = $el.FindAll([System.Windows.Automation.TreeScope]::Descendants, [System.Windows.Automation.Condition]::TrueCondition)
        "  controles: $($all.Count)"
        foreach ($c in $all) {
            $n = $c.Current.Name
            if ($n -and $n.Trim()) { Write-Host ("   [{0}] {1}" -f $c.Current.ControlType.ProgrammaticName -replace 'ControlType.', '', $n) }
        }
        $btn = $el.FindAll([System.Windows.Automation.TreeScope]::Descendants, [System.Windows.Automation.PropertyCondition]::new([System.Windows.Automation.AutomationElement]::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button))
        foreach ($b2 in $btn) { try { $b2.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); "  -> boton '$($b2.Current.Name)' pulsado" } catch {} }
    } catch { "  UIA fallo: $_" }
}
