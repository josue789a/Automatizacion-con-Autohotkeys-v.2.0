using System;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Drawing.Imaging;

public static class Ola0
{
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }

    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
    [DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
    [DllImport("user32.dll")] public static extern int FillRect(IntPtr dc, ref RECT r, IntPtr brush);
    [DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleDC(IntPtr dc);
    [DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleBitmap(IntPtr dc, int w, int h);
    [DllImport("gdi32.dll")] public static extern IntPtr SelectObject(IntPtr dc, IntPtr obj);
    [DllImport("gdi32.dll")] public static extern IntPtr CreateSolidBrush(uint color);
    [DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr obj);
    [DllImport("gdi32.dll")] public static extern bool DeleteDC(IntPtr dc);

    // flags: 0 = GDI normal; 2 = PW_RENDERFULLCONTENT (DirectComposition/Chromium)
    public static string Captura(IntPtr hwnd, string ruta, uint flags)
    {
        RECT r;
        if (!GetWindowRect(hwnd, out r)) return "rect-fallo";
        int w = r.R - r.L, h = r.B - r.T;
        if (w < 10 || h < 10) return "tamano-malo " + w + "x" + h;
        IntPtr hscr = GetDC(IntPtr.Zero);
        IntPtr mem = CreateCompatibleDC(hscr);
        IntPtr bmp = CreateCompatibleBitmap(hscr, w, h);
        SelectObject(mem, bmp);
        // fondo magenta: si PrintWindow no pinta, el png lo grita en vez de disfrazarse de negro
        RECT c0 = new RECT(); c0.L = 0; c0.T = 0; c0.R = w; c0.B = h;
        IntPtr brocha = CreateSolidBrush(0x00FF00FF);
        FillRect(mem, ref c0, brocha);
        DeleteObject(brocha);
        bool ok = PrintWindow(hwnd, mem, flags);
        string res;
        using (var img = Image.FromHbitmap(bmp))
        {
            img.Save(ruta, ImageFormat.Png);
            using (var b2 = new Bitmap(ruta))
            {
                res = "pw=" + (ok ? 1 : 0) + " " + b2.Width + "x" + b2.Height
                    + " esq[" + Col(b2, 0, 0) + " " + Col(b2, 2, 2) + " " + Col(b2, 4, 4) + " " + Col(b2, 8, 8) + "]"
                    + " centro=" + Col(b2, b2.Width / 2, b2.Height / 2);
            }
        }
        DeleteObject(bmp);
        DeleteDC(mem);
        ReleaseDC(IntPtr.Zero, hscr);
        return res;
    }

    private static string Col(Bitmap b, int x, int y)
    {
        var cc = b.GetPixel(x, y);
        return cc.R + "," + cc.G + "," + cc.B;
    }
}
