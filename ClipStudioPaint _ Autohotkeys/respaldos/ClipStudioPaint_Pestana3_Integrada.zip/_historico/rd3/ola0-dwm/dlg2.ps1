param([string]$Archivo = '', [int]$Espera = 3500, [switch]$Correr, [string]$Modo = 'validate')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
if ($Modo -eq 'correr') {
    $sw = '/ErrorStdOut "' + $Archivo + '"'
} else {
    $sw = '/validate /ErrorStdOut "' + $Archivo + '"'
}
$p = New-Object System.Diagnostics.Process
$si = $p.StartInfo
$si.FileName = $exe
$si.Arguments = $sw
$si.UseShellExecute = $false
$si.CreateNoWindow = $true
$si.RedirectStandardError = $true
$si.RedirectStandardOutput = $true
[void]$p.Start()
$re = $p.StandardError.ReadToEndAsync()
$ro = $p.StandardOutput.ReadToEndAsync()
Start-Sleep -Milliseconds $Espera
if ($p.HasExited) {
    $code = $p.ExitCode
    $errTxt = ''
    $outTxt = ''
    if ($re.Wait(2000)) { $errTxt = $re.Result }
    if ($ro.Wait(2000)) { $outTxt = $ro.Result }
    Write-Host "salio solo exit=$code"
    Write-Host "stderr: [$errTxt]"
    Write-Host "stdout: [$outTxt]"
    exit 0
}
$p.Refresh()
$hwnd = $p.MainWindowHandle
Write-Host "pid=$($p.Id) hwnd=$hwnd titulo=[$($p.MainWindowTitle)]"
$root = [System.Windows.Automation.AutomationElement]::FromHandle($hwnd)
$cond = [System.Windows.Automation.Condition]::TrueCondition
$all = $root.FindAll([System.Windows.Automation.TreeScope]::Subtree, $cond)
foreach ($e in $all) {
    $txt = ''
    try {
        if ($e.IsPatternAvailable([System.Windows.Automation.TextPattern]::Pattern)) {
            $tp = $e.GetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern)
            $txt = $tp.DocumentRange.GetText(-1)
        }
    } catch { }
    if (-not $txt) {
        try {
            if ($e.IsPatternAvailable([System.Windows.Automation.ValuePattern]::Pattern)) {
                $vp = $e.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
                $txt = $vp.Current.Value
            }
        } catch { }
    }
    if (-not $txt) { $txt = $e.Current.Name }
    if ($txt) {
        Write-Host ('--- ' + $e.Current.ControlType.ProgrammaticName + ' ---')
        Write-Host $txt
    }
}
$errTxt2 = ''
$outTxt2 = ''
if ($re.Wait(1000)) { $errTxt2 = $re.Result }
if ($ro.Wait(1000)) { $outTxt2 = $ro.Result }
Write-Host "stderr-parcial: [$errTxt2]"
Write-Host "stdout-parcial: [$outTxt2]"
$p.Kill()
