$ErrorActionPreference = 'Stop'
$U8 = New-Object System.Text.UTF8Encoding($false)
$dir = Join-Path $env:TEMP 'ola0_nombres'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$nombres = @(
    'MonitorCount()', 'MonitorGetCount()', 'MonitorGetPrimary()',
    'MonitorGet(1)', 'MonitorGetName(1)', 'MonitorGetWorkArea(1, &a, &b, &c, &d)',
    'MonitorGetDpi(1)', 'MonitorFromPoint(0, 0)', 'MonitorFromWindow(1)',
    'NumGet(Buffer(8,0),0,"int")', 'StrLen("ab")', 'A_ScreenDPI',
    'Format("0x{:X}", 1)', 'Round(1.2, 1)', 'Map()', 'Gui()'
)
foreach ($n in $nombres) {
    $f = Join-Path $dir ('n' + ([Math]::Abs($n.GetHashCode())) + '.ahk')
    $txt = 'r := ' + $n + "`r`n"
    if ($n -like '*&a*') { $txt = 'a := 0' + "`r`nb := 0`r`nc := 0`r`nd := 0`r`n" + $txt }
    [IO.File]::WriteAllText($f, $txt, $U8)
    $p = New-Object System.Diagnostics.Process
    $si = $p.StartInfo
    $si.FileName = $exe
    $si.Arguments = '/validate "' + $f + '"'
    $si.UseShellExecute = $false
    $si.CreateNoWindow = $true
    $si.RedirectStandardError = $true
    [void]$p.Start()
    $re = $p.StandardError.ReadToEndAsync()
    $res = ''
    if (-not $p.WaitForExit(5000)) { $p.Refresh(); $res = 'COLGO'; $p.Kill() }
    else { $res = 'exit ' + $p.ExitCode }
    $e = ''
    if ($re.Wait(1200)) { $e = ($re.Result -split "`r?`n" | Where-Object { $_ }) -join ' | ' }
    Write-Host ("{0,-42} {1}  {2}" -f $n, $res, $e)
}
