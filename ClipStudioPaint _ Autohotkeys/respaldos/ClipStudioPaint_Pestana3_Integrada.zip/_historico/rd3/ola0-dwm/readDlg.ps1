param([string]$Archivo = '', [int]$Espera = 4000)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$p = New-Object System.Diagnostics.Process
$si = $p.StartInfo
$si.FileName = $exe
$si.Arguments = "/validate `"$Archivo`""
$si.UseShellExecute = $false
$si.CreateNoWindow = $true
[void]$p.Start()
Start-Sleep -Milliseconds $Espera
if ($p.HasExited) {
    Write-Host "salio solo exit=$($p.ExitCode)"
    exit 0
}
$p.Refresh()
$hwnd = $p.MainWindowHandle
Write-Host "pid=$($p.Id) hwnd=$hwnd titulo=[$($p.MainWindowTitle)]"
if ($hwnd -ne 0) {
    $el = [System.Windows.Automation.AutomationElement]::FromHandle($hwnd)
    $cond = [System.Windows.Automation.Condition]::TrueCondition
    $all = $el.FindAll([System.Windows.Automation.TreeScope]::Subtree, $cond)
    foreach ($e in $all) {
        $t = $e.Current.Name
        if ($t) {
            Write-Host ("  [{0}] {1}" -f $e.Current.ControlType.ProgrammaticName, $t)
        }
    }
}
$p.Kill()
