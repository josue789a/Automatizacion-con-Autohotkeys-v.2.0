param([string]$Path, [int]$Timeout = 20, [string[]]$Extra = @())
$ahk = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $ahk
$psi.Arguments = (('/ErrorStdOut') + ($Extra -join ' ') + " `"$Path`"")
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.RedirectStandardError = $true
$psi.RedirectStandardOutput = $true
$psi.StandardErrorEncoding = New-Object System.Text.UTF8Encoding($false)
$psi.StandardOutputEncoding = New-Object System.Text.UTF8Encoding($false)
$pr = New-Object System.Diagnostics.Process
$pr.StartInfo = $psi
[void]$pr.Start()
# Leer los dos flujos ANTES de esperar: si no, un pipe lleno deadlocka (eso era el "COLGO").
$errTask = $pr.StandardError.ReadToEndAsync()
$outTask = $pr.StandardOutput.ReadToEndAsync()
if (-not $pr.WaitForExit($Timeout * 1000)) {
    try { $pr.Kill($true) } catch { try { $pr.Kill() } catch {} }
    "COLGO (> $Timeout s)"
} else {
    "exit $($pr.ExitCode)"
}
"--- stderr ---"
try { $errTask.Result } catch { '(sin lectura: ' + $_.Exception.Message + ')' }
"--- stdout ---"
try { $outTask.Result } catch { '(sin lectura)' }
