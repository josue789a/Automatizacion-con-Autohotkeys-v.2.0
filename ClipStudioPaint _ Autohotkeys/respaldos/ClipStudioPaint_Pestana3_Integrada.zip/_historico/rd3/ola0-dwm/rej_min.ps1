# rejilla.ps1 — clasifica los pixeles de un recorte de esquina contra dos colores leidos
# en la misma corrida (hijo / padre). Sirve para los casos de alfa bajo donde el tol fijo
# se queda corto: aqui cada pixel se asigna al MAS CERCANO y se imprime la reticula.
param(
    [string]$Nombres = 'A-norm,A-al235,A-al40,C-al40,B-al40,A-al40rec',
    [int]$Tam = 14
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$ruta = Join-Path $PSScriptRoot 'fotos-rgn'

foreach ($n in ($Nombres -split ',')) {
    $png = Join-Path $ruta ($n.Trim() + '_izq.png')
    if (-not (Test-Path $png)) { Write-Host "  (sin $png)"; continue }
    $bmp = [System.Drawing.Bitmap]::FromFile($png)
    Write-Host ''
    Write-Host ("=== " + $n.Trim() + "  recorte " + $bmp.Width + "x" + $bmp.Height + " (el hijo empieza en 4,4) ===")
    # leer todos los pixeles primero (GetPixel es lento; 40x40 = 1600 lecturas)
    $W = $bmp.Width
    $px = New-Object 'int[]' ($bmp.Width * $bmp.Height)
    for ($y = 0; $y -lt $bmp.Height; $y++) {
        for ($x = 0; $x -lt $W; $x++) {
            $c = $bmp.GetPixel($x, $y)
            $px[$y * $W + $x] = $c.R * 65536 + $c.G * 256 + $c.B
        }
    }
    $bmp.Dispose()
    # el color del hijo se toma del interior del propio recorte (13,13): ahi la region
    # ya no recorta en ninguna de las variantes probadas.
    $vh = $px[13 * $W + 13]
    $hijo = @(($vh -shr 16) -band 255, ($vh -shr 8) -band 255, $vh -band 255)
    # el color del padre: columna 3 del recorte = cliente del padre x=15, un pixel a la
    # izquierda del hijo y por debajo del arco DWM del padre (que mide ~12).
    $vp = $px[13 * $W + 3]
    $padre = @(($vp -shr 16) -band 255, ($vp -shr 8) -band 255, $vp -band 255)
    Write-Host ("  ref hijo=(" + ($hijo -join ',') + ") padre=(" + ($padre -join ',') + ")")
    $filas = @()
    for ($y = 0; $y -lt $Tam; $y++) {
        $linea = ''
        for ($x = 0; $x -lt $Tam; $x++) {
            $v = $px[$y * $W + $x]
            $c = @(($v -shr 16) -band 255, ($v -shr 8) -band 255, $v -band 255)
            $dh = [Math]::Pow($c[0]-$hijo[0],2) + [Math]::Pow($c[1]-$hijo[1],2) + [Math]::Pow($c[2]-$hijo[2],2)
            $dp = [Math]::Pow($c[0]-$padre[0],2) + [Math]::Pow($c[1]-$padre[1],2) + [Math]::Pow($c[2]-$padre[2],2)
            if ($x -lt 4 -or $y -lt 4) { $linea += '.' }
            elseif ($dh -lt $dp) { $linea += '#' } else { $linea += 'o' }
        }
        $filas += ('   y{0,2} {1}' -f $y, $linea)
    }
    $filas | ForEach-Object { Write-Host $_ }
    Write-Host '   # = color del hijo | o = color del padre (la region recorta) | . = antes de la caja'
}
