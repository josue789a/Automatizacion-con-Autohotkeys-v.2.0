param([int]$Secs = 6)
$ErrorActionPreference = 'Stop'
$ahk = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$dir = 'C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\ola0-dwm'
$run = Join-Path $env:TEMP 'ola0_dwm'
New-Item -ItemType Directory -Force $run | Out-Null
$probe = Join-Path $run 'probe_dwm.ahk'
Copy-Item (Join-Path $dir 'probe_dwm.txt') $probe -Force

# Igual que docs\ESTETICA\pruebas.ps1: Start-Process -PassThru + -RedirectStandardError
# devuelve ExitCode vacio (bug de PS) y HasExited no se refresca. System.Diagnostics.
function Invoke-Ahk {
    param([string]$Script, [string[]]$Extra, [int]$Timeout)
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $ahk
    $psi.Arguments = (($Extra + "`"$Script`"") -join ' ')
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardError = $true
    $psi.RedirectStandardOutput = $true
    $u8 = New-Object System.Text.UTF8Encoding($false)
    $psi.StandardErrorEncoding = $u8
    $psi.StandardOutputEncoding = $u8
    $pr = New-Object System.Diagnostics.Process
    $pr.StartInfo = $psi
    [void]$pr.Start()
    $t0 = Get-Date
    $matado = $false
    if (-not $pr.WaitForExit($Timeout * 1000)) {
        $matado = $true
        try { $pr.Kill($true) } catch { try { $pr.Kill() } catch {} }
    }
    $err = ''; $outp = ''
    try { $err = $pr.StandardError.ReadToEnd() } catch {}
    try { $outp = $pr.StandardOutput.ReadToEnd() } catch {}
    return @{ ExitCode = $(if ($matado) { -1 } else { $pr.ExitCode }); Stderr = $err; Stdout = $outp;
             Matado = $matado; Segundos = [math]::Round(((Get-Date) - $t0).TotalSeconds, 1) }
}

"--- 1. validate (no ejecuta nada) ---"
$v = Invoke-Ahk -Script $probe -Extra @('/validate', '/ErrorStdOut') -Timeout 25
"validate : exit {0}  ({1} s){2}" -f $v.ExitCode, $v.Segundos, $(if ($v.Matado) { '  MATADO POR WATCHDOG' } else { '' })
if ($v.Stderr.Trim()) { $v.Stderr }
if ($v.ExitCode -ne 0) { exit 1 }

"--- 2. corrida real en monitor 2 ---"
$out = Join-Path $run 'ola0_dwm.txt'
Remove-Item $out -ErrorAction SilentlyContinue
$argList = @('--secs=' + $Secs, '--monitor=2', "--out=$out")
$r = Invoke-Ahk -Script $probe -Extra $argList -Timeout 40
"ejecucion: exit {0}  ({1} s){2}" -f $r.ExitCode, $r.Segundos, $(if ($r.Matado) { '  MATADO POR WATCHDOG' } else { '' })
if ($r.Stderr.Trim()) { 'stderr:'; $r.Stderr } else { 'stderr vacio' }

Start-Sleep -Milliseconds 500
"AHK vivos         : " + ((Get-Process -Name AutoHotkey* -ErrorAction SilentlyContinue | Measure-Object).Count)
"companion 12532   : " + [bool](Get-Process -Id 12532 -ErrorAction SilentlyContinue)
$est = 'C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk'
"ESTABLE           : " + (Get-FileHash $est).Hash.Substring(0, 12) + "  (esperado DC012821F676)"
Write-Host ''
Write-Host '==================== ola0_dwm.txt ===================='
if (Test-Path $out) { Get-Content $out } else { '(no existe: fallo antes de escribir)' }
