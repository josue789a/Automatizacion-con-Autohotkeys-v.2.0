"""Censo de literales de color del ESTABLE: las 7 botoneras (l.2247-2584) y, de paso,
todo el archivo por funcion, para que la ola 1 se dicte con numeros y no con memoria."""
import re, io
from collections import Counter, defaultdict

RUTA = r"C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk"
INI, FIN = 2247, 2584

src = io.open(RUTA, encoding="utf-8", errors="replace").read()
lineas = src.split("\n")

PATTERNS = [
    ("texto c", re.compile(r"(?i)(?<![0-9a-f])c([0-9a-f]{6})(?![0-9a-f])")),
    ("Background", re.compile(r"(?i)Background(FF)?([0-9a-f]{6})(?![0-9a-f])")),
    ("0x", re.compile(r"(?i)0x([0-9a-f]{6})(?![0-9a-f])")),
    ("citado", re.compile(r'["\x27]([0-9a-fA-F]{6})["\x27]')),
    ("BackColor", re.compile(r"(?i)BackColor\s*:=\s*[\"']([0-9a-fA-F]{6})[\"']")),
]

def hexes(linea):
    visto = []
    for nombre, rx in PATTERNS:
        for m in rx.finditer(linea):
            h = m.group(m.re.groups and m.lastindex or len(m.groups()))
            h = (h or "").upper()
            if len(h) == 8:
                h = h[2:]
            if len(h) != 6 or not re.fullmatch(r"[0-9A-F]{6}", h):
                continue
            visto.append((nombre, h, m.group(0)))
    return visto

filas = []
for i in range(INI - 1, FIN):
    for (nombre, h, tex) in hexes(lineas[i]):
        filas.append((i + 1, nombre, h, tex, lineas[i].strip()[:90]))

# dedupe: la misma linea puede casar con 2 patrones (c00E5FF y "00E5FF")
uniq, vistos = [], set()
for f in filas:
    k = (f[0], f[2])
    if k in vistos:
        continue
    vistos.add(k)
    uniq.append(f)

print("== rango 2247-2584 ==  %d literales unicos" % len(uniq))
for f in uniq:
    print("  l.%-5d %-10s %-7s %-16s %s" % (f[0], f[1], "#" + f[2], f[3], f[4]))
print()
print("conteo por hex:", dict(Counter(f[2] for f in uniq)))
print("conteo por patron:", dict(Counter(f[1] for f in uniq)))

# todo el archivo, agrupado por la ultima funcion vista
KEYWORDS = {"if", "for", "while", "loop", "try", "catch", "else", "return", "throw",
            "finally", "switch", "until", "continue", "break"}
defs = []
for i, l in enumerate(lineas):
    m = re.match(r"^\s*([A-Za-z_]\w*)\s*\([^)]*\)\s*\{\s*$", l)
    if m and not l.strip().startswith(";") and m.group(1) not in KEYWORDS:
        defs.append((i + 1, m.group(1)))
def quien(n):
    actual = "(autoejecutable/global)"
    for dn, nom in defs:
        if dn <= n:
            actual = nom
        else:
            break
    return actual

por_fn = defaultdict(list)
for i, l in enumerate(lineas):
    for (nombre, h, tex) in hexes(l):
        por_fn[quien(i + 1)].append((i + 1, h, tex, l.strip()[:80]))
print()
print("== TODO el archivo: funciones con literales de color ==")
for fn in sorted(por_fn, key=lambda k: -len(por_fn[k])):
    print("  %-28s %3d   ej. l.%d %s" % (fn, len(por_fn[fn]), por_fn[fn][0][0], "#" + por_fn[fn][0][1]))
print("total literales en el archivo:", sum(len(v) for v in por_fn.values()))
