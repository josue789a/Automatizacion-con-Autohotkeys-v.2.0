param([string]$Path, [int]$Timeout = 15)
$ahk = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $ahk
$psi.Arguments = "/validate /ErrorStdOut `"$Path`""
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.RedirectStandardError = $true
$psi.RedirectStandardOutput = $true
$psi.StandardErrorEncoding = New-Object System.Text.UTF8Encoding($false)
$psi.StandardOutputEncoding = New-Object System.Text.UTF8Encoding($false)
$pr = New-Object System.Diagnostics.Process
$pr.StartInfo = $psi
[void]$pr.Start()
$errTask = $pr.StandardError.ReadToEndAsync()
$outTask = $pr.StandardOutput.ReadToEndAsync()
if (-not $pr.WaitForExit($Timeout * 1000)) {
    try { $pr.Kill($true) } catch { try { $pr.Kill() } catch {} }
    "COLGO (> $Timeout s)  $Path"
} else {
    "exit $($pr.ExitCode)  $Path"
}
$e = ''
try { $e = $errTask.Result } catch {}
$o = ''
try { $o = $outTask.Result } catch {}
if ($e.Trim()) { 'stderr: ' + $e.Trim() }
if ($o.Trim()) { 'stdout: ' + $o.Trim() }
if (-not $e.Trim() -and -not $o.Trim()) { '(ambos flujos vacios)' }
