$ErrorActionPreference = 'Stop'
$U8 = New-Object System.Text.UTF8Encoding($false)
$dir = Join-Path $env:TEMP 'ola0_micro'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$casos = [ordered]@{
    a_mc            = 'r := MonitorCount()'
    b_mc_concat     = 'r := "monitores : " MonitorCount()'
    c_mc_y_mas      = 'r := "monitores : " MonitorCount() "   pedido=" 2'
    d_llamada_env   = 'Rep("monitores : " MonitorCount() "   pedido=" MON)'
    e_if_sin_llave  = @'
MON := 2
if (MON > MonitorCount())
    MON := 1
'@
    f_posfija       = 'r := MonitorCount() + 1'
}
foreach ($k in $casos.Keys) {
    $f = Join-Path $dir ("m_" + $k + '.ahk')
    [IO.File]::WriteAllText($f, "#Requires AutoHotkey v2.0`r`n" + $casos[$k] + "`r`n", $U8)
    $p = New-Object System.Diagnostics.Process
    $si = $p.StartInfo
    $si.FileName = $exe
    $si.Arguments = "/validate /ErrorStdOut `"$f`""
    $si.UseShellExecute = $false
    $si.CreateNoWindow = $true
    $si.RedirectStandardError = $true
    [void]$p.Start()
    $re = $p.StandardError.ReadToEndAsync()
    $res = ''
    if (-not $p.WaitForExit(6000)) { $p.Refresh(); $res = 'COLGO [' + $p.MainWindowTitle + ']'; $p.Kill() }
    else { $res = 'exit ' + $p.ExitCode }
    $e = ''
    if ($re.Wait(1500)) { $e = ($re.Result -split "`r?`n" | Where-Object { $_ }) -join ' | ' }
    Write-Host ("{0,-16} {1}  {2}" -f $k, $res, $e)
}
