# foto_rgn.ps1 — corre probe_rgn.txt y mide los PIXELES de la esquina de cada hijo.
# Pregunta unica: ¿sobrevive el recorte SetWindowRgn de un control hijo cuando el padre es
# layered (WinSetTransparent 235 / 40)?
#   d0 = PADRE   -> la region recorta (opcion (a) viable)
#   d0 = HIJO    -> la region no hizo nada
# Se clasifica contra el color real del hijo (su propia C, sin region) y el del padre,
# muestreados en la misma ventana y al mismo tiempo, para que el alfa no importen.
param(
    [int]$Seg = 14,
    [int]$R = 8,
    [int]$Orden = 0,
    [int]$Esperado = 26,
    [switch]$SinFoto
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$src = Join-Path $PSScriptRoot 'probe_rgn.txt'
$dir = Join-Path $env:TEMP 'rgn_run'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$ahk = Join-Path $dir 'probe_rgn.ahk'
$live = Join-Path $dir 'live.txt'
$shots = Join-Path $PSScriptRoot 'fotos-rgn'
New-Item -ItemType Directory -Force -Path $shots | Out-Null
$U8 = New-Object System.Text.UTF8Encoding($false)
[IO.File]::WriteAllLines($ahk, [IO.File]::ReadAllLines($src), $U8)
if (Test-Path $live) { Remove-Item $live -Force }

$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$p = New-Object System.Diagnostics.Process
$si = $p.StartInfo
$si.FileName = $exe
$si.Arguments = '/ErrorStdOut "' + $ahk + '" --secs=' + $Seg + ' --out=' + $live + ' --r=' + $R + ' --orden=' + $Orden
$si.UseShellExecute = $false
$si.CreateNoWindow = $true
$si.RedirectStandardError = $true
[void]$p.Start()
$re = $p.StandardError.ReadToEndAsync()

function Read-Live([string]$ruta) {
    if (-not (Test-Path $ruta)) { return '' }
    try { $fs = [System.IO.File]::Open($ruta, 'Open', 'Read', 'ReadWrite') } catch { return '' }
    $sr = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8)
    $t = $sr.ReadToEnd(); $sr.Close(); $fs.Close()
    return $t
}
function Get-Pixel([int]$x, [int]$y) {
    $b = New-Object System.Drawing.Bitmap 1, 1
    $g = [System.Drawing.Graphics]::FromImage($b)
    $g.CopyFromScreen($x, $y, 0, 0, $b.Size)
    $c = $b.GetPixel(0, 0)
    $g.Dispose(); $b.Dispose()
    return @($c.R, $c.G, $c.B)
}
function Near([int[]]$a, [int[]]$b, [int]$tol) {
    return ([Math]::Abs($a[0] - $b[0]) -le $tol -and [Math]::Abs($a[1] - $b[1]) -le $tol -and [Math]::Abs($a[2] - $b[2]) -le $tol)
}

# el sampler necesita los N padres y sus 3 hijos cada uno
$esperado = $Esperado
$lineas = @()
$limite = (Get-Date).AddSeconds(20)
while ((Get-Date) -lt $limite) {
    $txt = Read-Live $live
    $lineas = @($txt -split "`r?`n" | Where-Object { $_ -match 'hwnd=\d+.*rect=\[.*frame=\[' })
    if ($lineas.Count -ge $esperado) { break }
    Start-Sleep -Milliseconds 200
}
Write-Host "lineas capturadas: $($lineas.Count) (esperadas $esperado)"

# OJO: PowerShell NO distingue mayusculas: si esto se llamara $re pisaria la tarea
# asincrona de stderr y el final revienta con "Object[] no contiene Wait".
$RX = 'rect=\[(\d+),(\d+)\s+(\d+)x(\d+)\]\s+frame=\[(\d+),(\d+)\s+(\d+)x(\d+)\]'
$padres = @{}
$hijos = @()
foreach ($ln in $lineas) {
    if ($ln -notmatch $RX) { Write-Host "  (no parseable) $ln"; continue }
    $n = ($ln -split ' ')[0]
    $o = [pscustomobject]@{ nombre = $n; fx = [int]$Matches[5]; fy = [int]$Matches[6]; fw = [int]$Matches[7]; fh = [int]$Matches[8] }
    if ($n -like 'padre-*') { $padres[$n.Substring(6)] = $o } else { $hijos += $o }
}

# color del PADRE: en el hueco libre entre las dos filas de hijos (y=64, x=250 dentro del
# padre). NO se usa la esquina +4,+4: con corner=2 el arco del padre mide ~12 px y ahi
# todavia hay escritorio, no 1A1A2E.
# color del HIJO: centro de su propio C (sin region) del mismo padre
$marcas = @()
foreach ($h in $hijos) {
    $tag = $h.nombre.Split('-')[1]
    $pad = $padres[$tag]
    if ($null -eq $pad) { Write-Host "  (sin padre para $($h.nombre))"; continue }
    $colPadre = Get-Pixel ($pad.fx + 4) ($pad.fy + 4)
    $cH = $hijos | Where-Object { $_.nombre -eq "C-$tag" } | Select-Object -First 1
    $colHijo = Get-Pixel ($cH.fx + [int]($cH.fw / 2)) ($cH.fy + [int]($cH.fh / 2))
    $contraste = (@([Math]::Abs($colHijo[0]-$colPadre[0]), [Math]::Abs($colHijo[1]-$colPadre[1]), [Math]::Abs($colHijo[2]-$colPadre[2])) | Measure-Object -Maximum).Maximum
    if ($contraste -le 14) {
        $marcas += ('{0,-14} INDETERMINADA: hijo y padre casi iguales (contraste {1})' -f $h.nombre, $contraste)
        continue
    }
    $filas = @()
    $d0 = $null
    foreach ($d in 0, 1, 2, 3, 4, 6, 8, 10) {
        $px = Get-Pixel ($h.fx + $d) ($h.fy + $d)
        $esPadre = Near $px $colPadre 7
        $esHijo = Near $px $colHijo 10
        $etiqueta = if ($esHijo) { 'HIJO' } elseif ($esPadre) { 'PADRE' } else { 'OTRO' }
        $filas += ("d{0}={1}" -f $d, $etiqueta)
        if ($null -eq $d0) { $d0 = $etiqueta }
    }
    # primera columna "dentro del hijo" en la fila dy=0 -> radio directo del arco
    $dx0 = -1
    for ($dx = 0; $dx -le 20; $dx++) {
        if (Near (Get-Pixel ($h.fx + $dx) $h.fy) $colHijo 10) { $dx0 = $dx; break }
    }
    # abajo-derecha: descubre en que sistema de coords se aplico la region
    $pxBR = Get-Pixel ($h.fx + $h.fw - 3) ($h.fy + $h.fh - 3)
    $br = if (Near $pxBR $colHijo 10) { 'HIJO' } elseif (Near $pxBR $colPadre 7) { 'PADRE' } else { 'OTRO' }
    # centro del hijo: si es PADRE, la region lo borro entero
    $pxC = Get-Pixel ($h.fx + [int]($h.fw / 2)) ($h.fy + [int]($h.fh / 2))
    $centro = if (Near $pxC $colHijo 10) { 'HIJO' } elseif (Near $pxC $colPadre 7) { 'PADRE' } else { 'OTRO' }
    $v = switch ($d0) {
        'PADRE' { if ($centro -eq 'PADRE') { 'REGION TOTAL: el hijo desaparecio (region fuera de su caja)' }
                  else { "REGION VIVA: recorta en la esquina (rojo desde dx=$dx0)" } }
        'HIJO'  { 'REGION MUERTA: pinta rojo hasta d0 (esquina cuadrada)' }
        default { 'OTRO en d0 (ni hijo ni padre): revisar' }
    }
    $marcas += ('{0,-14} d0={1,-5} centro={2,-5} ab-der={3,-5} fila0-rojo-en-dx={4,-3} | {5}' -f $h.nombre, $d0, $centro, $br, $dx0, $v)
    Write-Host ('{0}  caja={1},{2} {3}x{4}  padre=({5},{6},{7}) hijo=({8},{9},{10}) contraste={11}' -f $h.nombre, $h.fx, $h.fy, $h.fw, $h.fh, $colPadre[0], $colPadre[1], $colPadre[2], $colHijo[0], $colHijo[1], $colHijo[2], $contraste)
    Write-Host ('   diagonal: ' + ($filas -join ' '))
    if (-not $SinFoto) {
        $bmp = New-Object System.Drawing.Bitmap 40, 40
        $gr = [System.Drawing.Graphics]::FromImage($bmp)
        $gr.CopyFromScreen($h.fx - 4, $h.fy - 4, 0, 0, $bmp.Size)
        $gr.Dispose()
        $bmp.Save((Join-Path $shots ($h.nombre + '_izq.png')), [System.Drawing.Imaging.ImageFormat]::Png)
        $bmp2 = New-Object System.Drawing.Bitmap 40, 40
        $gr2 = [System.Drawing.Graphics]::FromImage($bmp2)
        $gr2.CopyFromScreen($h.fx + $h.fw - 36, $h.fy + $h.fh - 36, 0, 0, $bmp2.Size)
        $gr2.Dispose()
        $bmp2.Save((Join-Path $shots ($h.nombre + '_der.png')), [System.Drawing.Imaging.ImageFormat]::Png)
        $bmp.Dispose(); $bmp2.Dispose()
    }
}

Write-Host ''
Write-Host '=== veredicto por pixeles (15 hijos) ==='
$marcas | ForEach-Object { Write-Host "  $_" }
if (-not $p.WaitForExit(($Seg * 1000))) { $p.Kill(); Write-Host '(probe matado)' }
$e = ''
if ($re.Wait(1500)) { $e = $re.Result }
if ($e) { Write-Host "stderr: $e" }
Write-Host '--- log del probe ---'
$t = Read-Live $live
if ($t) { Write-Host $t }
