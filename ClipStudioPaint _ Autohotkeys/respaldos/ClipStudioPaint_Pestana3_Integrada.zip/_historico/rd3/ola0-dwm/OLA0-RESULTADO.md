# OLA 0 — spike DWM: resultado medido (2026-11-05, AHK 2.0.26, Windows 11 build 26200)

Ninguna línea del ESTABLE se tocó. El ESTABLE sigue en 4.038 líneas /
`DC012821F6767BEB1F55D2FD2CAC42B853A14B3DBEF269C7FB7A355F1A2FEED5`.

El probe son 11 ventanas que se autodestruyen (`NoActivate`, no roban el foco), con
veredicto por **pixeles de pantalla** (`foto.ps1`) y por **PrintWindow** (`pw.ps1`).

## Respuesta corta

| Pregunta | Veredicto | Evidencia |
|---|---|---|
| ¿DWM redondea las ventanas **sin caption**? | **Sí, por defecto.** `corner.antes = 0` y al leerlo da `2` (ROUND). Con `33=1` (DONOTROUND) la ventana sale **escuadra**: la esquina llega hasta d1 y d0 es el borde gris. El atributo manda. | 8-rojo-donotround |
| ¿Qué radio real da? | **ROUND ≈ 11-13 px**, **ROUNDSMALL ≈ 7-8 px**, DONOTROUND = recto. **Solo hay 3 opciones**, no hay radio a elección. | ajuste `r=(dx+dy)+√(2·dx·dy)` sobre las filas 1,2,4 |
| ¿El **alfa** rompe el redondeo? | **No.** Con `WinSetTransparent` (235, 128 y 40) el atributo sigue en `2` tras 1 s y en la ventana roja al 50 % el arco se ve igual: fondo hasta d2, rojo desde d3. **El fade de `_FadeAlpha` no necesita hornear nada.** | 5, 6, 7 |
| ¿`SetLayeredWindowAttributes` a mano? | **Falla** sobre una Gui de AHK que ya trae `WS_EX_LAYERED`: devuelve 0 con `gle=87` (ERROR_INVALID_PARAMETER). `WinSetTransparent` sí funciona y pone el ex-style él solo (`0x88 → 0x80088`). | 4 vs 5/6/7 |
| ¿Backdrop del sistema (acrylic)? | **Se pone y persiste**: `38=3` → lectura `3` tras 1 s. **Pero no se ve sin la hoja de vidrio** (`DwmExtendFrameIntoClientArea` con márgenes −1): el centro pasa de `26,26,46` a `237,237,255`. | 3 |
| **D4** — ¿`PrintWindow` devuelve negro? | **No, nunca.** `pw=1` y pinta contenido en las 11 ventanas, incluidas layered y alfa. **Dos limites**: (a) **no reproduce el arco** (siempre sale escuadrada), (b) **ignora el alfa**: la 6 con alfa 40 se captura sólida `26,26,46` y la 7 al 128 sale `255,0,0`. Con `flags=2` (RENDERFULLCONTENT) **sí entra el backdrop**; con `flags=0` el acrylic sale oscuro. | pw.ps1 |
| ¿Se puede redondear **un control** (pill/slider)? | **No.** `DwmSetWindowAttribute` sobre el hwnd de un `Text` hijo contesta **-2147024890 = 0x80070006 (ERROR_INVALID_HANDLE)** y el pixel de su esquina está rojo hasta d0. **DWM solo recorta ventanas de nivel superior.** | 11 |
| Coste por ventana (I13) | Crear+mostrar+atributos+lecturas: **15-63 ms** (una vez, en el arranque). `WinSetTransparent`: **0,0 ms por paso** (un primer paso de 15 ms que no se repite). Lectura/escritura de atributos DWM: dentro del rango anterior. | `t=` en cada línea |

## Lo que esto cambia en el plan

1. **Ola 4 (slider) y ola 5 (HUD/badge): el redondeo de la ventana es gratis.** No hace
   falta GDI+ ni `SetWindowRgn` para la silueta del panel, **tampoco durante el fade**.
2. **Pills, tracks y knobs NO son ventanas**: son controles hijo, y DWM los rechaza. Si se
   quieren esquinas en una pill, el coste es GDI+/Region por control (lo que ya hace
   `galeria.ahk` l.388-438) **o** convertir la pill en su propia ventana `SysMetadataToolTip`
   /`Gui` sin caption (que sí hereda el arco, pero son N ventanas más en el arranque).
   Decisión pendiente para Claude.
3. **`[radius] sm=6 md=10 lg=14` no es implementable como está.** DWM ofrece ~7 px y
   ~12 px y nada intermedio. Los tokens de radio solo significan algo para el recorte
   propio (GDI+), no para lo que entrega el sistema.
4. **+Border interfiere con el arco en la esquina**: el pixel d0 de la ventana escuadrada es
   `100,100,100` (el borde), no el color de la ventana. Para paneles redondeados conviene
   `-Border` y dejar que el arco haga de borde.
5. **La evidencia visual del parpadeo tiene que ser captura de pantalla, no PrintWindow**:
   PrintWindow ignora el alfa y el arco, así que un PNG de PrintWindow **miente** sobre el
   estado de un panel a media opacidad.

## Números crudos

Pixeles de pantalla, diagonal desde el vértice del frame (`<VENT` = coincide con el centro
de la propia ventana, `<FONDO` = coincide con el escritorio 24 px fuera):

```
2-sin-caption      d0=(24,26,25) d1=(24,26,25) d2=(51,56,82) d3=(26,26,46)<VENT  -> redondeada, d=3
3-acrylic          d0=(24,26,25) d1=(24,26,25) d2=(51,52,52) d3=(237,237,255)<VENT -> acrylic visible y redondeada
4-layered          d0=(24,26,25) d1=(24,26,25) d2=(51,52,52) d3=(26,26,46)<VENT  -> layered + arco
5-transp-235       d0=(32,34,32)<FONDO d1=<FONDO d2=(54,55,54) d3=(26,27,45)<VENT -> alfa 235 + arco
6-transp-40        señal 12 por canal contra el fondo: INDETERMINADA por pixeles
                    (atributo si: corner=2 tras 1 s, ex=0x80088)
7-rojo-128         d0=(21,23,22)<FONDO d1=<FONDO d2=(36,37,37) d3=(140,12,12)<VENT
                    radio: fila1 dx=8 r=13 | fila2 dx=5 r=11,5 | fila4 dx=3 r=11,9
8-rojo-DONOTROUND  d0=(100,100,100) d1=(255,0,0)<VENT -> ESCUADRA (control del metodo, funciona)
9-rojo-ROUNDSMALL  d0=<FONDO d1=(61,61,60) d2=(255,0,0)<VENT   radio: fila1 dx=4 r=7,8 | fila2 dx=2 r=6,8
10-rojo-ROUND      d0,d1=(23,25,24) d2=(50,52,51) d3=(255,0,0)<VENT  radio: 13 / 11,5 / 11,9
11-hijo-text       d0=(255,0,0)<VENT en todas las filas -> CUADRADA, atributo rechazado
```

PrintWindow (`pw.ps1`, C# `System.Drawing`, flags 0 y 2):

```
2-sin-caption   f0 pw=1 esq=[100,100,100 26,26,46 …] centro=26,26,46
2-sin-caption   f2 pw=1 esq=[100,100,100 26,26,46 …] centro=26,26,46
3-acrylic       f0 centro=26,26,46      <- sin RENDERFULLCONTENT el backdrop NO entra
3-acrylic       f2 centro=237,237,255   <- con flags=2 si
4-layered       f0/f2 pw=1 centro=26,26,46
6-transparente-40  f0/f2 centro=26,26,46  <- alfa 40 capturado SOLIDO
7-rojo-128      f0/f2 centro=255,0,0     <- alfa 128 capturado SOLIDO
```

Atributos por ventana tras 1 s (`corner=33`, `backdrop=38`):

```
post 1: corner=2 backdrop=0     post 7: corner=2 backdrop=0
post 2: corner=2 backdrop=0     post 8: corner=1 backdrop=0   (DONOTROUND pedido)
post 3: corner=2 backdrop=3     post 9: corner=3 backdrop=0   (ROUNDSMALL pedido)
post 4: corner=2 backdrop=0     post 10: corner=2 backdrop=0
post 5: corner=2 backdrop=0     post 11 (hijo): corner=0 backdrop=0
post 6: corner=2 backdrop=0
```

Modo oscuro (`20`) aplicado a las ventanas 1 y 2: `rc=0` en ambas y lectura correcta en 2.
Color de borde (`34`): `rc=0` al escribir pero la **lectura falla** con
`-2147024809 = 0x80070057 (E_INVALIDARG)` → se escribe, no se lee.

## Trampas de AHK encontradas (evitan repetir 2 h de depuración)

- **`MonitorGetCount()`** existe; `MonitorCount()`, `MonitorGetDpi(1)` como se escribieron,
  `MonitorFromPoint` y `MonitorFromWindow` **no**. Una llamada a función inexistente **no**
  salta por stderr: abre un **dialogo modal** (Help / Edit / Reload / Continue) y la corrida
  parece colgada. `chk.ps1` lo detecta con `MainWindowTitle`.
- **Salidas por referencia en AHK v2: `"int*", &v`.** Con `"int*", v` la llamada devuelve
  `0` (éxito) y **lee 0 siempre**. El bloque `A/B/C` del probe es el control que lo prueba:
  B) sin `&` → leido=0; con `&` en la misma ventana → leido=2.
- **Un `Buffer` se pasa por su dirección**: `"ptr", buf`. `"ptr", &buf` da
  `This value of type VarRef has no property named Ptr`.
- **`GdiplusStartupInput` son 24 bytes** en x64 (`uint` version al offset 0); con 20 da rc=2.
- **Los identificadores de AHK no distinguen mayúsculas**: una local `png` dentro de
  `Captura()` chocaba con el global `PNG` y reventaba con *"This local variable has not been
  assigned a value"*; antes, una local `w` chocó con el mapa global `W`
  (*"This value of type Integer has no property named __Item"*). Igual que `REP` vs `Rep()`
  en `spike_latencia.ahk`. **Regla: ninguna local de una función puede llamarse como un
  global, en cualquier mayúscula.**
- **GDI+ no puede guardar imágenes desde el proceso de AHK en este PC**: `GdipSaveImageToFile`
  y `GdipSaveImageToStream` devuelven **10 (OutOfMemory)** y dejan un PNG de 0 bytes en las 4
  variantes probadas (CLSID fijado a mano, `CLSIDFromString`, imagen de `GdipCreateBitmapFromScan0`,
  stream). Diagnóstico completo en `cap_micro.txt` / `run_micro.ps1`. **Por eso la evidencia PNG
  sale de PowerShell** (`pw.ps1` + `Ola0.cs`), no del propio probe.

## Cómo reproducir

```
cd "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\ola0-dwm"
powershell -NoProfile -ExecutionPolicy Bypass -File chk.ps1 -Hasta 0      # validate: exit 0
powershell -NoProfile -ExecutionPolicy Bypass -File foto.ps1 -Monitor 1 -Seg 24   # pixeles + radios
powershell -NoProfile -ExecutionPolicy Bypass -File pw.ps1   -Monitor 1 -Seg 22   # PrintWindow
```

`probe_dwm.txt` / `cap_micro.txt` son `.txt` a propósito: **no debe quedar ningún `.ahk`
ejecutable en esta carpeta** (se doble-clic). El staging se hace en `%TEMP%\ola0_run\`.
`--monitor=2` sigue el pedido pero **hoy el PC solo tiene 1 monitor detectado**
(`monitores : 1   pedido=2`); el probe cae a 1 solo.

## Estado de la ola 0

**CERRADA con números.** Queda una decisión de diseño para Claude (punto 2 de arriba:
pills como controles con GDI+ vs pills como ventanas con arco gratis), y la consecuencia
de que `[radius]` no es configurable. El resto del plan no cambia.
