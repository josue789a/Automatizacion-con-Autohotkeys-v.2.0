# foto.ps1 — corre el probe y mide los pixeles de las esquinas mientras las ventanas viven.
# Veredicto mecanico: si el pixel de la esquina del frame coincide con el fondo de detras
# (muestreado 24 px mas afuera), la ventana NO pinta ahi -> esquina redondeada.
# Si coincide con 1A1A2E (26,26,46) -> el color de la ventana llega hasta la esquina: cuadro.
param(
    [int]$Monitor = 1,
    [int]$Seg = 14,
    [switch]$SinFoto
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$src = Join-Path $PSScriptRoot 'probe_dwm.txt'
$dir = Join-Path $env:TEMP 'ola0_run'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$ahk = Join-Path $dir 'probe_dwm.ahk'
$live = Join-Path $dir 'live.txt'
$shots = Join-Path $PSScriptRoot 'fotos'
New-Item -ItemType Directory -Force -Path $shots | Out-Null
$U8 = New-Object System.Text.UTF8Encoding($false)
[IO.File]::WriteAllLines($ahk, [IO.File]::ReadAllLines($src), $U8)
if (Test-Path $live) { Remove-Item $live -Force }

$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$p = New-Object System.Diagnostics.Process
$si = $p.StartInfo
$si.FileName = $exe
$si.Arguments = '/ErrorStdOut "' + $ahk + '" --secs=' + $Seg + ' --out=' + $live + ' --monitor=' + $Monitor
$si.UseShellExecute = $false
$si.CreateNoWindow = $true
$si.RedirectStandardError = $true
[void]$p.Start()
$re = $p.StandardError.ReadToEndAsync()

# esperar las 4 lineas de ventana (Rep escribe en caliente; AHK deja el archivo con
# sharing violation, asi que se abre con FileShare ReadWrite)
function Read-Live([string]$ruta) {
    if (-not (Test-Path $ruta)) { return '' }
    try {
        $fs = [System.IO.File]::Open($ruta, 'Open', 'Read', 'ReadWrite')
    } catch { return '' }
    $sr = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8)
    $t = $sr.ReadToEnd()
    $sr.Close(); $fs.Close()
    return $t
}

$esperado = 11
$lineas = @()
$limite = (Get-Date).AddSeconds(10)
while ((Get-Date) -lt $limite) {
    $txt = Read-Live $live
    $lineas = @($txt -split "`r?`n" | Where-Object { $_ -match '^\S+\s+hwnd=\d+.*rect=\[.*frame=\[' })
    if ($lineas.Count -ge $esperado) { break }
    Start-Sleep -Milliseconds 250
}
Write-Host "lineas de ventana capturadas: $($lineas.Count)"

function Get-Pixel([int]$x, [int]$y) {
    $b = New-Object System.Drawing.Bitmap 1, 1
    $g = [System.Drawing.Graphics]::FromImage($b)
    $g.CopyFromScreen($x, $y, 0, 0, $b.Size)
    $c = $b.GetPixel(0, 0)
    $g.Dispose(); $b.Dispose()
    return @($c.R, $c.G, $c.B)
}

$VENTANA = @(26, 26, 46)
$marcas = @()
foreach ($ln in $lineas) {
    if ($ln -notmatch '^(\S+)\s.*rect=\[(\d+),(\d+)\s+(\d+)x(\d+)\]\s+frame=\[(\d+),(\d+)\s+(\d+)x(\d+)\]') {
        Write-Host "  (no parseable) $ln"
        continue
    }
    $n = $Matches[1]
    $fx = [int]$Matches[6]; $fy = [int]$Matches[7]; $fw = [int]$Matches[8]; $fh = [int]$Matches[9]
    # fondo de referencia: 24 px fuera del frame, a la izquierda y arriba
    $bg1 = Get-Pixel ($fx - 24) $fy
    $bg2 = Get-Pixel $fx ($fy - 24)
    $filas = @()
    # referencia = el centro de la propia ventana (auto-calibrada): con WinSetTransparent
    # el color se mezcla con el fondo y el empate contra (26,26,46) no ocurre.
    $centro = Get-Pixel ($fx + [int]($fw / 2)) ($fy + [int]($fh / 2))
    function Near([int[]]$a, [int[]]$b, [int]$tol) {
        return ([Math]::Abs($a[0] - $b[0]) -le $tol -and [Math]::Abs($a[1] - $b[1]) -le $tol -and [Math]::Abs($a[2] - $b[2]) -le $tol)
    }
    $REF = $centro
    $primerDentro = $null
    foreach ($d in 0, 1, 2, 3, 4, 6, 8, 10) {
        $px = Get-Pixel ($fx + $d) ($fy + $d)
        $esV = Near $px $REF 10
        $esBg = (Near $px $bg1 6) -or (Near $px $bg2 6)
        $filas += ("d{0}=({1},{2},{3}){4}{5}" -f $d, $px[0], $px[1], $px[2], $(if ($esV) { '<VENT' } else { '' }), $(if ($esBg) { '<FONDO' } else { '' }))
        if ($esV -and $null -eq $primerDentro) { $primerDentro = $d }
    }
    # veredicto mecanico: d0 dentro de la referencia -> la ventana pinta hasta la esquina
    # (cuadrada). d0 fuera y la ventana aparece en d=N -> radio ~N px.
    # OJO: si el centro apenas se distingue del fondo (alfa muy bajo) la prueba no tiene
    # senal: todo empate es ruido. En ese caso el veredicto es INDETERMINADA, no CUADRADA.
    $contraste = ([Math]::Abs($centro[0] - $bg1[0]), [Math]::Abs($centro[1] - $bg1[1]), [Math]::Abs($centro[2] - $bg1[2])) | Measure-Object -Maximum
    $v = if ($contraste.Maximum -le 12) { 'INDETERMINADA: alfa tan bajo que centro y fondo casi no difieren (' + ($contraste.Maximum) + ' por canal); usar ventana 7' }
        elseif ($null -eq $primerDentro) { 'INDETERMINADA (ningun pixel de la diagonal coincide con el centro)' }
        elseif ($primerDentro -eq 0) { 'CUADRADA (pinta hasta d0)' }
        else { "REDONDEADA: la ventana empieza en d=$primerDentro" }
    $marcas += ('{0}  ->  {1}' -f $n, $v)
    # RADIO en px: para un cuarto de circulo de radio r con el vertice en (0,0), el borde
    # cumple (r-dx)^2 + (r-dy)^2 = r^2, de donde r = (dx+dy) + sqrt(2*dx*dy) usando el
    # primer dx "dentro" de cada fila dy. dy=0 da r directo (la circunferencia toca el
    # borde superior justo en x=r).
    # Solo en las rojas (7-11): son las unicas con contraste limpio, y el barrido cuesta
    # ~150 lecturas; a los 1 s el probe arranca el bloque de ida y vuelta, que pone
    # corner=1 en la 2 y corromperia su medida.
    $radios = @()
    if ($n -match '^(7|8|9|10|11)-') {
        foreach ($dy in 0, 1, 2, 4, 6, 8) {
            for ($dx = 0; $dx -le 24; $dx++) {
                $px = Get-Pixel ($fx + $dx) ($fy + $dy)
                if (Near $px $REF 10) {
                    $radios += ('fila{0}:dx={1} -> r={2}' -f $dy, $dx, [Math]::Round(($dx + $dy) + [Math]::Sqrt(2 * $dx * $dy), 1))
                    break
                }
            }
        }
    }
    Write-Host ''
    Write-Host ("{0}  frame={1},{2} {3}x{4}" -f $n, $fx, $fy, $fw, $fh)
    Write-Host ("  fondo: izq=({0},{1},{2}) sup=({3},{4},{5})  centro=({6},{7},{8})" -f $bg1[0], $bg1[1], $bg1[2], $bg2[0], $bg2[1], $bg2[2], $centro[0], $centro[1], $centro[2])
    Write-Host ("  esquina superior-izquierda en diagonal: " + ($filas -join '  '))
    if ($radios.Count) {
        Write-Host ("  radio del arco: " + ($radios -join '  '))
        $marcas[-1] = $marcas[-1] + '  |  ' + ($radios -join '  ')
    }
    if (-not $SinFoto) {
        $bmp = New-Object System.Drawing.Bitmap 26, 26
        $gr = [System.Drawing.Graphics]::FromImage($bmp)
        $gr.CopyFromScreen($fx, $fy, 0, 0, $bmp.Size)
        $gr.Dispose()
        $ruta = Join-Path $shots ($n + '.png')
        $bmp.Save($ruta, [System.Drawing.Imaging.ImageFormat]::Png)
        $bmp.Dispose()
        Write-Host "  foto: $ruta"
    }
}

Write-Host ''
Write-Host '=== veredicto por pixeles (esquina contra centro de la misma ventana) ==='
$marcas | ForEach-Object { Write-Host "  $_" }
if (-not $p.WaitForExit(($Seg * 1000))) { $p.Kill(); Write-Host '(probe matado)' }
$e = ''
if ($re.Wait(1500)) { $e = $re.Result }
if ($e) { Write-Host "stderr: $e" }
Write-Host '--- log del probe ---'
$t = Read-Live $live
if ($t) { Write-Host $t }
