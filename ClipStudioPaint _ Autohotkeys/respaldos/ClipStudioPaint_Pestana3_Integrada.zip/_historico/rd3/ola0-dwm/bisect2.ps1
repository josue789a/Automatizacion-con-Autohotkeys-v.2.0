param([string]$Pasos = '20,40,60,80,100,120,140,160,180,196', [int]$Desde = 1, [int]$TimeoutSeg = 8, [string]$Cierre = '')
$ErrorActionPreference = 'Stop'
$U8 = New-Object System.Text.UTF8Encoding($false)
$src = Join-Path $PSScriptRoot 'probe_dwm.txt'
$dir = Join-Path $env:TEMP 'ola0_bis'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$ahk = Join-Path $dir 'b.ahk'
$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$lineas = [System.IO.File]::ReadAllLines($src)
Write-Host "archivo: $($lineas.Count) lineas"
foreach ($n in ($Pasos -split ',')) {
    $k = [int]$n
    if ($k -lt $Desde) { continue }
    $k = [Math]::Min($k, $lineas.Count)
    $cuerpo = $lineas[0..($k - 1)]
    if ($Cierre) { $cuerpo = $cuerpo + @($Cierre) }
    [IO.File]::WriteAllLines($ahk, $cuerpo, $U8)
    $p = New-Object System.Diagnostics.Process
    $si = $p.StartInfo
    $si.FileName = $exe
    $si.Arguments = "/validate /ErrorStdOut `"$ahk`""
    $si.UseShellExecute = $false
    $si.CreateNoWindow = $true
    $si.RedirectStandardError = $true
    $si.RedirectStandardOutput = $true
    [void]$p.Start()
    $re = $p.StandardError.ReadToEndAsync()
    $tit = ''
    if (-not $p.WaitForExit($TimeoutSeg * 1000)) {
        $p.Refresh()
        $tit = $p.MainWindowTitle
        $p.Kill()
        $res = "COLGO [$tit]"
        $code = '?'
    } else {
        $code = $p.ExitCode
        $res = if ($code -eq 0) { 'exit 0' } else { "exit $code" }
    }
    $e = ''
    if ($re.Wait(1500)) { $e = ($re.Result -split "`r?`n" | Where-Object { $_ }) -join ' | ' }
    Write-Host ("{0,4}  {1}  {2}" -f $k, $res, $e)
    Start-Sleep -Milliseconds 200
}
