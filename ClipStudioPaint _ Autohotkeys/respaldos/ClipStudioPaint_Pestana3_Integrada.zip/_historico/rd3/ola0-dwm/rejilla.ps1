# rejilla.ps1 — reticula de pixeles de la esquina de cada recorte que guardo foto_rgn.ps1.
# Cada pixel se asigna al color MAS CERCANO entre el del hijo (interior del propio recorte,
# 13,13) y el del padre (3,13 = 1 px a la izquierda del hijo y por debajo del arco DWM).
# OJO PowerShell: dentro de un @(...) la coma absorbe el operador, `A -band 255, B` se lee
# como `-band (255,B)` y revienta. Por eso aqui no se empaquetan canales: GetPixel directo.
param(
    [string]$Nombres = 'A-norm,A-al255,A-al235,A-al40,A-al40rec,B-al40,C-al40',
    [int]$Tam = 14
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$carpeta = Join-Path $PSScriptRoot 'fotos-rgn'

foreach ($n in ($Nombres -split ',')) {
    $n = $n.Trim()
    $png = Join-Path $carpeta ($n + '_izq.png')
    if (-not (Test-Path $png)) { Write-Host "  (sin $png)"; continue }
    $bmp = [System.Drawing.Bitmap]::FromFile($png)
    Write-Host ''
    Write-Host ('=== ' + $n + '  recorte ' + $bmp.Width + 'x' + $bmp.Height + '  (la caja del hijo empieza en 4,4) ===')
    $refH = $bmp.GetPixel(13, 13)
    # columna 3 del recorte = cliente del padre x=15, un pixel a la izquierda del hijo.
    # A y=20 la distancia al centro del arco del padre (12,12) es 8.5 < 12: pintado seguro.
    $refP = $bmp.GetPixel(3, 20)
    $hR = $refH.R; $hG = $refH.G; $hB = $refH.B
    $pR = $refP.R; $pG = $refP.G; $pB = $refP.B
    Write-Host ('  ref hijo=(' + $hR + ',' + $hG + ',' + $hB + ')  padre=(' + $pR + ',' + $pG + ',' + $pB + ')')
    for ($y = 0; $y -lt $Tam; $y++) {
        $linea = ''
        for ($x = 0; $x -lt $Tam; $x++) {
            if ($x -lt 4 -or $y -lt 4) { $linea += '.'; continue }
            $c = $bmp.GetPixel($x, $y)
            $dh = [Math]::Pow($c.R - $hR, 2) + [Math]::Pow($c.G - $hG, 2) + [Math]::Pow($c.B - $hB, 2)
            $dp = [Math]::Pow($c.R - $pR, 2) + [Math]::Pow($c.G - $pG, 2) + [Math]::Pow($c.B - $pB, 2)
            if ($dh -lt $dp) { $linea += '#' } else { $linea += 'o' }
        }
        Write-Host ('   y{0,2} {1}' -f $y, $linea)
    }
    $bmp.Dispose()
}
Write-Host ''
Write-Host '   # = color del hijo | o = color del padre (ahi la region si recorto) | . = fuera de la caja del hijo'
