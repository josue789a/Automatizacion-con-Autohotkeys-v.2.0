$ErrorActionPreference = 'Stop'
$U8 = New-Object System.Text.UTF8Encoding($false)
$dir = Join-Path $env:TEMP 'ola0_micro2'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$pref = @(
    @('sin-req', ''),
    @('con-req', "#Requires AutoHotkey v2.0`r`n")
)
$mods = @(
    @('x1', "x := 1`r`n"),
    @('mc', "r := MonitorCount()`r`n"),
    @('buf', "b := Buffer(16, 0)`r`n")
)
foreach ($pf in $pref) {
    foreach ($md in $mods) {
        $f = Join-Path $dir ($pf[0] + '_' + $md[0] + '.ahk')
        [IO.File]::WriteAllText($f, $pf[1] + $md[1], $U8)
        $p = New-Object System.Diagnostics.Process
        $si = $p.StartInfo
        $si.FileName = $exe
        $si.Arguments = "/validate /ErrorStdOut `"$f`""
        $si.UseShellExecute = $false
        $si.CreateNoWindow = $true
        $si.RedirectStandardError = $true
        [void]$p.Start()
        $re = $p.StandardError.ReadToEndAsync()
        $res = ''
        if (-not $p.WaitForExit(6000)) { $p.Refresh(); $res = 'COLGO [' + $p.MainWindowTitle + ']'; $p.Kill() }
        else { $res = 'exit ' + $p.ExitCode }
        $e = ''
        if ($re.Wait(1500)) { $e = ($re.Result -split "`r?`n" | Where-Object { $_ }) -join ' | ' }
        Write-Host ("{0,-9} {1,-6} {2}  {3}" -f $pf[0], $md[0], $res, $e)
    }
}
