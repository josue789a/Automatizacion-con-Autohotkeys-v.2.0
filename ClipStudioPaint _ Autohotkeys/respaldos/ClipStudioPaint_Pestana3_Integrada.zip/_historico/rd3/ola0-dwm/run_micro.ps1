param([string]$Nombre = 'cap_micro')
$ErrorActionPreference = 'Stop'
$U8 = New-Object System.Text.UTF8Encoding($false)
$dir = Join-Path $env:TEMP ('ola0_' + $Nombre)
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$ahk = Join-Path $dir ($Nombre + '.ahk')
[IO.File]::WriteAllLines($ahk, [IO.File]::ReadAllLines((Join-Path $PSScriptRoot ($Nombre + '.txt'))), $U8)
$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$p = New-Object System.Diagnostics.Process
$si = $p.StartInfo
$si.FileName = $exe
$si.Arguments = '/ErrorStdOut "' + $ahk + '"'
$si.UseShellExecute = $false
$si.CreateNoWindow = $true
$si.RedirectStandardError = $true
[void]$p.Start()
$re = $p.StandardError.ReadToEndAsync()
if (-not $p.WaitForExit(20000)) { $p.Refresh(); Write-Host "COLGO [$($p.MainWindowTitle)]"; $p.Kill() }
else { Write-Host "exit=$($p.ExitCode)" }
$e = ''
if ($re.Wait(1500)) { $e = $re.Result }
if ($e) { Write-Host "stderr: $e" }
$log = Join-Path $dir ($Nombre + '.txt')
if (Test-Path $log) { Write-Host '--- log ---'; Get-Content $log }
Get-ChildItem $dir -Filter *.png | ForEach-Object { Write-Host ("  png {0}  {1} B" -f $_.Name, $_.Length) }
