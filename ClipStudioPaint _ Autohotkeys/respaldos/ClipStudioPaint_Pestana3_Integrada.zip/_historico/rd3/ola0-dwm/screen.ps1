Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Screen]::AllScreens | ForEach-Object {
    Write-Host ("Bounds=" + $_.Bounds.Width + "x" + $_.Bounds.Height + " loc=" + $_.Bounds.X + "," + $_.Bounds.Y + " primary=" + $_.Primary)
}
Write-Host ("WorkingArea=" + [System.Windows.Forms.SystemInformation]::VirtualScreen.Width)
