param([string]$Path, [int]$Timeout = 12)
$ahk = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $ahk
$psi.Arguments = "/validate /ErrorStdOut `"$Path`""
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.RedirectStandardError = $true
$psi.RedirectStandardOutput = $true
$pr = New-Object System.Diagnostics.Process
$pr.StartInfo = $psi
[void]$pr.Start()
if (-not $pr.WaitForExit($Timeout * 1000)) {
    try { $pr.Kill($true) } catch { try { $pr.Kill() } catch {} }
    "COLGO  ($Path)"
    exit 9
}
$err = ''
try { $err = $pr.StandardError.ReadToEnd() } catch {}
"exit $($pr.ExitCode)  ($Path)"
if ($err.Trim()) { $err.Trim() }
