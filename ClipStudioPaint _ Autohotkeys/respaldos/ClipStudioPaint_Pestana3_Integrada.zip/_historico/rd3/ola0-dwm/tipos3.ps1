$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$png = Join-Path $PSScriptRoot 'fotos-rgn\A-norm_izq.png'
$bmp = [System.Drawing.Bitmap]::FromFile($png)
$W = $bmp.Width
$px = New-Object 'int[]' ($bmp.Width * $bmp.Height)
Write-Host ('px=' + $px.GetType().FullName + ' len=' + $px.Length + ' W=' + $W + ' Wtipo=' + $W.GetType().FullName)
for ($y = 0; $y -lt $bmp.Height; $y++) {
    for ($x = 0; $x -lt $W; $x++) {
        $c = $bmp.GetPixel($x, $y)
        $px[$y * $W + $x] = $c.R * 65536 + $c.G * 256 + $c.B
    }
}
$bmp.Dispose()
$vh = $px[13 * $W + 13]
Write-Host ('vh=' + $vh + ' tipo=' + $vh.GetType().FullName)
$hijo = @(($vh -shr 16) -band 255, ($vh -shr 8) -band 255, $vh -band 255)
Write-Host ('hijo=(' + ($hijo -join ',') + ')')
