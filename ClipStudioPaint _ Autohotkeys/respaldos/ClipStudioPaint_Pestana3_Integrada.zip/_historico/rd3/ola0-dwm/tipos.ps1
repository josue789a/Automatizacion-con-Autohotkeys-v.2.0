$a = New-Object 'int[]' 16
Write-Host ('tipo=' + $a.GetType().FullName)
$a[5] = 12345
$v = $a[5]
Write-Host ('v tipo=' + $v.GetType().FullName + ' valor=' + $v)
Write-Host ('shr=' + (($v -shr 8) -band 255))
$b = New-Object 'int[]' (40 * 40)
Write-Host ('b len=' + $b.Length)
