# chk.ps1 — valida/corre el probe con canal determinista.
#   .\chk.ps1              -> /validate
#   .\chk.ps1 -Correr      -> ejecuta con /ErrorStdOut
#   .\chk.ps1 -Hasta 103   -> trunca a N lineas antes de validar
[CmdletBinding()]
param(
    [int]$Hasta = 0,
    [switch]$Correr,
    [int]$Seg = 3,
    [int]$Monitor = 2,
    [int]$TimeoutSeg = 20,
    [string]$Archivo = 'probe_dwm.txt'
)
$ErrorActionPreference = 'Stop'
$U8 = New-Object System.Text.UTF8Encoding($false)

$src = Join-Path $PSScriptRoot $Archivo
$dir = Join-Path $env:TEMP 'ola0_chk'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$ahk = Join-Path $dir 'probe.ahk'

$lineas = [System.IO.File]::ReadAllLines($src)
if ($Hasta -gt 0) {
    $take = $lineas[0..([Math]::Min($Hasta, $lineas.Length) - 1)]
    [IO.File]::WriteAllLines($ahk, $take, $U8)
    Write-Host "truncado a $([Math]::Min($Hasta, $lineas.Length)) lineas"
} else {
    [IO.File]::WriteAllLines($ahk, $lineas, $U8)
}

$exe = 'C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe'
$sw = if ($Correr) { "/ErrorStdOut `"$ahk`" --secs=$Seg --out=$dir\ola0.txt --monitor=$Monitor" }
        else { "/validate /ErrorStdOut `"$ahk`"" }

$p = New-Object System.Diagnostics.Process
$p.StartInfo = New-Object System.Diagnostics.ProcessStartInfo
$p.StartInfo.FileName = $exe
$p.StartInfo.Arguments = $sw
$p.StartInfo.UseShellExecute = $false
$p.StartInfo.CreateNoWindow = $true
$p.StartInfo.RedirectStandardOutput = $true
$p.StartInfo.RedirectStandardError = $true
$outErr = New-Object System.Collections.Generic.List[string]
$outStd = New-Object System.Collections.Generic.List[string]
[void]$p.Start()
$re = $p.StandardError.ReadToEndAsync()
$ro = $p.StandardOutput.ReadToEndAsync()
if (-not $p.WaitForExit($TimeoutSeg * 1000)) {
    $p.Kill()
    Write-Host "COLGO (matado a los $TimeoutSeg s)" -ForegroundColor Red
}
if ($re.Wait(2000)) { $outErr.Add($re.Result) }
if ($ro.Wait(2000)) { $outStd.Add($ro.Result) }
$code = if ($p.ExitCode -ne $null) { $p.ExitCode } else { '?' }
Write-Host "exit $code"
$e = ($outErr | Where-Object { $_ }) -join "`n"
$o = ($outStd | Where-Object { $_ }) -join "`n"
if ($e) { Write-Host "--- stderr ---"; Write-Host $e }
if ($o) { Write-Host "--- stdout ---"; Write-Host $o }
if ($Correr) {
    $log = Join-Path $dir 'ola0.txt'
    if (Test-Path $log) {
        Write-Host '--- ola0.txt ---' -ForegroundColor Cyan
        Get-Content $log
    } else {
        Write-Host '(sin ola0.txt)' -ForegroundColor Yellow
    }
}
