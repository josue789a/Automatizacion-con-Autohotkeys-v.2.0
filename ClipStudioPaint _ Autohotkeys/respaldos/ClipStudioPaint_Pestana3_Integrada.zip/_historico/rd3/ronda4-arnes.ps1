# Ronda 4, item 2: -Modo esteril sobre el ESTABLE con el bloque F1 pegado,
# tras recalibrar la huella de pruebas.ps1 a 29/2/3.
$ErrorActionPreference = 'Stop'
$U8 = New-Object System.Text.UTF8Encoding($false)

$est   = "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk"
$bloque= "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\f1_tema.ahk"
$arnes = "C:\Users\jbard\Documents\AntiGravity\Autohotkeys\docs\ESTETICA\pruebas.ps1"
$cfgSrc= "C:\Users\jbard\Documents\AntiGravity\Autohotkeys"

# El arnes arma $Src = <Raiz>\XxxPPEN_a16pg2_displayAS_secondary.ahk.
# Se usa una raiz sin espacios porque el nombre real de la carpeta los lleva.
$Raiz = Join-Path $env:TEMP 'ronda4_arnes'
if (Test-Path $Raiz) { Remove-Item $Raiz -Recurse -Force }
New-Item -ItemType Directory -Force $Raiz | Out-Null
$dst = Join-Path $Raiz 'XxxPPEN_a16pg2_displayAS_secondary.ahk'

Copy-Item $est $dst -Force
$nl = if ([IO.File]::ReadAllText($dst).Contains("`r`n")) { "`r`n" } else { "`n" }
$b  = [IO.File]::ReadAllText($bloque) -replace "`r?`n", $nl
[IO.File]::AppendAllText($dst, $nl + $b + $nl, $U8)
"escenario : $dst"
"lineas    : $([IO.File]::ReadAllLines($dst).Length)   (ESTABLE solo = $([IO.File]::ReadAllLines($est).Length))"
"sha256    : $((Get-FileHash $dst -Algorithm SHA256).Hash)"

# Configuracion para que las rutas resuelvan igual que en produccion.
# posiciones_gui.ini: el del arbol ESTABLE (es el que ese script lee en produccion).
foreach ($cfg in @(@('posiciones_gui.ini', "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys"),
                  @('theme.ini', $cfgSrc))) {
    $o = Join-Path $cfg[1] $cfg[0]
    if (Test-Path $o) { Copy-Item $o (Join-Path $Raiz $cfg[0]) -Force; "config     : $($cfg[0]) <- $($cfg[1])" }
    else { "config     : $($cfg[0]) NO EXISTE en $($cfg[1])" }
}

# Prueba de no-regresion: el ESTABLE real no se toca.
$h0 = (Get-FileHash $est -Algorithm SHA256).Hash

Write-Host ''
Write-Host '===== pruebas.ps1 -Modo parse  (ESTABLE + F1) ====='
& $arnes -Modo parse -Raiz $Raiz
$rcParse = $LASTEXITCODE

Write-Host ''
Write-Host '===== pruebas.ps1 -Modo esteril (ESTABLE + F1) ====='
& $arnes -Modo esteril -Raiz $Raiz
$rcEsteril = $LASTEXITCODE

Write-Host ''
$h1 = (Get-FileHash $est -Algorithm SHA256).Hash
"ESTABLE intacto : $(if ($h0 -eq $h1) {'SI'} else {'NO !!!'})   $h0"
"exit parse=$rcParse  esteril=$rcEsteril"
