# RESPUESTA-CLAUDE-RONDA4

Emisor: Claude (arquitecto). Destinatario: Qoder / Josue.
Esta vez llegó todo pegado en el `.md`; no falta nada. Sigo sin poder ejecutar AutoHotkey aquí: todo bloque de código está `NO VERIFICADO` hasta que pase `/validate` en el PC. Cada parche indica su comprobación.

Orden: S7 de tu documento, punto por punto, más lo que encontré leyendo.

---

## 0. Lo que firmo y lo que corrijo de tu lectura

**Firmo:**
- S1: la recalibración de la huella a **29/2/3** es correcta. Las 2 llamadas `Show("NoActivate")` solo-canónico son del slider y están en código reescrito (toggle de visibilidad y `_EstabFocoOcultar`), no son una GUI de aviso o botonera.
- S2: con la huella resuelta, F1 tiene `parse` y `esteril` en PASS. **I4 queda cumplido.**
- S3.1: el backtick sin doblar en `_LatHb` era el motivo real de que la copia no cargara. Mi hipótesis anterior (auto-ejecución atascada) era errónea; las huellas muestran que el timer **sí** dispara (2,5 s tras el registro). Retiro el diagnóstico de T1.2.
- S6: los `.ahk` del paquete viajan como `.txt`. De acuerdo.

**Corrijo (matiz, no bloqueo) tu "deuda funcional" de S1-b.** Dices que el slider "deja de reaparecer" al salir del foco. Leyendo el diff: durante el foco la ventana **no se oculta** (`_EstabFocoMostrar` solo la muestra si no era visible, y `_AplicarEstabVisibilidadBase` no actúa mientras `estabGui.foco`). Si estaba visible antes, sigue visible al salir, así que el `Show` del canónico era redundante en ese caso. El único caso distinto es "slider oculto + foco": ambos árboles lo ocultan. **Mi lectura: no hay cambio de conducta.** Es lectura de diff, no prueba. Prueba manual de 20 s cuando Josue pueda: Enfoque → Shift+E → soltar → ¿el slider sigue donde estaba? Si no, se anota en §7 de CONTEXTO como deuda real; si sí, se retira.

---

## 1. `ArmarLlamada()` corregido + base real del slider (S7.1)

Tu diagnóstico del `Invalid option.` es exacto: `colorTexto` contiene `texto`, gana el primer patrón y recibe `"LAT"`.

Hay una segunda causa que explica **el cuelgue con N=20** (hallazgo 4), y es hipótesis mía, no medida: en `MostrarMiniTexto` el `Gui()` se crea y el error salta en `g.AddText(...)`, **antes** de `floatGui.miniTip := g`. La GUI queda huérfana: `_LimpiarGUIs()` no puede destruirla porque nadie la referencia. Con 6 llamadas fallidas quedan 6 GUIs huérfanas; con 21, 21, cada una con su `SetTimer`-closure pendiente. Corregido (2), el error desaparece y con él las huérfanas. **Verificación:** tras el parche, repetir con `--n=10` y comprobar que (a) `errores = 0` y (b) llega a `salida escrita`. Si N=20 sigue colgándose con 0 errores, la hipótesis es falsa y se mide aparte.

### Parche A (spike_latencia.ahk)

`ANCHOR: ArmarLlamada`  ACCION: REPLACE-RANGE de las líneas 272-274 y 282-285 de la v3 (el primero añade 3 líneas).

Líneas 272-274 (cabecera) →

```ahk
ArmarLlamada(nombre, firma) {
    static fijas := Map("ActualizarEstabGUI", "ActualizarEstabGUI(25, true)")
    if fijas.Has(nombre)
        return fijas[nombre]
    if (Trim(firma) = "")
        return nombre "()"
```

(Son 6 líneas por las 3 viejas, +3 en total: las dos últimas del bloque son las originales 273-274 conservadas. Aplica este cambio primero o desplaza en +3 el segundo rango.)

Líneas 282-285 →

```ahk
        if RegExMatch(nom, "^(col|clr|hex)")
            v := '"00E5FF"'
        else if RegExMatch(nom, "(txt|texto|text|msg|mensaje)")
            v := '"LAT"'
```

El color se evalúa primero y **anclado al inicio** del nombre: `colorHex`, `colorBarra`, `colorTexto`, `colorAcento` → color; `texto`, `comboText` → texto.

Efecto esperado en `anclas`/log: `MostrarMiniTexto("LAT", "00E5FF", 60, "00E5FF")` y `ActualizarEstabGUI(25, true)`.

Por qué `ActualizarEstabGUI(25, true)` y no alternar `v`: con `forzar := true` el guard de ESTABLE l.2748 (`!forzar && v = dibV && …`) **no corta**, así que se mide el redibujo completo. Cada llamada reasigna `dibV := 25`, no hay deriva.

**Limitación que debes tener presente al leer la base:** la copia estéril tiene todas las GUIs ocultas. `RedrawWindow` sobre una ventana oculta es más barato que sobre una visible. Esa base es un **piso**, no la latencia percibida. Sirve para I13-a **solo si el componente nuevo se mide en las mismas condiciones** (también oculto y con la misma rutina). No la compares con tiempos de pantalla real.

### Parche B (spike_latencia.ahk): `N` por defecto

`ANCHOR: línea 38, N := 20`  ACCION: REPLACE

```ahk
N := 10
```

Y la línea 49 (`N := Max(5, …)`) queda como está. El `--n=` explícito manda. **Registrar el p95 solo con N ≥ 10**: con N=5 el p95 es el máximo (tus 98,171 = 98,171).

### Base para F2 (propuesta, necesita una pieza que no tengo)

F2 toca las botoneras, no `MostrarHUD`/`ActualizarEstabGUI`. La base que le sirve a I13-a es la de `ActualizarDsGUI()` (en el ESTABLE hace `_SetIcono` + `SetFont` + `BackColor` por llamada). Para medirla basta añadir `"ActualizarDsGUI"` a la lista de la l.110 de `Principal()` **y** a la lista de anclas que alimenta `anclas`. Esa segunda lista está en una función que no he visto. **Pido:** la función que construye `anclas` (por nombre).

---

## 2. `--sinmsg`, `--prod` con espacios y `Fin()` (S7.2)

Los tres cambios son pequeños y van juntos. Aplican a `spike_latencia.ahk` v3.

### Parche C1: función auxiliar

`ANCHOR: línea 41 (for a in A_Args)`  ACCION: INSERT-BEFORE (antes del bloque de lectura de opciones; cualquier lugar que se ejecute antes de la línea 41 sirve, pero recuerda que en el spike esto es el auto-ejecutable: va **antes** de la línea 35 si prefieres no mezclar)

```ahk
; Une los trozos de A_Args partidos por espacios (cuando --prod= viene sin comillas).
ArgsUnidos() {
    r := []
    for a in A_Args {
        if (r.Length = 0 || SubStr(a, 1, 2) = "--")
            r.Push(a)
        else
            r[r.Length] .= " " a
    }
    return r
}
```

### Parche C2: lectura de opciones (l.40-50)

`ANCHOR: bloque for a in A_Args`  ACCION: REPLACE-RANGE (l.40-45 y la cabecera del `for`)

```ahk
FORZAR := false
SINMSG := false
for a in ArgsUnidos() {
    if (a = "--ejecutar")
        EJECUTAR := true
    else if (a = "--forzar")
        FORZAR := true
    else if (a = "--sinmsg")
        SINMSG := true
```

(El resto del `for`, desde `else if (SubStr(a, 1, 7) = "--prod=")`, no cambia.)

### Parche C3: `Fin()`

`ANCHOR: Fin`  ACCION: REPLACE (l.199-202)

```ahk
Fin(msg, cod) {
    global SINMSG
    if SINMSG {
        Rep("FIN (cod " cod "): " msg)
        try Guardar("latencia_base.txt")
        ExitApp(cod)
    }
    MsgBox(msg, "spike_latencia", cod = 0 ? "Iconi" : "Icon!")
    ExitApp(cod)
}
```

**Efecto:** sin `--sinmsg` el comportamiento es idéntico al actual (UX intacta). Con `--sinmsg` no hay cuadro de diálogo, el mensaje queda en el log y el código de salida es el real. Para una corrida automatizada: `--forzar --sinmsg --ejecutar --prod="…" --n=10`.

**Citas por si se rompe:**
- `SINMSG` es un global nuevo; en AHK v2 no distingue mayúsculas. Antes de aplicar: `Select-String spike_latencia.ahk -Pattern '\bsinmsg\b'` debe dar solo las apariciones de arriba (colisión con función = el script no carga, como `REP`).
- `Guardar()` borra y reescribe `latencia_base.txt` desde `REPTXT`; llamarla otra vez es seguro (REPTXT es acumulativo).
- Con espacios, desde PowerShell: `'--prod="C:\ruta con espacios\x.ahk"'` (comillas dentro del argumento). `ArgsUnidos` es la red si se olvidan; **un doble espacio se normaliza a uno** (AHK ya lo perdió al partir).

**Comprobación (C1+C2+C3):** `/validate` exit 0; luego `--forzar --sinmsg` contra una ruta inexistente debe terminar **sin cuadro** y con exit 3 (rama "no existe el canónico"); y la corrida normal sin `--sinmsg` debe seguir mostrando el `MsgBox` (probar solo el caso de fallo, no hace falta ejecutar la copia).

El parche de huellas que pedía el §5 **ya no se necesita**: está aplicado en v3. Cierro T1.2.

---

## 3. `_Pasar` con pareja ON/OFF controlada (S7.3)

Lo que sé: `_Pasar` solo conmuta cuando `esc = 1.0` y **después** de capturar. Lo que **no** sé: cómo guarda cada ventana su estado ni qué hace `_Reconstruir()` con él. Por eso el parche **no depende de nombres de campo**: captura el estado inicial (`a`), conmuta todo, captura (`b`) y revierte. Así siempre hay pareja, sea cual sea el estado de partida.

Limitación que declaro: los PNG quedan con sufijo `_a` / `_b`, **no `_ON` / `_OFF`**, porque no puedo leer el estado sin ver `_Toggle`. Con `_Toggle` y la estructura de `S.wins` lo etiqueto por nombre.

### Parche D1 (galeria.ahk): `_Par` + `_Pasar`

`ANCHOR: _Pasar`  ACCION: REPLACE-RANGE (l.282-303, la función completa) y INSERT-BEFORE de `_Par`

```ahk
_Par(valSlider) {
    for o in S.wins.Clone() {
        if (o.kind = "slider")
            _SetSlider(o, valSlider)
        else
            _Toggle(o)
    }
    Sleep(200)
}

_Pasar(mon, escalas) {
    S.mon := mon
    for esc in escalas {
        S.esc := esc
        for fi in [1, 3] {
            S.fondoI := fi
            _Reconstruir()
            Sleep(400)
            S.par := "a"
            _Captura()
            Sleep(120)
            _Par(80)
            S.par := "b"
            _Captura()
            Sleep(120)
            _Par(25)
        }
    }
}
```

### Parche D2 (galeria.ahk): nombre del PNG

`ANCHOR: _Captura`  ACCION: REPLACE (l.716, una línea → dos)

```ahk
    par := HasProp(S, "par") ? "_" S.par : ""
    ruta := A_ScriptDir "\captura_" Round(S.esc * 100) "_" FONDOS[S.fondoI][1] "_m" S.mon par "_" FormatTime(, "HHmmss") (ocl.Length ? "_OCLUIDA" : "") ".png"
```

(Evito poner `(…)` justo después de `S.mon` en la misma expresión: en v2 `S.mon (x)` podría leerse como llamada; por eso `par` va en variable.)

**Qué cambia en la corrida:**
- Por escala y fondo hay **2** capturas (`a`, `b`) en vez de 1. El barrido es 5 escalas × 2 fondos × 2 = **20 PNG**.
- Desaparece el bloque `if (esc = 1.0)` (el conmutar-y-medir al final). Las mediciones de redibujo que hacía `_Toggle`/`_SetSlider` ahora ocurren en **todas** las escalas, no solo al 100 %. Si algún análisis dependía de "solo 100 %", avisadme.
- El slider va a 80 en `b` y vuelve a 25: ya no hay pasada final a 25 sin captura.
- `_Reconstruir()` al inicio de cada (escala, fondo) reinicia el estado, así que la pareja de cada fondo es independiente. **`NO VERIFICADO`** que `_Reconstruir` reinicie el estado: si no lo hace, el estado `a` de la segunda pasada es el `a` ya revertido (por eso `_Par` se llama dos veces: quedan en el estado inicial).

**Comprobación:** `/validate` de `galeria.ahk` exit 0; `--oculto` sigue con `errores: 0` (no usa `_Pasar`); `--capturas` produce 20 PNG con `_a` y `_b`; pegar el listado de nombres.

**D6 (E8ECF4 vs FFFFFF):** sin cambio respecto a la ronda anterior. Dos corridas con `theme.ini` editado entre ellas, carpeta `capt_FFFFFF` y `capt_E8ECF4`. Sigue dependiendo de las capturas; no lo decido hoy.

---

## 4. Veredicto de F1 y arranque de F2 (S7.4)

### F1: aplicar al archivo real. Condiciones y orden

Veredicto: **se aplica.** Tres comprobaciones en verde (`validate` 0, `_Tema` 14/14, `esteril` PASS con el bloque), producción no se toca hasta este paso y `eliminadas: 0`.

**Advertencia operativa que no estaba en el plan y que viene del código:** `CheckReload()` (cada 600 ms) compara la fecha de modificación del propio script y llama a `Reload()` cuando cambia. Es decir, **añadir el bloque al archivo real recarga el script que Josue tiene corriendo**, con su ToolTip y sus pitidos. Es lo esperado y no necesita UAC adicional si el proceso ya es elevado, pero:
1. Aplicarlo **con Josue sin dibujar** (el reinicio vacía GUIs y reinicia estados como `colorEstado`, `sincronizado` del slider, etc.).
2. Tras el reinicio, el slider queda `sincronizado := false` hasta la primera resincronización (comportamiento ya existente, no nuevo).
3. Las funciones F1 no se llaman, así que **no hay cambio visual**: si algo parpadea o cambia, es un fallo.

Orden (cada paso usa su salida literal; pegarla):

```powershell
$ahk  = "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"
$prod = "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk"
$h0   = (Get-FileHash $prod -Algorithm SHA256).Hash          # debe ser 6375B86D…3A7D
if ($h0 -ne "6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D") { throw "El ESTABLE cambió: NO aplicar" }

$bak = "$prod.bak-ola1-$(Get-Date -f yyyyMMdd-HHmmss)"       # I2
Copy-Item $prod $bak
$bloque = <el mismo $bloque / f1_tema.ahk que usó la ronda 4 (F1-BEGIN..F1-END)>
$nl = if ([IO.File]::ReadAllText($prod).Contains("`r`n")) { "`r`n" } else { "`n" }
$bloque = $bloque -replace "`r?`n", $nl
[IO.File]::AppendAllText($prod, $nl + $bloque + $nl, (New-Object Text.UTF8Encoding($false)))

$a = [IO.File]::ReadAllLines($bak); $b = [IO.File]::ReadAllLines($prod)
"lineas: $($a.Length) -> $($b.Length)"
"eliminadas: " + @(Compare-Object $a $b | Where-Object SideIndicator -eq '<=').Count + "   (esperado 0)"
$r = Start-Process $ahk -ArgumentList '/validate', "`"$prod`"" -Wait -PassThru
"validate real -> exit $($r.ExitCode)   (esperado 0)"
```

Si cualquier valor no coincide: `Copy-Item $bak $prod -Force` **inmediatamente** (CheckReload volverá a recargar el script anterior).

Registro de I7 para la ola 1, con el criterio que adopto: **conteo por `ReadAllLines`** (el arnés suma 1 porque cuenta la última línea sin salto; la diferencia es de lectura, no de contenido). Inicio **3.959**, final esperado **4.040**, +81.

### F2: puede diseñarse ahora, sin aplicarla aún

F2 (pills + glifos + reajuste de paleta) **no depende** de la base de latencia para el diseño, pero **sí para la aceptación**: I13-a se mide contra `ActualizarDsGUI` y esa base aún no existe (§1). Orden propuesto:
1. Aplicar F1 al real (arriba).
2. Spike v3 con los parches A/B (y ampliar la lista a `ActualizarDsGUI`): base real.
3. Capturas D4/D6 con el parche D.
4. Solo entonces diseño F2 contra números, no contra intuición.

Si Josue prefiere avanzar, yo diseño F2 en paralelo, pero **no se aplica nada** hasta tener la base y D4 firmada.

---

## 5. Actualizaciones de CONTEXTO.md (para que el chat siguiente no re-discuta)

`ANCHOR: CONTEXTO.md §0 (tabla "Punto de partida")`  ACCION: REPLACE de las filas afectadas

```markdown
| Archivo objetivo | `XPPEN AHK VERSION ESTABLE.ahk` (Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\) |
| Líneas del `.ahk` (ReadAllLines) | **3.959** · SHA-256 `6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D` |
| `_EstabEmitir` | l.2909 · `pausa := ESTAB_RITMO`; `ESTAB_RACHA := 10` (l.29), `ESTAB_RITMO := 18` (l.30) |
| Huella `.Show()` del arnés | **29 string / 2 vacías / 3 posicionales** (el canónico de 3.917 daba 31) |
```

`ANCHOR: CONTEXTO.md §2 (mapa)`  ACCION: REPLACE completo por la tabla S5 de tu ronda 4 (37 anclas). No mezclar con el mapa anterior.

`ANCHOR: CONTEXTO.md §1, línea I7`  ACCION: REPLACE

```markdown
| I7 | **Presupuesto por ola**: línea inicial (por `ReadAllLines`, anotada en el CHANGELOG) ±100. Si una ola sale del rango, detenerse y justificarlo. Ola 1: 3.959 → 4.040. |
```

`ANCHOR: CONTEXTO.md §1`  ACCION: INSERT-AFTER de I11 (nuevas decisiones firmadas)

```markdown
| I12 | `_FadeAlpha` (l.563) y sus 6 llamadas (en `_SetColorV/_SetColorCC/_SetAR`) no se tocan. El animador nuevo solo opera sobre GUIs propias; nunca recibe el HWND de un panel de CSP. |
| I13 | **a)** ruta de hotkey: función estética nueva ≤ +2 ms sobre la mediana de `latencia_base.txt` (con N ≥ 10, mismas condiciones). **b)** repintado de componente en cambio de estado ≤ 35 ms. D4 sigue sin firmar hasta capturas. |
```

`ANCHOR: CONTEXTO.md §4.5`  ACCION: añadir a la lista de nombres reservados

`_TemaValido()` · `_TemaFuente()` · `_FuenteInstalada()` · `_RolDeHex()` · `_AvisoColor()` · `_LimpiarAvisos()` (F3)

`ANCHOR: CONTEXTO.md §7 (deuda)`  ACCION: añadir

```markdown
| `_LimpiarGUIs()` llamada desde `MostrarMiniTexto` y `MostrarTooltipToggle` apaga `enfoque.activo` y los marcos | l.1712, l.1759 | 3 (se crea `_LimpiarAvisos`) |
| `MostrarMiniTexto`/`MostrarBadgeCombo`: si una excepción salta entre `Gui()` y la asignación a `floatGui`, la GUI queda huérfana | 1711-1760 | — (anotado, I8) |
```

---

## 6. Qué traer en la ronda 5 (en este orden)

1. Salida de la aplicación de F1 al real (los 4 valores del bloque PowerShell de §4) y, si pudo ser, la confirmación de que Josue no vio parpadeo ni cambio tras el reinicio.
2. `/validate` y corrida `--forzar --sinmsg --ejecutar --n=10` del spike con los parches A/B/C: pegar la tabla de latencias y los latidos. Esperado: `errores = 0` en las tres filas y `ActualizarEstabGUI` con un valor claramente mayor que 0,020 ms.
3. De `galeria.ahk`: `_Toggle`, `_SetSlider` y `_Reconstruir` (por nombre), para etiquetar `_ON`/`_OFF` y confirmar el reinicio de estado. Y listado de los 20 PNG de la corrida con `_a/_b` (nombres, no imágenes).
4. La función que construye `anclas` (para añadir `ActualizarDsGUI`).
5. Resultado de la prueba manual de 20 s del §0 (slider tras salir de foco).

Sin capturas (PNG) hasta que las pida.