$ErrorActionPreference='SilentlyContinue'
Get-CimInstance Win32_Process -Filter "Name like 'AutoHotkey%'" | ForEach-Object {
  $cmd = $_.CommandLine
  [PSCustomObject]@{
    PID     = $_.ProcessId
    Inicio  = (Get-Process -Id $_.ProcessId).StartTime
    exe     = $_.Name
    Script  = if ($cmd) { ($cmd -replace '^"[^"]*"\s*', '') } else { '(ilegible: proceso elevado)' }
    CPUmin  = [math]::Round((Get-Process -Id $_.ProcessId).CPU / 60, 1)
  }
} | Sort-Object Script | Format-Table -AutoSize | Out-String -Width 260
