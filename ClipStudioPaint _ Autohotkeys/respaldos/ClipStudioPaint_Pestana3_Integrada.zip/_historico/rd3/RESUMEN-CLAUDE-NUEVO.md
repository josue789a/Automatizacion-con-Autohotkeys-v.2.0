# RESUMEN PARA UN CHAT NUEVO DE CLAUDE — 2026-11-05

(subida unica y compacta. El paquete completo con el CONTEXTO verbatim, el informe de la
ola 0 entero y las 338 lineas de codigo de las botoneras esta en `PAQUETE-CLAUDE-NUEVO.md`
(69 KB). Pide por nombre lo que te falte y Qoder te lo pega; no lo vuelvas a deducir.)

## Reparto de papeles
- **Josue** — dueno del PC, ilustrador, trabaja en Clip Studio Paint. No toca el codigo.
- **Qoder** — ejecuta, mide, valida y edita el archivo real. Escribe los informes.
- **Tu (Claude)** — decides y dictas parches **anclados por nombre de funcion**. No tienes
  runtime: todo se mide aqui, y cuando algo no se puede hacer en este Windows, se dice con
  el numero que hay abajo, no con una opinion.

## Que es el proyecto
Un companion en **AutoHotkey v2** (4.038 lineas, `XPPEN AHK VERSION ESTABLE.ahk`) que pinta
paneles flotantes sobre CSP: 7 botoneras (ds / cc / ar / hc / lock / frente / estab-btn),
un HUD, un badge, mini-textos de aviso y un deslizador de estabilizacion. Objetivo: estetica
propia sin romper lo que ya funciona. Plan en 5 olas + una fase 0 de verificacion (cerrada).

## Estado exacto (no asumir otra cosa)
- El real esta en **4.038 lineas / sha256 `DC012821F6767BEB1F55D2FD2CAC42B853A14B3DBEF269C7FB7A355F1A2FEED5`**.
- **F1 ya aplicada**: el cargador `_Tema()` + `theme.ini` viven en el archivo (l.3.960-4.038)
  y validan exit 0, pero **ninguna funcion los llama todavia** → hoy no cambia ni un pixel.
- **Ola 0 (spike DWM) cerrada con numeros** (abajo). **Ola 1 lista para dictar.** Olas 2-5 sin empezar.
- El companion de Josue esta vivo y **cada edicion del real lo reinicia a los ~2 s y le corta
  el dibujo**. Las ediciones van entre sesiones, con `.bak-olaN-<fecha>` antes de la primera.

## Ola 0 — lo que este Windows da y lo que no (medido, 11 ventanas, pixeles de pantalla)

| Pregunta | Respuesta |
|---|---|
| ¿DWM redondea las ventanas **sin caption**? | **Si, por defecto** (attr 33 leido = 2 ROUND). Con `33=1` salen escuadradas: el atributo manda. |
| ¿Que radio? | **Solo 3 opciones**: recto · `33=3` ROUNDSMALL ≈ **7-8 px** · `33=2` ROUND ≈ **11-13 px**. No hay radio a eleccion. |
| ¿El **alfa** de `WinSetTransparent` rompe el arco? | **No.** A 235, 128 y 40 el atributo sigue en 2 y la ventana roja al 50 % conserva el arco (fondo hasta d2, color desde d3). **El fade de `_FadeAlpha` no hay que hornearlo.** |
| `SetLayeredWindowAttributes` a mano | **Falla** en una Gui de AHK con `WS_EX_LAYERED` (rc=0, gle=87). Usar `WinSetTransparent` (pone el ex-style solo: 0x88 → 0x80088). |
| Backdrop acrylic (attr 38 = 3) | Se pone y **persiste** (leido 3 tras 1 s). **Sin hoja de vidrio no se ve**; con ella el centro pasa de 26,26,46 a 237,237,255. |
| `PrintWindow` (pregunta D4) | **Nunca negro**, `pw=1` en las 11 (layered incluidas). **No reproduce el arco** y **ignora el alfa** (alfa 40 se captura solido). El backdrop solo entra con `flags=2`. |
| ¿Se puede redondear **un control hijo** (pill / track / knob)? | **No.** El atributo contesta **-2147024890 = 0x80070006 ERROR_INVALID_HANDLE** y su esquina pinta hasta d0. **DWM solo recorta ventanas de nivel superior.** |
| Costes | Crear+mostrar+atributos: **15-63 ms por ventana**, una vez en el arranque. `WinSetTransparent`: **0,0 ms por paso**. Modo oscuro (20): rc=0. Color de borde (34): se escribe, la lectura da E_INVALIDARG. |

Consecuencias ya decididas por los numeros: las olas **4 y 5 heredan el arco gratis**, incluso
durante el fade. `+Border` dibuja 1 px gris en la esquina → para paneles redondeados conviene
`-Border`. La evidencia visual de un panel a media opacidad **tiene que ser captura de pantalla**,
no PrintWindow. **GDI+ no puede guardar PNG desde el proceso de AHK en este PC** (devuelve 10 y
deja 0 bytes en las 4 variantes), por eso la evidencia sale de PowerShell.

## Lo que se te pide ahora (3 cosas, en orden)

1. **Forma de la pill (ola 2).** Un control hijo no se redondea. Elegir:
   (a) `Text` con recorte GDI+/Region propio (coste: 1 region por repintado, antialias manual),
   (b) ventana sin caption por pill (arco del sistema gratis, ~12 px, pero +N hwnds y
   15-63 ms por ventana en el arranque). Da la opcion con el coste justificado y el radio
   resultante.
2. **Que hacer con `[radius] sm=6 md=10 lg=14`.** El sistema solo ofrece recto / ~7-8 / ~11-13.
   ¿Se redefinen los tokens a los 3 valores reales, o se declaran validos solo para recorte
   propio (GDI+)?
3. **Dictar la ola 1.** Sustituir los **51 literales** de las 7 botoneras (censo abajo) por
   `_Tema("color", clave, defecto)` con mapeo **1:1 al hex actual** (ola 2 es la que afina la
   paleta, no esta). Anclar por nombre de funcion. Max ~100 lineas (I7). Al final del parche,
   el numero de sustituciones debe dar **51** y ningun hex de la lista puede quedar suelto en
   el rango.

## Censo mecanico de las 7 botoneras (l.2247-2584 del real, generado por `censo.py`)

```text
== rango 2247-2584 ==  51 literales unicos
  l.2249  citado     #424242 "424242"         dsGui.g.BackColor := "424242"
  l.2268  texto c    #B4C0DE cB4C0DE          dsGui.barra.Opt("cB4C0DE")
  l.2269  citado     #636D83 "636D83"         dsGui.g.BackColor := "636D83"
  l.2270  texto c    #FFFFFF cFFFFFF          dsGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
  l.2274  texto c    #6A6A6A c6A6A6A          dsGui.barra.Opt("c6A6A6A")
  l.2275  citado     #424242 "424242"         dsGui.g.BackColor := "424242"
  l.2276  texto c    #B2B2B2 cB2B2B2          dsGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
  l.2283  citado     #424242 "424242"         ccGui.g.BackColor := "424242"
  l.2315  texto c    #B4C0DE cB4C0DE          ccGui.barra.Opt("cB4C0DE")
  l.2316  citado     #636D83 "636D83"         ccGui.g.BackColor := "636D83"
  l.2317  texto c    #FFFFFF cFFFFFF          ccGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
  l.2321  texto c    #6A6A6A c6A6A6A          ccGui.barra.Opt("c6A6A6A")
  l.2322  citado     #424242 "424242"         ccGui.g.BackColor := "424242"
  l.2323  texto c    #B2B2B2 cB2B2B2          ccGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
  l.2330  citado     #424242 "424242"         arGui.g.BackColor := "424242"
  l.2362  texto c    #B4C0DE cB4C0DE          arGui.barra.Opt("cB4C0DE")
  l.2363  citado     #636D83 "636D83"         arGui.g.BackColor := "636D83"
  l.2364  texto c    #FFFFFF cFFFFFF          arGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
  l.2368  texto c    #6A6A6A c6A6A6A          arGui.barra.Opt("c6A6A6A")
  l.2369  citado     #424242 "424242"         arGui.g.BackColor := "424242"
  l.2370  texto c    #B2B2B2 cB2B2B2          arGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
  l.2377  citado     #424242 "424242"         hcGui.g.BackColor := "424242"
  l.2409  texto c    #B4C0DE cB4C0DE          hcGui.barra.Opt("cB4C0DE")
  l.2410  citado     #636D83 "636D83"         hcGui.g.BackColor := "636D83"
  l.2411  texto c    #FFFFFF cFFFFFF          hcGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
  l.2415  texto c    #6A6A6A c6A6A6A          hcGui.barra.Opt("c6A6A6A")
  l.2416  citado     #424242 "424242"         hcGui.g.BackColor := "424242"
  l.2417  texto c    #B2B2B2 cB2B2B2          hcGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
  l.2426  citado     #424242 "424242"         lockGui.g.BackColor := "424242"
  l.2455  texto c    #6A6A6A c6A6A6A          lockGui.barra.Opt("c6A6A6A")
  l.2456  citado     #424242 "424242"         lockGui.g.BackColor := "424242"
  l.2459  texto c    #B4C0DE cB4C0DE          lockGui.barra.Opt("cB4C0DE")
  l.2460  citado     #636D83 "636D83"         lockGui.g.BackColor := "636D83"
  l.2466  citado     #2B2B2B "2B2B2B"         try estabGui.g.BackColor := panelBlk.locked ? "2B2B2B" : "3A4260"
  l.2466  citado     #3A4260 "3A4260"         try estabGui.g.BackColor := panelBlk.locked ? "2B2B2B" : "3A4260"
  l.2473  citado     #424242 "424242"         frenteGui.g.BackColor := "424242"
  l.2504  texto c    #B4C0DE cB4C0DE          frenteGui.barra.Opt("cB4C0DE")
  l.2505  citado     #636D83 "636D83"         frenteGui.g.BackColor := "636D83"
  l.2508  texto c    #6A6A6A c6A6A6A          frenteGui.barra.Opt("c6A6A6A")
  l.2509  citado     #424242 "424242"         frenteGui.g.BackColor := "424242"
  l.2522  citado     #44DD88 "44DD88"         MostrarHUD(panelBlk.frente ? "📌 GUI AL FRENTE" : "📌 GUI SOLO EN CSP",panelBlk.frente ? "44
  l.2522  citado     #FF6B00 "FF6B00"         MostrarHUD(panelBlk.frente ? "📌 GUI AL FRENTE" : "📌 GUI SOLO EN CSP",panelBlk.frente ? "44
  l.2526  citado     #424242 "424242"         estabBtnGui.g.BackColor := "424242"
  l.2560  texto c    #B4C0DE cB4C0DE          estabBtnGui.barra.Opt("cB4C0DE")
  l.2561  citado     #636D83 "636D83"         estabBtnGui.g.BackColor := "636D83"
  l.2562  texto c    #FFFFFF cFFFFFF          estabBtnGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
  l.2566  texto c    #6A6A6A c6A6A6A          estabBtnGui.barra.Opt("c6A6A6A")
  l.2567  citado     #424242 "424242"         estabBtnGui.g.BackColor := "424242"
  l.2568  texto c    #B2B2B2 cB2B2B2          estabBtnGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
  l.2583  citado     #44DD88 "44DD88"         MostrarHUD(estabGui.visible ? "🎚 DESLIZADOR VISIBLE" : "🎚 DESLIZADOR OCULTO",estabGui.visi
  l.2583  citado     #FF6B00 "FF6B00"         MostrarHUD(estabGui.visible ? "🎚 DESLIZADOR VISIBLE" : "🎚 DESLIZADOR OCULTO",estabGui.visi

conteo por hex: {'424242': 14, 'B4C0DE': 7, '636D83': 7, 'FFFFFF': 5, '6A6A6A': 7, 'B2B2B2': 5, '2B2B2B': 1, '3A4260': 1, '44DD88': 2, 'FF6B00': 2}
conteo por patron: {'citado': 27, 'texto c': 24}
```

Fuera del rango hay **263 literales en 65 funciones** (olas 2-5). Nota del censo: 14 veces
`424242`, 7 `B4C0DE`, 7 `636D83`, 7 `6A6A6A`, 5 `FFFFFF`, 5 `B2B2B2`, 2 `44DD88`, 2 `FF6B00`,
1 `2B2B2B`, 1 `3A4260`. Los dos ultimos **no estan en `theme.ini`** → di que token reciben
(o si se añaden claves; `theme.ini` es archivo de usuario, no se sobreescribe a ciegas).

## theme.ini tal como esta en el disco

```ini
; theme.ini — tokens de diseño (refactor estético)
; Formato: RRGGBB sin '#'. Valores = captura 1:1 de lo que ya pinta el script.
; La afinación de paleta ocurre en la ola 2, con prueba visual.
; Si este archivo falta, el script usa los valores por defecto del código.

[color]
surface.base     = 12141A
surface.raised   = 1B1E26
surface.overlay  = 20242E
surface.off      = 424242
surface.on       = 636D83
text.primary     = FFFFFF
text.idle        = B2B2B2
text.muted       = 8E97A8
text.disabled    = 5A6273
accent.info      = 00E5FF
accent.success   = 44DD88
accent.warn      = FF6B00
accent.danger    = FF4444
accent.estab     = 9A7BFF
accent.estabSoft = B4C0DE
track.off        = 3A3A45
track.pillOff    = 6A6A6A

[alpha]
pill  = 235
badge = 230
hud   = 215
mini  = 200
icono = 185

[radius]
sm = 6
md = 10
lg = 14

[type]
family       = Segoe UI
family.value = Cascadia Mono
size.caption = 9
size.body    = 11
size.value   = 13

[motion]
fast = 120
base = 180
slow = 240
easing = out-cubic

[fx]
; 0 = region (actual) | 1 = DWM corner | 2 = DWM corner + backdrop
; Decidido en la ola 0.
corners  = 0
backdrop = 0
```

## API ya viva en el archivo (F1)

`_Tema(seccion, clave, defecto)` → lee `theme.ini` una vez y cachea en un `Map`; si falta el
archivo o la clave, **devuelve el defecto hardcodeado** (un tema roto jamas deja la UI sin
color). Los colores son `RRGGBB` **sin** `#`. El bloque completo esta en
`PAQUETE-CLAUDE-NUEVO.md` seccion 4 (80 lineas) si lo necesitas literal.

## Como responder

Un solo mensaje con: (1) decision de la pill + coste, (2) resolucion de `[radius]`,
(3) la ola 1 en trozos `ANTES/DESPUES` por funcion con su conteo de sustituciones.
Si algo de lo anterior te parece falso, dilo y se vuelve a medir — pero hay evidencia por
pixel detras de cada numero.

---
MANIFIESTO — fuentes de este resumen:
`censo_color.txt` sha256 `3AD11BCA04309B838D2819C93AB987CE884F5DBE4A92D2DFA0C540EAF1A8640A` · paquete completo `PAQUETE-CLAUDE-NUEVO.md` sha256 `D4DBB4F62310FFCCCEE780D79B777056C30CCC4EC7FD7F99D1278FA31FC4B17F`
