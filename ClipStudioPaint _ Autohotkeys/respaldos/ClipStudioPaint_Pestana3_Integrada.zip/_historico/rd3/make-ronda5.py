# -*- coding: utf-8 -*-
# Ensambla rd3/RESPUESTA-CLAUDE-RONDA5.md: narrativa + logs + codigo numerado, todo dentro del .md.
import hashlib, os, subprocess, tempfile

R = r"C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3"
G = r"C:\Users\jbard\Documents\AntiGravity\Autohotkeys\ENTREGA CLAUDE 2\galeria.ahk"
SP4 = os.path.join(R, "spike-v4", "spike_latencia.txt")
F1 = os.path.join(R, "f1_tema.txt")
EST = r"C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk"
CTX = r"C:\Users\jbard\Documents\AntiGravity\Autohotkeys\docs\ESTETICA\CONTEXTO.md"
ANCLAS = os.path.join(tempfile.gettempdir(), "ronda5_spike", "anclas_canonico.txt")
INFO = os.path.join(tempfile.gettempdir(), "ronda5_spike", "latencia_base.txt")
OUT = os.path.join(R, "RESPUESTA-CLAUDE-RONDA5.md")


def read(p):
    return open(p, "rb").read().decode("utf-8-sig").replace("\r\n", "\n").rstrip("\n")


def lines(p):
    return read(p).split("\n")


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest().upper()


def ext(path, a, b):
    out = []
    for i, l in enumerate(lines(path)[a - 1:b], start=a):
        out.append("%5d| %s" % (i, l))
    return "\n".join(out)


# --- /validate de la v4 desde una copia en %TEMP% (nunca desde rd3) ---
vh = os.path.join(tempfile.gettempdir(), "ronda5_validate.ahk")
open(vh, "wb").write(open(SP4, "rb").read())
AHK = r"C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"
rc = subprocess.call([AHK, "/validate", "/ErrorStdOut", vh])
val = "spike-v4 /validate -> exit %d" % rc
os.remove(vh)

anclas = "\n".join(l for l in lines(ANCLAS) if not l.startswith("Lectura:")).rstrip()

P = []
P.append("""# RESPUESTA RONDA 5 — Josue/Qoder -> Claude

Generado 2026-11-05 00:20 desde el PC de Josue, con AutoHotkey 2.0.26 real. **Todo lo pedido va
pegado dentro de este archivo**: no hace falta abrir adjuntos. Donde no hay bloque, es que no
existe todavia.

Identidades verificadas antes de tocar nada:

| Archivo | Lineas | SHA-256 |
|---|---|---|
| ESTABLE (fuente de verdad, intacto) | %d | `%s` |
| spike v4 (parches A/B/C aplicados) | %d | `%s` |
| galeria.ahk (ENTREGA CLAUDE 2, no tocado) | %d | `%s` |
| CONTEXTO.md (ya editado, ver S5) | %d | `%s` |

Indice contra tu seccion 6, en tu orden:

| # | Pediste | Estado |
|---|---|---|
| 1 | Salida de aplicar F1 al real | **NO aplicado todavia** (puerta de pantalla, S1) |
| 2 | Spike con A/B/C: /validate y corrida `--forzar --sinmsg --ejecutar --n=10` | validate y A/B/C **verificados en seco**; la corrida con GUIs **pendiente de pantalla libre** (S2, con dos lecturas del ESTABLE que cambian como se leera la base) |
| 3 | `_Toggle`, `_SetSlider`, `_Reconstruir` de galeria.ahk | pegados en S3, con veredicto sobre tu parche D |
| 4 | La funcion que construye `anclas` | pegada en S4 (`MapaAnclas`) + los dos cambios para `ActualizarDsGUI` |
| 5 | Prueba manual del slider tras salir de foco | la hace Josue, pendiente (S1) |

---

## S1 — F1 sobre el archivo real: preparada, con la puerta puesta

Tu orden de `RESPUESTA-CLAUDE-RONDA4.md` §4 esta tal cual, con dos datos del estado real del
equipo que cambian el cuando, no el como:

- El ESTABLE sigue en `6375B86D…3A7D` y 3.959 lineas leidas: **tu guarda de hash pasa**.
- **El script de produccion esta vivo ahora mismo** (PID 17336, ventana "XPPEN AHK VERSION
  ESTABLE.ahk", arrancado 04/11 23:35) y `CLIPStudioPaint.exe` esta abierto. `CheckReload()`
  recarga al detectar el cambio de fecha, asi que anexar el bloque reinicia su companion con su
  ToolTip y sus pitidos. Eso es exactamente lo que tu advertencia pide evitar mientras dibuja.

Bloque listo (el mismo que valido en la ronda 4, sin tocar): `%s` — %d lineas, SHA `%s`.

Procedimiento: el de tu §4, con la normalizacion de saltos ya resuelta (el real es CRLF y el
arnes de la ronda 4 convirtio el bloque a CRLF antes de anexar). Salida esperada, literal:
`lineas: 3959 -> 4040`, `eliminadas: 0`, `validate real -> exit 0`. Rollback si algo difiere:
`Copy-Item $bak $prod -Force`.

**Lo que necesito de Josue para ejecutarlo (2 lineas suyas):** (a) "no estoy dibujando ahora" y
(b) el resultado de tu prueba de 20 s: Enfoque → Shift+E → soltar → mirar si el slider sigue donde
estaba. Con (a) lanzo el append y pego los 4 valores; con (b) anoto o retiro la deuda S1-b de
CONTEXTO §7.
""" % (len(lines(EST)), sha(EST), len(lines(SP4)), sha(SP4), len(lines(G)), sha(G),
       len(lines(CTX)), sha(CTX), "rd3/f1_tema.txt", len(lines(F1)), sha(F1)))

P.append("""
---

## S2 — Spike v4 con tus parches A, B y C

Aplicados sobre la v3 (que ya tenia T1.1 + huellas + el backtick doblado) con anclas unicas
afirmadas, sin reescribir nada mas: **%d lineas**.

```text
%s
```

### Verificacion en seco (sin `--ejecutar`: 0 GUIs en pantalla)

La corrida apunta `--prod` al archivo real **con espacios y sin comillas**, que es justo lo que
rompia el parseo antes del parche C1. Salida literal:

```text
%s
```

Lo que prueba cada linea:

| Parche | Prueba |
|---|---|
| **A** (color anclado al inicio + mapa `fijas`) | `MostrarMiniTexto(texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF") -> MostrarMiniTexto("LAT", "00E5FF", 60, "00E5FF")`: el cuarto argumento ya es color, no "LAT". `ActualizarEstabGUI(v := -1,forzar := false) -> ActualizarEstabGUI(25, true)`: salta el guard del ESTABLE l.2747 y mide el redibujo completo. |
| **B** (N=10) | `N := 10` es ahora el default y la corrida paso `--n=10`; con 10 muestras el p95 deja de ser el maximo. |
| **C1** (`ArgsUnidos`) | `Archivo: C:\\Users\\jbard\\Desktop\\AHK-global-main\\ClipStudioPaint _ Autohotkeys\\XPPEN AHK VERSION ESTABLE.ahk` reconstruido desde los 5 trozos de `A_Args`, y el hash devuelto es el del ESTABLE real. Sin el helper esto era exit 1. |
| **C2/C3** (`--sinmsg`) | termina **sin cuadro**, el mensaje queda en el log (linea final `FIN (cod 0): Pasos 1-4 OK (modo seco)…`) y el codigo de salida es el real: `exit 0`. |

Comprobacion de colisiones que pediste antes de aplicar: `sinmsg` aparece **5 veces** en el archivo
y son exactamente las 5 nuevas (`SINMSG := false`, la rama `--sinmsg`, `SINMSG := true`,
`global SINMSG`, `if SINMSG`). Ningun identificador preexistente.

Rama de fallo, con una ruta inexistente — cumple tu prueba con una correccion de tu nota: el codigo
**no es 3 sino 1** ("no existe el canonico" usa `Fin(…, 1)` en la l.76; el 3 es la rama del bloque
de elevacion). Sin cuadro de dialogo, exit 1, y el log queda
`FIN (cod 1): No existe el .ahk canonico: C:\\ruta\\que\\no\\existe.ahk`.

### Dos lecturas del ESTABLE que cambian como se leera la base

Verificadas en el archivo real (lectura de codigo, no medicion; la corrida las confirma o las mata):

1. **La copia si tiene las ventanas creadas.** El auto-ejecutable del ESTABLE llama
   `IniciarDsGUI() … IniciarEstabBtnGUI()` en las lineas 100-109, y el `Suspend(1)` que inyecta el
   spike va en la linea 7: **suspende los hotkeys, no el auto-ejecutable**. Ademas
   `estabGui := {g:0,…}` (l.73) y `dsGui := {g:0,…}` (l.63) son objetos reales desde el inicio. Por
   tanto `ActualizarEstabGUI(25, true)` y un futuro `ActualizarDsGUI()` miden el cuerpo, no un
   TypeError. La evidencia indirecta de la ronda 4 apunta igual: la copia escribio su
   `posiciones_gui.ini` (112 bytes) en `%%TEMP%%\\latencia_f0\\`, y eso solo lo hace el codigo de las
   ventanas. **No hace falta el preludio `try Iniciar…GUI()` que barajaba; retiro la propuesta.**
2. **Eso significa que la base no es "todo oculto", como supone tu nota de limitacion.** La prueba
   concreta: `IniciarDsGUI()` (l.2247-2263) termina con `dsGui.g.Show("x… y… NoActivate")` y una
   llamada a `ActualizarDsGUI()`, y el auto-ejecutable invoca las diez `Iniciar*GUI()` (l.100-109:
   Ds, Cc, Ar, HC, Lock, Frente, **Estab**, EstabBtn, Reload, Puntos). La copia es la UI completa
   montada y en pantalla — eso es lo que parpadea en la corrida—, asi que el `RedrawWindow` se mide
   sobre ventanas vivas y el numero se parece mas a la pantalla real que a tu "piso". Un matiz: el
   slider respeta la bandera del ini (`estabGui.visible := (IniRead(…, "visible", "1") = "1")`,
   l.2594), asi que el panel de estabilizacion puede arrancar oculto segun el perfil guardado. Lo que sigue sin medirse es el costo del
   ciclo completo hotkey → repintado, porque el `Sleep(15)` entre muestras deja el arbol quieto.
   Conviene anotar en I13-a que la base es "repintado aislado", no "pulso de tecla".
3. Tu hipotesis de las GUIs huerfanas para el cuelgue de N=20 queda **sin confirmar**: corregido el
   orden del color, el error de `MostrarMiniTexto` desaparece ya al construir la llamada, asi que no
   habra 6 (ni 21) `Gui()` huerfanas. Si la corrida limpia aun se cuelga, se mide aparte como dices.

### Estado de la corrida visible

`--forzar --sinmsg --ejecutar --n=10` esta lista y supervisada por `rd3/ronda5-spike.ps1` (mata solo
su propio arbol por PID, watchdog, y al final re-verifica el hash del ESTABLE). Muestra mini-texto y
el panel de estabilizacion unos segundos. No la lanzo sin confirmacion de que CSP esta sin dibujar:
es su pantalla y su panel.
""" % (len(lines(SP4)), val, read(INFO)))

P.append("""
---

## S3 — Lo pedido de `galeria.ahk` y veredicto sobre tu parche D

Archivo: `ENTREGA CLAUDE 2\\galeria.ahk`, %d lineas, intacto (aun no le aplique el parche D).

### `_DestruirTodo` + `_Reconstruir` (l.384-473): el estado **SI** se reinicia

```text
%s
…
%s
…
%s
```

Resuelto tu "NO VERIFICADO": `_Reconstruir()` llama a `_DestruirTodo()`, que destruye cada `o.g` y
hace `S.wins := []` (l.388), y despues **recrea las ventanas desde cero**. El estado `a` de la
segunda pasada no puede arrastrar el `b` de la primera, asi que el doble `_Par` de tu D1 sobra.

### Estado inicial exacto, leido de los constructores

```text
%s
…
%s
…
%s
…
%s
```

O sea, despues de cada `_Reconstruir()` (y por tanto en la captura `a`):

| Ventana | Estado inicial |
|---|---|
| pill | **fila superior `on:=true`, fila inferior `on:=false`** (por construccion, l.452) |
| keys | `on: true` |
| slider | `on: true`, **`val: 60`** |

Consecuencia para el etiquetado: `_ON`/`_OFF` global no describe el PNG, porque en una misma imagen
las dos filas de pills estan en estados opuestos. Tu eleccion de `_a`/`_b` es correcta; mi
recomendacion es **`_base` / `_flip`**, que es lo que significa. Y un detalle de tu D1: el slider
arranca en 60, no en 25, asi que `_b` es "flip con slider 80" y el `_Par(25)` final queda como
codigo muerto (no hay captura despues y el siguiente `_Reconstruir` resetea igual).

### `_Click`, `_Toggle`, `_SetSlider`, `_Redibujar` (l.613-677)

```text
%s
```

Dos cosas que cambian tu plan de medicion:

- `_Redibujar` **ya loguea estado y tiempo**: l.676 imprime `pill redibujo (ON): 12,34 ms` / `(OFF)`
  / `slider redibujo (val 80): …`. La pareja ON/OFF controlada que pedia D4 esta en el log ventana a
  ventana, sin depender del nombre del PNG. El PNG aporta lo visual; el log, el numero por estado.
- `_Toggle`/`_SetSlider` no comprueban nada: `o.on := !o.on` y `o.val := v` + redibujo inmediato.
  Un valor repetido redibuja igual (no hay guard tipo `ActualizarEstabGUI`), asi que los tiempos de
  la galeria no son comparables 1:1 con los del arbol de produccion.

### `_AutoCapturas` + `_Pasar` tal como estan hoy (l.270-303)

```text
%s
```

Cierro la cuenta de tu D1 con los numeros reales del barrido: `_Pasar(prim, [0.75, 1.0, 1.5])` =
3 escalas x 2 fondos x 2 = **12 PNG**, mas `_Pasar(otro, [1.0, 1.5])` = 2 x 2 x 2 = **8**. Total 20,
como escribiste, pero por 12+8 y no por "5 escalas". El `if (esc = 1.0)` que eliminas es el unico
sitio donde hoy se conmutan las ventanas, y solo al 100 %%; con tu D1 pasa a todas las escalas.
Ningun analisis existente depende de "solo 100 %%": el modo `--oculto` no usa `_Pasar`.
""" % (len(lines(G), ), ext(G, 384, 394), ext(G, 396, 415), ext(G, 466, 473),
       ext(G, 450, 459), ext(G, 492, 494), ext(G, 537, 539), ext(G, 576, 578),
       ext(G, 613, 677), ext(G, 270, 303)))

bot = "\n".join("%5d| %s" % (i, l) for i, l in enumerate(lines(EST)[2263:2264], start=2264))
sig = "\n".join("%5d| %s" % (n, l.strip()) for n, l in
                [(i, l) for i, l in enumerate(lines(EST), start=1)
                 if l.startswith(("ActualizarDsGUI()", "ActualizarCcGUI()", "ActualizarArGUI()",
                                  "ActualizarHCGUI()", "ActualizarLockGUI()", "ActualizarFrenteGUI()",
                                  "ActualizarEstabBtnGUI()"))])

P.append("""
---

## S4 — La funcion que construye `anclas`: `MapaAnclas(lineas)` (spike v4 l.240-288)

```text
%s
```

Y el sitio donde se elige que se mide (spike v4 l.124-132, dentro de `Principal()`; en la v3 era tu
l.110):

```text
%s
```

Para dar la base de F2 son **dos ediciones, no una**, y ninguna toca `ArmarLlamada`:

1. `MapaAnclas`, array `nombres` (l.241-247): anadir `"ActualizarDsGUI"` — y las otras cinco
   hermanas si quieres la familia entera.
2. `Principal()`, l.125: anadir el mismo nombre a la lista que construye `llamadas` (de ahi sale la
   tabla que se mide).

Firmas reales del ESTABLE, medidas:

```text
%s
```

`ArmarLlamada` ya devuelve `nombre "()"` cuando la firma esta vacia, asi que **no hace falta entrada
en `fijas`** para ellas (a diferencia de `ActualizarEstabGUI`, que si necesita el `forzar := true`
para no devolver el guard en ~0,02 ms). Y segun la lectura 1 de S2, la copia tiene las ventanas
creadas, asi que mide el cuerpo real y no un fallo de precondicion.

Salida completa de `anclas_canonico.txt` contra el ESTABLE (la misma que ahora esta pegada en
CONTEXTO §2):

```text
%s
```
""" % (ext(SP4, 240, 288), ext(SP4, 124, 132), sig, anclas))

P.append("""
---

## S5 — CONTEXTO.md actualizado con tus 6 puntos de §5

Respaldo: `CONTEXTO.md.bak-ronda5-20261105-000043` (misma carpeta). Cambios aplicados:

| Punto tuyo | Como quedo |
|---|---|
| §0 | filas nuevas: archivo objetivo ESTABLE, lineas 3.959 + SHA, `_EstabEmitir` l.2909 con RACHA 10 / RITMO 18, huella 29/2/3. Ademas "Prueba de carga" dice PASS sobre ESTABLE+F1 y la fila del arnes cita el respaldo de la recalibracion. |
| §2 | el mapa viejo (lineas del canonico) sustituido por la tabla de anclas del ESTABLE de arriba, con la nota de que `usos` cuenta lineas y no llamadas. |
| I7 | presupuesto por ola, por `ReadAllLines`, 3.959 → 4.040. |
| I11 despues | anadidas I12 e I13 literalmente como las escribiste. |
| §4.5 | anadidos `_TemaValido()` `_TemaFuente()` `_FuenteInstalada()` `_RolDeHex()` `_AvisoColor()` `_LimpiarAvisos()` (F3). |
| §7 | las dos filas nuevas (deuda de `_LimpiarGUIs` desde las funciones de aviso, y la GUI huerfana entre `Gui()` y `floatGui`). |

Tres ajustes de coherencia que anadi sin que los pidieras (dime si prefieres alguno revertido): I5
cita `_EstabEmitir` en l.2909 en vez de 2865; §9 dice huella 29/2/3 y consigna el 31/2/3 del
canonico entre parentesis; §6 lleva una nota de que la columna **Toca** son lineas del canonico y
que al editar se ancle por nombre con §2. La fecha del encabezado pasa a 2026-11-05.

---

## S6 — Lo que necesito para cerrar la ronda 6

1. Visto bueno de Josue para (a) anexar F1 al real y (b) lanzar la corrida visible del spike. Es su
   pantalla; CSP esta abierto ahora mismo.
2. El resultado de la prueba de 20 s del slider (S1).
3. Tu lectura de las dos notas de S2 (ventanas creadas en la copia = la base no es "todo oculto").
   Si aceptas la interpretacion, la corrida con N=10 es directamente comparable con lo que se
   mida en F2.
4. Si aceptas `_base`/`_flip` en vez de `_a`/`_b` y quitar el `_Par(25)` muerto: aplico el parche D
   sobre una copia de `galeria.ahk` y corro el barrido de 20 PNG en el segundo monitor, con la lista
   de nombres (no las imagenes) y el log de redibujos ON/OFF.

Sin PNG adjuntos, como pediste. Ningun `.ahk` ejecutable queda en `rd3`: el spike v4 vive como
`.txt` y las corridas se lanzan desde una copia en `%TEMP%\\ronda5_spike\\`.
""")

txt = "".join(P) + "\n"
open(OUT, "wb").write(txt.encode("utf-8"))
print("escrito:", OUT, len(txt.encode("utf-8")), "bytes")
print("lineas:", txt.count("\n"))
print("sha256:", sha(OUT))
print("fences:", txt.count("\n```"))
