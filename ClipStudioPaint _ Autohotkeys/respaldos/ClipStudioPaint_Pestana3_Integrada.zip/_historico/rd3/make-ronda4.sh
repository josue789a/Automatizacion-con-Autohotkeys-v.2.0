#!/usr/bin/env bash
# Ensambla rd3/RESPUESTA-RONDA4.md: narrative + logs + codigo, TODO dentro del .md.
set -euo pipefail
R="/c/Users/jbard/Desktop/AHK-global-main/ClipStudioPaint _ Autohotkeys/rd3"
EST="/c/Users/jbard/Documents/AntiGravity/Autohotkeys"
SP="$R/spike-v3/spike_latencia.ahk"
OUT="$R/RESPUESTA-RONDA4.md"
AHKG="/c/Users/jbard/Desktop/AHK-global-main/ClipStudioPaint _ Autohotkeys/XPPEN AHK VERSION ESTABLE.ahk"
CAN="$EST/XxxPPEN_a16pg2_displayAS_secondary.ahk"
ARN="$EST/docs/ESTETICA/pruebas.ps1"
TEMPDIR="/c/Users/jbard/AppData/Local/Temp"

# numero | contenido (recorta CR)
ext() { awk -v s="$2" -v e="$3" 'sub(/\r$/,""); NR>=s && NR<=e {printf "%5d| %s\n", NR, $0}' "$1"; }
num() { awk 'sub(/\r$/,""); {printf "%5d| %s\n", NR, $0}' "$1"; }
sha() { sha256sum "$1" | cut -c1-64 | tr 'a-f' 'A-F'; }

{
cat <<'EOF'
# RESPUESTA RONDA 4 — Josue/Qoder -> Claude 3

Generado 2026-11-04 23:40, desde la maquina de Josue. **Todo el contenido va pegado en este
archivo**: no hace falta ningun adjunto para responder. Si algo no esta aqui, es que no existe.

Arbol de referencia confirmado (tu T4 en firme): **ESTABLE**, 3.959 lineas leidas por
`ReadAllLines`, SHA-256 medido:

EOF
echo "- ESTABLE  \`$(sha "$AHKG")\`"
echo "- canonico \`$(sha "$CAN")\`"
cat <<'EOF'

Indice de lo que ContestA a tu seccion 6, en tu orden:

| # | Pediste | Estado |
|---|---|---|
| 1 | Salida del comando de tu 2 (las 2 lineas `.Show("...")`) | resuelto, S1 |
| 2 | `-Modo esteril` sobre el ESTABLE con F1 | **PASS**, S2 |
| 3 | Extractos + `Fin()` + lectura de `A_Args` | pegados, S4 |
| 4 | Corrida del paso 4 con huellas | **hecha**, con tabla y 4 hallazgos, S3 |

---

## S1 — Las 2 lineas `.Show("...")` que solo estan en el canonico

Comando ejecutado (tu formula, sobre los dos arboles):

```powershell
Select-String -Path $can,$est -Pattern '\.Show\("'   # + Compare-Object de lineas trimadas
```

Resultado literal:

```text
canonical .Show(" count = 31
estable   .Show(" count = 29

=== SOLO EN CANONICO ===
  estabGui.g.Show("NoActivate")
  estabGui.g.Show("NoActivate")
=== SOLO EN ESTABLE ===
  (ninguna)
```

Ambas son la **misma cadena**, y las dos son del slider, no de avisos ni botoneras. Identificadas
una a una en el canonico:

**a) canonico l.2537 — dentro del toggle de visibilidad del slider.** En el ESTABLE ese bloque se
reescribio para llamar a `_AplicarEstabVisibilidadBase()` (ESTABLE l.1792-1800), que si contiene un
`.Show("NoActivate")` (esa es una de las 29). El diff real:

```text
@@ -2532,9 +2574,8 @@
     estabGui.visible := !estabGui.visible
     IniWrite(estabGui.visible ? 1 : 0,_PosGuiIniPath(),"Estab_p" PERFIL,"visible")
-    if (estabGui.visible && enfoque.activo) {
-        if (IsObject(estabGui.g) && !DllCall("IsWindowVisible","Ptr",estabGui.g.Hwnd))
-            estabGui.g.Show("NoActivate")
+    if estabGui.visible {
+        _AplicarEstabVisibilidadBase()
         ActualizarEstabGUI()
     } else if (IsObject(estabGui.g) && !estabGui.foco)
         estabGui.g.Hide()
```

**b) canonico l.2824 — dentro de `_EstabFocoOcultar()`.** El branch `Show` se elimino y queda solo
el `Hide`:

```text
@@ -2820,9 +2867,7 @@
-    if (enfoque.activo && estabGui.visible)
-        estabGui.g.Show("NoActivate")
-    else
+    if (!enfoque.activo || !estabGui.visible)
         estabGui.g.Hide()
```

Las dos caen en el caso que tu regla autoriza: **codigo reescrito del bloque `rectNormal`/foco**,
no una GUI que el arnes deba ocultar. Verificacion adicional que hice antes de tocar nada: las 3
`.Show("NoActivate")` que quedan en el ESTABLE (l.1796, l.2851, l.2998) cubren los tres caminos por
los que el slider puede volver a verse, y el regex del arnes (`.Show("` -> `.Show("Hide " "`) sigue
aplicandose a las 29. Ninguna GUI escapa a la ocultacion.

Debt funcional anotada (no la toco, I8): en (b) el slider **deja de reaparecer** al salir del foco
si `enfoque.activo && estabGui.visible`; antes se re-mostraba. Es un cambio de conducta del ESTABLE
respecto al canonico, no un error del arnes.

### Recalibracion aplicada

`docs/ESTETICA/pruebas.ps1`, respaldo `pruebas.ps1.bak-ronda4-20261104-232447`. Estado actual:

```powershell
EOF
ext "$ARN" 202 222
cat <<'EOF'
```

Consecuencia que debes saber: con 29/2/3 el arnes **rechaza el canonico de 3.917**. Es coherente
con T4 (el canonico ya no es la fuente de verdad), pero si alguien apunta `-Raiz` al arbol viejo,
verá un FAIL de huella y no un problema de sintaxis.

---

## S2 — `-Modo esteril` sobre el ESTABLE con el bloque F1: PASS

Escenario: copia del ESTABLE + F1 pegado al final, en `%TEMP%\ronda4_arnes\` (sin espacios, y el
arnes exige el nombre `XxxPPEN_a16pg2_displayAS_secondary.ahk`). El ESTABLE real nunca se toca;
se comprueba su hash antes y despues.

- `lineas    : 4040   (ESTABLE solo = 3959)` — tu presupuesto I7 por ola: inicio 3.959, F1 4.040, +81.
- `sha256` del escenario: `894B4634027FEA278E3353AA544EFD4FCB661BFE243F8BC1A5E2E5AE8BCEC9AB`

Volcado literal de `rd3/ronda4-arnes.log`:

```text
EOF
sed -e 's/\r$//' "$R/ronda4-arnes.log"
cat <<'EOF'
```

**Lee esto como el cierre del bloqueo de F1.** La I4 (prueba de carga) era lo unico que impedía
aplicar el bloque: antes fallaba solo por la huella. Con 29/2/3, `parse` y `esteril` dan PASS y la
copia arranca y termina limpia en 2,2 s con stderr vacio. El test funcional de `_Tema` ya habia
salido 14/14 exacto en la ronda 3.

---

## S3 — Paso 4 con huellas: la tabla existe, y el timer SII dispara

Esto responde a la sospecha de tu ronda ("el timer -2500 de la copia nunca dispara"). **Si dispara.**
Los latidos lo prueban y ademas enseñan 4 cosas que no sabiamos.

### Lo que tuve que arreglar para poder correrlo

1. **La plantilla del inyectable tenia un backtick sin doblar** y por eso la copia nunca cargo.
   La fila de `_LatHb` estaba escrita

   ```ahk
   try FileAppend(A_TickCount " | " t "`r`n", "@@HB@@", "UTF-8")     -> /validate exit 2
   ```

   Dentro del literal `c := "` + `( ... )` + `"`, un backtick se interpreta al parsear el spike y
   se convierte en CR/LF real: la copia salia con la instruccion partida en dos lineas. Error de
   carga exacto:

   ```text
   ...\latencia_f0\prueba_latencia.ahk (3966) : ==> Missing """
        Specifically: try FileAppend(A_TickCount " | " t "
   ```

   Correction de 1 caracter, ya aplicada en el spike v3: `"``r``n"`. Regla para el resto del
   proyecto: **dentro de la plantilla del inyectable, todo backtick va doblado** (`_LatMedir` y
   `_LatBase` ya lo hacian; `_LatHb` era la unica que no).

2. **`--prod` no acepta rutas con espacios** (ya lo avise): `A_Args` parte por espacios y
   `ClipStudioPaint _ Autohotkeys` se rompe en 3 argumentos. Se ensaya el archivo en
   `%TEMP%\ronda4_prod\` con hash identico al real.

3. `--forzar` es obligatorio hasta que el spike apunte al ESTABLE: espera 3.917 lineas y el hash
   `CEF745C7...`; el arbol de referencia es 3.959 / `6375B86D...`. **No** cambie esas constantes
   sin tu visto bueno.

### Spike v3 (tu copia + T1.1 + huellas + backtick)

`rd3/spike-v3/spike_latencia.ahk` — 377 lineas, SHA-256 `59031CD890F786F63E9B3D872F26BF7B1FD347D203D98B7E979896CD0F1EF126`.
Es exactamente el archivo que subiste en `ENTREGA CLAUDE 2`, con tu parche T1.1 aplicado y las 5
llamadas `_LatHb`. En el zip va como `.txt` para que nadie lo ejecute con doble clic (ver S6).

### Latencias base, ESTABLE, N=5 (corrida 23:37)

```text
EOF
sed -ne '/Latencias base/,/Criterio I13/p' "$R/spike-v3/latencia_base.txt" | sed -e 's/\r$//' -e 's/^\xef\xbb\xbf//'
cat <<'EOF'
```

Latidos de la copia (`A_TickCount | etapa`):

```text
EOF
sed -e '1s/^\xef\xbb\xbf//' -e 's/\r$//' "$TEMPDIR/latencia_f0/heartbeat_latencia.txt"
cat <<'EOF'
```

Y la verificacion de integridad de esa misma corrida: `Produccion intacta: SI`,
`ESTABLE real intacto: SI`, stderr de la copia **vacio**.

### Los 4 hallazgos, en orden de importancia para ti

**(1) `ActualizarEstabGUI = 0,020 ms` es el guard, no el redibujado.** La llamada armada es
`ActualizarEstabGUI()` con `v = -1, forzar = false`, y ESTABLE l.2748 corta antes de dibujar:

```text
 2747|     sig := estabGui.ancho "x" estabGui.alto "x" estabGui.horiz
 2748|     if (!forzar && v = estabGui.dibV && sig = estabGui.dibG)
 2749|         return
```

Es la razon exacta por la que tu I13-b (nuevo metodo <= 2 ms sobre la base) **no se puede decidir
con este numero**. La base del slider hay que medirla forzando el dibujo (`ActualizarEstabGUI(25,true)`
o alternando `v`), y `ArmarLlamada()` no sabe generar un literal `true`.

**(2) `MostrarMiniTexto` midio 0 llamadas validas: 6 errores `Invalid option.`** Los 6 = warm-up + 5,
o sea todas. Causa: `ArmarLlamada` prueba primero `(txt|texto|text|msg|mensaje)` y despues
`(col|color|hex|clr)`; el parametro `colorTexto` gana el primer patron y recibe `"LAT"`, que acaba
en `g.AddText("c" colorTexto " Center w" ...)` -> opcion de color invalida. Los 73 ms medidos son
el coste de lanzar la excepcion, no la funcion. Fix minimo: invertir el orden de los `if`  (o probar
`^color` antes que `txt`), o anadir una regla explicita `color*` -> hex.

**(3) `MostrarHUD` si es real: mediana 20,3 ms, max 98,2 ms con N=5.** Ojo porque el `Sleep(15)`
entre muestras no evita que se creen y destruyan 6 GUIs; el max de 98 ms es el primer caso o un
pico con recoleccion. Para F2 el numero util es la mediana, y el criterio de 2 ms de I13-a sigue
sin base valida de slider.

**(4) Con N=20 la copia no termino nunca; con N=5 tardo 1,25 s.** Los latidos de la corrida N=20
se detienen en `empieza MostrarMiniTexto` y el watchdog mato el arbol a los 45 s, con stderr
vacio. Con N=5 la misma secuencia cierra con `salida escrita`. La diferencia son 21 GUIs+timers de
`MostrarMiniTexto` en vez de 6; no lo he diagnosticado mas (I8: no toco lo que no me toca).
Sugerencia: N=8 o N=10 como defecto del spike, y no subir de ahi hasta que (2) este arreglado.

---

## S4 — Extractos pedidos, pegados aqui

Origenes: `spike_latencia.ahk` v3 (hash arriba) y `galeria.ahk` de `ENTREGA CLAUDE 2`
(1.030 lineas, SHA `F611A498855E13729FBF4F0D9F9F18B2EDE84DF3E1C6500D4F044766F2A69761`).
Numeracion = linea real del archivo. Nada transcrito a mano.

### `A_Args` — lectura de opciones (l.35-52)

```ahk
EOF
ext "$SP" 35 52
cat <<'EOF'
```

Aqui es donde tu `ArgsUnidos()` iria INSERT-BEFORE. Reparo que debes saber: en esta version las
constantes `HASH_ESPERADO`/`LINEAS_ESPERADAS` (l.35-36) ya son las reales del canonico, y el bug
`REP`/`Rep` esta resuelto por tu propio T1.1.

### `Fin()` y su entorno (l.188-208)

```ahk
EOF
ext "$SP" 188 208
cat <<'EOF'
```

El `MsgBox` de `Fin()` es lo que bloquea la corrida sin supervision (el proceso queda vivo hasta
que alguien pulsa Aceptar; si ademas lo abre un usuario desde el Explorer, puede quedar elevado e
inmortalizable sin UAC). Mi arnes lo resuelve matando el arbol del spike por PID, pero eso no es
portable: de ahi tu parche `--sinmsg`.

### `Principal()` — generador de la copia (l.89-157)

```ahk
EOF
ext "$SP" 89 157
cat <<'EOF'
```

### `Inyectable()` — `_LatHb` / `_LatQPC` / `_LatMedir` / `_LatBase` (l.299-377)

```ahk
EOF
ext "$SP" 299 377
cat <<'EOF'
```

### Lo que pediste de `galeria.ahk` (`_AutoCapturas`, `_Pasar`, `_Ocluyentes`, `_Captura`, `_PosLibre`)

Se perdio como adjunto en la ronda 3; va integro aqui debajo.

EOF
sed -e 's/\r$//' "$R/EXTRACTOS-ronda3.md" | sed -e 's/^## /#### /' -e 's/^# /### /'
cat <<'EOF'

> Nota: la seccion "Estado del diagnostico de huellas (para T1.2)" de arriba quedo superada por la
> S3 de este archivo: ya hay corrida, hay latidos y hay tabla.

---

## S5 — Mapa de anclas del ESTABLE (recien generado, 23:36)

`anclas_canonico.txt` produced by the spike v3 dry run against the ESTABLE. Esto es lo que
reemplaza tus numeros de linea de CONTEXTO 2:

```text
EOF
num "$R/spike-v3/anclas_canonico.txt" | sed 's/^ *[0-9]*| //'
cat <<'EOF'
```

Tres lecturas utiles: `_LimpiarAvisos` y `Sanar` siguen con `def=0 usos=0` (D2 sigue abierta, no
existe a quien llamar); `_FadeAlpha` existe con `usos=7` (I12 tiene objeto); y las firmas reales de
las tres funciones medidas son las que salen en S3.

---

## S6 — Dos incidentes en pantalla de Josue (para que no se repitan)

1. A las 23:28 abrio con doble clic `rd3\spike-v3\spike_latencia.ahk` (la carpeta se le creyo un
   entregable). Salto `Fin()` con "no existe el .ahk canonico" porque la ruta por defecto del spike
   (`A_ScriptDir \..\..\..\`) no apunta a ningun sitio desde ahi. Tuve que pedirle que cerrara el
   cuadro: un proceso **elevado** no se puede matar desde esta consola, y mientras vivia bloqueo
   mi corrida por `#SingleInstance Force`.
   -> Desde ahora los `.ahk` del paquete viajan como `.txt`; el ejecutable solo vive en `%TEMP%`.
2. A las 23:35 y 23:37 parpadearon las GUIs del script unos segundos (corridas N=20 y N=5). Anunciado
   antes y supervisado: los dos arboles se cerraron por PID. Su companion ESTABLE se cae y el lo
   relanzo a las 23:35:15 (PID 17336); no hay senal de que mis copias lo tocaran: el hash del
   ESTABLE es idéntico antes y despues de cada corrida.

---

## S7 — Lo que necesito de ti en la ronda 5 (orden de bloqueos)

1. **`ArmarLlamada()` corregido** (orden de los `if` de nombre) y **una forma de forzar el
   redibujado del slider** en la medicion, para tener la base real de `ActualizarEstabGUI`. Sin
   eso, I13-b no se decide y D4 no se firma.
2. **`--sinmsg`** (o `Fin()` sin cuadro cuando hay `--ejecutar`) y el parche de huellas ya no hace
   falta: esta aplicado en v3. Si quieres el diff exacto de las 9 lineas, esta en S4.
3. **`_Pasar` con pareja ON/OFF controlada** por fondo y escala (hueco D4-a del 5), y decision de
   D6 (`FFFFFF` vs `E8ECF4`) que depende de esas capturas.
4. **Veredicto F1 / arranque de F2.** F1 esta verde en los tres test (validate, `_Tema` 14/14,
   esteril PASS con el bloque puesto). Tienes via libre para pedir su aplicacion al archivo real
   con `.bak-ola1-<fecha>` (I2) o para decir que F2 se disena encima sin aplicarlo aun.
5. Si vas a tocar el arnes otra vez: la huella vive en `pruebas.ps1:213-216` y su respaldo es
   `pruebas.ps1.bak-ronda4-20261104-232447`.

### Como reproducir todo esto (por si quieres verificar sin mi pantalla)

```powershell
# S1: las 2 lineas .Show
$can="C:\Users\jbard\Documents\AntiGravity\Autohotkeys\XxxPPEN_a16pg2_displayAS_secondary.ahk"
$est="C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk"
Compare-Object (Select-String $can -Pattern '\.Show\("' | ForEach-Object { $_.Line.Trim() }) `
               (Select-String $est -Pattern '\.Show\("' | ForEach-Object { $_.Line.Trim() })

# S2: arnes con F1  (los .ps1 estan en el zip; -Raiz apunta a una copia en TEMP sin espacios)
& "$env:TEMP\ronda4\rd3\ronda4-arnes.ps1"

# S3: spike v3, seco y ejecutado (parpadea las GUIs; no lo corras mientras dibuja)
& "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" "...\spike_latencia.ahk" --forzar --prod="$env:TEMP\ronda4_prod\XxxPPEN_a16pg2_displayAS_secondary.ahk" --n=5
```

EOF
} > "$OUT"
wc -c "$OUT"
