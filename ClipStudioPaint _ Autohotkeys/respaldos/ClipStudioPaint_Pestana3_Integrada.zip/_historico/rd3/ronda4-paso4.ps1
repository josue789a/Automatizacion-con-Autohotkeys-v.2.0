# Ronda 4, item 4: corrida supervisada del paso 4 (latencias base + huellas).
# -Seco : pasos 1-4 sin ejecutar la copia (0 GUIs, 0 parpadeo).
param([switch]$Seco, [int]$Muestras = 20)
$ErrorActionPreference = 'Stop'
$ahk   = "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"
$spike = "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\spike-v3\spike_latencia.ahk"
$est   = "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk"

# El --prod se pasa por una ruta SIN ESPACIOS: A_Args parte por espacios y
# "ClipStudioPaint _ Autohotkeys" se rompe en tres argumentos.
$prod = Join-Path $env:TEMP 'ronda4_prod\XxxPPEN_a16pg2_displayAS_secondary.ahk'
New-Item -ItemType Directory -Force (Split-Path $prod) | Out-Null
Copy-Item $est $prod -Force
"prod en escenario : $prod"
"sha256 escenario  : $((Get-FileHash $prod -Algorithm SHA256).Hash)"
"sha256 real       : $((Get-FileHash $est  -Algorithm SHA256).Hash)"

# Limpiar resultados de corridas anteriores.
foreach ($f in @('latencia_base.txt', 'anclas_canonico.txt')) {
    Remove-Item (Join-Path (Split-Path $spike) $f) -ErrorAction SilentlyContinue
}
Remove-Item (Join-Path $env:TEMP 'latencia_f0\*') -Recurse -Force -ErrorAction SilentlyContinue

$flags = if ($Seco) { '--forzar' } else { '--ejecutar --forzar' }
$arg = "`"$spike`" $flags --prod=`"$prod`" --n=$Muestras"
"lanzando          : AutoHotkey64.exe $arg"
$p = Start-Process $ahk -ArgumentList $arg -PassThru
"pid spike         : $($p.Id)"

$inf  = Join-Path (Split-Path $spike) 'latencia_base.txt'
$hb   = Join-Path $env:TEMP 'latencia_f0\heartbeat_latencia.txt'
$sal  = Join-Path $env:TEMP 'latencia_f0\salida_latencia.txt'
$t0 = Get-Date
$muerte = $null
while (((Get-Date) - $t0).TotalSeconds -lt 120) {
    if ((Test-Path $inf) -and (Get-Item $inf).Length -gt 200) { $muerte = 'informe escrito'; break }
    if (-not (Get-Process -Id $p.Id -ErrorAction SilentlyContinue)) { $muerte = 'el proceso termino solo'; break }
    Start-Sleep -Milliseconds 500
}
"salida            : $muerte  ({0:n1} s)" -f ((Get-Date) - $t0).TotalSeconds

# El MsgBox de Fin() bloquea el ExitApp: se cierra solo el arbol del spike.
if (Get-Process -Id $p.Id -ErrorAction SilentlyContinue) {
    "matando pid spike $($p.Id) y su arbol (MsgBox de Fin() abierto)"
    & taskkill /PID $p.Id /T /F | Out-Null
}
Start-Sleep -Seconds 1
"vivos de AutoHotkey tras el cierre:"
Get-Process -Name AutoHotkey64, AutoHotkey -ErrorAction SilentlyContinue |
    Select-Object Id, StartTime, MainWindowTitle | Format-Table -AutoSize | Out-String

Write-Host ''
Write-Host '==================== latencia_base.txt ===================='
if (Test-Path $inf) { Get-Content $inf } else { '(no existe)' }
Write-Host ''
Write-Host '==================== heartbeat_latencia.txt ================'
if (Test-Path $hb) { Get-Content $hb } else { "(no existe): $hb" }
Write-Host ''
Write-Host '==================== stderr de la copia ===================='
$errf = Join-Path $env:TEMP 'latencia_f0\stderr_latencia.txt'
if (Test-Path $errf) { $e = (Get-Content $errf -Raw); if ([string]::IsNullOrWhiteSpace($e)) { '(vacio)' } else { $e } } else { '(no existe)' }
Write-Host ''
"ESTABLE real intacto : $(if ((Get-FileHash $est).Hash -eq '6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D') {'SI'} else {'NO !!!'})"
