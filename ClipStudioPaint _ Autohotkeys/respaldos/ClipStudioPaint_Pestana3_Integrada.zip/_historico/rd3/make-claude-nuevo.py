"""Genera PAQUETE-CLAUDE-NUEVO.md: un solo archivo autocontenido para un chat de Claude
que empieza de cero (no ve el PC de Josue ni tiene los archivos). Todo va pegado dentro
del md; el zip es opcional. Sin backticks sin doblar: este generador escribe por partes."""
import io, os, re, hashlib

RAIZ = r"C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys"
ESTABLE = os.path.join(RAIZ, "XPPEN AHK VERSION ESTABLE.ahk")
CONTEXTO = r"C:\Users\jbard\Documents\AntiGravity\Autohotkeys\docs\ESTETICA\CONTEXTO.md"
OLA0 = os.path.join(RAIZ, "rd3", "ola0-dwm", "OLA0-RESULTADO.md")
CENSO = os.path.join(RAIZ, "rd3", "ola0-dwm", "censo_color.txt")
F1 = os.path.join(RAIZ, "rd3", "f1_tema.txt")
THEME = os.path.join(RAIZ, "theme.ini")
SALIDA = os.path.join(RAIZ, "rd3", "PAQUETE-CLAUDE-NUEVO.md")


def leer(p):
    return io.open(p, encoding="utf-8", errors="replace").read()


def sha(p):
    return hashlib.sha256(io.open(p, "rb").read()).hexdigest().upper()


est = leer(ESTABLE).split("\n")
botoneras = "\n".join("%5d  %s" % (i + 1, l) for i, l in enumerate(est[2246:2584], start=2246))

BRIEF = """# PAQUETE PARA UN CHAT NUEVO DE CLAUDE (2026-11-05 02:10)

Eres un chat **nuevo de Claude** sin memoria ni archivos: todo lo que necesitas esta pegado
aqui. No intentes leer el PC del usuario: no lo ves. Las pruebas ya estan hechas y sus
numeros estan abajo; **no vuelvas a pedirlas**.

## Quien es quien
- **Josue** - ilustrador, dona el PC. Trabaja en Clip Studio Paint con un companion en
  **AutoHotkey v2** que le pinta paneles flotantes (botoneras, HUD, badge, un deslizador de
  estabilizacion) y le reenvia atajos. El archivo vivo es `XPPEN AHK VERSION ESTABLE.ahk`.
- **Qoder** - el agente ejecutor. Corre el runtime real, mide, valida y edita. Escribe los
  informes. Este paquete lo firma el.
- **Tu rol (arquitecto)** - decidir, dictar parches anclados por nombre de funcion y revisar
  los numeros. **No tienes runtime**: todo lo que propongas se ejecuta y se mide aqui, y lo
  que no se pueda medir en este Windows se dice con numbers, no con opinion.

## Estado en una linea
Fase 0 cerrada. **Ola 0 (spike DWM) cerrada con numeros** (seccion 3). Ola 1 (tokens de color)
**lista para dictar**: el cargador `_Tema()` ya esta **dentro del archivo real** y nadie lo llama
todavia. Las olas 2-5 sin empezar.

## Lo que se te pide AHORA (tres cosas, en este orden)
1. **Decidir la forma de la pill** (ola 2), que la ola 0 dejo abierta: un control hijo **no
   puede redondearse** (DWM rechaza el hwnd hijo con ERROR_INVALID_HANDLE), asi que o
   (a) pill = control `Text` con recorte GDI+/Region propio, o (b) pill = **ventana sin caption
   propia** que hereda el arco del sistema gratis. Cuesta (a) ~1 region por repintado y (b)
   15-63 ms por ventana en el arranque y N hwnds mas.
2. **Que hacer con `[radius] sm=6 md=10 lg=14`** del token de tema: el sistema solo ofrece
   recto / ~7-8 px / ~11-13 px. Propon si los tokens se redefinen a esos 3 valores o si se
   declaran solo validos para recortes propios.
3. **Dictar la ola 1** sobre el censo de la seccion 6: 51 literales en las 7 botoneras,
   mapeados 1:1 a los tokens de `theme.ini` (seccion 5). Ancla por nombre de funcion, no por
   numero de linea (I1). Maximo ~100 lineas por ola (I7).

## Reglas del juego (no negociables; estan en I1-I13 de la seccion 2)
- Cualquier edicion del archivo real **reinicia el companion de Josue a los ~2 s** y le corta
  la sesion de dibujo. Las ediciones van **entre sesiones**, con `.bak-olaN-<fecha>` previo.
- El archivo real **no se pega entero jamas**: diffs anclados o la funcion completa.
- Nada de `Sleep` en rutas de input, nada de tocar `#HotIf`, nada de tocar `_FadeAlpha` (I12).
- `theme.ini` y `posiciones_gui.ini` son archivos de usuario: **no se sobreescriben**, se leen.

## Lo que ya esta medido y NO debe volver a proponerse
- Guardar PNG desde GDI+ dentro del proceso AHK: **roto en este PC** (devuelve 10 y deja 0
  bytes en las 4 variantes probadas). La evidencia sale de PowerShell con `System.Drawing`.
- Redondear un **control** con `DwmSetWindowAttribute`: rechazado (`0x80070006`).
- `SetLayeredWindowAttributes` a mano sobre una Gui de AHK: falla (`gle=87`). Usar
  `WinSetTransparent`.
- Usar **PrintWindow como evidencia visual de un fade**: ignora el alfa y el arco (captura
  solida una ventana al 40 %). Sirve para contenido, no para estado de opacidad.
- El techo I13-a "funcion nueva <= 2 ms" **no aplica a crear ventanas** (cuesta 15-63 ms una
  vez); aplica a repintados. `WinSetTransparent` mide **0,0 ms por paso**.

## Como responder
Un solo bloque de texto: (1) la decision de la pill con su justificacion de coste, (2) que
haces con `[radius]`, (3) el parche de la ola 1 en trozos anclados
`ANTES -> DESPUES` por funcion, con el numero de sustituciones esperadas (debe dar 51).
Si necesitas ver codigo que no esta aqui, pide **la funcion por nombre** y Qoder la pega.
"""


def bloque(titulo, ruta, lang):
    txt = leer(ruta)
    n = len(txt.split("\n"))
    return ("\n\n---\n\n## %s\n\n`%s` - %d lineas - sha256 `%s`\n\n```%s\n%s\n```\n"
            % (titulo, os.path.basename(ruta), n, sha(ruta), lang, txt.rstrip()))


partes = [BRIEF]
partes.append("\n\n---\n\n# SECCION 1 - CONTEXTO del proyecto (CONTEXTO.md verbatim)\n")
partes.append(leer(CONTEXTO).rstrip())
# OLA0-RESULTADO.md lleva sus propios bloques ``` : se pega verbatim, sin fence exterior.
o0 = leer(OLA0).rstrip()
partes.append("\n\n---\n\n# SECCION 2 - OLA 0 cerrada: resultado medido\n\n"
              "`OLA0-RESULTADO.md` verbatim - %d lineas - %d bytes - sha256 `%s`\n\n%s\n"
              % (len(o0.split("\n")), os.path.getsize(OLA0), sha(OLA0), o0))
partes.append(bloque("SECCION 3 - theme.ini tal como esta en el disco", THEME, "ini"))
partes.append(bloque("SECCION 4 - F1: el bloque `_Tema()` YA APLICADO al real (l.3960-4038)", F1, "ahk"))

censo_txt = leer(CENSO).rstrip()
partes.append("\n\n---\n\n## SECCION 5 - censo mecanico de literales de color (generado por `censo.py` sobre el real)\n\n"
              "Ola 1 = sustituir **solo** los del rango 2247-2584 (las 7 botoneras: `IniciarDsGUI`\n"
              "a `IniciarEstabBtnGUI`, cada una con su `Actualizar*GUI` dentro). Son **51**.\n"
              "El resto del archivo (263 en total, 65 funciones) entra en olas posteriores.\n\n"
              "```text\n%s\n```\n" % censo_txt)

partes.append("\n\n---\n\n## SECCION 6 - las 7 botoneras tal como estan (l.2247-2584 del real, con numeracion)\n\n"
              "```ahk\n%s\n```\n" % botoneras)

manifiesto = ["\n\n---\n\n## MANIFIESTO (sha256 de lo que se uso para armar este paquete)\n\n",
              "| archivo | lineas | bytes | sha256 |\n|---|---|---|---|\n"]
for etiqueta, ruta in [("CONTEXTO.md", CONTEXTO), ("OLA0-RESULTADO.md", OLA0),
                      ("censo_color.txt", CENSO), ("theme.ini", THEME),
                      ("f1_tema.txt (bloque F1 aplicado)", F1),
                      ("probe_dwm.txt (spike ola 0)", os.path.join(RAIZ, "rd3", "ola0-dwm", "probe_dwm.txt")),
                      ("XPPEN AHK VERSION ESTABLE.ahk (real, sin tocar)", ESTABLE)]:
    t = leer(ruta)
    manifiesto.append("| %s | %d | %d | `%s` |\n" % (etiqueta, len(t.split("\n")),
                                                     os.path.getsize(ruta), sha(ruta)))
partes.append("".join(manifiesto))

paquete = "".join(partes)
io.open(SALIDA, "w", encoding="utf-8", newline="\n").write(paquete)
print("escrito:", SALIDA)
print("lineas:", len(paquete.split("\n")), "bytes:", len(paquete.encode("utf-8")))
print("sha256:", hashlib.sha256(paquete.encode("utf-8")).hexdigest().upper())
