# Ronda 5, item 2: spike v4 con los parches A/B/C de Claude.
# -Seco    : sin --ejecutar (0 GUIs en pantalla).
# -SinRuta : prueba la rama de fallo (prod inexistente) sin cuadro de dialogo.
# -Visible : corrida real; MUESTRA mini-texto y el panel de estabilizacion unos segundos.
param([switch]$Seco, [switch]$SinRuta, [switch]$Visible, [int]$Muestras = 10)
$ErrorActionPreference = 'Stop'
$ahk   = "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"
$dir   = "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\rd3\spike-v4"
$est   = "C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk"
# Hash DEL ESTABLE ya con F1 anexado (ronda 5, S1). Sin F1 era 6375B86D…3A7D.
$HASH_EST = 'DC012821F6767BEB1F55D2FD2CAC42B853A14B3DBEF269C7FB7A355F1A2FEED5'

# El .ahk ejecutable NO vive en rd3 (Josue abre esas carpetas y los lanza con doble clic).
$run   = Join-Path $env:TEMP 'ronda5_spike'
New-Item -ItemType Directory -Force $run | Out-Null
$spike = Join-Path $run 'spike_latencia.ahk'
Copy-Item (Join-Path $dir 'spike_latencia.txt') $spike -Force

foreach ($f in @('latencia_base.txt', 'anclas_canonico.txt')) { Remove-Item (Join-Path $run $f) -ErrorAction SilentlyContinue }
Remove-Item (Join-Path $env:TEMP 'latencia_f0\*') -Recurse -Force -ErrorAction SilentlyContinue

# --prod va SIN comillas y con espacios: prueba el ArgsUnidos() del parche C1.
$prod = if ($SinRuta) { 'C:\ruta\que\no\existe.ahk' } else { $est }
$flags = if ($Seco) { '--forzar --sinmsg' } else { '--forzar --sinmsg --ejecutar' }
$argList = "`"$spike`" $flags --n=$Muestras --prod=$prod"
"lanzando: AutoHotkey64.exe $argList"

$p = Start-Process $ahk -ArgumentList $argList -PassThru
"pid spike: $($p.Id)"

$inf = Join-Path $run 'latencia_base.txt'
$hb  = Join-Path $env:TEMP 'latencia_f0\heartbeat_latencia.txt'
$t0  = Get-Date
$espera = if ($Seco -or $SinRuta) { 40 } else { 150 }
$nota = 'sigue vivo'
while (((Get-Date) - $t0).TotalSeconds -lt $espera) {
    if (Test-Path $inf) { if ((Get-Item $inf).Length -gt 200) { $nota = 'informe escrito'; break } }
    if (-not (Get-Process -Id $p.Id -ErrorAction SilentlyContinue)) { $nota = 'proceso terminado'; break }
    Start-Sleep -Milliseconds 400
}
if (Get-Process -Id $p.Id -ErrorAction SilentlyContinue) {
    "AVISO: el spike sigue vivo tras $espera s; con --sinmsg no deberia haber cuadros. Matando arbol."
    & taskkill /PID $p.Id /T /F | Out-Null
} else {
    $p.Refresh()
    $nota += "  (exit $($p.ExitCode))"
}
"salida : $nota  ({0:n1} s)" -f ((Get-Date) - $t0).TotalSeconds
Start-Sleep -Seconds 1
"AutoHotkey vivos ahora:"
Get-Process -Name AutoHotkey64, AutoHotkey -ErrorAction SilentlyContinue |
    Select-Object Id, StartTime, MainWindowTitle | Format-Table -AutoSize | Out-String

Write-Host ''
Write-Host '==================== latencia_base.txt ===================='
if (Test-Path $inf) { Get-Content $inf } else { '(no existe)' }
Write-Host ''
Write-Host '==================== heartbeat_latencia.txt ================'
if (Test-Path $hb) { Get-Content $hb } else { '(no existe)' }
Write-Host ''
Write-Host '==================== stderr de la copia ===================='
$errf = Join-Path $env:TEMP 'latencia_f0\stderr_latencia.txt'
if (Test-Path $errf) { $e = (Get-Content $errf -Raw); if ([string]::IsNullOrWhiteSpace($e)) { '(vacio)' } else { $e } } else { '(no existe)' }
Write-Host ''
$actual = (Get-FileHash $est -Algorithm SHA256).Hash
"ESTABLE real intacto : $(if ($actual -eq $HASH_EST) { 'SI' } else { 'NO !!! ' + $actual })"
