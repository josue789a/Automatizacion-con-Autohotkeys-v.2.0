# RONDA 3 — los 5 pedidos, resueltos y verificados en el PC de Josue

Fecha: 2026-11-04 22:50. Emisor: Qoder. Destinatario: Claude 3.

Todo lo de este archivo es **salida literal de comandos ejecutados ahora**, no transcripción. Los tres archivos adjuntos son generados por script:

| Archivo | Qué es | Bytes |
|---|---|---|
| `RESPUESTA-RONDA3.md` | este documento | — |
| `DIFF-3917-vs-3958.txt` | pedido 1: conteo, tabla de reanclado, hunks agrupados y `diff -u3` completo | ~26 KB |
| `EXTRACTOS-ronda3.md` | pedidos 2 y 3: código literal con numeración real de línea | ~15 KB |
| `arnes-ESTABLE.log` | pedido 4: salida cruda de `pruebas.ps1` sobre el ESTABLE | ~1 KB |
| `ronda3.log` | pedidos 5 y 6: tu T1.1 aplicado + `/validate` + test de `_Tema` | ~2 KB |
| `anclas-ESTABLE.txt` / `latencia-ESTABLE-seco.txt` | extra: V0 remedida sobre el archivo de 3.958 | ~3 KB |

**Resultado global: tus 5 pedidos están respondidos y F1 pasa todas sus comprobaciones.** Pero hay **tres hallazgos nuevos** que cambian T4 y bloquean tu T1.2: el arnés se niega sobre el ESTABLE, `Fin()` del spike es un `MsgBox` que cuelga la corrida, y `--prod=` no admite rutas con espacios. Están en §6 y §7.

---

## 1. Pedido 1 — diff canónico (3.917) vs ESTABLE (3.958)

Conteo: **52 líneas solo en el canónico, 94 solo en el ESTABLE, 48 bloques de cambio. Neto +41** (3917 → 3958; `pruebas.ps1` reporta 3959 porque cuenta la línea final sin salto).

Tu condición (1) de T4 — *"el ESTABLE es un superconjunto limpio del canónico"* — **no se cumple tal cual**: hay 52 líneas del canónico que no están en el ESTABLE. Casi todas son reestructuraciones, no funciones perdidas:

| Grupo | Evidencia | Veredicto |
|---|---|---|
| Hotkeys `~Space & e:: _ToggleLayerVis()`, `~Space & q:: AccionEnfoque()` | presentes 1 y 1 en ambos; cambia la escritura de la línea | reformateado |
| `_EstabTeclaMenos` (solo canónico) → `_EstabTeclaMenos` + `_EstabTeclaMenosUp` | ocurrencias 2 → 5 | dividido, no perdido |
| `_ToggleLayerVis` / `AccionEnfoque` / `estadoEstab` / `fPrevHasta` / `sincronizado` | idéntico en cantidad | intacto |

**Solo hay dos diferencias semánticas reales:**

1. **`_EstabEmitir` — zona prohibida I5.** Canónico l.2865 `(tecla,n,pausa := 8)` con comentario *ráfagas de 5* y `k := (n > 5) ? 5 : n`. ESTABLE l.2909 `(tecla,n,pausa := ESTAB_RITMO)` con `ESTAB_RACHA := 10` (l.29) / `ESTAB_RITMO := 18` (l.30) y `k := (n > ESTAB_RACHA) ? ESTAB_RACHA : n`. Las **ocurrencias reales son 6 en ambos** (contando llamadas, no líneas) — la columna `usos=5` de tu Anexo D contaba líneas.
2. **Captura de `estabGui.rectNormal` al entrar en foco.** El canónico (l.2788-2796) lee el `GetWindowRect`, lo valida con `_EstabTamanoValido(nw,nh)` y cae al respaldo `_EstabRectGuardada()` → `{x:0,y:0,w:420,h:44}`. El ESTABLE (l.2836-2845) asigna el rect **sin validar ni respaldar en ese punto**. Aclaración que te debo: `_EstabTamanoValido` (l.2669) y `_EstabRectGuardada` (l.2947) **sí existen** en el ESTABLE y se usan en l.2602, 2815, 2956, 2969, 3643. Lo que se perdió es la guarda en la ruta "entrar en foco con ventana de tamaño basura". Anotado, no corregido (I8).

Funciones nuevas del ESTABLE (5): `_FlushPendentes` (518), `_AplicarEstabVisibilidadBase` (1792), `_EstabFocoCond` (2792), `_EstabFocoTecla` (2793), `_EstabTeclaMenosUp` (2800). Única función que solo tiene el canónico (1): `_EstabSoloMenos` (2752).

Deriva por tramos medida: **+24** hasta `_FadeAlpha` (539→563), **+12 extra** entre 563 y 1542 (ahí cae `_FlushPendentes` l.518 y los bloques de hover), luego **+36** en la familia de avisos, **+42/+43** en paneles y `_SetIcono`, **+44** en `ActualizarEstabGUI`/`_Estab*`. La tabla completa de las 37 anclas reancoradas está en `DIFF-3917-vs-3958.txt` (sección "TABLA DE REANCLADO") — sustituye `CONTEXTO.md §0/§2` si se elige B.

---

## 2. Pedido 2 — `galeria.ahk`: `_AutoCapturas`, `_Captura`, `_Ocluyentes`

En `EXTRACTOS-ronda3.md`, con la numeración del archivo real (1.030 líneas, SHA `f611a498855e1372…`). Incluye además `_Pasar` (l.282-304), `_DescVentana` (l.305-316) y el bloque de candidatos de posición (l.340-362), porque tu hueco D4-a se decide en `_Pasar`, no en `_AutoCapturas`.

Lo que verás: `_AutoCapturas` llama `_Pasar(prim, [0.75, 1.0, 1.5])` y `_Pasar(otro, [1.0, 1.5])`; dentro de `_Pasar`, por cada escala se recorre `for fi in [1, 3]` (Oscuro y Claro) con `_Reconstruir(); Sleep(400); _Captura()`, y **el toggle ON/OFF ocurre después de capturar**, solo cuando `esc = 1.0`. O sea: el estado ON/OFF de 75 % y 150 % es el estado inicial heredado de la pasada anterior, no una pareja controlada. Ahí está tu parche de 4 líneas.

`_Ocluyentes` filtra por `WinGetExStyle & 0x8` (topmost), descarta minimizadas y `Shell_TrayWnd`/`Shell_SecondaryTrayWnd`, y `WinGetPos` por ventana — con el stage también topmost, que es lo correcto.

---

## 3. Pedido 3 — el generador de la copia y `_LatBase`

También en `EXTRACTOS-ronda3.md`, del **spike parcheado** (377 líneas, SHA `13d4bfd466a28ccc…`): `Principal()` l.96-152 (anula 3-6, inserta `Suspend(1)` + `SetTimer(_LatBase, -2500)`, escribe la copia y la valida), `ArmarLlamada` l.272-303 e `Inyectable()` l.304-377 (`_LatHb`, `_LatQPC`, `_LatMedir`, `_LatBase`).

**Aviso: tu parche de huellas ya está parcialmente puesto, y hay una corrida que no ocurrió.** Nuestra copia de trabajo inyecta `_LatHb` en tres puntos — autoexec (`_LatHb("autoexec: Suspend + timer registrados")` l.127, justo antes del `SetTimer`), entrada a `_LatBase` (l.360) y escritura de salida. El archivo que quedó en `%TEMP%\latencia_f0\prueba_latencia.ahk` es de la corrida de las 21:20 y **no contiene `_LatHb` ni una vez** (`grep -c` = 0): esa corrida usó una versión anterior. Por tanto tu tabla de huellas no se puede llenar con datos existentes; hay que correr de nuevo, y para eso primero hay que resolver los dos bloqueos de §6.

Detalle de construcción que quizá quieras revisar: `_LatMedir` hace `Sleep(15)` entre muestras y `fn.Call()` una vez extra "de calentamiento" antes de las N; con N=20 y tres funciones son ~60 llamadas + 30 `Sleep`, todo dentro de un timer de un solo disparo.

---

## 4. Pedido 4 — `pruebas.ps1` sobre el ESTABLE: **parse PASS, esteril FAIL**

Salida cruda en `arnes-ESTABLE.log`. Se corrió sobre una copia exacta del ESTABLE en ruta sin espacios, con `-Raiz` apuntando allí (el arnés exige el nombre `XxxPPEN_a16pg2_displayAS_secondary.ahk`):

```text
== Modo: parse ==   líneas : 3959   sha256 : 6375B86D633AEA04...
  [OK] exit 0 en 0.09s        [OK] archivo intacto
RESULTADO: PASS

== Modo: esteril ==
  [OK] elevación desactivada (sin UAC)     [OK] hotkeys suspendidos
  [OK] GUIs forzadas a ocultas             [OK] ExitApp() añadido
== El script cambió y el arnés ya no encaja ==
  [FAIL] huella .Show() inesperada: string=29 vacías=2 posicionales=3 (esperado 31/2/3)
  [FAIL] revisar pruebas.ps1 antes de seguir (NO ejecutar a ciegas)
```

**Tu predicción de T4 se cumplió.** El riesgo que anotaste ("verifica una huella estructural de `.Show()` (31 + 2 + 3) y se niega a ejecutar") es exactamente lo que pasa: en el ESTABLE hay **29** `.Show()` con string en vez de 31. La comprobación está en `docs\ESTETICA\pruebas.ps1:213` y el mensaje en la 214.

Esto **condiciona la opción B**: sin esteril no hay prueba de carga (I4), y F1 exige I4. Necesitamos de ti una de las dos: (a) recalibrar la huella a 29/2/3 y decir **por qué** desaparecieron esos 2 `.Show("...")` (¿son los del `rectNormal`/foco que se reescribieron en el ESTABLE?), o (b) declarar que la huella se ancla al árbol elegido y añadirla a la tabla de reanclado. No queremos que edites `pruebas.ps1` a ciegas: es la única red que tenemos.

---

## 5. Pedido 5 — `/validate` del bloque F1 y `salida.txt` del test

**El bloque F1 tal como lo escribiste pasa todo. Salida de `ronda3.log`:**

```text
validate copia con F1 -> exit 0   (esperado 0)
lineas: 3959 -> 4040
eliminadas: 0   (esperado 0)
h0 = 6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D
h1 = 6375B86D633AEA04C0C731E23B3D5B1C51DCAF49042D20387825D9BE055A3A7D   (produccion intacta)
bloque recuperado de la copia: 2875 chars
```

El `salida.txt` del test funcional coincidió con tu bloque esperado **línea por línea, 14 de 14, sin una sola diferencia**:

```text
base=12141A
off_zzz=424242
on_lower=ABCDEF
track_comment=111111
alpha_ok=200
alpha_300=230
alpha_neg=215
alpha_missing=200
family_empty=Cascadia Mono
rol_info=info
rol_unknown=[]
aviso_info=00E5FF
aviso_neutral=EEEEEE
fuente_iconos=Segoe Fluent Icons
```

Así que `Loop Reg` con ruta concatenada y modo `"V"` funciona, `IsInteger` sobre el defecto funciona, y la cláusula R1 se comporta como predijiste: `track_comment=111111` — el defecto gana porque `IniRead` se traga el comentario y el valor resultante no valida como hex.

Dos matiz de medición: aplicamos el bloque sobre el **ESTABLE** (3.958 → 4.040), no sobre el canónico, porque T4 apunta a B. Tu cuenta decía ~4.039; la diferencia de 1 línea es el `nl` extra que añade el propio script de append. Con 4.040, el techo de I7 (4.050) queda a **10 líneas**, no 11: F2 lo rebasa seguro. Tu propuesta de rango por ola queda justificada con este dato.

---

## 6. Verificación de tu T1.1 — funciona, y dos cosas que te bloquean la automatización

```text
REP=4 (esperado 4)   hash=1 (esperado 1)
PLAN-V2 hash=1 (esperado >=1)
/validate spike_latencia.ahk parcheado -> exit 0   (esperado 0)
spike_latencia.ahk  l.35   PLAN-V2.md  l.25
```

Lo aplicamos en una **copia de trabajo** (`rd3\spike-parcheado\`) y no sobre `ENTREGA CLAUDE 2`, para dejarte el árbol original intacto; tu script generó los `.bak-f0r3-20261104-224717` como pedía I2. El spike parcheado **carga** (exit 0), que es la primera vez que eso pasa desde que nos lo entregaste.

Dos defectos de operatividad que necesitas para el paso 4:

1. **`Fin()` hace `MsgBox` y `ExitApp`.** Cualquier corrida sin supervisión se queda colgada esperando un clic: la nuestra quedó viva hasta que matamos el PID. Para un script que se invoca desde terminal, `MsgBox` es un bloqueo. Propuesta: `if A_IsCompiled || EJMODO...` — o simplemente escribir el mensaje en el log y hacer `ExitApp(cod)` cuando detecte que no hay consola, con una bandera `--sinmsg` para forzarlo. **No lo toques sin confirmación**: es tu diseño de UX.
2. **`--prod=` no soporta rutas con espacios.** `A_Args` parte por espacios, así que `--prod=C:\...\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk` llegó truncado y el spike abortó con el MsgBox del punto 1 (y sin `latencia_base.txt`). Solución temporal: copiar el objetivo a una ruta sin espacios (hizo falta para el pedido 4). Solución de una vez: reconstruir `A_Args` uniendo los trozos que empiecen por `--`, o exigir `--prod="RUTA"` con comillas y retirarlas.

---

## 7. Extra que no pediste: V0 remedida sobre el ESTABLE

Corrimos tu spike parcheado en modo seco contra el ESTABLE (con `--forzar`, porque su hash `6375B86D…` no es el del canónico). Resultado en `anclas-ESTABLE.txt`; el registro de la corrida es `latencia-ESTABLE-seco.txt`. Resumen:

```text
Lineas: 3959 (esperadas 3917)   Coincide con el canonico: NO
_FadeAlpha            def= 563  usos= 7   (hwnd,hasta,pasos := 6,delayMs := 10)
_LimpiarAvisos        def=   0  usos= 0
_LimpiarGUIs          def=1542  usos= 4
MostrarHUD            def=1610  usos=69
MostrarMiniTexto      def=1711  usos=33
MostrarBadgeCombo     def=1564  usos= 5
ActualizarEstabGUI    def=2742  usos=10   (v := -1,forzar := false)
_EstabEmitir          def=2909  usos= 5   (tecla,n,pausa := ESTAB_RITMO)
Copia desechable: %TEMP%\latencia_f0\prueba_latencia.ahk  ->  /validate exit 0
```

**Consecuencia para T2: tus decisiones sobreviven el cambio de árbol.** `_LimpiarAvisos` no existe también en el ESTABLE (D2 sigue como la cerraste), `_FadeAlpha` existe con 7 usos (I12 con objeto, igual), `Sanar()` no existe en ninguno de los dos (el hallazgo 13 no aplica en ambos), y las firmas de las 6 funciones de aviso son idénticas salvo el número de línea. Lo único que cambia es la numeración, que ya está en la tabla de reanclado del pedido 1. Y `MostrarHUD` pasa de 70 a 69 usos: una de sus llamadas estaba en las líneas que el ESTABLE reescribió.

---

## 8. Qué necesitamos de ti (una sola ronda, y F1 queda aplicable)

1. **T4 en firme.** Con el diff de §1 y el FAIL del arnés de §4, decide (y escríbelo): árbol fuente de verdad + qué se recalibra en `pruebas.ps1:213` y por qué + el nuevo rango de I7 por ola. Josue ejecuta el ESTABLE; si eliges B, la huella es el único impedimento que queda.
2. **El parche de `--sinmsg` / `--prod` con espacios** (o la confirmación de que los dos se quedan como están y nosotros corremos siempre con copia en ruta sin espacios y con supervisión del MsgBox).
3. **Tu versión de `_Pasar`/`_AutoCapturas` con pareja ON/OFF controlada** por fondo y escala, y la segunda corrida de D6 con `theme.ini` en `E8ECF4`. Con eso firmamos D4 y D6 en una sola tarde de capturas.
4. **El parche de huellas completo** (4 líneas sobre el código del pedido 3) para cerrar el paso 4 — que es lo que desbloquea I13-a y por tanto F3 y F4.
5. Nada más. Con 1-4 aplicamos F1 sobre el archivo que decidas, con `.bak-ola1`, y te traemos `salida.txt` de la verificación de producción.

Sin capturas hasta que las pidas. Si alguna cifra de este documento no te cuadra, dilo: todas tienen su comando y su archivo de origen, y podemos rerutearlos.
