#Requires AutoHotkey v2.0
#SingleInstance Force
#Warn All, OutputDebug

archivo := A_ScriptDir "\diagnostico_keydial_final.txt"

; Crear archivo limpio
f := FileOpen(archivo, "w")
f.Write("=== DIAGNOSTICO KEYDIAL XP-PEN ===")
f.Write("`n")
f.Write("Fecha: " . A_YEAR . "-" . A_MM . "-" . A_DD . " " . A_HOUR . ":" . A_MIN . ":" . A_SEC)
f.Write("`n`n")
f.Write("INSTRUCCIONES: presione y suelte el boton Space del KeyDial.")
f.Write("`n")
f.Write("También puede presionar la tecla Space de su teclado para comparar.")
f.Write("`n")
f.Write("El script grabara KEYDOWN y KEYUP con VK y SC en hexadecimal.")
f.Write("`n")
f.Write("El script finalizara automaticamente en 60 segundos.")
f.Write("`n`n")
f.Write("=== RESULTADOS ===")
f.Write("`n")
f.Close()

ih := InputHook()
ih.OnKeyDown := Func("OnKeyDownCB")
ih.OnKeyUp := Func("OnKeyUpCB")
ih.Start()

OnKeyDownCB(vk, sc) {
    global archivo
    nombre := GetKeyName("vk" . Format("{:02X}", vk))
    linea := "KEYDOWN: VK=0x" . Format("{:02X}", vk) . "  SC=0x" . Format("{:02X}", sc) . "  Tecla=" . nombre
    ToolTip(linea)
    f := FileOpen(archivo, "a")
    f.Write(linea)
    f.Write("`n")
    f.Close()
    SetTimer(() => ToolTip(), -3000)
}

OnKeyUpCB(vk, sc) {
    global archivo
    nombre := GetKeyName("vk" . Format("{:02X}", vk))
    linea := "KEYUP:   VK=0x" . Format("{:02X}", vk) . "  SC=0x" . Format("{:02X}", sc) . "  Tecla=" . nombre
    ToolTip(linea)
    f := FileOpen(archivo, "a")
    f.Write(linea)
    f.Write("`n")
    f.Close()
    SetTimer(() => ToolTip(), -3000)
}

tiempoInicio := A_TickCount
while (A_TickCount - tiempoInicio < 60000) {
    Sleep(100)
}

ih.Stop()
f := FileOpen(archivo, "a")
f.Write("`n")
f.Write("=== DIAGNOSTICO TERMINADO ===")
f.Close()
ToolTip()
ExitApp()
