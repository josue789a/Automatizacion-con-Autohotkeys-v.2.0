﻿#Requires AutoHotkey v2.0
#SingleInstance Force
#Warn All, OutputDebug

; ==============================================================================
; DIAGNÓSTICO PROFESIONAL KEYDIAL XP-PEN Y TECLADO (AutoHotkey v2)
; Captura en tiempo real: Evento (Down/Up), VK, SC, Tecla, Modificadores, Ventana.
; Escribe en vivo en diagnostico_keydial.txt sin bloqueos de archivo.
; ==============================================================================

logPath := A_ScriptDir "\diagnostico_keydial.txt"
global logPath
global heldKeys := Map()
global registroBuffer := ""

; Iniciar archivo con encabezado limpio
try {
    f := FileOpen(logPath, "w", "UTF-8")
    f.Write("====================================================================`r`n")
    f.Write("DIAGNÓSTICO DE PULSACIONES: KEYDIAL XP-PEN vs TECLADO`r`n")
    f.Write("Fecha: " FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`r`n")
    f.Write("AHK Version: " A_AhkVersion " | OS: " A_OSVersion "`r`n")
    f.Write("====================================================================`r`n`r`n")
    f.Close()
} catch {
}

; --- INTERFAZ GRÁFICA FLOTANTE (SIEMPRE VISIBLE) ---
diagGui := Gui("+AlwaysOnTop +Resize", "Diagnóstico KeyDial XP-Pen — Monitor en Vivo")
diagGui.SetFont("s10", "Segoe UI")

diagGui.AddText("w620 c0055AA", "INSTRUCCIONES:`n1. Presiona y suelta el botón Space de tu KeyDial XP-Pen (3 veces).`n2. Presiona y suelta la barra Space de tu teclado normal (3 veces).`n3. Observa la tabla abajo y haz clic en 'Copiar Diagnóstico' cuando termines.")

lv := diagGui.AddListView("w620 h280 Grid", ["Tiempo (ms)", "Evento", "Tecla", "VK (Hex)", "SC (Hex)", "Modificadores", "Ventana Activa"])
lv.ModifyCol(1, 80)
lv.ModifyCol(2, 75)
lv.ModifyCol(3, 85)
lv.ModifyCol(4, 65)
lv.ModifyCol(5, 65)
lv.ModifyCol(6, 110)
lv.ModifyCol(7, 130)

btnCopiar := diagGui.AddButton("xm w190 h32", "📋 Copiar Diagnóstico")
btnAbrir  := diagGui.AddButton("x+15 yp w190 h32", "📂 Abrir diagnostico_keydial.txt")
btnLimpiar := diagGui.AddButton("x+15 yp w190 h32", "🧹 Limpiar Lista")

lblStatus := diagGui.AddText("xm w620 cGreen", "● Monitor activo escuchando todos los dispositivos...")

btnCopiar.OnEvent("Click", CopiarPortapapeles)
btnAbrir.OnEvent("Click", AbrirArchivoLog)
btnLimpiar.OnEvent("Click", LimpiarRegistros)
diagGui.OnEvent("Close", (*) => ExitApp())

diagGui.Show("w650 h420")

; --- CAPTURA MEDIANTE INPUTHOOK GLOBAL ---
ih := InputHook("V L0")
ih.KeyOpt("{All}", "N") ; Notificar todas las teclas
ih.OnKeyDown := (hook, vk, sc) => ProcesarTecla("KEYDOWN", vk, sc)
ih.OnKeyUp   := (hook, vk, sc) => ProcesarTecla("KEYUP", vk, sc)
ih.Start()

; --- SALIDA DE EMERGENCIA ---
^!+q:: ExitApp()

; ==============================================================================
; FUNCIONES DE PROCESAMIENTO
; ==============================================================================

ProcesarTecla(tipoEvento, vk, sc) {
    global heldKeys, logPath, lv, registroBuffer

    ; Identificación de nombre de tecla
    nombreTecla := ""
    try {
        nombreTecla := GetKeyName(Format("vk{:x}sc{:x}", vk, sc))
    } catch {
        nombreTecla := ""
    }
    if (nombreTecla = "") {
        try {
            nombreTecla := GetKeyName(Format("vk{:02x}", vk))
        } catch {
            nombreTecla := "Desconocida"
        }
    }

    ; Detección de modificadores activos
    mods := ""
    if GetKeyState("Shift")
        mods .= "Shift "
    if GetKeyState("Ctrl")
        mods .= "Ctrl "
    if GetKeyState("Alt")
        mods .= "Alt "
    if GetKeyState("LWin") || GetKeyState("RWin")
        mods .= "Win "
    if (mods = "")
        mods := "Ninguno"

    ; Ventana activa en ese instante
    winTitle := ""
    try {
        winTitle := WinGetProcessName("A")
    } catch {
        winTitle := "N/A"
    }

    vkHex := Format("0x{:02X}", vk)
    scHex := Format("0x{:03X}", sc)
    tiempo := A_TickCount

    ; ToolTip visual inmediato si es Space o tecla relevante
    if (InStr(nombreTecla, "Space") || vk = 0x20 || sc = 0x039) {
        ToolTip("[" tipoEvento "] " nombreTecla " | VK=" vkHex " | SC=" scHex "`nMods: " mods "`nVentana: " winTitle)
        SetTimer(() => ToolTip(), -2000)
    }

    ; Agregar a ListView
    lv.Add(, tiempo, tipoEvento, nombreTecla, vkHex, scHex, mods, winTitle)
    lv.Modify(lv.GetCount(), "Vis") ; Auto-scroll al final

    ; Formatear línea de registro
    linea := Format("{:-10} | {:7} | {:12} | VK={:4} | SC={:5} | Mods: {:10} | App: {}`r`n",
        tiempo, tipoEvento, nombreTecla, vkHex, scHex, mods, winTitle)

    registroBuffer .= linea

    ; Escribir directamente a disco de forma segura
    try {
        FileAppend(linea, logPath, "UTF-8")
    } catch {
    }
}

CopiarPortapapeles(*) {
    global logPath
    try {
        contenido := FileRead(logPath, "UTF-8")
        A_Clipboard := contenido
        MsgBox("¡Diagnóstico copiado al portapapeles con éxito!`nPégalo en el chat de la conversación.", "Copiado", "Iconi")
    } catch as err {
        MsgBox("Error al leer el archivo para copiar: " err.Message, "Error", "Iconx")
    }
}

AbrirArchivoLog(*) {
    global logPath
    if FileExist(logPath)
        Run(logPath)
    else
        MsgBox("Aún no se ha generado el archivo de diagnóstico.", "Aviso", "Icon!")
}

LimpiarRegistros(*) {
    global logPath, lv, registroBuffer
    lv.Delete()
    registroBuffer := ""
    try {
        f := FileOpen(logPath, "w", "UTF-8")
        f.Write("=== REGISTRO REINICIADO ===`r`n`r`n")
        f.Close()
    } catch {
    }
}
