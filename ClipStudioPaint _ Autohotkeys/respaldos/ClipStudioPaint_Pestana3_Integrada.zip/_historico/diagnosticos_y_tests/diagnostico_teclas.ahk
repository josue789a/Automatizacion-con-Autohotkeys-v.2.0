#Requires AutoHotkey v2.0
#SingleInstance Force
#Warn All, OutputDebug

~*:: {
    vk := GetKeyVK(A_ThisHotkey)
    sc := GetKeySC(A_ThisHotkey)
    ToolTip("VK: 0x" Format("{:02X}", vk) "   SC: 0x" Format("{:02X}", sc) "`nPresiona ESC para salir")
    SetTimer(() => ToolTip(), -2000)
}

Esc:: ExitApp()

while (true)
    Sleep(100)
