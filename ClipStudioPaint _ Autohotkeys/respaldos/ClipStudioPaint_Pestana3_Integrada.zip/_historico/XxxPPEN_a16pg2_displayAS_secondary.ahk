#Requires AutoHotkey v2.0
#SingleInstance Force
if !A_IsAdmin {
    try Run('*RunAs "' A_ScriptFullPath '"')
    ExitApp()
}
try TraySetIcon("C:\Users\jbard\Documents\@Otros\icons\clipstudio.ico")
DllCall("SetThreadDpiAwarenessContext","ptr",-3,"ptr")
SendMode("Input")
KEY_NTILDE := "{vkC0sc027}"
KEY_MENOR := "{vkE2sc056}"
EnviarNtilde() => SendInput(KEY_NTILDE)
EnviarMenor() => SendInput(KEY_MENOR)
SetWorkingDir(A_ScriptDir)
SetKeyDelay(-1,-1)
SetMouseDelay(-1)
SetDefaultMouseSpeed(0)
CoordMode("Mouse","Screen")
CoordMode("ToolTip","Screen")
SetTitleMatchMode(2)
sys := {lastModTime:"",modoEscritura:false}
stylus := {altActive:false,rButtonHeld:false,comboUsado:false,upSinteticoTick:0,botonSostenido:false,smearSend:false,ignorarUpSintetico:false,bSinteticoTick:0,origX:0,origY:0,spaceFlipTimerRunning:0}
sel := {estado:0,estadoAltX:false,estadoC:0,guiActivo:false,sRapido:false}
colorEstado := 0
UP_SINTETICO_MS := 70
S_RAPIDO_MS := 400
ESTAB_MIN := 7
ESTAB_MAX := 75
ESTAB_COLOR := "9A7BFF"
ESTAB_ALPHA_H := 128
ESTAB_ALPHA_ACT := 235
ESTAB_ALPHA_F := 150
FOCO_GRACIA_MS := 200
FOCO_TIMEOUT_MS := 10000
E := {procesando:false,last:0}
W := {last:0}
Z := {last:0,timerRunning:0}
Q := {last:0,estadoEstab:0}
RM := {last:0}
A_state := {lastPress:0}
AltS_state := {lastPress:0}
AltB_s_state := {lastPress:0,timerRunning:0}
AltB_a_state := {lastPress:0,timerRunning:0}
AltF_state := {lastPress:0,timerRunning:0,held:false}
S := {estadoCaracter:0,skipNext:false,lastTick:0}
O := {ciclo:0}
N6 := {estadoEscala:0,layerVis:1}
hist := {abierto:false,modo:1,id:0}
btn := {b1:false,b2:false,b3:false}
botDer := {b1:false,b2:false,b3:false}
colorV := {dsID:0,dsVis:false,bDS:0,hover:true,cspHwnd:0,dsX:0,dsY:0,dsW:0,dsH:0,supresionHasta:0}
colorCC := {id:0,dsVis:false,bCC:0,hover:false,ccX:0,ccY:0,ccW:0,ccH:0,supresionHasta:0}
ar := {id:0,dsVis:false,bAR:0,hover:false}
floatGui := {miniTip:0,miniGUI:0,tooltipToggle:0,enfoque:0,miniTipTick:0,miniTipID:0,hud:0,hudLabel:0,hudBar:0,hudHwnd:0,overlayIcon:0,overlayIconID:0,badge:0,badgeHwnd:0,badgeSub:0,badgeMain:0,badgeSubBar:0,badgeBar:0,badgeID:0}
enfoque := {activo:false}
shiftSostenido := {activo:false}
opacidad := {nivel:100}
boost := {holdDelay:300,maxBoost:5}
spc := {last:0,downTick:0,selectArmed:false,rotOn:false}
dial := {modo:1,g:0,icono:0,label:0,barra:0}
dsGui := {g:0,icono:0,label:0,barra:0}
ccGui := {g:0,icono:0,label:0,barra:0}
arGui := {g:0,icono:0,label:0,barra:0}
hcGui := {g:0,icono:0,label:0,barra:0}
reloadGui := {g:0,icono:0,label:0,barra:0}
puntosGui := {g:0,icono:0,barra:0}
ptsEd := {g:0,lv:0,ex:0,ey:0,dx:0,dy:0,hAlto:0,eEsc:0,eEscAv:0,eAlpha:0,eAlphaF:0,st:0,bCap:0,sel:0,capturando:false,dibujando:false,ovl:[]}
lockGui := {g:0,icono:0,barra:0}
frenteGui := {g:0,icono:0,barra:0}
estabBtnGui := {g:0,icono:0,label:0,barra:0}
estabGui := {g:0,slider:0,knob:0,valorTxt:0,fondo:0,grip:0,valor:50,previsto:50,sincronizado:false,arrastrando:false,visible:true,ancho:0,alto:0,txtH:0,trackW:0,trackX:0,trackY:0,trackH:0,knobSize:0,horiz:false,txtW:0,fuente:9,foco:false,rectNormal:0,fAbajo:false,fSoltado:0,fTick:0,fPrevHasta:0,dibV:-1,dibG:""}
panelBlk := {locked:true,frente:false}
PANEL_GAP := 6
LAYOUT_NORMAL := {ds:{x:-1059,y:143,w:383,h:185},cc:{x:-676,y:143,w:359,h:295},ar:{x:-537,y:438,w:220,h:483},hc:{x:-2240,y:1253,w:1905,h:104}}
LAYOUT_ENFOQUE := {ds:{x:-836,y:136,w:383,h:185},cc:{x:-453,y:118,w:359,h:295},ar:{x:-317,y:413,w:223,h:483},hc:{x:-2240,y:1253,w:1905,h:104}}
PUNTOS_DEF := [[1970,-154],[4437,-154],[1924,-132],[1976,-130],[1923,-95],[1973,-94],[1925,-91],[1973,-89],[1926,-55],[1975,-55],[1927,-47],[1974,-46],[1924,-15],[1976,-10],[4423,-132],[4473,-131],[4423,-99],[4476,-98],[4425,-90],[4474,-89],[4423,-55],[4473,-55],[4426,-47],[4472,-47],[4424,-13],[4475,-10],[2246,1158],[4136,1156],[2011,-225],[2239,-98],[1900,500],[1940,700]]
PUNTOS := []
AVISO_ESC := 1.0
HIST_ALTO := 104
ZONAS := {}
PERFILES := ["Laptop + tableta","Monitor + tableta"]
PERFIL := 1
ElegirPerfil()
ESC := 1.0
CargarEscala()
CargarEscalaAvisos()
CargarPuntos()
SetTimer(CheckReload,600)
SetTimer(ChequearZonaHistorial,200)
SetTimer(ChequearZonaAltA,35)
SetTimer(ChequearZonaDerecha,35)
SetTimer(LoopColorV,80)
SetTimer(LoopColorCC,80)
SetTimer(LoopAccesoRapido,80)
SetTimer(ResetAlphaStates,500)
SetTimer(LimpiarAltPegadoPureRef,150)
IniciarDeteccion()
IniciarDsGUI()
IniciarCcGUI()
IniciarArGUI()
IniciarHCGUI()
IniciarLockGUI()
IniciarFrenteGUI()
IniciarEstabGUI()
IniciarEstabBtnGUI()
IniciarReloadGUI()
IniciarPuntosGUI()
EsEditorTexto() => WinActive("ahk_exe notepad++.exe") || WinActive("ahk_exe notepad.exe")
#HotIf EsEditorTexto()
^s:: {
    SendInput("^s")
    Sleep(200)
    Reload()
}
^g:: {
    if !(WinActive("ahk_exe notepad++.exe") || WinActive("ahk_exe notepad.exe"))
        return
    ts := FormatTime(,"yyyy-MM-dd_HH-mm-ss")
    repoPath := "C:\Users\JOSUE\Desktop\AHK-global-main"
    cmd := 'git -C "' repoPath '" add -A && git -C "' repoPath '" commit -m "auto_' ts '" && git -C "' repoPath '" push'
    Run('cmd /k "' cmd ' && timeout /t 3 && exit"',,"")
    SetTimer(_CheckGitDone,-5000)
}
#HotIf
#SuspendExempt
`:: {
    sys.modoEscritura := !sys.modoEscritura
    if (sys.modoEscritura) {
        Suspend(1)
        MostrarIndicador("🔴📝 MODO ESCRITURA — puedes escribir libremente 📝🔴")
    } else {
        Suspend(0)
        MostrarIndicador("🟢✅ MODO AHK ACTIVO — hotkeys habilitadas ✅🟢")
    }
}
#SuspendExempt False
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")
RButton:: {
    stylus.rButtonHeld := true
    stylus.comboUsado := false
    stylus.upSinteticoTick := 0
}
RButton up:: {
    elapsed := (stylus.upSinteticoTick > 0) ? (A_TickCount - stylus.upSinteticoTick) : 9999
    if (elapsed < UP_SINTETICO_MS) {
        stylus.rButtonHeld := true
        stylus.upSinteticoTick := 0
        return
    }
    stylus.rButtonHeld := false
    if (!stylus.comboUsado)
        SendInput("{RButton}")
}
Space & RButton:: {
    stylus.comboUsado := true
    _InvSeleccionConGUI()
}
Numpad0:: {
    hcOn := _ToggleHistorialColor()
    ActualizarHCGUI()
    MostrarHUD(hcOn ? "🟢 DYNAMIC HISTORY" : "🔒 HISTORY LOCKED",hcOn ? "00E5FF" : "FF6B00",5000)
}
_ToggleHistorialColor() {
    hist.modo := (hist.modo = 1) ? 2 : 1
    if (hist.modo = 2 && hist.abierto) {
        hist.abierto := false
        Send("{Numpad9}")
    }
    return (hist.modo = 1)
}
^s:: {
    SendInput("^s")
    SetTimer(() => SoundPlay(A_WinDir "\Media\notify.wav"),-1)
    MostrarHUD("💾 GUARDADO Y MODIFICADO","44DD88",800)
}
~!b:: {
    elapsedB := (stylus.bSinteticoTick > 0) ? (A_TickCount - stylus.bSinteticoTick) : 9999
    if (elapsedB < UP_SINTETICO_MS) {
        stylus.bSinteticoTick := 0
        return
    }
    if (stylus.smearSend)
        return
    stylus.altActive := true
}
~!b up:: {
    elapsedB := (stylus.bSinteticoTick > 0) ? (A_TickCount - stylus.bSinteticoTick) : 9999
    if (elapsedB < UP_SINTETICO_MS) {
        stylus.bSinteticoTick := 0
        return
    }
    Send("{Alt up}")
    stylus.altActive := false
    if (stylus.smearSend) {
        stylus.smearSend := false
        SendInput("b")
        MostrarHUD("SMEAR","AA44FF",950)
    }
}
c:: _InvSeleccionConGUI()
_InvSeleccionConGUI() {
    if (sel.estadoC = 0) {
        MostrarMiniTexto("🔄 INV. ÁREA SELECC.","FF6F61",900)
        SoundBeep(280,120)
        SoundBeep(220,160)
        sel.estadoC := 1
        SetTimer(__ResetEstadoC,-2000)
    } else {
        MostrarMiniTexto("🔁 INV. ÁREA SELECC.","32CD32",900)
        sel.estadoC := 0
        SetTimer(__ResetEstadoC,0)
    }
    Send("c")
}
x:: {
    if stylus.altActive
        return
    if (sel.sRapido) {
        sel.sRapido := false
        MostrarMiniTexto("❌ DESELECCIÓN","C0392B",700)
        Send("x")
        sel.estado := 1
        return
    }
    if (sel.estado = 0) {
        MostrarMiniTexto("❌ DESELECCIÓN","C0392B",700)
        Send("x")
        sel.estado := 1
    } else {
        MostrarMiniTexto("✅ RESELECCIÓN","27AE60",1200)
        Send("{F10}")
        sel.estado := 0
    }
}
$^z:: _DeshacerRehacer()
_MaskRButton() {
    stylus.comboUsado := true
    if (stylus.botonSostenido)
        return
    stylus.botonSostenido := true
    Send("!m")
    MostrarHUD("MASK (ALT+M)","00E5FF",900)
}
_DeshacerRehacer() {
    if (stylus.rButtonHeld) {
        _MaskRButton()
        return
    }
    if (stylus.rButtonHeld || stylus.altActive) {
        stylus.comboUsado := true
        if (!stylus.botonSostenido) {
            stylus.botonSostenido := true
            if (stylus.rButtonHeld) {
                stylus.upSinteticoTick := A_TickCount
                MouseGetPos(&origX,&origY)
                MouseMove(PUNTOS[29][1],PUNTOS[29][2],0)
                SendInput("{RButton up}")
                SendInput("^y")
                MouseMove(origX,origY,0)
            } else {
                SendInput("^y")
            }
        } else {
            SendInput("^y")
        }
        ToolTipCS("🟢 REHACER",600)
    } else {
        SendInput("^z")
        ToolTipCS("🔴 DESHACER",300)
    }
}
$^z up:: stylus.botonSostenido := false
!z:: {
    SendInput("^c")
    SoundPlay(A_WinDir "\Media\ding.wav")
    ToolTipCS("📋 COPIAR",600)
}
!^z:: {
    stylus.botonSostenido := true
    SendInput("^y")
    ToolTipCS("🟢 REHACER",600)
}
!^z up:: stylus.botonSostenido := false
#HotIf stylus.altActive && !WinActive("ahk_exe PureRef.exe")
z:: {
    SendInput("^c")
    SoundPlay(A_WinDir "\Media\ding.wav")
    ToolTipCS("📋 COPIAR",600)
}
w:: {
    Send("+s")
    MostrarHUD("SHIFT+S","00E5FF",800)
}
-:: _CicloO()
e:: {
    MostrarHUD("ALL LAYERS ERASER","FF4444",800)
    Send("{F5}")
}
x:: {
    if (AltB_a_state.lastPress = 1) {
        AltB_a_state.lastPress := 0
        SendEvent("p")
        MostrarHUD("SMUDGE  (P)","FF6B00",950)
    } else {
        AltB_a_state.lastPress := 1
        SendEvent("d")
        MostrarHUD("COLOR MIX  (D)","FF8C42",950)
    }
}
a:: {
    now := A_TickCount
    if (now - AltB_a_state.lastPress < 2400) {
        AltB_a_state.lastPress := 0
        Send("p")
        MostrarHUD("SMUDGE  (P)","FF6B00",950)
    } else {
        AltB_a_state.lastPress := now
        Send("d")
        MostrarHUD("COLOR MIX  (D)","FF8C42",950)
    }
}
s:: {
    now := A_TickCount
    if (now - AltB_s_state.lastPress < 2400) {
        AltB_s_state.lastPress := 0
        SendInput("{F7}")
        MostrarHUD("ALL LAYERS (2)","FF6B00",3140)
    } else {
        AltB_s_state.lastPress := now
        SendInput("{Blind}a")
        MostrarHUD("LAYER CURRENT (1)","00E5FF",950)
    }
}
f:: {
    if AltF_state.held
        return
    AltF_state.held := true
    now := A_TickCount
    if (now - AltF_state.lastPress < 2400) {
        AltF_state.lastPress := 0
        SendInput("{NumpadEnd}")
        MostrarHUD("SMEAR SOFT  (2)","FF6B00",950)
    } else {
        AltF_state.lastPress := now
        stylus.bSinteticoTick := A_TickCount
        SendInput("{Blind}{b up}{b down}")
        MostrarHUD("SMEAR  (1)","00E5FF",950)
    }
}
f up:: AltF_state.held := false
$!Space::
$Space:: {
    stylus.comboUsado := true
    SendInput("!g")
    MostrarHUD("FLIP HORIZONTAL","888888",700)
    SoundBeep(800,100)
}
#HotIf
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")
$a:: {
    if stylus.altActive
        return
    now := A_TickCount
    if (now - A_state.lastPress < 2400) {
        A_state.lastPress := 0
        SendInput("{F7}")
        MostrarHUD("ALL LAYERS (2)","FF6B00",3140)
    } else {
        A_state.lastPress := now
        SendInput("{Blind}a")
        MostrarHUD("LAYER CURRENT (1)","00E5FF",950)
    }
}
~RButton & a:: {
    stylus.comboUsado := true
    EnviarNtilde()
    MostrarHUD("REFERENCE LAYER","AA44FF",1680)
}
$e:: {
    global colorEstado
    now := A_TickCount
    if GetKeyState("Shift") {
        Send("e")
        return
    }
    if (now - E.last < 300) {
        E.last := 0
        SendInput("{e up}")
        if (colorEstado = 2) {
            Send("k")
            colorEstado := 0
        }
        Send("l")
        MostrarToolTipE("SOFT ERASER  (2)")
        return
    }
    E.last := now
    if (colorEstado = 2) {
        Send("k")
        colorEstado := 0
    }
    Send("e")
    MostrarToolTipE("ERASER  (1)")
}
~RButton & e:: {
    stylus.comboUsado := true
    Send("{F12}")
    SoundPlay(A_WinDir "\Media\Windows Recycle.wav")
    MostrarHUD("ERASER LAZO","FF4444",1200)
}
^e:: {
    MostrarHUD("ALL LAYERS ERASER","FF4444",800)
    Send("{F5}")
}
!e:: {
    MostrarHUD("ALL LAYERS ERASER","FF4444",800)
    Send("{F5}")
}
!q:: {
    Send("y")
    MostrarBadgeCombo("ALT + Q","SOFT BRUSH","FF6B00",2200)
}
~LAlt & 1::
~RAlt & 1:: {
    opacidad.nivel := Min(opacidad.nivel + 10,100)
    _EnviarOpacidad()
}
~LAlt & 2::
~RAlt & 2:: {
    opacidad.nivel := Max(opacidad.nivel - 10,10)
    _EnviarOpacidad()
}
!Home:: {
    Send("{PageDown}")
    MostrarHUD("ACCESO RÁPIDO","AA8844",800)
}
!-:: _CicloO()
$w:: {
    global colorEstado
    now := A_TickCount
    if (now - W.last < 300) {
        W.last := 0
        if (colorEstado = 2) {
            SendInput("k")
            colorEstado := 0
            SendInput("{Blind}w")
            MostrarMiniTexto("💨 AERÓGRAFO","1A1A2E",1200)
        } else {
            if (colorEstado = 1)
                SendInput("^2")
            SendInput("k")
            colorEstado := 2
            SendInput("{Blind}w")
            MostrarMiniTexto("⚪ AERÓGRAFO ALPHA","1C6EA4",1200)
            SoundPlay(A_ScriptDir "\sonidos\alpha_short.wav")
        }
        return
    }
    W.last := now
    SendInput("{Blind}w")
    MostrarMiniTexto(colorEstado = 2 ? "⚪ AERÓGRAFO ALPHA" : "💨 AERÓGRAFO",colorEstado = 2 ? "1C6EA4" : "1A1A2E",1200)
}
$z:: {
    now := A_TickCount
    if (now - Z.last < 300) {
        Z.last := 0
        Z.timerRunning := 0
        SendInput("{z up}")
        SendInput("r")
        MostrarToolTipZ("✋ R",800)
        return
    }
    Z.last := now
    Z.timerRunning := 1
    SendInput("{Blind}z")
    MostrarToolTipZ("🔍 Z",800)
}
$q:: {
    if GetKeyState("Alt","P") {
        Send("!q")
        return
    }
    now := A_TickCount
    if (now - Q.last < 300) {
        Q.last := 0
        SetTimer(__Q_SEND_NORMAL,0)
        global colorEstado
        if (colorEstado = 2) {
            Send("k")
            colorEstado := 0
        }
        SendInput("^2")
        if (colorEstado = 0) {
            colorEstado := 1
            MostrarMiniTextoOscuro("🟡 COLOR SECUNDARIO","51D67B",1200)
            SoundPlay(A_WinDir "\Media\Windows Notify.wav")
        } else {
            colorEstado := 0
            MostrarMiniTexto("🔵 COLOR PRIMARIO","2B3B32",1200)
        }
        return
    }
    Q.last := now
    if GetKeyState("RButton","P") {
        AlternarEstabilizacion()
        return
    }
    SetTimer(__Q_SEND_NORMAL,-50)
}
_ToggleLayerVis() {
    SendEvent("{Alt up}{Shift down}d{Shift up}")
    MostrarHUD(N6.layerVis ? "🚫 HIDE LAYER" : "👁 SHOW LAYER",N6.layerVis ? "FF4444" : "44DD88",600)
    N6.layerVis := !N6.layerVis
}
+w:: {
    hoverOn := _ToggleHoverPaneles()
    ActualizarDsGUI()
    ActualizarCcGUI()
    ActualizarArGUI()
    if (hoverOn)
        MostrarMiniTexto("🟠 HOVER ON — deslizador + círculo + acceso rápido","1E8449",1200)
    else
        MostrarMiniTexto("👁 HOVER OFF — paneles visibles","1A5276",1200)
}
+q:: {
    Send("y")
    MostrarHUD("SOFT (Y)","00E5FF",800)
}
!j:: {
    hoverOn := _ToggleHoverPaneles()
    ActualizarDsGUI()
    ActualizarCcGUI()
    ActualizarArGUI()
    if (hoverOn)
        MostrarTooltipToggle("HOVER ACTIVO","▶","verde")
    else
        MostrarTooltipToggle("HOVER PAUSADO","⏸","rojo")
}
_FadeAlpha(hwnd,hasta,pasos := 6,delayMs := 10) {
    try actual := WinGetTransparent("ahk_id " hwnd)
    if (actual = "" || !IsNumber(actual))
        actual := hasta
    if (actual = hasta)
        return
    paso := (hasta - actual) / pasos
    valor := actual
    Loop pasos {
        valor += paso
        v := Round(valor)
        v := (v < 0) ? 0 : (v > 255 ? 255 : v)
        try WinSetTransparent(v,"ahk_id " hwnd)
        Sleep(delayMs)
    }
    try WinSetTransparent(hasta,"ahk_id " hwnd)
}
_SetColorV(on) {
    colorV.hover := on
    colorV.dsVis := !on
    if (on)
        colorV.supresionHasta := A_TickCount + 400
    if (colorV.dsID && WinExist("ahk_id " colorV.dsID)) {
        SetTimer(LoopColorV,0)
        if (on) {
            _FadeAlpha(colorV.dsID,5)
            try WinSetExStyle("+0x20","ahk_id " colorV.dsID)
        } else {
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
            try WinSetExStyle("-0x20","ahk_id " colorV.dsID)
            _FadeAlpha(colorV.dsID,255)
        }
        SetTimer(LoopColorV,80)
    }
    return on
}
_SetColorCC(on) {
    colorCC.hover := on
    colorCC.dsVis := !on
    if (on)
        colorCC.supresionHasta := A_TickCount + 400
    if (colorCC.id && WinExist("ahk_id " colorCC.id)) {
        SetTimer(LoopColorCC,0)
        if (on) {
            _FadeAlpha(colorCC.id,5)
            try WinSetExStyle("+0x20","ahk_id " colorCC.id)
        } else {
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
            try WinSetExStyle("-0x20","ahk_id " colorCC.id)
            _FadeAlpha(colorCC.id,255)
        }
        SetTimer(LoopColorCC,80)
    }
    return on
}
_SetAR(on) {
    ar.hover := on
    ar.dsVis := !on
    if (ar.id && WinExist("ahk_id " ar.id)) {
        SetTimer(LoopAccesoRapido,0)
        if (on) {
            _FadeAlpha(ar.id,5)
            try WinSetExStyle("+0x20","ahk_id " ar.id)
        } else {
            if IsObject(ar.bAR)
                ar.bAR.Hide()
            try WinSetExStyle("-0x20","ahk_id " ar.id)
            _FadeAlpha(ar.id,255)
        }
        SetTimer(LoopAccesoRapido,80)
    }
    return on
}
_ToggleColorV() => _SetColorV(!colorV.hover)
_ToggleColorCC() => _SetColorCC(!colorCC.hover)
_ToggleAR() => _SetAR(!ar.hover)
_ToggleHoverPaneles() {
    target := !colorV.hover
    _SetColorV(target)
    _SetColorCC(target)
    _SetAR(target)
    return target
}
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe") && stylus.altActive
$!x:: {
    now := A_TickCount
    if (now - AltB_a_state.lastPress < 300) {
        SetTimer(__AltX_SEND_NORMAL,0)
        AltB_a_state.timerRunning := 0
        AltB_a_state.lastPress := 0
        SendEvent("{Alt up}p{Alt down}")
        MostrarHUD("SMUDGE  (P)","FF6B00",950)
        return
    }
    AltB_a_state.lastPress := now
    AltB_a_state.timerRunning := 1
    SetTimer(__AltX_SEND_NORMAL,-250)
}
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")
__AltX_SEND_NORMAL() {
    if !AltB_a_state.timerRunning
        return
    AltB_a_state.timerRunning := 0
    seguiaSostenido := stylus.altActive
    SendEvent("{Alt up}d")
    if (seguiaSostenido)
        SendEvent("{Alt down}")
    MostrarHUD("COLOR MIX  (D)","FF8C42",950)
}
!s:: {
    if !stylus.altActive
        return
    now := A_TickCount
    if (now - AltB_s_state.lastPress < 300) {
        SetTimer(__AltS_SEND_NORMAL,0)
        AltB_s_state.timerRunning := 0
        AltB_s_state.lastPress := 0
        SendEvent("{Alt up}{F7}{Alt down}")
        MostrarHUD("ALL LAYERS (2)","FF6B00",3140)
        return
    }
    AltB_s_state.lastPress := now
    AltB_s_state.timerRunning := 1
    SetTimer(__AltS_SEND_NORMAL,-250)
}
__AltS_SEND_NORMAL() {
    if !AltB_s_state.timerRunning
        return
    AltB_s_state.timerRunning := 0
    seguiaSostenido := stylus.altActive
    SendEvent("{Alt up}a")
    if (seguiaSostenido)
        SendEvent("{Alt down}")
    MostrarHUD("LAYER CURRENT (1)","00E5FF",950)
}
$s:: {
    if stylus.altActive
        return
    if GetKeyState("Alt","P")
        return
    ahora := A_TickCount
    esRapido := (S.lastTick > 0 && ahora - S.lastTick < S_RAPIDO_MS)
    S.lastTick := esRapido ? 0 : ahora
    if (esRapido) {
        S.skipNext := true
        sel.sRapido := true
        MostrarMiniTexto("🟢 ÁREA CON COLOR","27AE60",1200)
        SendInput("^x")
        SendEvent("{F7}")
        Send("{Alt down}{x}{Alt up}")
        sel.guiActivo := true
        sel.estadoAltX := true
        SetTimer(ResetEstadoAltX,-3000)
        SoundPlay(A_WinDir "\Media\Windows Exclamation.wav")
        return
    }
    if (GetKeyState("Space","P") || spc.selectArmed) {
        S.skipNext := true
        if (spc.selectArmed)
            SetTimer(_DesarmarSpaceSelect,-500)
        if (S.estadoCaracter = 0) {
            Send(",")
            MostrarTooltipToggle("AGREGAR A SELECCION","+","verde")
            S.estadoCaracter := 1
        } else {
            Send(".")
            MostrarTooltipToggle("ELIMINAR SELECCIÓN","–","rojo")
            S.estadoCaracter := 0
        }
        SetTimer(QuitarTooltipToggle,-1500)
        return
    }
    if S.skipNext {
        S.skipNext := false
        return
    }
    Send("s")
    SetTimer(() => MostrarHUD("LASSO","FF6B00",950),-1)
}
$o:: _CicloO()
_CicloO() {
    O.ciclo := Mod(O.ciclo,3) + 1
    if (O.ciclo = 1) {
        Send("h")
        MostrarMiniTexto("🔍 BUSCAR CAPAS (1/3)","1A5276",1200)
    } else if (O.ciclo = 2) {
        SendInput("{Ctrl down}{Numpad1}{Ctrl up}")
        MostrarMiniTexto("🎨 COLOR CAPA (2/3)","6C3483",1200)
    } else {
        SendInput("{Ctrl down}{Numpad2}{Ctrl up}")
        MostrarMiniTexto("🗑 BORRAR COLOR CAPA (3/3)","424949",1200)
    }
}
$Escape:: {
    if (O.ciclo != 0) {
        O.ciclo := 0
        MostrarMiniTexto("↺ CICLO O RESETADO","555555",900)
    }
    global colorEstado
    if (colorEstado = 2) {
        colorEstado := 0
        Send("k")
        MostrarMiniTexto("🎨 ALPHA RESETEADO","555555",900)
    }
    if (sel.guiActivo) {
        sel.guiActivo := false
        sel.estadoAltX := false
        sel.estado := 0
        Send("{Alt down}{x}{Alt up}")
        SetTimer(ResetEstadoAltX,0)
        MostrarMiniTexto("↩ SELECCIÓN CANCELADA","C0392B",700)
        Send("x")
        Send("{Escape}")
        return
    }
    Send("{Escape}")
}
+r:: {
    MostrarHUD("REFLEJAR HORIZONTAL","00E5FF",1500)
    Send("+r")
}
Tab:: AccionEnfoque()
F3:: AccionEnfoque()
~f:: {
}
~RButton & s:: {
    stylus.comboUsado := true
    MostrarHUD("LAZO CON AUTORELLENO","FF6B00",1200)
    SoundPlay(A_ScriptDir "\sonidos\fill_loud.wav")
    Send("{F9}")
}
~RButton & q:: {
    stylus.comboUsado := true
    Send("{F6}")
    MostrarBadgeCombo("PEN + Q","HARD BRUSH","FF6B00",2200)
}
~RButton & f:: {
    stylus.comboUsado := true
    shiftSostenido.activo := !shiftSostenido.activo
    if (shiftSostenido.activo) {
        Send("{Shift down}")
        SoundPlay(A_WinDir "\Media\Windows Foreground.wav")
        MostrarHUD("SHIFT SOSTENIDO","AA8844",900)
    } else {
        Send("{Shift up}")
        SoundPlay(A_WinDir "\Media\Windows Background.wav")
        MostrarHUD("SHIFT LIBERADO","555555",700)
    }
}
~RButton & w:: {
    stylus.comboUsado := true
    EnviarNtilde()
    MostrarBadgeCombo("PEN + W","DIFU MIXER 2","00E5FF",2200)
}
!w:: {
    EnviarMenor()
    MostrarBadgeCombo("ALT + W","★ OPC PRESSURE 2","00E5FF",2200)
}
~RButton & -:: {
    stylus.comboUsado := true
    now := A_TickCount
    if (now - RM.last < 300) {
        RM.last := 0
        Send("!t")
        MostrarHUD("OCULTAR REGLA","1A1A2E",800)
        return
    }
    RM.last := now
    Send("t")
    MostrarHUD("Rule","1A1A2E",800)
}
~RButton & z:: {
    stylus.comboUsado := true
    if GetKeyState("Ctrl") {
        _MaskRButton()
        return
    }
    Send("^v")
    SoundPlay(A_WinDir "\Media\notify.wav")
    MostrarHUD("📋 PEGAR (CTRL+V)","44DD88",800)
}
~RButton & z up:: stylus.botonSostenido := false
~RButton & x:: {
    stylus.comboUsado := true
    Send("u")
    MostrarHUD("GRADIENT (U)","00E5FF",900)
}
~RButton & 1:: {
    stylus.comboUsado := true
    MostrarToolTipE("FILL  (V)")
    Send("v")
}
~RButton & 2:: {
    stylus.comboUsado := true
    Send("{F11}")
    MostrarHUD("Advanced fill","AA8844",800)
}
_EnviarOpacidad() {
    key := (opacidad.nivel = 100) ? "0" : String(opacidad.nivel // 10)
    SendInput("+" key)
    ActualizarDialGUI()
    MostrarHUD("OPACIDAD " opacidad.nivel "%","00E5FF",900)
}
~RButton & 3::
~RButton & 4::
~RButton & 5::
~RButton & 6::
~RButton & 7::
~RButton & 8::
~RButton & 9::
~RButton & 0:: {
    stylus.comboUsado := true
    key := SubStr(A_ThisHotkey,StrLen(A_ThisHotkey))
    porcentaje := (key = "0") ? 100 : Integer(key) * 10
    opacidad.nivel := porcentaje
    SendInput("+" key)
    ActualizarDialGUI()
    MostrarHUD("OPACIDAD " porcentaje "%","00E5FF",900)
}
~1:: {
    if (dial.modo != 1) {
        dial.modo := 1
        ActualizarDialGUI()
    }
}
~2:: {
    if (dial.modo != 1) {
        dial.modo := 1
        ActualizarDialGUI()
    }
}
~3:: {
    if (dial.modo != 2) {
        dial.modo := 2
        ActualizarDialGUI()
    }
}
~4:: {
    if (dial.modo != 2) {
        dial.modo := 2
        ActualizarDialGUI()
    }
}
NumpadDiv:: {
    dial.modo := (dial.modo = 1) ? 2 : 1
    ActualizarDialGUI()
}
Numpad8:: {
    _LimpiarGUIs()
    try dial.g.Destroy()
    dial.g := 0
    dial.icono := 0
    dial.label := 0
    dial.barra := 0
    IniciarDialGUI()
    try dsGui.g.Destroy()
    dsGui.g := 0
    dsGui.icono := 0
    dsGui.label := 0
    dsGui.barra := 0
    try OnMessage(0x0201,_DsGUI_WM_LBUTTONDOWN,0)
    IniciarDsGUI()
    try ccGui.g.Destroy()
    ccGui.g := 0
    ccGui.icono := 0
    ccGui.label := 0
    ccGui.barra := 0
    try OnMessage(0x0201,_CcGUI_WM_LBUTTONDOWN,0)
    IniciarCcGUI()
    try arGui.g.Destroy()
    arGui.g := 0
    arGui.icono := 0
    arGui.label := 0
    arGui.barra := 0
    try OnMessage(0x0201,_ArGUI_WM_LBUTTONDOWN,0)
    IniciarArGUI()
    try hcGui.g.Destroy()
    hcGui.g := 0
    hcGui.icono := 0
    hcGui.label := 0
    hcGui.barra := 0
    try OnMessage(0x0201,_HCGUI_WM_LBUTTONDOWN,0)
    IniciarHCGUI()
    try lockGui.g.Destroy()
    lockGui.g := 0
    lockGui.icono := 0
    lockGui.barra := 0
    try OnMessage(0x0201,_LockGUI_WM_LBUTTONDOWN,0)
    IniciarLockGUI()
    try frenteGui.g.Destroy()
    frenteGui.g := 0
    frenteGui.icono := 0
    frenteGui.barra := 0
    try OnMessage(0x0201,_FrenteGUI_WM_LBUTTONDOWN,0)
    IniciarFrenteGUI()
    try estabGui.g.Destroy()
    estabGui.g := 0
    estabGui.slider := 0
    estabGui.knob := 0
    estabGui.valorTxt := 0
    estabGui.fondo := 0
    estabGui.grip := 0
    estabGui.foco := false
    estabGui.dibV := -1
    SetTimer(_EstabFocoVigilar,0)
    try OnMessage(0x0201,_EstabGUI_WM_LBUTTONDOWN,0)
    try OnMessage(0x0207,_EstabGUI_WM_MBUTTONDOWN,0)
    IniciarEstabGUI()
    try estabBtnGui.g.Destroy()
    estabBtnGui.g := 0
    estabBtnGui.icono := 0
    estabBtnGui.label := 0
    estabBtnGui.barra := 0
    try OnMessage(0x0201,_EstabBtnGUI_WM_LBUTTONDOWN,0)
    IniciarEstabBtnGUI()
    ToolTip("🔄 GUIs reiniciadas")
    SetTimer(() => ToolTip(),-1000)
}
~Space & NumpadAdd:: {
    Send("+p")
    MostrarMiniTexto("SPACE  +  +","1E8449",700)
}
~Space & NumpadSub:: {
    Send("^+p")
    MostrarMiniTexto("SPACE  +  −","922B21",700)
}
~Space & w:: {
    Send("+w")
    MostrarMiniTexto("Up","1E8449",700)
}
~Space & x:: {
    Send("+s")
    MostrarMiniTexto("Down","1E8449",700)
}
~Space & e:: _ToggleLayerVis()
~Space & q:: AccionEnfoque()
~Space & s:: {
    SendInput("+f")
    SetTimer(() => SoundPlay(A_WinDir "\Media\chord.wav"),-1)
    MostrarHUD("🔒 BLOQUEO TRANSPARENCIA","00E5FF",900)
}
~Space & f:: {
    static estado := 0
    Send("{Insert}")
    if (estado = 0) {
        MostrarHUD("Gray scale","888888",1000)
        estado := 1
    } else {
        MostrarHUD("color","FF4444",1000)
        estado := 0
    }
}
~Space & Numpad1::
~Space & Numpad2::
~Space & Numpad3::
~Space & Numpad4::
~Space & Numpad5::
~Space & Numpad6:: {
    tecla := SubStr(A_ThisHotkey,StrLen(A_ThisHotkey))
    tipos := Map("1","HSV","2","Brillo/Contraste","3","Equilibrio color","4","Curva tonos","5","Niveles","6","Degradado")
    MostrarHUD("Capa: " tipos[tecla],"AA44FF",500)
    Send("^!" tecla)
}
$Numpad6:: {
    Send("{Insert}")
    MostrarHUD("Grayscale Toggle","888888",800)
}
*Backspace:: {
    if GetKeyState("Space","P") {
        Send("8")
        MostrarHUD("BORRAR CAPA DE CORRECCIÓN","FF4444",1200)
        return
    }
    Send("{Backspace}")
}
~Space:: spc.downTick := A_TickCount
~Space up:: {
    held := A_TickCount - spc.downTick
    now := A_TickCount
    if (held <= 180) && (now - spc.last < 320) {
        spc.last := 0
        sel.guiActivo := true
        if sel.estadoAltX {
            MostrarMiniTexto("👁 MOSTRAR BORDE","2ECC71",1200)
            sel.estadoAltX := false
        } else {
            MostrarMiniTexto("🚫 OCULTAR BORDE","E74C3C",1200)
            sel.estadoAltX := true
        }
        Send("{Alt down}{x}{Alt up}")
        SetTimer(ResetEstadoAltX,-3000)
        return
    }
    if (held <= 180)
        spc.last := now
    if (held <= 450) {
        spc.selectArmed := true
        SetTimer(_DesarmarSpaceSelect,-500)
    }
}
_DesarmarSpaceSelect() => spc.selectArmed := false
#HotIf
class BorderFrame {
    T := 0
    B := 0
    L := 0
    R := 0
    __New(color) {
        opts := "-Caption +AlwaysOnTop +ToolWindow +E0x20"
        for side in ["T","B","L","R"] {
            g := Gui(opts)
            g.BackColor := color
            g.Show("w0 h0 NoActivate")
            this.%side% := g
        }
    }
    Show(x,y,w,h,g := 1) {
        flags := 0x10 | 0x40
        DllCall("SetWindowPos","Ptr",this.T.Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",w,"Int",g,"UInt",flags)
        DllCall("SetWindowPos","Ptr",this.B.Hwnd,"Ptr",-1,"Int",x,"Int",y + h - g,"Int",w,"Int",g,"UInt",flags)
        DllCall("SetWindowPos","Ptr",this.L.Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",g,"Int",h,"UInt",flags)
        DllCall("SetWindowPos","Ptr",this.R.Hwnd,"Ptr",-1,"Int",x + w - g,"Int",y,"Int",g,"Int",h,"UInt",flags)
        WinSetTransparent(85,"ahk_id " this.T.Hwnd)
        WinSetTransparent(85,"ahk_id " this.B.Hwnd)
        WinSetTransparent(85,"ahk_id " this.L.Hwnd)
        WinSetTransparent(85,"ahk_id " this.R.Hwnd)
    }
    Hide() {
        this.T.Hide()
        this.B.Hide()
        this.L.Hide()
        this.R.Hide()
    }
}
ObtenerMonitorCSP() {
    if (colorV.cspHwnd) {
        try {
            WinGetPos(&wx,&wy,&ww,&wh,"ahk_id " colorV.cspHwnd)
            cx := wx + ww // 2
            cy := wy + wh // 2
            loop MonitorGetCount() {
                MonitorGet(A_Index,&mL,&mT,&mR,&mB)
                if (cx >= mL && cx < mR && cy >= mT && cy < mB)
                    return {x:mL,y:mT,w:mR - mL,h:mB - mT}
            }
        }
    }
    pri := MonitorGetPrimary()
    MonitorGet(pri,&mL,&mT,&mR,&mB)
    return {x:mL,y:mT,w:mR - mL,h:mB - mT}
}
IniciarDeteccion() {
    bestHwnd := 0
    bestArea := 0
    for hwnd in WinGetList("ahk_exe CLIPStudioPaint.exe") {
        try {
            WinGetPos(&tx,&ty,&tw,&th,"ahk_id " hwnd)
            if (tw * th > bestArea) {
                bestArea := tw * th
                bestHwnd := hwnd
            }
        }
    }
    colorV.cspHwnd := bestHwnd
    colorV.dsID := BuscarVentanaCSP(0,"eslizador","colores")
    if (colorV.dsID) {
        colorV.bDS := BorderFrame("44AA66")
        colorV.hover := true
        colorV.dsVis := false
        try WinSetTransparent(5,"ahk_id " colorV.dsID)
        try WinSetExStyle("+0x20","ahk_id " colorV.dsID)
    }
    colorCC.id := BuscarVentanaCSP(0,"rculo de colores","olores")
    if (colorCC.id) {
        colorCC.bCC := BorderFrame("AA6622")
        colorCC.hover := false
        colorCC.dsVis := true
        try WinSetTransparent(255,"ahk_id " colorCC.id)
        try WinSetExStyle("-0x20","ahk_id " colorCC.id)
    }
    ar.id := BuscarVentanaCSP(0,"Acceso r","pido")
    if (ar.id) {
        ar.bAR := BorderFrame("AA8844")
        ar.hover := false
        ar.dsVis := true
        try WinSetTransparent(255,"ahk_id " ar.id)
        try WinSetExStyle("-0x20","ahk_id " ar.id)
    }
}
BuscarVentanaCSP(idActual,frag1,frag2) {
    if (idActual) {
        try {
            if WinExist("ahk_id " idActual)
                return idActual
        }
    }
    for hwnd in WinGetList("ahk_exe CLIPStudioPaint.exe") {
        try {
            t := WinGetTitle("ahk_id " hwnd)
            if InStr(t,frag1) && InStr(t,frag2)
                return hwnd
        }
    }
    return 0
}
CheckReload() {
    try newTime := FileGetTime(A_ScriptFullPath,"M")
    catch
        return
    if (sys.lastModTime = "") {
        sys.lastModTime := newTime
        return
    }
    if (newTime != sys.lastModTime) {
        sys.lastModTime := newTime
        mon := ObtenerMonitorCSP()
        x := mon.x + (mon.w // 2) - 120
        y := mon.y + (mon.h // 2) - 20
        ToolTip("💾 Script actualizado y recargado",x,y)
        SoundBeep(750,180)
        SoundBeep(950,180)
        SoundBeep(850,180)
        Sleep(300)
        ToolTip()
        Reload()
    }
}
ChequearZonaHistorial() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe")
        return
    if sys.modoEscritura
        return
    if (hist.modo = 2)
        return
    MouseGetPos(&mx,&my)
    z := ZONAS.hist
    enZona := (mx >= z.x1 && mx <= z.x2 && my >= z.y1 && my <= z.y2)
    if (enZona && !hist.abierto) {
        hist.abierto := true
        Send("{Numpad9}")
    } else if (!enZona && hist.abierto) {
        hist.abierto := false
        Send("{Numpad9}")
    }
}
LimpiarAltPegadoPureRef() {
    if !stylus.altActive
        return
    if !WinActive("ahk_exe PureRef.exe")
        return
    stylus.altActive := false
    Send("{Alt up}")
}
ChequearZonaAltA() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe")
        return
    if sys.modoEscritura
        return
    _ChequearBotones(btn,ZONAS.izq)
}
ChequearZonaDerecha() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe")
        return
    if sys.modoEscritura
        return
    _ChequearBotones(botDer,ZONAS.der)
}
_ChequearBotones(estado,zonas) {
    MouseGetPos(&mx,&my)
    Loop 3 {
        z := zonas[A_Index]
        k := "b" A_Index
        enZona := (mx >= z.x1 && mx <= z.x2 && my >= z.y1 && my <= z.y2)
        if (enZona && !estado.%k%) {
            estado.%k% := true
            SendEvent("{Click " mx " " my "}")
        } else if (!enZona && estado.%k%)
            estado.%k% := false
    }
}
LoopColorV() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if (colorV.hover) {
            if (colorV.dsVis && colorV.dsID) {
                colorV.dsVis := false
                try WinSetTransparent(5,"ahk_id " colorV.dsID)
                try WinSetExStyle("+0x20","ahk_id " colorV.dsID)
            }
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
        }
        return
    }
    if (!colorV.dsID) {
        colorV.dsID := BuscarVentanaCSP(0,"eslizador","colores")
        if (colorV.dsID) {
            colorV.bDS := BorderFrame("44AA66")
            colorV.dsVis := false
            try WinSetTransparent(5,"ahk_id " colorV.dsID)
            try WinSetExStyle("+0x20","ahk_id " colorV.dsID)
        }
        return
    }
    try {
        if !WinExist("ahk_id " colorV.dsID) {
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
            colorV.dsID := 0
            colorV.dsVis := false
            return
        }
        WinGetPos(&wx,&wy,&ww,&wh,"ahk_id " colorV.dsID)
        colorV.dsX := wx
        colorV.dsY := wy
        colorV.dsW := ww
        colorV.dsH := wh
    } catch {
        if IsObject(colorV.bDS)
            colorV.bDS.Hide()
        colorV.dsID := 0
        colorV.dsVis := false
        return
    }
    if (!colorV.hover)
        return
    MouseGetPos(&mx,&my)
    enDS := (mx >= wx && mx <= wx + ww && my >= wy && my <= wy + wh)
    enCirculo := false
    if (colorCC.id && colorCC.ccW > 0) {
        if (colorCC.hover)
            enCirculo := colorCC.dsVis
        else
            enCirculo := (mx >= colorCC.ccX && mx <= colorCC.ccX + colorCC.ccW && my >= colorCC.ccY && my <= colorCC.ccY + colorCC.ccH)
    }
    if (A_TickCount < colorV.supresionHasta) {
        enDS := false
        enCirculo := false
    }
    if (enDS || enCirculo) {
        if (!colorV.dsVis) {
            colorV.dsVis := true
            try WinSetTransparent(255,"ahk_id " colorV.dsID)
            try WinSetExStyle("-0x20","ahk_id " colorV.dsID)
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
        }
    } else {
        if (colorV.dsVis) {
            colorV.dsVis := false
            try WinSetTransparent(5,"ahk_id " colorV.dsID)
            try WinSetExStyle("+0x20","ahk_id " colorV.dsID)
        }
        if IsObject(colorV.bDS)
            colorV.bDS.Show(wx,wy,ww,wh)
    }
}
LoopColorCC() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if (colorCC.hover) {
            if (colorCC.dsVis && colorCC.id) {
                colorCC.dsVis := false
                try WinSetTransparent(5,"ahk_id " colorCC.id)
                try WinSetExStyle("+0x20","ahk_id " colorCC.id)
            }
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
        }
        colorCC.ccW := 0
        return
    }
    if (!colorCC.id) {
        colorCC.id := BuscarVentanaCSP(0,"rculo de colores","olores")
        if (colorCC.id) {
            colorCC.bCC := BorderFrame("AA6622")
            colorCC.dsVis := false
            try WinSetTransparent(5,"ahk_id " colorCC.id)
            try WinSetExStyle("+0x20","ahk_id " colorCC.id)
        }
        return
    }
    try {
        if !WinExist("ahk_id " colorCC.id) {
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
            colorCC.id := 0
            colorCC.dsVis := false
            colorCC.ccW := 0
            return
        }
        WinGetPos(&wx,&wy,&ww,&wh,"ahk_id " colorCC.id)
        colorCC.ccX := wx
        colorCC.ccY := wy
        colorCC.ccW := ww
        colorCC.ccH := wh
    } catch {
        if IsObject(colorCC.bCC)
            colorCC.bCC.Hide()
        colorCC.id := 0
        colorCC.dsVis := false
        colorCC.ccW := 0
        return
    }
    if (!colorCC.hover)
        return
    MouseGetPos(&mx,&my)
    dentro := (mx >= wx && mx <= wx + ww && my >= wy && my <= wy + wh)
    if (!dentro) {
        enDeslizador := false
        if (!colorV.hover && colorV.dsID && colorV.dsW > 0)
            enDeslizador := (mx >= colorV.dsX && mx <= colorV.dsX + colorV.dsW && my >= colorV.dsY && my <= colorV.dsY + colorV.dsH)
        dentro := enDeslizador
    }
    if (A_TickCount < colorCC.supresionHasta)
        dentro := false
    if (dentro) {
        if (!colorCC.dsVis) {
            colorCC.dsVis := true
            try WinSetTransparent(255,"ahk_id " colorCC.id)
            try WinSetExStyle("-0x20","ahk_id " colorCC.id)
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
        }
    } else {
        if (colorCC.dsVis) {
            colorCC.dsVis := false
            try WinSetTransparent(5,"ahk_id " colorCC.id)
            try WinSetExStyle("+0x20","ahk_id " colorCC.id)
        }
        if IsObject(colorCC.bCC)
            colorCC.bCC.Show(wx,wy,ww,wh)
    }
}
LoopAccesoRapido() {
    if (!ar.hover)
        return
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if (ar.dsVis && ar.id) {
            ar.dsVis := false
            try WinSetTransparent(5,"ahk_id " ar.id)
            try WinSetExStyle("+0x20","ahk_id " ar.id)
        }
        if IsObject(ar.bAR)
            ar.bAR.Hide()
        return
    }
    if (!ar.id) {
        ar.id := BuscarVentanaCSP(0,"Acceso r","pido")
        if (ar.id) {
            ar.bAR := BorderFrame("AA8844")
            ar.dsVis := false
            try WinSetTransparent(5,"ahk_id " ar.id)
            try WinSetExStyle("+0x20","ahk_id " ar.id)
        }
        return
    }
    try {
        if !WinExist("ahk_id " ar.id) {
            if IsObject(ar.bAR)
                ar.bAR.Hide()
            ar.id := 0
            ar.dsVis := false
            return
        }
        WinGetPos(&wx,&wy,&ww,&wh,"ahk_id " ar.id)
    } catch {
        if IsObject(ar.bAR)
            ar.bAR.Hide()
        ar.id := 0
        ar.dsVis := false
        return
    }
    MouseGetPos(&mx,&my)
    dentro := (mx >= wx && mx <= wx + ww && my >= wy && my <= wy + wh)
    if (dentro) {
        if (!ar.dsVis) {
            ar.dsVis := true
            try WinSetTransparent(255,"ahk_id " ar.id)
            try WinSetExStyle("-0x20","ahk_id " ar.id)
            if IsObject(ar.bAR)
                ar.bAR.Hide()
        }
    } else {
        if (ar.dsVis) {
            ar.dsVis := false
            try WinSetTransparent(5,"ahk_id " ar.id)
            try WinSetExStyle("+0x20","ahk_id " ar.id)
        }
        if IsObject(ar.bAR)
            ar.bAR.Show(wx,wy,ww,wh)
    }
}
ResetProcesando() => E.procesando := false
__Q_SEND_NORMAL() {
    global colorEstado
    SendInput("q")
    if (colorEstado = 1)
        MostrarMiniTextoOscuro("🟡 COLOR SECUNDARIO","51D67B",800)
    else if (colorEstado = 2)
        MostrarMiniTexto("⚪ ALPHA TRANSPARENTE","1C6EA4",800)
    else
        MostrarMiniTexto("🔵 COLOR PRIMARIO","2B3B32",800)
}
AlternarEstabilizacion() {
    static ocupado := false
    static lastTick := 0
    static lastPressTime := 0
    now := A_TickCount
    if (ocupado || (now - lastTick < 80))
        return
    if GetKeyState("LButton","P") || GetKeyState("RButton","P")
        return
    lastTick := now
    ocupado := true
    esDobleTap := (now - lastPressTime < 350)
    lastPressTime := esDobleTap ? 0 : now
    delta := ESTAB_MAX - ESTAB_MIN
    try {
        BlockInput(true)
        if (esDobleTap) {
            if (Q.estadoEstab = 0) {
                SendInput("{j 80}{- " ESTAB_MAX "}")
                Q.estadoEstab := 1
                MostrarMiniTexto("🔄 RE-SINCRONIZADO: ALTA (" ESTAB_MAX ")","1A5C2A",1000)
                SetTimer(_BeepEstabAlta,-1)
            } else {
                SendInput("{j 80}{- " ESTAB_MIN "}")
                Q.estadoEstab := 0
                MostrarMiniTexto("🔄 RE-SINCRONIZADO: BAJA (" ESTAB_MIN ")","1A2E5C",1000)
                SetTimer(_BeepEstabBaja,-1)
            }
        } else {
            if (Q.estadoEstab = 0) {
                SendInput("{- " delta "}")
                Q.estadoEstab := 1
                MostrarMiniTexto("🟢 ESTABILIZACIÓN ALTA (" ESTAB_MAX ")","1A5C2A",700)
                SetTimer(_BeepEstabAlta,-1)
            } else {
                SendInput("{j " delta "}")
                Q.estadoEstab := 0
                MostrarMiniTexto("🔵 ESTABILIZACIÓN BAJA (" ESTAB_MIN ")","1A2E5C",700)
                SetTimer(_BeepEstabBaja,-1)
            }
        }
    } finally {
        BlockInput(false)
        ocupado := false
        estabGui.sincronizado := false
    }
}
_BeepEstabAlta() => SoundPlay(A_WinDir "\Media\Windows Ding.wav")
_BeepEstabBaja() => SoundPlay(A_WinDir "\Media\Windows Balloon.wav")
_CheckGitDone() {
    MostrarHUD("✅ GitHub actualizado","44DD88",2000)
    SoundPlay(A_WinDir "\Media\Windows Navigation Start.wav")
}
ResetEstadoAltX() {
    sel.estadoAltX := false
    sel.guiActivo := false
}
__ResetEstadoC() => sel.estadoC := 0
_DestruirGui(guiObj) {
    if !IsObject(guiObj)
        return
    try guiObj.Destroy()
}
_LimpiarGUIs() {
    _DestruirGui(floatGui.hud)
    floatGui.hud := 0
    floatGui.hudHwnd := 0
    floatGui.hudLabel := 0
    floatGui.hudBar := 0
    _DestruirGui(floatGui.miniTip)
    floatGui.miniTip := 0
    floatGui.miniTipID := 0
    floatGui.miniTipTick := 0
    _DestruirGui(floatGui.tooltipToggle)
    floatGui.tooltipToggle := 0
    _DestruirGui(floatGui.miniGUI)
    floatGui.miniGUI := 0
    _DestruirGui(floatGui.enfoque)
    floatGui.enfoque := 0
    enfoque.activo := false
    OcultarGUIEnfoque()
    _DestruirGui(floatGui.overlayIcon)
    floatGui.overlayIcon := 0
    floatGui.overlayIconID := 0
}
MostrarBadgeCombo(comboText,toolText,colorAcento := "00E5FF",duracion := 2200) {
    global AVISO_ESC
    if IsObject(floatGui.miniTip)
        _DestruirGui(floatGui.miniTip)
    if IsObject(floatGui.miniGUI)
        _DestruirGui(floatGui.miniGUI)
    if IsObject(floatGui.tooltipToggle)
        _DestruirGui(floatGui.tooltipToggle)
    if IsObject(floatGui.hud)
        floatGui.hud.Hide()
    thisID := A_TickCount
    floatGui.badgeID := thisID
    x := -2247
    y := 30
    w := Round(240 * AVISO_ESC)
    h := Round(62 * AVISO_ESC)
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := "12141A"
    g.MarginX := 0
    g.MarginY := 0
    WinSetTransparent(230,g)
    bLeft := g.Add("Progress","x0 y0 w" Round(5 * AVISO_ESC) " h" h)
    bLeft.Opt("c" colorAcento)
    bLeft.Value := 100
    lblSub := g.Add("Text","x" Round(12 * AVISO_ESC) " y" Round(6 * AVISO_ESC) " w" (w - Round(16 * AVISO_ESC)) " c8E9AA0",comboText)
    lblSub.SetFont("s" Max(6,Round(9 * AVISO_ESC)) " bold","Segoe UI")
    lblMain := g.Add("Text","x" Round(12 * AVISO_ESC) " y" Round(24 * AVISO_ESC) " w" (w - Round(16 * AVISO_ESC)) " cWhite",toolText)
    lblMain.SetFont("s" Max(7,Round(13 * AVISO_ESC)) " bold","Segoe UI")
    bSub := g.Add("Progress","x0 y" Round(58 * AVISO_ESC) " w" w " h" Round(4 * AVISO_ESC))
    bSub.Opt("c" colorAcento)
    bSub.Value := 100
    g.Show("w" w " h" h " NoActivate Hide")
    floatGui.badge := g
    floatGui.badgeHwnd := g.Hwnd
    floatGui.badgeSub := lblSub
    floatGui.badgeMain := lblMain
    floatGui.badgeSubBar := bLeft
    floatGui.badgeBar := bSub
    DllCall("SetWindowPos","Ptr",floatGui.badgeHwnd,"Ptr",-1,"int",x,"int",y,"int",0,"int",0,"uint",0x0040 | 0x0010 | 0x0001)
    floatGui.badge.Show("NoActivate")
    SetTimer(() => _OcultarBadgeSi(thisID),-duracion)
}
_OcultarBadgeSi(targetID) {
    if (IsObject(floatGui.badge) && floatGui.badgeID = targetID)
        floatGui.badge.Hide()
}
MostrarHUD(texto,colorBarra := "00E5FF",duracion := 1200) {
    global AVISO_ESC
    if IsObject(floatGui.miniTip)
        _DestruirGui(floatGui.miniTip)
    if IsObject(floatGui.miniGUI)
        _DestruirGui(floatGui.miniGUI)
    if IsObject(floatGui.tooltipToggle)
        _DestruirGui(floatGui.tooltipToggle)
    x := -2247
    y := 30
    w := Round(208 * AVISO_ESC)
    h := Round(40 * AVISO_ESC)
    if (!IsObject(floatGui.hud) || !floatGui.hudHwnd || !DllCall("IsWindow","Ptr",floatGui.hudHwnd)) {
        g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
        g.BackColor := "1a1a1a"
        g.MarginX := 0
        g.MarginY := 0
        WinSetTransparent(215,g)
        lbl := g.Add("Text","x0 y" Round(7 * AVISO_ESC) " w" w " h" Round(26 * AVISO_ESC) " cWhite +0x200 Center",texto)
        lbl.SetFont("s" Max(6,Round(12 * AVISO_ESC)) " bold","Segoe UI")
        bar := g.Add("Progress","x0 y" Round(35 * AVISO_ESC) " w" w " h" Round(5 * AVISO_ESC))
        bar.Opt("c" colorBarra)
        bar.Value := 100
        g.Show("w" w " h" h " NoActivate Hide")
        floatGui.hud := g
        floatGui.hudLabel := lbl
        floatGui.hudBar := bar
        floatGui.hudHwnd := g.Hwnd
    } else {
        floatGui.hudLabel.Value := texto
        floatGui.hudBar.Opt("c" colorBarra)
        floatGui.hudBar.Value := 100
    }
    DllCall("SetWindowPos","Ptr",floatGui.hudHwnd,"Ptr",-1,"int",x,"int",y,"int",0,"int",0,"uint",0x0040 | 0x0010 | 0x0001)
    hwnd := floatGui.hudHwnd
    SetTimer(() => _OcultarHUDSi(hwnd),-duracion)
}
_OcultarHUDSi(hwnd) {
    if (IsObject(floatGui.hud) && floatGui.hudHwnd = hwnd)
        floatGui.hud.Hide()
}
QuitarToolTip() => ToolTip()
OcultarToolTip() => ToolTip()
OcultarToolTipAltG() => ToolTip()
OcultarToolTipQ() => ToolTip()
OcultarIndicador() => ToolTip()
QuitarToolTipE() => ToolTip()
QuitarToolTipZ() => ToolTip()
MostrarIndicador(texto) {
    ToolTip(texto)
    SetTimer(OcultarIndicador,-2500)
}
MostrarToolTipE(texto,duracion := 2190) => MostrarHUD(texto,"FF4444",duracion)
MostrarIconoHerramienta(tipo,duracion := 700) {
    global AVISO_ESC
    if IsObject(floatGui.overlayIcon)
        _DestruirGui(floatGui.overlayIcon)
    thisID := A_TickCount
    floatGui.overlayIconID := thisID
    lado := Round(110 * AVISO_ESC)
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := "181818"
    g.MarginX := 0
    g.MarginY := 0
    iconoChar := (tipo = "zoom") ? "🔍" : (tipo = "rotar") ? "↻" : "⚙"
    fSize := (tipo = "rotar") ? Round(56 * AVISO_ESC) : Round(50 * AVISO_ESC)
    txt := g.Add("Text","x0 y0 w" lado " h" lado " Center +0x0200 cWhite",iconoChar)
    txt.SetFont("s" fSize " bold","Segoe UI Symbol")
    g.Show("w" lado " h" lado " NoActivate Hide")
    DllCall("SetWindowPos","Ptr",g.Hwnd,"Ptr",-1,"int",PUNTOS[30][1],"int",PUNTOS[30][2],"int",0,"int",0,"uint",0x0040 | 0x0010 | 0x0001)
    try {
        rad := Round(50 * AVISO_ESC)
        rgn := DllCall("Gdi32\CreateRoundRectRgn","int",0,"int",0,"int",lado + 1,"int",lado + 1,"int",rad,"int",rad,"Ptr")
        DllCall("SetWindowRgn","Ptr",g.Hwnd,"Ptr",rgn,"int",1)
    }
    WinSetTransparent(185,"ahk_id " g.Hwnd)
    floatGui.overlayIcon := g
    SetTimer(() => _OcultarIconoSi(thisID),-duracion)
}
_OcultarIconoSi(id) {
    if (floatGui.overlayIconID != id)
        return
    try {
        if IsObject(floatGui.overlayIcon)
            floatGui.overlayIcon.Destroy()
    }
    floatGui.overlayIcon := 0
    floatGui.overlayIconID := 0
}
MostrarToolTipZ(texto,duracion := 800) {
    if InStr(texto,"Z")
        MostrarIconoHerramienta("zoom",duracion)
    else if InStr(texto,"R")
        MostrarIconoHerramienta("rotar",duracion)
    else
        MostrarHUD(texto,"00E5FF",duracion)
}
ToolTipCS(texto,duracion := 800) => MostrarHUD(texto,texto = "🟢 REHACER" ? "44DD88" : "FF4444",duracion)
_AvisoPosicionar(hwnd) {
    DllCall("SetWindowPos","Ptr",hwnd,"Ptr",-1,"int",PUNTOS[30][1],"int",PUNTOS[30][2],"int",0,"int",0,"uint",0x0040 | 0x0010 | 0x0001)
}
MostrarMiniTexto(texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF") {
    _LimpiarGUIs()
    thisID := A_TickCount
    floatGui.miniTipID := thisID
    floatGui.miniTipTick := thisID
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := colorHex
    g.SetFont("s" Max(6,Round(12 * AVISO_ESC)) " Bold","Segoe UI")
    g.AddText("c" colorTexto " Center w" Round(260 * AVISO_ESC),texto)
    g.Show("Hide AutoSize NoActivate")
    _AvisoPosicionar(g.Hwnd)
    WinSetTransparent(200,"ahk_id " g.Hwnd)
    floatGui.miniTip := g
    SetTimer(() => _OcultarMiniTipSi(thisID),-duracion)
}
_OcultarMiniTipSi(id) {
    if (floatGui.miniTipID != id)
        return
    try {
        if IsObject(floatGui.miniTip)
            floatGui.miniTip.Destroy()
    }
    floatGui.miniTip := 0
    floatGui.miniTipID := 0
    floatGui.miniTipTick := 0
}
MostrarMiniTextoOscuro(texto,colorHex := "EEEEEE",duracion := 800) => MostrarMiniTexto(texto,colorHex,duracion,"000000")
MostrarMiniGUI(texto,colorHex := "222222",duracion := 1200) {
    if IsObject(floatGui.miniGUI)
        try floatGui.miniGUI.Destroy()
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := colorHex
    g.SetFont("s" Max(6,Round(12 * AVISO_ESC)) " Bold","Segoe UI")
    g.AddText("cFFFFFF Center w" Round(260 * AVISO_ESC),texto)
    g.Show("Hide AutoSize NoActivate")
    _AvisoPosicionar(g.Hwnd)
    WinSetTransparent(200,"ahk_id " g.Hwnd)
    floatGui.miniGUI := g
    hwndMG := g.Hwnd
    SetTimer(() => _OcultarMiniGUISi(hwndMG),-duracion)
}
_OcultarMiniGUISi(hwndMG) {
    if (IsObject(floatGui.miniGUI) && floatGui.miniGUI.Hwnd = hwndMG) {
        floatGui.miniGUI.Destroy()
        floatGui.miniGUI := 0
    }
}
MostrarTooltipToggle(titulo,simbolo,color) {
    _LimpiarGUIs()
    g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20")
    fs := Max(6,Round(12 * AVISO_ESC))
    if (color = "verde") {
        g.BackColor := "1F4D3A"
        g.SetFont("s" fs " Bold cWhite","Segoe UI")
        simColor := "Lime"
    } else {
        g.BackColor := "D92B2B"
        g.SetFont("s" fs " Bold cWhite","Segoe UI")
        simColor := "White"
    }
    k := AVISO_ESC
    g.AddText("x" Round(8*k) " y" Round(5*k) " w" Round(221*k) " h" Round(23*k) " Center",titulo)
    g.SetFont("s" fs " Bold c" simColor,"Segoe UI")
    g.AddText("x" Round(232*k) " y" Round(4*k) " w" Round(23*k) " h" Round(23*k) " Center",simbolo)
    g.Show("w" Round(260*k) " h" Round(34*k) " NoActivate Hide")
    _AvisoPosicionar(g.Hwnd)
    floatGui.tooltipToggle := g
    hwndT := g.Hwnd
    SetTimer(() => _OcultarToggleSi(hwndT),-1500)
}
_OcultarToggleSi(hwndT) {
    if (IsObject(floatGui.tooltipToggle) && floatGui.tooltipToggle.Hwnd = hwndT) {
        floatGui.tooltipToggle.Destroy()
        floatGui.tooltipToggle := 0
    }
}
QuitarTooltipToggle() {
    if IsObject(floatGui.tooltipToggle)
        try floatGui.tooltipToggle.Destroy()
    floatGui.tooltipToggle := 0
}
AccionEnfoque() {
    enfoque.activo := !enfoque.activo
    MouseGetPos(&origX,&origY)
    Click(PUNTOS[1][1] " " PUNTOS[1][2])
    Click(PUNTOS[2][1] " " PUNTOS[2][2])
    DllCall("SetCursorPos","int",origX,"int",origY)
    _AplicarLayoutPaneles(enfoque.activo ? "Enfoque" : "Normal")
    _NotificarPureRef(enfoque.activo ? 1 : 0)
    if (enfoque.activo) {
        _EstabFocoOcultar()
        if IsObject(estabGui.g)
            try estabGui.g.Hide()
        MostrarGUIEnfoque()
        MostrarHUD("🎯 MODO ENFOQUE","00E5FF",900)
        SetTimer(() => SoundPlay(A_WinDir "\Media\Windows Feed Discovered.wav"),-1)
    } else {
        OcultarGUIEnfoque()
        _EstabFocoOcultar()
        if (estabGui.visible && IsObject(estabGui.g))
            try estabGui.g.Show("NoActivate")
        SetTimer(() => SoundPlay(A_WinDir "\Media\Windows Pop-up Blocked.wav"),-1)
    }
}
_NotificarPureRef(modo) {
    prevDHW := A_DetectHiddenWindows
    DetectHiddenWindows(true)
    for hwnd in WinGetList("ahk_class AutoHotkey") {
        try {
            title := WinGetTitle("ahk_id " hwnd)
            if InStr(title,"PureRef_layout.ahk")
                PostMessage(0x5501,modo,0,,"ahk_id " hwnd)
        }
    }
    DetectHiddenWindows(prevDHW)
}
_IdsPaneles() {
    try {
        if (!colorV.dsID || !WinExist("ahk_id " colorV.dsID))
            colorV.dsID := BuscarVentanaCSP(0,"eslizador","colores")
        if (!colorCC.id || !WinExist("ahk_id " colorCC.id))
            colorCC.id := BuscarVentanaCSP(0,"rculo de colores","olores")
        if (!ar.id || !WinExist("ahk_id " ar.id))
            ar.id := BuscarVentanaCSP(0,"Acceso r","pido")
        if (!hist.id || !WinExist("ahk_id " hist.id))
            hist.id := BuscarVentanaCSP(0,"istorial","color")
    }
    ids := Map()
    ids["ds"] := colorV.dsID
    ids["cc"] := colorCC.id
    ids["ar"] := ar.id
    ids["hc"] := hist.id
    return ids
}
_LayoutPanelGuardado(nombre,clave,mon) {
    ini := _PosGuiIniPath()
    sec := "Layout" nombre
    x := IniRead(ini,sec,clave "x","")
    y := IniRead(ini,sec,clave "y","")
    w := IniRead(ini,sec,clave "w","")
    h := IniRead(ini,sec,clave "h","")
    if (x = "" || y = "" || w = "" || h = "")
        return 0
    return {x:mon.x + Integer(x),y:mon.y + Integer(y),w:Integer(w),h:Integer(h)}
}
_AplicarLayoutPaneles(nombre) {
    mon := ObtenerMonitorCSP()
    def := (nombre = "Enfoque") ? LAYOUT_ENFOQUE : LAYOUT_NORMAL
    SWP_FLAGS := 0x0004 | 0x0010
    for clave,id in _IdsPaneles() {
        if (!id || !WinExist("ahk_id " id))
            continue
        r := _LayoutPanelGuardado(nombre,clave,mon)
        if (!r)
            r := def.%clave%
        x := Max(mon.x,Min(r.x,mon.x + mon.w - r.w))
        y := Max(mon.y,Min(r.y,mon.y + mon.h - r.h))
        try {
            DllCall("SetWindowPos","Ptr",id,"Ptr",0,"int",x,"int",y,"int",r.w,"int",r.h,"uint",SWP_FLAGS)
            if (clave = "ds") {
                colorV.dsX := x
                colorV.dsY := y
                colorV.dsW := r.w
                colorV.dsH := r.h
            } else if (clave = "cc") {
                colorCC.ccX := x
                colorCC.ccY := y
                colorCC.ccW := r.w
                colorCC.ccH := r.h
            }
        }
    }
}
_CapturarLayout(nombre) {
    SetTimer(() => SoundPlay(A_WinDir "\Media\ding.wav"),-1)
    ToolTip("Guardando layout " nombre "...")
    SetTimer(() => ToolTip(),-1500)
    try {
        if (!colorV.dsID)
            colorV.dsID := BuscarVentanaCSP(0,"eslizador","colores")
        if (!colorCC.id)
            colorCC.id := BuscarVentanaCSP(0,"rculo de colores","olores")
        if (!ar.id)
            ar.id := BuscarVentanaCSP(0,"Acceso r","pido")
        if (!hist.id)
            hist.id := BuscarVentanaCSP(0,"istorial","color")
    }
    mon := ObtenerMonitorCSP()
    ini := _PosGuiIniPath()
    sec := "Layout" nombre
    guardados := 0
    for clave,id in _IdsPaneles() {
        if (!id || !WinExist("ahk_id " id))
            continue
        try {
            WinGetPos(&x,&y,&w,&h,"ahk_id " id)
            IniWrite(x - mon.x,ini,sec,clave "x")
            IniWrite(y - mon.y,ini,sec,clave "y")
            IniWrite(w,ini,sec,clave "w")
            IniWrite(h,ini,sec,clave "h")
            guardados++
        }
    }
    MostrarHUD("LAYOUT " StrUpper(nombre) " GUARDADO (" guardados "/4)",guardados = 4 ? "44DD88" : "FF6B00",1600)
}
$^F11:: _CapturarLayout("Normal")
$^F12:: _CapturarLayout("Enfoque")
$^F10:: AbrirPanelPuntos()
MostrarGUIEnfoque() {
    mon := ObtenerMonitorCSP()
    opts := "-Caption +AlwaysOnTop +ToolWindow +E0x20"
    flags := 0x0010 | 0x0040
    x := mon.x
    y := mon.y
    w := mon.w
    h := mon.h
    if (!HasProp(floatGui,"enfoqueGuis") || !IsObject(floatGui.enfoqueGuis) || floatGui.enfoqueGuis.Length != 8) {
        floatGui.enfoqueGuis := []
        Loop 4 {
            g := Gui(opts)
            g.BackColor := "0077B6"
            g.Show("w0 h0 NoActivate")
            WinSetTransparent(46,g)
            floatGui.enfoqueGuis.Push(g)
        }
        Loop 4 {
            g := Gui(opts)
            g.BackColor := "00B4D8"
            g.Show("w0 h0 NoActivate")
            WinSetTransparent(76,g)
            floatGui.enfoqueGuis.Push(g)
        }
    }
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[1].Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",w,"Int",6,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[2].Hwnd,"Ptr",-1,"Int",x,"Int",y + h - 6,"Int",w,"Int",6,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[3].Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",6,"Int",h,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[4].Hwnd,"Ptr",-1,"Int",x + w - 6,"Int",y,"Int",6,"Int",h,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[5].Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",w,"Int",3,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[6].Hwnd,"Ptr",-1,"Int",x,"Int",y + h - 3,"Int",w,"Int",3,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[7].Hwnd,"Ptr",-1,"Int",x,"Int",y,"Int",3,"Int",h,"UInt",flags)
    DllCall("SetWindowPos","Ptr",floatGui.enfoqueGuis[8].Hwnd,"Ptr",-1,"Int",x + w - 3,"Int",y,"Int",3,"Int",h,"UInt",flags)
}
OcultarGUIEnfoque() {
    if (HasProp(floatGui,"enfoqueGuis") && IsObject(floatGui.enfoqueGuis)) {
        for g in floatGui.enfoqueGuis {
            try DllCall("ShowWindow","Ptr",g.Hwnd,"Int",0)
        }
    }
}
ResetEnfoque() {
    if (enfoque.activo) {
        enfoque.activo := false
        OcultarGUIEnfoque()
        _EstabFocoOcultar()
        if (estabGui.visible && IsObject(estabGui.g))
            try estabGui.g.Show("NoActivate")
    }
}
ResetAlphaStates() {
    global colorEstado,panelBlk
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if panelBlk.frente {
            _MostrarPaneles()
            _TraerPanelesAlFrente()
            return
        }
        for g in [dial,dsGui,ccGui,arGui,hcGui,lockGui,frenteGui,estabBtnGui,reloadGui,estabGui] {
            if IsObject(g.g)
                g.g.Hide()
        }
        return
    }
    _MostrarPaneles()
    if (floatGui.miniTipID != 0 && floatGui.miniTipTick != 0) {
        if (A_TickCount - floatGui.miniTipTick > 4000) {
            try {
                if IsObject(floatGui.miniTip)
                    floatGui.miniTip.Destroy()
            }
            floatGui.miniTip := 0
            floatGui.miniTipID := 0
            floatGui.miniTipTick := 0
        }
    }
}
_TraerPanelesAlFrente() {
    for g in [dsGui,ccGui,arGui,hcGui,lockGui,frenteGui,estabBtnGui,reloadGui,puntosGui,estabGui] {
        if !IsObject(g.g)
            continue
        try {
            if DllCall("IsWindowVisible","Ptr",g.g.Hwnd)
                DllCall("SetWindowPos","Ptr",g.g.Hwnd,"Ptr",-1,"int",0,"int",0,"int",0,"int",0,"uint",0x0001 | 0x0002 | 0x0010)
        }
    }
}
_MostrarPaneles() {
    estabHwnd := IsObject(estabGui.g) ? estabGui.g.Hwnd : 0
    for g in [dial,dsGui,ccGui,arGui,hcGui,lockGui,frenteGui,estabBtnGui,reloadGui,estabGui] {
        if !IsObject(g.g)
            continue
        if (g.g.Hwnd = estabHwnd && (!estabGui.visible || enfoque.activo))
            continue
        try {
            if !DllCall("IsWindowVisible","Ptr",g.g.Hwnd)
                g.g.Show("NoActivate")
        }
    }
}
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")
!f:: {
    if !stylus.altActive
        return
    if AltF_state.held
        return
    AltF_state.held := true
    now := A_TickCount
    if (now - AltF_state.lastPress < 300) {
        AltF_state.lastPress := 0
        seguiaSostenido := stylus.altActive
        SendEvent("{Alt up}{NumpadEnd}")
        if (seguiaSostenido)
            SendEvent("{Alt down}")
        MostrarHUD("SMEAR SOFT  (2)","FF6B00",950)
    } else {
        AltF_state.lastPress := now
        stylus.bSinteticoTick := A_TickCount
        seguiaSostenido := stylus.altActive
        SendEvent("{Alt up}{b up}{b down}")
        if (seguiaSostenido)
            SendEvent("{Alt down}")
        MostrarHUD("SMEAR  (1)","00E5FF",950)
    }
}
!f up:: AltF_state.held := false
~b & k:: {
    global colorEstado
    if (colorEstado = 1)
        SendInput("^2")
    Send("k")
    Send("k")
    colorEstado := 0
    MostrarMiniTexto("🔄 RESET → COLOR PRIMARIO","1A1A2E",1200)
}
#HotIf
_PosGuiIniPath() => A_ScriptDir "\posiciones_gui.ini"
GuardarPosicionGUI(nombre,hwnd) {
    global PERFIL
    sec := nombre "_p" PERFIL
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",hwnd,"Ptr",rc)
    IniWrite(NumGet(rc,0,"int"),_PosGuiIniPath(),sec,"x")
    IniWrite(NumGet(rc,4,"int"),_PosGuiIniPath(),sec,"y")
}
LeerPosicionGUI(nombre) {
    global PERFIL
    for sec in [nombre "_p" PERFIL,nombre] {
        x := IniRead(_PosGuiIniPath(),sec,"x","")
        y := IniRead(_PosGuiIniPath(),sec,"y","")
        if (x != "" && y != "")
            return {x:Integer(x),y:Integer(y)}
    }
    return 0
}
_PosicionValidaEnPantalla(x,y) {
    Loop MonitorGetCount() {
        MonitorGet(A_Index,&l,&t,&r,&b)
        if (x >= l && x <= r && y >= t && y <= b)
            return true
    }
    return false
}
_AnclaBloquePaneles() {
    static ancla := 0
    if IsObject(ancla)
        return ancla
    mon := ObtenerMonitorCSP()
    anchoBloque := _E(104) + PANEL_GAP + _E(104) + PANEL_GAP + _E(104)
    defX := mon.x + (mon.w - anchoBloque) // 2
    defY := mon.y + Round(mon.h * 0.02) + 42 + 4
    guardada := LeerPosicionGUI("PanelBlock")
    if IsObject(guardada) && _PosicionValidaEnPantalla(guardada.x,guardada.y) {
        ancla := guardada
        return ancla
    }
    vieja := LeerPosicionGUI("Slider")
    if IsObject(vieja) && _PosicionValidaEnPantalla(vieja.x,vieja.y) {
        ancla := vieja
        return ancla
    }
    ancla := {x:defX,y:defY}
    return ancla
}
_ArrastrarPanelBloque(hwndClick,lParam,guiObj) {
    global panelBlk
    static arrastrando := false
    if (arrastrando)
        return
    if !IsObject(guiObj.g)
        return
    if !(hwndClick = guiObj.g.Hwnd || guiObj.g.Hwnd = DllCall("GetParent","Ptr",hwndClick,"Ptr"))
        return
    arrastrando := true
    pt := Buffer(8,0)
    NumPut("int",lParam & 0xFFFF,pt,0)
    NumPut("int",(lParam >> 16) & 0xFFFF,pt,4)
    DllCall("ClientToScreen","Ptr",hwndClick,"Ptr",pt)
    clickX := NumGet(pt,0,"int")
    clickY := NumGet(pt,4,"int")
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",guiObj.g.Hwnd,"Ptr",rc)
    origX := NumGet(rc,0,"int")
    origY := NumGet(rc,4,"int")
    offX := clickX - origX
    offY := clickY - origY
    SWP_NOSIZE := 0x0001
    SWP_NOZORDER := 0x0004
    SWP_NOACTIVATE := 0x0010
    cur := Buffer(8,0)
    movido := false
    while GetKeyState("LButton","P") {
        DllCall("GetCursorPos","Ptr",cur)
        mx := NumGet(cur,0,"int")
        my := NumGet(cur,4,"int")
        if (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4) {
            movido := true
            if !panelBlk.locked {
                newX := mx - offX
                newY := my - offY
                DllCall("SetWindowPos","Ptr",guiObj.g.Hwnd,"Ptr",0,"int",newX,"int",newY,"int",0,"int",0,"uint",SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE)
            }
        }
        Sleep(8)
    }
    if !movido {
        if (guiObj.g.Hwnd = dsGui.g.Hwnd) {
            _ToggleColorV()
            ActualizarDsGUI()
        } else if (guiObj.g.Hwnd = ccGui.g.Hwnd) {
            _ToggleColorCC()
            ActualizarCcGUI()
        } else if (guiObj.g.Hwnd = arGui.g.Hwnd) {
            _ToggleAR()
            ActualizarArGUI()
        } else if (guiObj.g.Hwnd = hcGui.g.Hwnd) {
            _ToggleHistorialColor()
            ActualizarHCGUI()
        } else if (guiObj.g.Hwnd = frenteGui.g.Hwnd) {
            _ToggleFrente()
        } else if (guiObj.g.Hwnd = estabBtnGui.g.Hwnd) {
            _ToggleEstabVisible()
        } else {
            _ToggleBloqueo()
        }
    } else if !panelBlk.locked {
        if (guiObj.g.Hwnd = dsGui.g.Hwnd) {
            GuardarPosicionGUI("Slider",dsGui.g.Hwnd)
            GuardarPosicionGUI("PanelBlock",dsGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = ccGui.g.Hwnd) {
            GuardarPosicionGUI("Circle",ccGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = arGui.g.Hwnd) {
            GuardarPosicionGUI("Quick",arGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = hcGui.g.Hwnd) {
            GuardarPosicionGUI("HC",hcGui.g.Hwnd)
            _GuardarOffsetHC()
        } else if (guiObj.g.Hwnd = lockGui.g.Hwnd) {
            GuardarPosicionGUI("Lock",lockGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = frenteGui.g.Hwnd) {
            GuardarPosicionGUI("Frente",frenteGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = estabBtnGui.g.Hwnd) {
            GuardarPosicionGUI("EstabBtn",estabBtnGui.g.Hwnd)
        }
    }
    arrastrando := false
}
_GuardarOffsetHC() {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "PanelBlock_p" PERFIL
    rd := Buffer(16,0)
    rh := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",dsGui.g.Hwnd,"Ptr",rd)
    DllCall("GetWindowRect","Ptr",hcGui.g.Hwnd,"Ptr",rh)
    IniWrite(NumGet(rh,0,"int") - NumGet(rd,0,"int"),ini,sec,"hcdx")
    IniWrite(NumGet(rh,4,"int") - NumGet(rd,4,"int"),ini,sec,"hcdy")
}
_ToggleBloqueo() {
    panelBlk.locked := !panelBlk.locked
    IniWrite(panelBlk.locked ? 1 : 0,_PosGuiIniPath(),"PanelBlock","locked")
    ActualizarLockGUI()
    MostrarHUD(panelBlk.locked ? "🔒 BLOQUE FIJADO" : "🔓 BLOQUE LIBRE",panelBlk.locked ? "44DD88" : "FF6B00",1200)
}
_HcOffsetBloque() {
    global ESC
    ini := _PosGuiIniPath()
    sec := "PanelBlock_p" PERFIL
    dx := IniRead(ini,sec,"hcdx","")
    dy := IniRead(ini,sec,"hcdy","")
    if (dx != "" && dy != "")
        return {dx:Integer(dx),dy:Integer(dy)}
    dx := IniRead(ini,"PanelBlock","hcdx","")
    dy := IniRead(ini,"PanelBlock","hcdy","")
    if (dx != "" && dy != "") {
        dx := Round(Integer(dx) * ESC)
        dy := Round(Integer(dy) * ESC)
        IniWrite(dx,ini,sec,"hcdx")
        IniWrite(dy,ini,sec,"hcdy")
        return {dx:dx,dy:dy}
    }
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",dsGui.g.Hwnd,"Ptr",rc)
    ah := NumGet(rc,12,"int") - NumGet(rc,4,"int")
    return {dx:0,dy:ah + PANEL_GAP}
}
IniciarDialGUI() => 0
ActualizarDialGUI() {
    global opacidad
    if (!IsObject(dial.g) || !dial.icono)
        return
    if (dial.modo = 1) {
        dial.icono.Value := "🖌"
        dial.label.Value := "Tamaño"
        dial.barra.Opt("c00e5ff")
        dial.barra.Value := 100
    } else {
        dial.icono.Value := "◑"
        dial.label.Value := "Opacidad " opacidad.nivel "%"
        dial.barra.Opt("cff6b00")
        dial.barra.Value := opacidad.nivel
    }
}
IniciarDsGUI() {
    dsGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    dsGui.g.BackColor := "424242"
    dsGui.g.MarginX := 0
    dsGui.g.MarginY := 0
    WinSetTransparent(235,dsGui.g)
    dsGui.icono := dsGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20),"")
    dsGui.label := dsGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
    dsGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
    dsGui.barra := dsGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
    OnMessage(0x0201,_DsGUI_WM_LBUTTONDOWN)
    posDs := LeerPosicionGUI("Slider")
    if !(IsObject(posDs) && _PosicionValidaEnPantalla(posDs.x,posDs.y))
        posDs := _AnclaBloquePaneles()
    dsGui.g.Show("x" posDs.x " y" posDs.y " w" _E(104) " h" _E(25) " NoActivate")
    ActualizarDsGUI()
}
ActualizarDsGUI() {
    if (colorV.hover) {
        _SetIcono(dsGui.icono,"slider_on")
        dsGui.label.Value := "SLIDER ON"
        dsGui.barra.Opt("cB4C0DE")
        dsGui.g.BackColor := "636D83"
        dsGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
    } else {
        _SetIcono(dsGui.icono,"slider_off")
        dsGui.label.Value := "SLIDER OFF"
        dsGui.barra.Opt("c6A6A6A")
        dsGui.g.BackColor := "424242"
        dsGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
    }
    dsGui.barra.Value := 100
}
_DsGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,dsGui)
IniciarCcGUI() {
    ccGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    ccGui.g.BackColor := "424242"
    ccGui.g.MarginX := 0
    ccGui.g.MarginY := 0
    WinSetTransparent(235,ccGui.g)
    ccGui.icono := ccGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20),"")
    ccGui.label := ccGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
    ccGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
    ccGui.barra := ccGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
    OnMessage(0x0201,_CcGUI_WM_LBUTTONDOWN)
    posCc := LeerPosicionGUI("Circle")
    if (IsObject(posCc) && _PosicionValidaEnPantalla(posCc.x,posCc.y)) {
        ccX := posCc.x
        ccY := posCc.y
    } else {
        try {
            WinGetPos(&dsX,&dsY,&dsW,&dsH,"ahk_id " dsGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            dsX := ancla.x
            dsY := ancla.y
            dsW := _E(104)
        }
        ccX := dsX + dsW + PANEL_GAP
        ccY := dsY
    }
    ccGui.g.Show("x" ccX " y" ccY " w" _E(104) " h" _E(25) " NoActivate")
    ActualizarCcGUI()
}
ActualizarCcGUI() {
    if (colorCC.hover) {
        _SetIcono(ccGui.icono,"circle_on")
        ccGui.label.Value := "CIRCLE ON"
        ccGui.barra.Opt("cB4C0DE")
        ccGui.g.BackColor := "636D83"
        ccGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
    } else {
        _SetIcono(ccGui.icono,"circle_off")
        ccGui.label.Value := "CIRCLE OFF"
        ccGui.barra.Opt("c6A6A6A")
        ccGui.g.BackColor := "424242"
        ccGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
    }
    ccGui.barra.Value := 100
}
_CcGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,ccGui)
IniciarArGUI() {
    arGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    arGui.g.BackColor := "424242"
    arGui.g.MarginX := 0
    arGui.g.MarginY := 0
    WinSetTransparent(235,arGui.g)
    arGui.icono := arGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20),"")
    arGui.label := arGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
    arGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
    arGui.barra := arGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
    OnMessage(0x0201,_ArGUI_WM_LBUTTONDOWN)
    posAr := LeerPosicionGUI("Quick")
    if (IsObject(posAr) && _PosicionValidaEnPantalla(posAr.x,posAr.y)) {
        arX := posAr.x
        arY := posAr.y
    } else {
        try {
            WinGetPos(&ccX,&ccY,&ccW,&ccH,"ahk_id " ccGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            ccX := ancla.x + _E(104) + PANEL_GAP
            ccY := ancla.y
            ccW := _E(104)
        }
        arX := ccX + ccW + PANEL_GAP
        arY := ccY
    }
    arGui.g.Show("x" arX " y" arY " w" _E(104) " h" _E(25) " NoActivate")
    ActualizarArGUI()
}
ActualizarArGUI() {
    if (ar.hover) {
        _SetIcono(arGui.icono,"quick_on")
        arGui.label.Value := "QUICK ON"
        arGui.barra.Opt("cB4C0DE")
        arGui.g.BackColor := "636D83"
        arGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
    } else {
        _SetIcono(arGui.icono,"quick_off")
        arGui.label.Value := "QUICK OFF"
        arGui.barra.Opt("c6A6A6A")
        arGui.g.BackColor := "424242"
        arGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
    }
    arGui.barra.Value := 100
}
_ArGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,arGui)
IniciarHCGUI() {
    hcGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    hcGui.g.BackColor := "424242"
    hcGui.g.MarginX := 0
    hcGui.g.MarginY := 0
    WinSetTransparent(235,hcGui.g)
    hcGui.icono := hcGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20),"")
    hcGui.label := hcGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
    hcGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
    hcGui.barra := hcGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
    OnMessage(0x0201,_HCGUI_WM_LBUTTONDOWN)
    posHc := LeerPosicionGUI("HC")
    if (IsObject(posHc) && _PosicionValidaEnPantalla(posHc.x,posHc.y)) {
        x := posHc.x
        y := posHc.y
    } else {
        try {
            WinGetPos(&aX,&aY,,,"ahk_id " dsGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            aX := ancla.x
            aY := ancla.y
        }
        off := _HcOffsetBloque()
        x := aX + off.dx
        y := aY + off.dy
    }
    hcGui.g.Show("x" x " y" y " w" _E(104) " h" _E(25) " NoActivate")
    ActualizarHCGUI()
}
ActualizarHCGUI() {
    if (hist.modo = 1) {
        _SetIcono(hcGui.icono,"hist_on")
        hcGui.label.Value := "HC ON"
        hcGui.barra.Opt("cB4C0DE")
        hcGui.g.BackColor := "636D83"
        hcGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
    } else {
        _SetIcono(hcGui.icono,"hist_off")
        hcGui.label.Value := "HC OFF"
        hcGui.barra.Opt("c6A6A6A")
        hcGui.g.BackColor := "424242"
        hcGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
    }
    hcGui.barra.Value := 100
}
_HCGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,hcGui)
IniciarLockGUI() {
    global panelBlk
    panelBlk.locked := (IniRead(_PosGuiIniPath(),"PanelBlock","locked","1") = "1")
    lockGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    lockGui.g.BackColor := "424242"
    lockGui.g.MarginX := 0
    lockGui.g.MarginY := 0
    WinSetTransparent(235,lockGui.g)
    lockGui.icono := lockGui.g.Add("Picture","x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19),"")
    lockGui.barra := lockGui.g.Add("Progress","x0 y" _E(22) " w" _E(31) " h" _E(3))
    OnMessage(0x0201,_LockGUI_WM_LBUTTONDOWN)
    posLock := LeerPosicionGUI("Lock")
    if (IsObject(posLock) && _PosicionValidaEnPantalla(posLock.x,posLock.y)) {
        lockX := posLock.x
        lockY := posLock.y
    } else {
        try {
            WinGetPos(&arX,&arY,&arW,&arH,"ahk_id " arGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            arX := ancla.x + 2 * (_E(104) + PANEL_GAP)
            arY := ancla.y
            arW := _E(104)
        }
        lockX := arX + arW + PANEL_GAP
        lockY := arY
    }
    lockGui.g.Show("x" lockX " y" lockY " w" _E(31) " h" _E(25) " NoActivate")
    ActualizarLockGUI()
}
ActualizarLockGUI() {
    if (panelBlk.locked) {
        _SetIcono(lockGui.icono,"lock_closed")
        lockGui.barra.Opt("c6A6A6A")
        lockGui.g.BackColor := "424242"
    } else {
        _SetIcono(lockGui.icono,"lock_open")
        lockGui.barra.Opt("cB4C0DE")
        lockGui.g.BackColor := "636D83"
    }
    lockGui.barra.Value := 100
    if IsObject(estabGui.grip)
        estabGui.grip.Visible := !panelBlk.locked
    if IsObject(estabGui.g)
        try estabGui.g.BackColor := panelBlk.locked ? "2B2B2B" : "3A4260"
}
_LockGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,lockGui)
IniciarFrenteGUI() {
    global panelBlk
    panelBlk.frente := (IniRead(_PosGuiIniPath(),"PanelBlock","frente","0") = "1")
    frenteGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    frenteGui.g.BackColor := "424242"
    frenteGui.g.MarginX := 0
    frenteGui.g.MarginY := 0
    WinSetTransparent(235,frenteGui.g)
    frenteGui.icono := frenteGui.g.Add("Picture","x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19),"")
    frenteGui.barra := frenteGui.g.Add("Progress","x0 y" _E(22) " w" _E(31) " h" _E(3))
    OnMessage(0x0201,_FrenteGUI_WM_LBUTTONDOWN)
    posF := LeerPosicionGUI("Frente")
    if (IsObject(posF) && _PosicionValidaEnPantalla(posF.x,posF.y)) {
        fX := posF.x
        fY := posF.y
    } else {
        try {
            WinGetPos(&lX,&lY,&lW,&lH,"ahk_id " lockGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            lX := ancla.x + 3 * (_E(104) + PANEL_GAP)
            lY := ancla.y
            lW := _E(31)
        }
        fX := lX + lW + PANEL_GAP
        fY := lY
    }
    frenteGui.g.Show("x" fX " y" fY " w" _E(31) " h" _E(25) " NoActivate")
    ActualizarFrenteGUI()
}
ActualizarFrenteGUI() {
    if !IsObject(frenteGui.icono)
        return
    if panelBlk.frente {
        _SetIcono(frenteGui.icono,"pin_on")
        frenteGui.barra.Opt("cB4C0DE")
        frenteGui.g.BackColor := "636D83"
    } else {
        _SetIcono(frenteGui.icono,"pin_off")
        frenteGui.barra.Opt("c6A6A6A")
        frenteGui.g.BackColor := "424242"
    }
    frenteGui.barra.Value := 100
}
_FrenteGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,frenteGui)
_ToggleFrente() {
    panelBlk.frente := !panelBlk.frente
    IniWrite(panelBlk.frente ? 1 : 0,_PosGuiIniPath(),"PanelBlock","frente")
    ActualizarFrenteGUI()
    if panelBlk.frente {
        _MostrarPaneles()
        _TraerPanelesAlFrente()
    }
    MostrarHUD(panelBlk.frente ? "📌 GUI AL FRENTE" : "📌 GUI SOLO EN CSP",panelBlk.frente ? "44DD88" : "FF6B00",1200)
}
IniciarEstabBtnGUI() {
    estabBtnGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    estabBtnGui.g.BackColor := "424242"
    estabBtnGui.g.MarginX := 0
    estabBtnGui.g.MarginY := 0
    WinSetTransparent(235,estabBtnGui.g)
    estabBtnGui.icono := estabBtnGui.g.Add("Picture","x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20),"")
    estabBtnGui.label := estabBtnGui.g.Add("Text","x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite","")
    estabBtnGui.label.SetFont("s" _FS(9) " bold","Segoe UI")
    estabBtnGui.barra := estabBtnGui.g.Add("Progress","x0 y" _E(22) " w" _E(104) " h" _E(3))
    OnMessage(0x0201,_EstabBtnGUI_WM_LBUTTONDOWN)
    posB := LeerPosicionGUI("EstabBtn")
    if (IsObject(posB) && _PosicionValidaEnPantalla(posB.x,posB.y)) {
        eX := posB.x
        eY := posB.y
    } else {
        try {
            WinGetPos(&fX,&fY,&fW,&fH,"ahk_id " frenteGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            fX := ancla.x + 3 * (_E(104) + PANEL_GAP) + _E(31) + PANEL_GAP
            fY := ancla.y
            fW := _E(31)
        }
        eX := fX + fW + PANEL_GAP
        eY := fY
    }
    estabBtnGui.g.Show("x" eX " y" eY " w" _E(104) " h" _E(25) " NoActivate")
    ActualizarEstabBtnGUI()
}
ActualizarEstabBtnGUI() {
    if !IsObject(estabBtnGui.g) || !IsObject(estabBtnGui.label)
        return
    if estabGui.visible {
        _SetIcono(estabBtnGui.icono,"slider_on")
        estabBtnGui.label.Value := "ESTAB ON"
        estabBtnGui.barra.Opt("cB4C0DE")
        estabBtnGui.g.BackColor := "636D83"
        estabBtnGui.label.SetFont("s" _FS(9) " bold cFFFFFF","Segoe UI")
    } else {
        _SetIcono(estabBtnGui.icono,"slider_off")
        estabBtnGui.label.Value := "ESTAB OFF"
        estabBtnGui.barra.Opt("c6A6A6A")
        estabBtnGui.g.BackColor := "424242"
        estabBtnGui.label.SetFont("s" _FS(9) " bold cB2B2B2","Segoe UI")
    }
    estabBtnGui.barra.Value := 100
}
_EstabBtnGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) => _ArrastrarPanelBloque(hwnd,lParam,estabBtnGui)
_ToggleEstabVisible() {
    global PERFIL
    estabGui.visible := !estabGui.visible
    IniWrite(estabGui.visible ? 1 : 0,_PosGuiIniPath(),"Estab_p" PERFIL,"visible")
    if estabGui.visible {
        if (!enfoque.activo && IsObject(estabGui.g) && !DllCall("IsWindowVisible","Ptr",estabGui.g.Hwnd))
            estabGui.g.Show("NoActivate")
        ActualizarEstabGUI()
    } else if (IsObject(estabGui.g) && !estabGui.foco)
        estabGui.g.Hide()
    ActualizarEstabBtnGUI()
    MostrarHUD(estabGui.visible ? "🎚 DESLIZADOR VISIBLE" : "🎚 DESLIZADOR OCULTO",estabGui.visible ? "44DD88" : "FF6B00",1100)
}
IniciarEstabGUI() {
    global PERFIL,panelBlk,ESTAB_ALPHA_H,ESTAB_ALPHA_F
    ini := _PosGuiIniPath()
    v := IniRead(ini,"Estab_p" PERFIL,"valor","")
    estabGui.valor := (IsInteger(v) && Integer(v) >= 0 && Integer(v) <= 100) ? Integer(v) : 50
    estabGui.previsto := estabGui.valor
    pidGuardado := IniRead(ini,"Estab_p" PERFIL,"pid","")
    pidCSP := ProcessExist("CLIPStudioPaint.exe")
    estabGui.sincronizado := (pidCSP && pidGuardado != "" && String(pidCSP) = pidGuardado)
    estabGui.visible := (IniRead(ini,"Estab_p" PERFIL,"visible","1") = "1")
    estabGui.arrastrando := false
    a := IniRead(ini,"Estab_p" PERFIL,"alphaH","")
    if (IsInteger(a) && Integer(a) >= 10 && Integer(a) <= 100)
        ESTAB_ALPHA_H := Round(Integer(a) * 2.55)
    a := IniRead(ini,"Estab_p" PERFIL,"alphaF","")
    if (IsInteger(a) && Integer(a) >= 10 && Integer(a) <= 100)
        ESTAB_ALPHA_F := Round(Integer(a) * 2.55)
    r := _EstabRectGuardada()
    if IsObject(r) {
        w := r.w
        h := r.h
        px := r.x
        py := r.y
    } else {
        mon0 := ObtenerMonitorCSP()
        w := _E(420)
        h := _E(44)
        posE := LeerPosicionGUI("Estab")
        if (IsObject(posE) && _PosicionValidaEnPantalla(posE.x,posE.y)) {
            px := posE.x
            py := posE.y
        } else {
            px := mon0.x + (mon0.w - w) // 2
            py := mon0.y + Round(mon0.h * 0.14)
        }
    }
    mon := _EstabMonitorEn(px + w // 2,py + h // 2)
    w := Max(14,Min(w,mon.w))
    h := Max(14,Min(h,mon.h))
    px := Max(mon.x,Min(px,mon.x + mon.w - w))
    py := Max(mon.y,Min(py,mon.y + mon.h - h))
    _EstabCalcular(w,h)
    estabGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x08000000 -DPIScale","")
    estabGui.g.BackColor := panelBlk.locked ? "2B2B2B" : "3A4260"
    estabGui.g.MarginX := 0
    estabGui.g.MarginY := 0
    _EstabAlpha(false)
    estabGui.fondo := estabGui.g.Add("Text","x" estabGui.trackX " y" estabGui.trackY " w" estabGui.trackW " h" estabGui.trackH " Background3A3A45","")
    estabGui.slider := estabGui.g.Add("Progress","x" estabGui.trackX " y" estabGui.trackY " w" estabGui.trackW " h" estabGui.trackH " c" ESTAB_COLOR)
    estabGui.slider.Value := 100
    estabGui.knob := estabGui.g.Add("Text","x0 y0 w" estabGui.knobSize " h" estabGui.knobSize " BackgroundFFFFFF","")
    estabGui.valorTxt := estabGui.g.Add("Text","x0 y0 w" w " h" estabGui.txtH " Center +0x200 c" ESTAB_COLOR,"")
    estabGui.valorTxt.SetFont("s" estabGui.fuente " bold","Segoe UI")
    estabGui.grip := estabGui.g.Add("Text","x" Max(0,w - _E(15)) " y" (h - _E(15)) " w" _E(15) " h" _E(15) " Right +0x200 BackgroundTrans c6A6A6A","◢")
    estabGui.grip.SetFont("s" Max(7,Round(9 * ESC)),"Segoe UI")
    estabGui.grip.Visible := !panelBlk.locked
    OnMessage(0x0201,_EstabGUI_WM_LBUTTONDOWN)
    OnMessage(0x0207,_EstabGUI_WM_MBUTTONDOWN)
    HotIf(_EstabZonaRueda)
    try Hotkey("WheelUp",_EstabWheelUp,"On")
    try Hotkey("WheelDown",_EstabWheelDown,"On")
    HotIf(_EstabCSPActivo)
    try Hotkey("~j",_EstabTeclaJ,"On")
    try Hotkey("~-",_EstabTeclaMenos,"On")
    HotIf(_EstabFocoCond)
    try Hotkey("$+e",_EstabFocoTecla,"On")
    try Hotkey("~*e up",_EstabTeclaMenosUp,"On")
    try Hotkey("~*Shift up",_EstabTeclaMenosUp,"On")
    HotIf()
    estabGui.g.Show("x" px " y" py " w" w " h" h " NoActivate")
    if !estabGui.visible
        estabGui.g.Hide()
    _EstabRegion(w,h)
    _EstabLayout(w,h)
    ActualizarEstabBtnGUI()
}
_EstabMonitorEn(x,y) {
    Loop MonitorGetCount() {
        MonitorGet(A_Index,&mL,&mT,&mR,&mB)
        if (x >= mL && x < mR && y >= mT && y < mB)
            return {x:mL,y:mT,w:mR - mL,h:mB - mT}
    }
    return ObtenerMonitorCSP()
}
_EstabTamanoValido(w,h) => (Min(w,h) >= 14 && Max(w,h) >= 60)
_EstabAlpha(activo := false) {
    if !IsObject(estabGui.g)
        return
    if estabGui.foco
        a := activo ? ESTAB_ALPHA_ACT : ESTAB_ALPHA_F
    else
        a := estabGui.horiz ? (activo ? ESTAB_ALPHA_ACT : ESTAB_ALPHA_H) : 235
    try WinSetTransparent(a,"ahk_id " estabGui.g.Hwnd)
}
_EstabCalcular(w,h) {
    estabGui.ancho := w
    estabGui.alto := h
    estabGui.horiz := (w > h)
    if estabGui.horiz {
        estabGui.txtH := h
        estabGui.txtW := Max(34,Round(h * 1.4))
        estabGui.knobSize := Max(12,Round(h * 0.86))
        estabGui.trackH := Max(6,Round(h * 0.46))
        estabGui.trackY := Round((h - estabGui.trackH) / 2)
        k := Round(estabGui.knobSize / 2)
        estabGui.trackX := k + 3
        estabGui.trackW := Max(20,w - estabGui.txtW - estabGui.trackX - k - 3)
        estabGui.fuente := Max(8,Round(h * 0.30))
    } else {
        estabGui.txtH := Max(18,Round(h * 0.10))
        estabGui.txtW := w
        estabGui.knobSize := Max(14,Round(w * 0.58))
        k := Round(estabGui.knobSize / 2)
        estabGui.trackW := Max(6,Round(w * 0.22))
        estabGui.trackX := Round((w - estabGui.trackW) / 2)
        estabGui.trackY := Max(k + 3,Round(h * 0.03))
        estabGui.trackH := Max(24,h - estabGui.txtH - 2 * estabGui.trackY)
        estabGui.fuente := Max(7,Round(w * 0.26))
    }
}
_EstabLayout(w,h) {
    _EstabCalcular(w,h)
    if !IsObject(estabGui.fondo)
        return
    try {
        estabGui.fondo.Move(estabGui.trackX,estabGui.trackY,estabGui.trackW,estabGui.trackH)
        estabGui.knob.Move(,,estabGui.knobSize,estabGui.knobSize)
        _EstabKnobRegion()
        estabGui.valorTxt.SetFont("s" estabGui.fuente " bold","Segoe UI")
        if estabGui.horiz
            estabGui.valorTxt.Move(w - estabGui.txtW,0,estabGui.txtW,h)
        else
            estabGui.valorTxt.Move(0,h - estabGui.txtH,w,estabGui.txtH)
        estabGui.grip.Move(Max(0,w - _E(15)),h - _E(15),_E(15),_E(15))
        estabGui.grip.Visible := (!panelBlk.locked && !estabGui.foco)
    }
    _EstabAlpha(false)
    ActualizarEstabGUI(-1,true)
}
_EstabKnobRegion() {
    if !IsObject(estabGui.knob)
        return
    d := estabGui.knobSize
    try {
        rgn := DllCall("Gdi32\CreateEllipticRgn","int",0,"int",0,"int",d + 1,"int",d + 1,"Ptr")
        DllCall("SetWindowRgn","Ptr",estabGui.knob.Hwnd,"Ptr",rgn,"int",1)
    }
}
_EstabRegion(w,h) {
    if !IsObject(estabGui.g)
        return
    try {
        rad := Max(6,Round(Min(w,h) * 0.18))
        rgn := DllCall("Gdi32\CreateRoundRectRgn","int",0,"int",0,"int",w + 1,"int",h + 1,"int",rad,"int",rad,"Ptr")
        DllCall("SetWindowRgn","Ptr",estabGui.g.Hwnd,"Ptr",rgn,"int",1)
    }
}
ActualizarEstabGUI(v := -1,forzar := false) {
    if !IsObject(estabGui.g)
        return
    if (v < 0)
        v := estabGui.valor
    sig := estabGui.ancho "x" estabGui.alto "x" estabGui.horiz
    if (!forzar && v = estabGui.dibV && sig = estabGui.dibG)
        return
    try {
        d := estabGui.knobSize
        if estabGui.horiz {
            fillW := Max(1,Round((v / 100) * estabGui.trackW))
            estabGui.slider.Move(estabGui.trackX,estabGui.trackY,fillW,estabGui.trackH)
            cx := estabGui.trackX + Round((v / 100) * estabGui.trackW) - Round(d / 2)
            cy := Round((estabGui.alto - d) / 2)
        } else {
            fillH := Max(1,Round((v / 100) * estabGui.trackH))
            estabGui.slider.Move(estabGui.trackX,estabGui.trackY + estabGui.trackH - fillH,estabGui.trackW,fillH)
            cx := estabGui.trackX + Round(estabGui.trackW / 2) - Round(d / 2)
            cy := estabGui.trackY + estabGui.trackH - Round((v / 100) * estabGui.trackH) - Round(d / 2)
        }
        estabGui.slider.Visible := (v > 0)
        estabGui.valorTxt.Value := String(v)
        estabGui.knob.Move(Max(0,cx),Max(0,cy),d,d)
        estabGui.dibV := v
        estabGui.dibG := sig
        ; repinta fondo + barra + perilla juntos: evita las perillas "fantasma"
        DllCall("RedrawWindow","Ptr",estabGui.g.Hwnd,"Ptr",0,"Ptr",0,"UInt",0x0001 | 0x0004 | 0x0080 | 0x0100)
    }
}
_EstabCSPActivo(*) => WinActive("ahk_exe CLIPStudioPaint.exe")
_EstabZonaRueda(*) => _EstabCSPActivo() && _EstabBajoMouse()
_EstabBajoMouse() {
    if !IsObject(estabGui.g) || !DllCall("IsWindowVisible","Ptr",estabGui.g.Hwnd)
        return false
    MouseGetPos(&mx,&my)
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",estabGui.g.Hwnd,"Ptr",rc)
    return (mx >= NumGet(rc,0,"int") && mx <= NumGet(rc,8,"int") && my >= NumGet(rc,4,"int") && my <= NumGet(rc,12,"int"))
}
_EstabWheelUp(*) {
    _EstabAplicarValor(estabGui.valor + 5)
    MostrarHUD("ESTABILIZACIÓN " estabGui.valor,"9A7BFF",600)
}
_EstabWheelDown(*) {
    _EstabAplicarValor(estabGui.valor - 5)
    MostrarHUD("ESTABILIZACIÓN " estabGui.valor,"9A7BFF",600)
}
_EstabTeclaJ() => _EstabTeclaLocal(-1)
_EstabTeclaMenos() => _EstabTeclaLocal(1)
_EstabFocoCond(*) => enfoque.activo && WinActive("ahk_exe CLIPStudioPaint.exe")
_EstabFocoTecla(*) => _EstabFocoMostrar()
_EstabTeclaMenosUp(*) {
    if !estabGui.foco
        return
    estabGui.fAbajo := false
    estabGui.fSoltado := A_TickCount
}
_EstabFocoRect() {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "Estab_p" PERFIL
    x := IniRead(ini,sec,"fx","")
    y := IniRead(ini,sec,"fy","")
    w := IniRead(ini,sec,"fw","")
    h := IniRead(ini,sec,"fh","")
    if (IsInteger(x) && IsInteger(y) && IsInteger(w) && IsInteger(h)) {
        if (_EstabTamanoValido(Integer(w),Integer(h)) && _PosicionValidaEnPantalla(Integer(x),Integer(y)))
            return {x:Integer(x),y:Integer(y),w:Integer(w),h:Integer(h)}
    }
    mon := ObtenerMonitorCSP()
    w := Min(mon.w - 40,Round(mon.w * 0.45))
    h := _E(64)
    return {x:mon.x + (mon.w - w) // 2,y:mon.y + mon.h - h - Round(mon.h * 0.10),w:w,h:h}
}
_EstabFocoGuardarRect(x,y,w,h) {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "Estab_p" PERFIL
    IniWrite(x,ini,sec,"fx")
    IniWrite(y,ini,sec,"fy")
    IniWrite(w,ini,sec,"fw")
    IniWrite(h,ini,sec,"fh")
}
_EstabFocoMostrar() {
    if !IsObject(estabGui.g)
        return
    estabGui.fAbajo := true
    estabGui.fTick := A_TickCount
    if estabGui.foco
        return
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",estabGui.g.Hwnd,"Ptr",rc)
    nx := NumGet(rc,0,"int")
    ny := NumGet(rc,4,"int")
    estabGui.rectNormal := {x:nx,y:ny,w:NumGet(rc,8,"int") - nx,h:NumGet(rc,12,"int") - ny}
    r := _EstabFocoRect()
    estabGui.foco := true
    DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",-1,"int",r.x,"int",r.y,"int",r.w,"int",r.h,"uint",0x0010)
    _EstabRegion(r.w,r.h)
    _EstabLayout(r.w,r.h)
    if !DllCall("IsWindowVisible","Ptr",estabGui.g.Hwnd)
        estabGui.g.Show("NoActivate")
    _EstabAlpha(false)
    SetTimer(_EstabFocoVigilar,40)
}
_EstabFocoOcultar(*) {
    if !estabGui.foco
        return
    SetTimer(_EstabFocoVigilar,0)
    estabGui.foco := false
    estabGui.fAbajo := false
    estabGui.fPrevHasta := 0
    if !IsObject(estabGui.g)
        return
    r := estabGui.rectNormal
    if IsObject(r) {
        DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",0,"int",r.x,"int",r.y,"int",r.w,"int",r.h,"uint",0x0004 | 0x0010)
        _EstabRegion(r.w,r.h)
        _EstabLayout(r.w,r.h)
    }
    if (enfoque.activo || !estabGui.visible)
        estabGui.g.Hide()
    _EstabAlpha(false)
}
_EstabFocoVigilar(*) {
    if !estabGui.foco {
        SetTimer(_EstabFocoVigilar,0)
        return
    }
    if (A_TickCount < estabGui.fPrevHasta)
        return
    if estabGui.arrastrando {
        estabGui.fTick := A_TickCount
        return
    }
    if (!enfoque.activo || !WinActive("ahk_exe CLIPStudioPaint.exe") || GetKeyState("Escape","P") || A_TickCount - estabGui.fTick > FOCO_TIMEOUT_MS) {
        _EstabFocoOcultar()
        return
    }
    if (!estabGui.fAbajo && A_TickCount - estabGui.fSoltado > FOCO_GRACIA_MS)
        _EstabFocoOcultar()
}
_EstabFocoPrevisualizar() {
    if estabGui.foco
        return
    _EstabFocoMostrar()
    estabGui.fAbajo := false
    estabGui.fSoltado := 0
    estabGui.fPrevHasta := A_TickCount + 2200
}
_EstabTeclaLocal(d) {
    if !IsObject(estabGui.g) || !estabGui.sincronizado
        return
    estabGui.valor := Max(0,Min(100,estabGui.valor + d))
    ActualizarEstabGUI()
    _GuardarValorEstab()
}
_EstabEmitir(tecla,n,pausa := 8) {
    ; ráfagas de 5: 50 cambios ≈ 80 ms en vez de 500 ms
    while (n > 0) {
        if !WinActive("ahk_exe CLIPStudioPaint.exe")
            return false
        k := (n > 5) ? 5 : n
        SendInput("{" tecla " " k "}")
        n -= k
        Sleep(pausa)
    }
    return true
}
_EstabEnviarDelta(nuevo) {
    d := nuevo - estabGui.valor
    if (d = 0)
        return true
    ok := (d > 0) ? _EstabEmitir("-",d) : _EstabEmitir("j",Abs(d))
    if !ok {
        estabGui.sincronizado := false
        return false
    }
    estabGui.valor := nuevo
    return true
}
_EstabPrevisualizar(cx,cy) {
    if estabGui.horiz
        nuevo := Round(((cx - estabGui.trackX) / estabGui.trackW) * 100)
    else
        nuevo := Round(((estabGui.trackY + estabGui.trackH - cy) / estabGui.trackH) * 100)
    estabGui.previsto := Max(0,Min(100,nuevo))
    ActualizarEstabGUI(estabGui.previsto)
}
_EstabEnBarra(rx,ry) {
    k := Round(estabGui.knobSize / 2)
    if estabGui.horiz
        return (rx >= estabGui.trackX - k - 2 && rx <= estabGui.trackX + estabGui.trackW + k + 2)
    return (rx >= estabGui.trackX - _E(10) && rx <= estabGui.trackX + estabGui.trackW + _E(10) && ry >= estabGui.trackY - k && ry <= estabGui.trackY + estabGui.trackH + k)
}
_EstabRectGuardada() {
    global PERFIL
    ini := _PosGuiIniPath()
    sec := "Estab_p" PERFIL
    x := IniRead(ini,sec,"x","")
    y := IniRead(ini,sec,"y","")
    w := IniRead(ini,sec,"w","")
    h := IniRead(ini,sec,"h","")
    if (IsInteger(x) && IsInteger(y) && IsInteger(w) && IsInteger(h)) {
        if (_EstabTamanoValido(Integer(w),Integer(h)) && _PosicionValidaEnPantalla(Integer(x),Integer(y)))
            return {x:Integer(x),y:Integer(y),w:Integer(w),h:Integer(h)}
    }
    return _EstabRectCalibrada()
}
_EstabRectCalibrada() {
    global PUNTOS,PUNTOS_DEF
    if (PUNTOS.Length < 32)
        return 0
    if (PUNTOS[31][1] = PUNTOS_DEF[31][1] && PUNTOS[31][2] = PUNTOS_DEF[31][2] && PUNTOS[32][1] = PUNTOS_DEF[32][1] && PUNTOS[32][2] = PUNTOS_DEF[32][2])
        return 0
    w := Abs(PUNTOS[32][1] - PUNTOS[31][1])
    h := Abs(PUNTOS[32][2] - PUNTOS[31][2])
    if !_EstabTamanoValido(w,h)
        return 0
    return {x:Min(PUNTOS[31][1],PUNTOS[32][1]),y:Min(PUNTOS[31][2],PUNTOS[32][2]),w:w,h:h}
}
_EstabGuardarRect() {
    global PERFIL
    if (!IsObject(estabGui.g) || estabGui.foco)
        return
    ini := _PosGuiIniPath()
    sec := "Estab_p" PERFIL
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",estabGui.g.Hwnd,"Ptr",rc)
    x := NumGet(rc,0,"int")
    y := NumGet(rc,4,"int")
    IniWrite(x,ini,sec,"x")
    IniWrite(y,ini,sec,"y")
    IniWrite(NumGet(rc,8,"int") - x,ini,sec,"w")
    IniWrite(NumGet(rc,12,"int") - y,ini,sec,"h")
}
_EstabAplicarRect(x,y,w,h) {
    global PUNTOS,PERFIL
    if !IsObject(estabGui.g)
        return false
    DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",0,"int",x,"int",y,"int",w,"int",h,"uint",0x0004 | 0x0010)
    _EstabLayout(w,h)
    _EstabRegion(w,h)
    if !estabGui.visible {
        estabGui.visible := true
        IniWrite(1,_PosGuiIniPath(),"Estab_p" PERFIL,"visible")
        estabGui.g.Show("NoActivate")
        ActualizarEstabBtnGUI()
    }
    _EstabGuardarRect()
    if (PUNTOS.Length >= 32) {
        PUNTOS[31] := [x,y]
        PUNTOS[32] := [x + w,y + h]
    }
    ori := estabGui.horiz ? "HORIZONTAL" : "VERTICAL"
    MostrarHUD("🎚 DESLIZADOR " w "×" h " · " ori,"9A7BFF",1500)
    return true
}
_EstabGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) {
    global panelBlk
    if (estabGui.arrastrando || !IsObject(estabGui.g))
        return
    if !(hwnd = estabGui.g.Hwnd || estabGui.g.Hwnd = DllCall("GetParent","Ptr",hwnd,"Ptr"))
        return
    estabGui.arrastrando := true
    pt := Buffer(8,0)
    NumPut("int",lParam & 0xFFFF,pt,0)
    NumPut("int",(lParam >> 16) & 0xFFFF,pt,4)
    DllCall("ClientToScreen","Ptr",hwnd,"Ptr",pt)
    clickX := NumGet(pt,0,"int")
    clickY := NumGet(pt,4,"int")
    rc := Buffer(16,0)
    DllCall("GetWindowRect","Ptr",estabGui.g.Hwnd,"Ptr",rc)
    winX := NumGet(rc,0,"int")
    winY := NumGet(rc,4,"int")
    rx := clickX - winX
    ry := clickY - winY
    winW := NumGet(rc,8,"int") - winX
    winH := NumGet(rc,12,"int") - winY
    grip := _E(15)
    enGrip := !panelBlk.locked && (rx >= winW - grip && ry >= winH - grip)
    enBarra := !enGrip && _EstabEnBarra(rx,ry)
    mon := _EstabMonitorEn(clickX,clickY)
    _EstabAlpha(true)
    cur := Buffer(8,0)
    try {
        if (estabGui.foco) {
            ; deslizador de ENFOQUE: toda la zona elige valor en vivo; sin mover ni redimensionar
            estabGui.fTick := A_TickCount
            _EstabPrevisualizar(rx,ry)
            if estabGui.sincronizado
                _EstabEnviarDelta(estabGui.previsto)
            while GetKeyState("LButton","P") {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                _EstabPrevisualizar(mx - winX,my - winY)
                if (estabGui.sincronizado && estabGui.previsto != estabGui.valor)
                    _EstabEnviarDelta(estabGui.previsto)
                estabGui.fTick := A_TickCount
                Sleep(8)
            }
            _EstabAplicarValor(estabGui.previsto)
        } else if (enGrip) {
            while GetKeyState("LButton","P") {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                nw := Max(14,Min(mon.w,winW + (mx - clickX)))
                nh := Max(14,Min(mon.h,winH + (my - clickY)))
                DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",0,"int",0,"int",0,"int",nw,"int",nh,"uint",0x0002 | 0x0004 | 0x0010)
                _EstabLayout(nw,nh)
                _EstabRegion(nw,nh)
                Sleep(8)
            }
            _EstabGuardarRect()
        } else if !panelBlk.locked {
            movido := false
            while GetKeyState("LButton","P") {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                if (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4)
                    movido := true
                if movido
                    DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",0,"int",mx - rx,"int",my - ry,"int",0,"int",0,"uint",0x0001 | 0x0004 | 0x0010)
                Sleep(8)
            }
            if movido
                _EstabGuardarRect()
            else if enBarra {
                _EstabPrevisualizar(rx,ry)
                _EstabAplicarValor(estabGui.previsto)
                MostrarHUD("ESTABILIZACIÓN " estabGui.valor,"9A7BFF",700)
            }
        } else if enBarra {
            _EstabPrevisualizar(rx,ry)
            if estabGui.sincronizado
                _EstabEnviarDelta(estabGui.previsto)
            while GetKeyState("LButton","P") {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                _EstabPrevisualizar(mx - winX,my - winY)
                if (estabGui.sincronizado && estabGui.previsto != estabGui.valor)
                    _EstabEnviarDelta(estabGui.previsto)
                Sleep(8)
            }
            _EstabAplicarValor(estabGui.previsto)
            MostrarHUD("ESTABILIZACIÓN " estabGui.valor,"9A7BFF",700)
        } else {
            while GetKeyState("LButton","P")
                Sleep(8)
        }
    } finally {
        _EstabAlpha(false)
        estabGui.arrastrando := false
        if estabGui.foco {
            estabGui.fTick := A_TickCount
            if !estabGui.fAbajo
                estabGui.fSoltado := A_TickCount
        }
    }
}
_EstabGUI_WM_MBUTTONDOWN(wParam,lParam,msg,hwnd) {
    if !IsObject(estabGui.g)
        return
    if !(hwnd = estabGui.g.Hwnd || estabGui.g.Hwnd = DllCall("GetParent","Ptr",hwnd,"Ptr"))
        return
    estabGui.sincronizado := false
    _EstabAplicarValor(estabGui.valor)
    MostrarHUD("🔄 ESTAB. RESINCRONIZADA","44DD88",900)
}
_EstabAplicarValor(nuevo) {
    nuevo := Max(0,Min(100,Round(nuevo)))
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        MostrarHUD("⚠ ACTIVA CLIP STUDIO PAINT","FF4444",1200)
        estabGui.sincronizado := false
        ActualizarEstabGUI()
        return
    }
    desfasado := !estabGui.sincronizado
    if (nuevo = estabGui.valor && !desfasado) {
        ActualizarEstabGUI()
        _GuardarValorEstab()
        return
    }
    base := estabGui.valor
    ok := true
    try {
        BlockInput(true)
        if desfasado {
            MostrarHUD("🔄 SINCRONIZANDO…","9A7BFF",900)
            ok := _EstabEmitir("j",100,5)
            base := 0
            estabGui.sincronizado := ok
            if ok {
                estabGui.valor := 0
                ActualizarEstabGUI(0)
            }
        }
        if ok {
            d := nuevo - base
            if (d > 0)
                ok := _EstabEmitir("-",d)
            else if (d < 0)
                ok := _EstabEmitir("j",Abs(d))
        }
    } finally {
        BlockInput(false)
    }
    if !ok {
        estabGui.sincronizado := false
        MostrarHUD("⚠ SINCRONIZACIÓN INTERRUMPIDA","FFAA33",1300)
        ActualizarEstabGUI()
        return
    }
    estabGui.valor := nuevo
    estabGui.previsto := nuevo
    ActualizarEstabGUI()
    _GuardarValorEstab()
}
_GuardarValorEstab() {
    global PERFIL
    ini := _PosGuiIniPath()
    IniWrite(estabGui.valor,ini,"Estab_p" PERFIL,"valor")
    pid := ProcessExist("CLIPStudioPaint.exe")
    try {
        if pid
            IniWrite(pid,ini,"Estab_p" PERFIL,"pid")
        else
            IniDelete(ini,"Estab_p" PERFIL,"pid")
    }
}
IniciarReloadGUI() {
    reloadGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    reloadGui.g.BackColor := "3B7A4B"
    reloadGui.g.MarginX := 0
    reloadGui.g.MarginY := 0
    WinSetTransparent(235,reloadGui.g)
    reloadGui.icono := reloadGui.g.Add("Picture","x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19),"")
    _SetIcono(reloadGui.icono,"reload_g")
    reloadGui.barra := reloadGui.g.Add("Progress","x0 y" _E(22) " w" _E(31) " h" _E(3))
    reloadGui.barra.Value := 100
    OnMessage(0x0201,_ReloadGUI_WM_LBUTTONDOWN)
    mon := ObtenerMonitorCSP()
    x := mon.x + (mon.w - _E(104)) // 2
    y := mon.y + Round(mon.h * 0.02) + 42 + 4 + _E(25) + 4 + _E(25) + 4 + _E(25) + 4 + _E(25) + 4
    guardada := LeerPosicionGUI("Reload")
    if IsObject(guardada) && _PosicionValidaEnPantalla(guardada.x,guardada.y) {
        x := guardada.x
        y := guardada.y
    }
    reloadGui.g.Show("x" x " y" y " w" _E(31) " h" _E(25) " NoActivate")
}
_ReloadGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) {
    static arrastrando := false
    if (arrastrando)
        return
    if (hwnd = reloadGui.g.Hwnd || reloadGui.g.Hwnd = DllCall("GetParent","Ptr",hwnd,"Ptr")) {
        arrastrando := true
        pt := Buffer(8,0)
        NumPut("int",lParam & 0xFFFF,pt,0)
        NumPut("int",(lParam >> 16) & 0xFFFF,pt,4)
        DllCall("ClientToScreen","Ptr",hwnd,"Ptr",pt)
        clickX := NumGet(pt,0,"int")
        clickY := NumGet(pt,4,"int")
        rc := Buffer(16,0)
        DllCall("GetWindowRect","Ptr",reloadGui.g.Hwnd,"Ptr",rc)
        offX := clickX - NumGet(rc,0,"int")
        offY := clickY - NumGet(rc,4,"int")
        cur := Buffer(8,0)
        movido := false
        while GetKeyState("LButton","P") {
            DllCall("GetCursorPos","Ptr",cur)
            mx := NumGet(cur,0,"int")
            my := NumGet(cur,4,"int")
            if (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4) {
                movido := true
                DllCall("SetWindowPos","Ptr",reloadGui.g.Hwnd,"Ptr",0,"int",mx - offX,"int",my - offY,"int",0,"int",0,"uint",0x0001 | 0x0004 | 0x0010)
            }
            Sleep(8)
        }
        if !movido {
            SoundBeep(700,60)
            Reload()
        } else
            GuardarPosicionGUI("Reload",reloadGui.g.Hwnd)
        arrastrando := false
    }
}
PuntosPorDefecto() {
    r := []
    for p in PUNTOS_DEF
        r.Push([p[1],p[2]])
    return r
}
CargarPuntos() {
    global PUNTOS,HIST_ALTO,PERFIL
    ini := _PosGuiIniPath()
    sec := "Puntos" PERFIL
    PUNTOS := []
    for i,p in PUNTOS_DEF {
        x := IniRead(ini,sec,"P" i "x","")
        y := IniRead(ini,sec,"P" i "y","")
        if ((x = "" || y = "") && PERFIL = 1) {
            x := IniRead(ini,"Puntos","P" i "x","")
            y := IniRead(ini,"Puntos","P" i "y","")
        }
        if (IsInteger(x) && IsInteger(y))
            PUNTOS.Push([Integer(x),Integer(y)])
        else
            PUNTOS.Push([p[1],p[2]])
    }
    h := IniRead(ini,sec,"HistAlto","")
    if (h = "" && PERFIL = 1)
        h := IniRead(ini,"Puntos","HistAlto","")
    HIST_ALTO := IsInteger(h) ? Integer(h) : 104
    RecalcularZonas()
}
GuardarPuntos(conFirma := true) {
    global PUNTOS,HIST_ALTO,PERFIL
    ini := _PosGuiIniPath()
    sec := "Puntos" PERFIL
    for i,p in PUNTOS {
        IniWrite(p[1],ini,sec,"P" i "x")
        IniWrite(p[2],ini,sec,"P" i "y")
    }
    IniWrite(HIST_ALTO,ini,sec,"HistAlto")
    if (conFirma)
        IniWrite(_FirmaMonitores(),ini,sec,"firma")
}
CargarEscala() {
    global ESC,PERFIL
    v := IniRead(_PosGuiIniPath(),"Puntos" PERFIL,"escala","")
    if (!IsNumber(v) || Number(v) < 40 || Number(v) > 200)
        v := (PERFIL = 1) ? 75 : 100
    ESC := Number(v) / 100
}
CargarEscalaAvisos() {
    global AVISO_ESC,ESC,PERFIL
    v := IniRead(_PosGuiIniPath(),"Puntos" PERFIL,"escalaAvisos","")
    if (!IsNumber(v) || Number(v) < 40 || Number(v) > 250)
        v := Round(ESC * 110)
    AVISO_ESC := Number(v) / 100
}
_E(n) => Max(1,Round(n * ESC))
_FS(n) => Max(6,Round(n * ESC))
_FirmaMonitores() {
    f := ""
    Loop MonitorGetCount() {
        MonitorGet(A_Index,&l,&t,&r,&b)
        f .= (f = "" ? "" : ";") l "," t "," r "," b
    }
    f := Sort(f,"D;")
    return f
}
ElegirPerfil() {
    global PERFIL,PERFILES
    ini := _PosGuiIniPath()
    act := IniRead(ini,"Perfil","actual","1")
    PERFIL := (IsInteger(act) && Integer(act) >= 1 && Integer(act) <= PERFILES.Length) ? Integer(act) : 1
    firma := _FirmaMonitores()
    previa := IniRead(ini,"Perfil","ultimaFirma","")
    if (previa = firma)
        return
    IniWrite(firma,ini,"Perfil","ultimaFirma")
    primera := (previa = "")
    for i,nombre in PERFILES {
        if (IniRead(ini,"Puntos" i,"firma","") = firma) {
            PERFIL := i
            IniWrite(i,ini,"Perfil","actual")
            msg := "PERFIL AUTO: " nombre
            SetTimer(() => MostrarHUD(msg,"9AA7C7",2500),-1800)
            return
        }
    }
    if (primera)
        return
    msg := "MONITORES CAMBIARON — elige perfil en 📍 (actual: " PERFILES[PERFIL] ")"
    SetTimer(() => MostrarHUD(msg,"9AA7C7",3500),-1800)
}
_ZonaDePuntos(desde,n) {
    global PUNTOS
    x1 := PUNTOS[desde][1]
    x2 := x1
    y1 := PUNTOS[desde][2]
    y2 := y1
    Loop n - 1 {
        p := PUNTOS[desde + A_Index]
        x1 := Min(x1,p[1])
        x2 := Max(x2,p[1])
        y1 := Min(y1,p[2])
        y2 := Max(y2,p[2])
    }
    return {x1:x1,y1:y1,x2:x2,y2:y2}
}
RecalcularZonas() {
    global ZONAS,HIST_ALTO
    izq := []
    der := []
    Loop 3 {
        izq.Push(_ZonaDePuntos(3 + (A_Index - 1) * 4,4))
        der.Push(_ZonaDePuntos(15 + (A_Index - 1) * 4,4))
    }
    h := _ZonaDePuntos(27,2)
    if (HIST_ALTO >= 0)
        h.y2 := h.y2 + HIST_ALTO
    else
        h.y1 := h.y1 + HIST_ALTO
    ZONAS := {izq:izq,der:der,hist:h}
}
_NombrePunto(i) {
    if (i <= 2)
        return "Ocultar/mostrar · " (i = 1 ? "izq" : "der")
    if (i <= 14)
        return "Izq B" ((i - 3) // 4 + 1) " · esq " (Mod(i - 3,4) + 1)
    if (i <= 26)
        return "Der B" ((i - 15) // 4 + 1) " · esq " (Mod(i - 15,4) + 1)
    if (i = 27)
        return "Historial · izq"
    if (i = 28)
        return "Historial · der"
    if (i = 29)
        return "Zona segura (rehacer)"
    if (i = 30)
        return "Avisos · esq. sup. izq. (HUD)"
    return "Punto " i
}
IniciarPuntosGUI() {
    global reloadGui
    puntosGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow","")
    puntosGui.g.BackColor := "424242"
    puntosGui.g.MarginX := 0
    puntosGui.g.MarginY := 0
    WinSetTransparent(235,puntosGui.g)
    puntosGui.icono := puntosGui.g.Add("Picture","x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19),"")
    _SetIcono(puntosGui.icono,"calib")
    puntosGui.barra := puntosGui.g.Add("Progress","x0 y" _E(22) " w" _E(31) " h" _E(3))
    puntosGui.barra.Value := 100
    OnMessage(0x0201,_PuntosGUI_WM_LBUTTONDOWN)
    mon := ObtenerMonitorCSP()
    x := mon.x + (mon.w - _E(104)) // 2 + _E(31) + PANEL_GAP
    y := mon.y + Round(mon.h * 0.02)
    try {
        WinGetPos(&rX,&rY,&rW,&rH,"ahk_id " reloadGui.g.Hwnd)
        x := rX + rW + PANEL_GAP
        y := rY
    }
    guardada := LeerPosicionGUI("PuntosBtn")
    if IsObject(guardada) && _PosicionValidaEnPantalla(guardada.x,guardada.y) {
        x := guardada.x
        y := guardada.y
    }
    puntosGui.g.Show("x" x " y" y " w" _E(31) " h" _E(25) " NoActivate")
}
_PuntosGUI_WM_LBUTTONDOWN(wParam,lParam,msg,hwnd) {
    static arrastrando := false
    if (arrastrando)
        return
    if !IsObject(puntosGui.g)
        return
    if (hwnd = puntosGui.g.Hwnd || puntosGui.g.Hwnd = DllCall("GetParent","Ptr",hwnd,"Ptr")) {
        arrastrando := true
        pt := Buffer(8,0)
        NumPut("int",lParam & 0xFFFF,pt,0)
        NumPut("int",(lParam >> 16) & 0xFFFF,pt,4)
        DllCall("ClientToScreen","Ptr",hwnd,"Ptr",pt)
        clickX := NumGet(pt,0,"int")
        clickY := NumGet(pt,4,"int")
        rc := Buffer(16,0)
        DllCall("GetWindowRect","Ptr",puntosGui.g.Hwnd,"Ptr",rc)
        offX := clickX - NumGet(rc,0,"int")
        offY := clickY - NumGet(rc,4,"int")
        cur := Buffer(8,0)
        movido := false
        while GetKeyState("LButton","P") {
            DllCall("GetCursorPos","Ptr",cur)
            mx := NumGet(cur,0,"int")
            my := NumGet(cur,4,"int")
            if (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4) {
                movido := true
                DllCall("SetWindowPos","Ptr",puntosGui.g.Hwnd,"Ptr",0,"int",mx - offX,"int",my - offY,"int",0,"int",0,"uint",0x0001 | 0x0004 | 0x0010)
            }
            Sleep(8)
        }
        if !movido
            AbrirPanelPuntos()
        else
            GuardarPosicionGUI("PuntosBtn",puntosGui.g.Hwnd)
        arrastrando := false
    }
}
AbrirPanelPuntos() {
    global PERFIL,PERFILES,ESC,AVISO_ESC,panelBlk
    if IsObject(ptsEd.g) {
        try {
            ptsEd.g.Show()
            return
        }
        ptsEd.g := 0
    }
    g := Gui("+AlwaysOnTop","📍 Calibración de puntos")
    g.SetFont("s9","Segoe UI")
    g.Add("Text","xm y+4","Perfil de equipo:")
    ddl := g.Add("DropDownList","x+8 yp-3 w230 Choose" PERFIL,PERFILES)
    ddl.OnEvent("Change",_PtsCambiarPerfil)
    g.Add("Text","xm y+8","Escala de botones (%):")
    eEsc := g.Add("Edit","x+8 yp-3 w55",Round(ESC * 100))
    g.Add("Text","x+8 yp+3","(se aplica al guardar)")
    g.Add("Text","xm y+8","Escala de avisos (%):")
    eEscAv := g.Add("Edit","x+8 yp-3 w55",Round(AVISO_ESC * 100))
    g.Add("Text","x+8 yp+3","(HUD, mini-textos)")
    lv := g.Add("ListView","xm y+8 w440 r11 -Multi NoSortHdr Grid",["#","Punto","X","Y"])
    for i,p in PUNTOS {
        if (i > 30)
            break
        lv.Add("","P" i,_NombrePunto(i),p[1],p[2])
    }
    lv.ModifyCol(1,40)
    lv.ModifyCol(2,220)
    lv.ModifyCol(3,70)
    lv.ModifyCol(4,70)
    g.Add("Text","xm y+10","Seleccionado:   X")
    ex := g.Add("Edit","x+6 yp-3 w70","")
    g.Add("Text","x+12 yp+3","Y")
    ey := g.Add("Edit","x+6 yp-3 w70","")
    g.Add("Text","xm y+10","Desplazar TODOS:   ΔX")
    dx := g.Add("Edit","x+6 yp-3 w60","0")
    g.Add("Text","x+12 yp+3","ΔY")
    dy := g.Add("Edit","x+6 yp-3 w60","0")
    bDelta := g.Add("Button","x+12 yp-2 w80","Aplicar Δ")
    g.Add("Text","xm y+10","Alto franja historial:")
    hAlto := g.Add("Edit","x+6 yp-3 w60",HIST_ALTO)
    g.Add("Text","xm y+12","📌 Ubicar GUI — botones del script:")
    bMover := g.Add("Button","x+8 yp-4 w135",panelBlk.locked ? "🔓 Mover botones" : "🔒 Fijar botones")
    bReub := g.Add("Button","x+6 yp w135","↺ Reubicar botones")
    g.Add("Text","xm y+8","📌 Ubicar GUI — paneles de CSP:")
    bLN := g.Add("Button","x+8 yp-4 w125","💾 Guardar Normal")
    bLE := g.Add("Button","x+6 yp w125","💾 Guardar Enfoque")
    bLA := g.Add("Button","x+6 yp w90","▶ Aplicar")
    g.Add("Text","xm y+8","🎚 Deslizador de estabilización:")
    bZona := g.Add("Button","x+8 yp-4 w215","✏ Dibujar zona del deslizador")
    g.Add("Text","xm y+8","Opacidad del deslizador horizontal (%):")
    eAlpha := g.Add("Edit","x+8 yp-3 w55",Round(ESTAB_ALPHA_H / 2.55))
    g.Add("Text","x+8 yp+3","(zona ancha = horizontal · alta = vertical)")
    bZonaF := g.Add("Button","xm y+10 w330","✏ Dibujar zona del deslizador de ENFOQUE (aparece con Shift+E)")
    g.Add("Text","xm y+8","Opacidad del deslizador de enfoque (%):")
    eAlphaF := g.Add("Edit","x+8 yp-3 w55",Round(ESTAB_ALPHA_F / 2.55))
    bCap := g.Add("Button","xm y+12 w115","🎯 Captura (F1)")
    bVer := g.Add("Button","x+6 yp w90","👁 Ver zonas")
    bDef := g.Add("Button","x+6 yp w120","↺ Puntos por defecto")
    bOk := g.Add("Button","x+6 yp w125 Default","💾 Guardar y cerrar")
    bRei := g.Add("Button","xm y+8 w140","🔄 Reiniciar script")
    st := g.Add("Text","xm y+10 w440 h34","")
    ptsEd.g := g
    ptsEd.lv := lv
    ptsEd.ex := ex
    ptsEd.ey := ey
    ptsEd.dx := dx
    ptsEd.dy := dy
    ptsEd.hAlto := hAlto
    ptsEd.eEsc := eEsc
    ptsEd.eEscAv := eEscAv
    ptsEd.st := st
    ptsEd.bCap := bCap
    ptsEd.eAlpha := eAlpha
    ptsEd.eAlphaF := eAlphaF
    ptsEd.sel := 0
    ptsEd.capturando := false
    st.Value := "Perfil activo: " PERFILES[PERFIL] ". Selecciona un punto."
    lv.OnEvent("ItemSelect",_PtsSel)
    ex.OnEvent("Change",_PtsEditChange)
    ey.OnEvent("Change",_PtsEditChange)
    hAlto.OnEvent("Change",_PtsAltoChange)
    bDelta.OnEvent("Click",_PtsDesplazar)
    bMover.OnEvent("Click",(ctrl,*) => _PtsMoverBotones(ctrl))
    bReub.OnEvent("Click",_PtsReubicar)
    bLN.OnEvent("Click",(*) => _CapturarLayout("Normal"))
    bLE.OnEvent("Click",(*) => _CapturarLayout("Enfoque"))
    bLA.OnEvent("Click",(*) => _AplicarLayoutPaneles(enfoque.activo ? "Enfoque" : "Normal"))
    bZona.OnEvent("Click",(*) => _PtsDibujarZonaEstab(false))
    bZonaF.OnEvent("Click",(*) => _PtsDibujarZonaEstab(true))
    eAlpha.OnEvent("Change",_PtsAlphaChange)
    eAlphaF.OnEvent("Change",_PtsAlphaFChange)
    bCap.OnEvent("Click",_PtsToggleCaptura)
    bVer.OnEvent("Click",(*) => MostrarZonasCalibracion(3500))
    bDef.OnEvent("Click",_PtsDefecto)
    bRei.OnEvent("Click",_PtsReiniciar)
    bOk.OnEvent("Click",_PtsCerrar)
    g.OnEvent("Close",_PtsCerrar)
    g.OnEvent("Escape",_PtsCerrar)
    g.Show("AutoSize")
    lv.Modify(1,"Select Focus")
    _PtsSel(lv,1,true)
}
_PtsAlphaChange(*) {
    global ESTAB_ALPHA_H,PERFIL
    v := Trim(ptsEd.eAlpha.Value)
    if (!IsInteger(v) || Integer(v) < 10 || Integer(v) > 100)
        return
    ESTAB_ALPHA_H := Round(Integer(v) * 2.55)
    IniWrite(Integer(v),_PosGuiIniPath(),"Estab_p" PERFIL,"alphaH")
    _EstabAlpha(false)
}
_PtsAlphaFChange(*) {
    global ESTAB_ALPHA_F,PERFIL
    v := Trim(ptsEd.eAlphaF.Value)
    if (!IsInteger(v) || Integer(v) < 10 || Integer(v) > 100)
        return
    ESTAB_ALPHA_F := Round(Integer(v) * 2.55)
    IniWrite(Integer(v),_PosGuiIniPath(),"Estab_p" PERFIL,"alphaF")
    if estabGui.foco
        _EstabAlpha(false)
}
_PtsDibujarZonaEstab(foco := false) {
    if (ptsEd.dibujando)
        return
    ptsEd.dibujando := true
    ov := 0
    tip := 0
    pv := 0
    ok := false
    cancelado := false
    rx := 0
    ry := 0
    rw := 0
    rh := 0
    try {
        if (ptsEd.capturando)
            _PtsCapturaOff()
        vx := SysGet(76)
        vy := SysGet(77)
        vw := SysGet(78)
        vh := SysGet(79)
        ov := Gui("+AlwaysOnTop -Caption +ToolWindow -DPIScale","")
        ov.BackColor := "0B0B14"
        ov.Show("x" vx " y" vy " w" vw " h" vh)
        WinSetTransparent(80,"ahk_id " ov.Hwnd)
        mon := ObtenerMonitorCSP()
        tip := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale","")
        tip.BackColor := "1E1E2E"
        tip.SetFont("s11 bold cWhite","Segoe UI")
        tip.AddText("x12 y8 w640 h26 Center",foco ? "✏ Dibuja la zona del deslizador de ENFOQUE  ·  ancho = horizontal  ·  Esc = cancelar" : "✏ Arrastra para dibujar la zona del deslizador  ·  ancho = horizontal  ·  Esc = cancelar")
        tip.Show("x" (mon.x + (mon.w - 664) // 2) " y" (mon.y + 40) " w664 h42 NoActivate")
        cur := Buffer(8,0)
        t0 := A_TickCount
        while !GetKeyState("LButton","P") {
            if (GetKeyState("Escape","P") || A_TickCount - t0 > 60000) {
                cancelado := true
                break
            }
            Sleep(10)
        }
        if !cancelado {
            DllCall("GetCursorPos","Ptr",cur)
            x0 := NumGet(cur,0,"int")
            y0 := NumGet(cur,4,"int")
            pv := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale","")
            pv.BackColor := ESTAB_COLOR
            pv.Show("x" x0 " y" y0 " w4 h4 NoActivate")
            WinSetTransparent(150,"ahk_id " pv.Hwnd)
            rx := x0
            ry := y0
            rw := 4
            rh := 4
            while GetKeyState("LButton","P") {
                DllCall("GetCursorPos","Ptr",cur)
                mx := NumGet(cur,0,"int")
                my := NumGet(cur,4,"int")
                rx := Min(x0,mx)
                ry := Min(y0,my)
                rw := Max(4,Abs(mx - x0))
                rh := Max(4,Abs(my - y0))
                DllCall("SetWindowPos","Ptr",pv.Hwnd,"Ptr",-1,"int",rx,"int",ry,"int",rw,"int",rh,"uint",0x0010)
                if GetKeyState("Escape","P") {
                    cancelado := true
                    break
                }
                Sleep(8)
            }
            if !cancelado
                ok := true
        }
    } finally {
        for gg in [pv,tip,ov] {
            if IsObject(gg)
                try gg.Destroy()
        }
        ptsEd.dibujando := false
    }
    try ptsEd.g.Show()
    if !ok {
        try ptsEd.st.Value := "Dibujo cancelado."
        return
    }
    if !_EstabTamanoValido(rw,rh) {
        try ptsEd.st.Value := "Zona demasiado pequeña (mín. 14 px de grosor y 60 de largo)."
        return
    }
    if foco {
        _EstabFocoGuardarRect(rx,ry,rw,rh)
        ori := (rw > rh) ? "horizontal" : "vertical"
        try ptsEd.st.Value := "Zona de ENFOQUE guardada: " rw "×" rh " (" ori "). Aparece al presionar Shift+E en modo enfoque."
        _EstabFocoPrevisualizar()
        return
    }
    if _EstabAplicarRect(rx,ry,rw,rh) {
        ori := estabGui.horiz ? "horizontal" : "vertical"
        try ptsEd.st.Value := "Zona guardada: " rw "×" rh " (" ori "). Usa el candado para fijarla."
    }
}
_PtsSel(ctrl,item,selected) {
    if (!selected || item < 1)
        return
    ptsEd.sel := item
    ptsEd.ex.Value := PUNTOS[item][1]
    ptsEd.ey.Value := PUNTOS[item][2]
    if (ptsEd.capturando)
        _PtsEstadoCaptura()
    else
        ptsEd.st.Value := "P" item " — " _NombrePunto(item)
}
_PtsEditChange(*) {
    i := ptsEd.sel
    if (i < 1)
        return
    x := Trim(ptsEd.ex.Value)
    y := Trim(ptsEd.ey.Value)
    if (!IsInteger(x) || !IsInteger(y))
        return
    x := Integer(x)
    y := Integer(y)
    if (PUNTOS[i][1] = x && PUNTOS[i][2] = y)
        return
    PUNTOS[i][1] := x
    PUNTOS[i][2] := y
    ptsEd.lv.Modify(i,"","P" i,_NombrePunto(i),x,y)
    RecalcularZonas()
}
_PtsAltoChange(*) {
    v := Trim(ptsEd.hAlto.Value)
    if (!IsInteger(v) || Integer(v) = HIST_ALTO)
        return
    HIST_ALTO := Integer(v)
    RecalcularZonas()
}
_PtsDesplazar(*) {
    dx := Trim(ptsEd.dx.Value)
    dy := Trim(ptsEd.dy.Value)
    if (!IsInteger(dx) || !IsInteger(dy)) {
        ptsEd.st.Value := "ΔX y ΔY deben ser enteros."
        return
    }
    dx := Integer(dx)
    dy := Integer(dy)
    for p in PUNTOS {
        p[1] += dx
        p[2] += dy
    }
    _PtsRefrescar()
    ptsEd.dx.Value := "0"
    ptsEd.dy.Value := "0"
    ptsEd.st.Value := "Desplazados: ΔX=" dx " ΔY=" dy
}
_PtsRefrescar() {
    global HIST_ALTO
    for i,p in PUNTOS {
        if (i > 30)
            break
        ptsEd.lv.Modify(i,"","P" i,_NombrePunto(i),p[1],p[2])
    }
    ptsEd.hAlto.Value := HIST_ALTO
    if (ptsEd.sel >= 1) {
        ptsEd.ex.Value := PUNTOS[ptsEd.sel][1]
        ptsEd.ey.Value := PUNTOS[ptsEd.sel][2]
    }
    RecalcularZonas()
}
_PtsReiniciar(*) {
    _PtsCapturaOff()
    GuardarPuntos()
    ToolTip("🔄 Reiniciando script…")
    Sleep(250)
    Reload()
}
_PtsDefecto(*) {
    global HIST_ALTO
    PUNTOS := PuntosPorDefecto()
    HIST_ALTO := 104
    _PtsRefrescar()
    ptsEd.st.Value := "Cargados los puntos por defecto (se guardan con 💾)."
}
_PtsMoverBotones(ctrl) {
    _ToggleBloqueo()
    ctrl.Text := panelBlk.locked ? "🔓 Mover botones" : "🔒 Fijar botones"
}
_PtsReubicar(*) {
    ReubicarBotones()
    ptsEd.st.Value := "Botones reubicados para este perfil."
}
ReubicarBotones() {
    mon := ObtenerMonitorCSP()
    F := 0x0001 | 0x0004 | 0x0010
    ancho := _E(104) * 4 + _E(31) * 2 + PANEL_GAP * 5
    x0 := mon.x + (mon.w - ancho) // 2
    y0 := mon.y + Round(mon.h * 0.02) + 42 + 4
    sx := x0
    for g in [dsGui,ccGui,arGui,lockGui,frenteGui,estabBtnGui] {
        if !IsObject(g.g)
            continue
        DllCall("SetWindowPos","Ptr",g.g.Hwnd,"Ptr",0,"int",sx,"int",y0,"int",0,"int",0,"uint",F)
        WinGetPos(&gx,&gy,&gw,&gh,"ahk_id " g.g.Hwnd)
        sx += gw + PANEL_GAP
    }
    if (IsObject(estabGui.g) && !estabGui.horiz) {
        WinGetPos(&lkX,&lkY,&lkW,&lkH,"ahk_id " lockGui.g.Hwnd)
        ex := Min(lkX + lkW + PANEL_GAP,mon.x + mon.w - _E(220))
        DllCall("SetWindowPos","Ptr",estabGui.g.Hwnd,"Ptr",0,"int",ex,"int",lkY,"int",0,"int",0,"uint",F)
    }
    WinGetPos(&gx,&gy,&gw,&dsH,"ahk_id " dsGui.g.Hwnd)
    hcY := y0 + dsH + PANEL_GAP
    DllCall("SetWindowPos","Ptr",hcGui.g.Hwnd,"Ptr",0,"int",x0,"int",hcY,"int",0,"int",0,"uint",F)
    WinGetPos(&gx,&gy,&gw,&hcH,"ahk_id " hcGui.g.Hwnd)
    ry := hcY + hcH + PANEL_GAP
    DllCall("SetWindowPos","Ptr",reloadGui.g.Hwnd,"Ptr",0,"int",x0,"int",ry,"int",0,"int",0,"uint",F)
    WinGetPos(&gx,&gy,&rw,&rh,"ahk_id " reloadGui.g.Hwnd)
    DllCall("SetWindowPos","Ptr",puntosGui.g.Hwnd,"Ptr",0,"int",x0 + rw + PANEL_GAP,"int",ry,"int",0,"int",0,"uint",F)
    GuardarPosicionGUI("PanelBlock",dsGui.g.Hwnd)
    GuardarPosicionGUI("Slider",dsGui.g.Hwnd)
    GuardarPosicionGUI("Circle",ccGui.g.Hwnd)
    GuardarPosicionGUI("Quick",arGui.g.Hwnd)
    GuardarPosicionGUI("Lock",lockGui.g.Hwnd)
    GuardarPosicionGUI("Frente",frenteGui.g.Hwnd)
    GuardarPosicionGUI("EstabBtn",estabBtnGui.g.Hwnd)
    GuardarPosicionGUI("HC",hcGui.g.Hwnd)
    _GuardarOffsetHC()
    GuardarPosicionGUI("Reload",reloadGui.g.Hwnd)
    GuardarPosicionGUI("PuntosBtn",puntosGui.g.Hwnd)
    GuardarPosicionGUI("Estab",estabGui.g.Hwnd)
}
_PtsCambiarPerfil(ctrl,*) {
    nuevo := ctrl.Value
    if (nuevo < 1 || nuevo = PERFIL)
        return
    _PtsCapturaOff()
    GuardarPuntos(false)
    ini := _PosGuiIniPath()
    IniWrite(nuevo,ini,"Perfil","actual")
    IniWrite(_FirmaMonitores(),ini,"Perfil","ultimaFirma")
    OcultarZonasCalibracion()
    ToolTip("🔄 Perfil: " PERFILES[nuevo])
    Sleep(300)
    Reload()
}
_PtsToggleCaptura(*) {
    if (ptsEd.capturando)
        _PtsCapturaOff()
    else
        _PtsCapturaOn()
}
_PtsCapturaOn(*) {
    if (ptsEd.sel < 1) {
        ptsEd.lv.Modify(1,"Select Focus")
        ptsEd.sel := 1
    }
    ptsEd.capturando := true
    ptsEd.bCap.Text := "⏹ Terminar (F2)"
    HotIf()
    Hotkey("$F1",_PtsCapturar,"On")
    Hotkey("$F2",_PtsCapturaOff,"On")
    _PtsEstadoCaptura()
}
_PtsCapturaOff(*) {
    ptsEd.capturando := false
    HotIf()
    try Hotkey("$F1","Off")
    try Hotkey("$F2","Off")
    if IsObject(ptsEd.g) {
        try {
            ptsEd.bCap.Text := "🎯 Captura (F1)"
            ptsEd.st.Value := "Captura terminada."
        }
    }
}
_PtsEstadoCaptura() {
    i := ptsEd.sel
    ptsEd.st.Value := "CAPTURA: lápiz sobre P" i " (" _NombrePunto(i) ") y pulsa F1. F2 = terminar."
}
_PtsCapturar(*) {
    i := ptsEd.sel
    if (i < 1 || !IsObject(ptsEd.g))
        return
    MouseGetPos(&mx,&my)
    PUNTOS[i][1] := mx
    PUNTOS[i][2] := my
    ptsEd.lv.Modify(i,"","P" i,_NombrePunto(i),mx,my)
    RecalcularZonas()
    SoundBeep(1000,50)
    if (i < PUNTOS.Length) {
        ptsEd.sel := i + 1
        ptsEd.lv.Modify(i + 1,"Select Focus Vis")
        ptsEd.ex.Value := PUNTOS[i + 1][1]
        ptsEd.ey.Value := PUNTOS[i + 1][2]
        _PtsEstadoCaptura()
    } else {
        _PtsCapturaOff()
        ptsEd.st.Value := "Captura completa (💾 para persistir)."
    }
}
_PtsCerrar(*) {
    _PtsCapturaOff()
    GuardarPuntos()
    OcultarZonasCalibracion()
    recargar := false
    try {
        v := Trim(ptsEd.eEsc.Value)
        if (IsNumber(v) && Number(v) >= 40 && Number(v) <= 200 && Abs(Number(v) - ESC * 100) >= 0.5) {
            IniWrite(Round(Number(v)),_PosGuiIniPath(),"Puntos" PERFIL,"escala")
            recargar := true
        }
    }
    try {
        v := Trim(ptsEd.eEscAv.Value)
        if (IsNumber(v) && Number(v) >= 40 && Number(v) <= 250 && Abs(Number(v) - AVISO_ESC * 100) >= 0.5) {
            IniWrite(Round(Number(v)),_PosGuiIniPath(),"Puntos" PERFIL,"escalaAvisos")
            recargar := true
        }
    }
    try ptsEd.g.Destroy()
    ptsEd.g := 0
    ptsEd.sel := 0
    if (recargar) {
        ToolTip("🔄 Aplicando escala…")
        Sleep(250)
        Reload()
    }
    SetTimer(() => SoundBeep(900,70),-1)
}
MostrarZonasCalibracion(ms := 3000) {
    OcultarZonasCalibracion()
    for z in ZONAS.izq
        ptsEd.ovl.Push(_CrearRectOverlay(z.x1,z.y1,z.x2 - z.x1 + 1,z.y2 - z.y1 + 1,"2ECC71"))
    for z in ZONAS.der
        ptsEd.ovl.Push(_CrearRectOverlay(z.x1,z.y1,z.x2 - z.x1 + 1,z.y2 - z.y1 + 1,"3498DB"))
    h := ZONAS.hist
    ptsEd.ovl.Push(_CrearRectOverlay(h.x1,h.y1,h.x2 - h.x1 + 1,h.y2 - h.y1 + 1,"E67E22"))
    for i in [1,2,29,30]
        ptsEd.ovl.Push(_CrearRectOverlay(PUNTOS[i][1] - 8,PUNTOS[i][2] - 8,16,16,i = 29 ? "F1C40F" : (i = 30 ? "9B59B6" : "E74C3C")))
    SetTimer(OcultarZonasCalibracion,-ms)
}
OcultarZonasCalibracion() {
    for g in ptsEd.ovl
        try g.Destroy()
    ptsEd.ovl := []
}
_CrearRectOverlay(x,y,w,h,color) {
    g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale","")
    g.BackColor := color
    g.Show("x" x " y" y " w" Max(w,4) " h" Max(h,4) " NoActivate")
    WinSetTransparent(140,g)
    return g
}
_SetIcono(ctrl,nombre) {
    ruta := _RutaIcono(nombre)
    if (ruta = "")
        return
    try ctrl.Value := ruta
}
_RutaIcono(nombre) {
    arch := "csp2_" nombre ".png"
    ruta := A_ScriptDir "\iconos\" arch
    if FileExist(ruta)
        return ruta
    suelto := A_ScriptDir "\" arch
    if FileExist(suelto)
        return suelto
    if _IconoExtraer(nombre,ruta)
        return ruta
    tmp := A_Temp "\csp_iconos\" arch
    if FileExist(tmp)
        return tmp
    if _IconoExtraer(nombre,tmp)
        return tmp
    return ""
}
_IconoExtraer(nombre,ruta) {
    mapa := _IconosB64()
    if !mapa.Has(nombre)
        return false
    b64 := mapa[nombre]
    try {
        DirCreate(RegExReplace(ruta,"\\[^\\]+$"))
        n := 0
        if !DllCall("Crypt32\CryptStringToBinaryW","Str",b64,"UInt",0,"UInt",1,"Ptr",0,"UInt*",&n,"Ptr",0,"Ptr",0)
            return false
        buf := Buffer(n)
        if !DllCall("Crypt32\CryptStringToBinaryW","Str",b64,"UInt",0,"UInt",1,"Ptr",buf,"UInt*",&n,"Ptr",0,"Ptr",0)
            return false
        f := FileOpen(ruta,"w")
        f.RawWrite(buf,n)
        f.Close()
        return true
    }
    return false
}
_IconosB64() {
    ; Los iconos originales se perdieron en la compactación. Copia la
    ; función _IconosB64() completa desde tu archivo de respaldo v52.
    ; Mientras tanto, esta versión vacía hace que los botones se muestren
    ; como "SLIDER ON/OFF", "CIRCLE ON/OFF", etc. sin dibujito.
    return Map()
}