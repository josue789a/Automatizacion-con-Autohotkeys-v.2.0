# PAQUETE-CLAUDE-3 — Fase 0: cerrar lo abierto y arrancar F1

Destinatario: Claude (arquitecto). Emisor: Qoder, en el PC de Josue.
Fecha: 2026-11-04 (madrugada del 05).
Este archivo es **autocontenido y autoverificable**: todo lo que necesitas está inline (Anexos A-F). No tienes acceso al PC de Josue y **no debes asumir nada que no aparezca aquí**.

---

## 0. Reglas de este chat (léelas antes de responder)

1. **Sé tu fuente es este documento.** El script de producción (3.917 líneas / 130 KB) NO se adjunta: solo el extracto del Anexo C. Si necesitas ver otra función, **pídela por nombre**, y te la traemos en la próxima ronda.
2. **Prohibido escribir hashes, números de línea o firmas de memoria.** En la entrega anterior el spike llevaba `HASH_ESPERADO := CEF745C7685DED9C9BC437FE20CEFFB3688126743A9024D9DE964092EBEA983E`: los primeros 8 caracteres son reales y los 56 restantes no existen. Ese detalle abortó una corrida de 45 segundos y costó un día de espera. Los valores verificados están en el §3; cópialos literalmente.
3. **No devuelvas un `.ahk` completo.** Devuelve bloques pequeños con ancla por **nombre de función** (regla R5), y el comando exacto para aplicarlo. Los parches largos por chat se truncan.
4. **No vuelvas a entregar el mismo binario.** Verifica tu salida con `/validate` antes de enviarla, y comprueba que no reintroduces colisiones de nombres: AHK v2 no distingue mayúsculas, así que una variable global `REP` y una función `Rep()` son el mismo símbolo y el script **no carga**.
5. Si algo de este documento contradice tu plan anterior, **este documento gana** (son datos medidos en el equipo real). Dilo explícitamente en tu resumen en vez de ignorarlo.

---

## 1. El proyecto en 12 líneas

Josue dibuja en **Clip Studio Paint** con tableta **XP-Pen**. Un script de **AutoHotkey v2.0.26** (Windows 11 build 26200, 2 monitores, DPI 96, sin elevar en pruebas) le añade atajos, un HUD, avisos de estado, botoneras de herramienta y un deslizador de estabilización. Ese script es el producto: 3.917 líneas, todo GUI de AHK, y funciona.

El trabajo actual es un **refactor estético por olas** (F0-F6) con arquitectura *strangler*: envolver, nunca reescribir. Se cambia cómo se ve (superficie redondeada con antialias, color por rol semántico, tipografía en 3 niveles, glifos en vez de emoji, movimiento solo de opacidad) sin tocar la ruta del lápiz ni el envío de teclas.

Fases: **F0** reconciliar anclas + latencias base + firmar la técnica de render (D4). **F1** `_Tema()` + roles + detección de fuentes, **cero cambio visual**. **F2** botoneras. **F3** avisos. **F4** animación. **F5** slider. **F6** opcional.

---

## 2. Dónde estamos (estado real, no el del HANDOFF)

Tu `HANDOFF-F0.md` pide 6 pasos. Resultado de haberlos corrido en el equipo real:

| Paso | Estado | Nota |
|---|---|---|
| 1 `/validate` ambos scripts | **FALLO en spike** | `galeria.ahk` exit 0; `spike_latencia.ahk` **exit 2 sin mensaje** (colisión `REP`/`Rep`) |
| 2 `galeria.ahk --oculto` | **OK** | exit 0, `errores: 0` (Anexo E: latencias de redibujo del log) |
| 3 spike seco → `anclas_canonico.txt` | **OK, con 2 parches locales** | Anexo D completo. V0 ya está respondida (§3) |
| 4 spike `--ejecutar` → `latencia_base.txt` | **ROTO** | la copia arranca, `/validate` exit 0, el `SetTimer(_LatBase, -2500)` **nunca dispara**, el watchdog la cierra a los 45 s con stderr vacío |
| 5 sesión visual + capturas → D4/D6 | **BLOQUEADO** | `_Captura()` hacía `BitBlt` del DC de pantalla: fotografiaba otras ventanas de Josue y recortaba la columna E. **Tu entrega 2 introduce `--capturas` que arregla esto** (ver §5) |
| 6 `pruebas.ps1 -Modo parse` / `-Modo esteril` | **PASS** | y el hash de producción salió intacto antes y después |

Tu `RESULTADOS.md` sigue siendo la plantilla vacía: los apartados 1-6 no tienen ni un dato. Todo lo que hay que rellenar ya existe en los Anexos D y E.

---

## 3. Hallazgos verificados (esto es lo que la regla V0 pedía)

Medido sobre el canónico real, 3.917 líneas, SHA-256 `CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E` (este sí verificado por `certutil`/`Get-FileHash`, Anexo D).

**Dónde vive el canónico** — y esto es importante porque tu paquete estaba desplegado en la carpeta equivocada:

| Archivo | Líneas | SHA-256 (16 primeros) | Qué es |
|---|---|---|---|
| `Documents\AntiGravity\Autohotkeys\XxxPPEN_a16pg2_displayAS_secondary.ahk` | 3.917 | `cef745c7ecdbbf82` | **EL CANÓNICO.** Tu ruta por defecto (`..\..\..\` desde `docs\ESTETICA\spike`) apunta bien aquí |
| `Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XxxPPEN...ahk` | 3.913 | `608802933b4b001d` | variante de Desktop, **no** es el canónico |
| `... \XPPEN AHK VERSION ESTABLE.ahk` | 3.958 | `6375b86d633aea04` | el único con `ESTAB_RACHA := 10` / `ESTAB_RITMO := 18` y `_EstabEmitir(tecla, n, pausa := ESTAB_RITMO)` |
| `... \XPPEN..._copia.ahk` | 4.277 | `94464da46eb1fa56` | descarte |

Josue dibuja con **`XPPEN AHK VERSION ESTABLE.ahk` (3.958)** de la carpeta Desktop, no con tu canónico. Antes de F2/F5 hay que resolver qué árbol es la fuente de verdad; si seguimos con el de 3.917, todas las anclas de botoneras y slider están a ~40 líneas de distancia del archivo que él ejecuta. **No decidas esto por ti mismo: plantéalo como pregunta con las dos opciones.**

### V0 respondida (Anexo D = evidencia)

| Marca | Medido | Conclusión |
|---|---|---|
| `_FadeAlpha` | **def l.539, 7 usos**, firma `(hwnd,hasta,pasos := 6,delayMs := 10)` | **I12 tiene objeto.** Tu cláusula "si V0 muestra que `_FadeAlpha` existe, tampoco se toca y el animador nuevo opera solo sobre GUIs propias" **activa**. D1 se cierra con esa redacción |
| `_LimpiarAvisos` | **def 0, usos 0 — NO EXISTE** | **D2 vuelve a abierta.** El hallazgo #1 de tu tabla es real: `_LimpiarGUIs()` (def l.1506, 4 usos) destruye `floatGui.hud*` y apaga el modo Enfoque. Necesita decisión nueva, no "cerrada condicionada" |
| `208 * AVISO_ESC` | l.1584, 1 aparición | hallazgo #3 confirmado en canónico |
| `-2247` | l.1540, 2 apariciones | hallazgo #2 confirmado |
| `PUNTOS[30]` | l.1643, 2 apariciones | hallazgo #2 confirmado → **D3 sigue abierta**, ambas anclas coexisten |
| `Sanar()` | **def 0, usos 0** | no existe en el canónico; cualquier plan que la mencione se refiere a otra variante. El hallazgo #13 (emoji en `Sanar()`) **no aplica** aquí |
| Firmas reales | `MostrarHUD(texto,colorBarra := "00E5FF",duracion := 1200)` 70 usos · `MostrarMiniTexto(texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")` 33 usos · `MostrarBadgeCombo(comboText,toolText,colorAcento := "00E5FF",duracion := 2200)` 5 usos · `ActualizarEstabGUI(v := -1,forzar := false)` 10 usos · `_EstabEmitir(tecla,n,pausa := 8)` 5 usos | úsalas literalmente; `_EstabEmitir` tiene `pausa := 8`, **no** `ESTAB_RITMO` en el canónico |

---

## 4. Los 4 defectos de ENTREGA CLAUDE 2 (con el parche exacto)

**D-1 (fatal) — `spike_latencia.ahk` no carga.** Es **byte a byte idéntico** al zip v2 anterior (`21c202370c8f8474…`), así que el bug que ya te reportamos sigue ahí:

```ahk
; linea 52   REP := ""            ; variable global
; linea 183  Rep(t) { global REP  ;函数 con el mismo nombre (AHK v2 = case-insensitive)
```

`/validate` → **exit 2**, sin mensaje en stderr (el fallo es de carga, no de sintaxis). El parche que sí funciona, aplicado en nuestra copia de trabajo: renombrar la variable a `REPTXT` en sus 4 apariciones (`REP := ""`, `global REP`, `REP .= t`, `FileAppend(REP, ...)`) y dejar `Rep()` intacta.

**D-2 (aborta el paso 1)** — `HASH_ESPERADO` de la línea 35 con el digest inventado (§0.2). Valor correcto: `CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E`.

**D-3 (documentación)** — `README-SPIKE.md`, `RESULTADOS.md`, `HANDOFF-F0.md`, `CHANGELOG-F0.md`, `PLAN-V2.md`, `ROLES_LEGACY.md` y `roles_legacy.ahk` tienen **0 líneas de diferencia** con el zip anterior. El modo `--capturas` que sí añadiste en `galeria.ahk` **no está documentado en ningún lado**, y el `CHANGELOG` sigue sin entrada para esta entrega.

**D-4 (contradicción interna en PLAN-V2)** — la línea 25 de `PLAN-V2.md` publica el digest inventado como "fuente de verdad", y la §1 del propio plan ordena "comprobar contra el canónico" con un hash que ese archivo no tiene. Corregir la línea 25 con el hash real del §3.

---

## 5. Lo abierto, y la vía realista para cerrarlo

### D4 — técnica de render (E GDI+/ULW vs A Region)

**No hace falta `PrintWindow`.** Tu modo nuevo `--capturas` ya da evidencia válida: coloca las ventanas **en pantalla**, `_Ocluyentes()` detecta si hay ventanas ajenas sobre el rectángulo, lo registra en el log y añade `_OCLUIDA` al nombre del PNG. Con `--pos=X,Y` se mueve el stage a una zona limpia.

Qué cubre el barrido, leído del código de la entrega 2 (`_AutoCapturas` l.270-296):

- Monitor primario a **75 / 100 / 150 %** y secundario a **100 / 150 %**, dos fondos por escala (índices 1 y 3 = Oscuro y Claro), `Sleep(400)` antes de cada `BitBlt`.
- La **posición la elige solo**: puntúa candidatos por cuántas ventanas ajenas *topmost* los tapan (`_Ocluyentes`, filtra `Shell_TrayWnd`); `--pos=X,Y` añade una candidata preferida.
- Al pasar por 100 % conmutea ON/OFF de pills, keycaps y slider (y mide el redibujo), pero **después** de capturar.
- Sale con `ExitApp(errores ? 1 : 0)`.

```powershell
cd "C:\Users\jbard\Documents\AntiGravity\Autohotkeys\ENTREGA CLAUDE 2"
& "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" galeria.ahk --capturas
```

Tres huecos que hay que cerrar antes de firmar D4 con este modo, y son decisiones tuyas: (a) no garantiza la **pareja ON y OFF** en cada fondo y escala, así que la evidencia de "pill ON vs OFF a 150 % sobre Claro" puede no existir; (b) no itera `text.primary` `FFFFFF` vs `E8ECF4` en la misma corrida, así que **D6 exige dos corridas** editando `theme.ini` entre ellas; (c) sigue siendo `BitBlt` del DC de pantalla: si CSP queda encima, esa captura no sirve (de ahí la marca `_OCLUIDA`), así que hay que despejar la zona antes de lanzar.

Lo que ya mide el modo oculto (Anexo E: 3 pasadas por escala 75/100/150 %, n=12 en pills, n=6 en keycaps y slider):

| Elemento | A Region | E GDI+/ULW | Lectura |
|---|---|---|---|
| pill ON/OFF | 44,27 - 256,25 ms | **4,50 - 30,52 ms** | E ~10x mas rapida y con varianza baja |
| keycaps | 3,57 - 120,23 ms | 5,36 - 9,84 ms | A gana un caso aislado; E estable |
| slider (val 20 y 80) | 14,84 - 75,03 ms | 5,92 - 16,31 ms | E ~4x |
| B / C / D | 11,65 - 258,44 ms | - | ya descartadas por tu CONTRA-EVAL M4 |

A redibuja una pill hasta en 256 ms; E nunca pasa de 30 ms. **Pero tu criterio (< 2 ms, y en I13 para cualquier funcion estetica nueva) no lo cumple E ni una sola vez.** Hay que revisar ese numero: o se referia al pintado interno de una pill y no al ciclo Show/Hide que midio el spike, o el techo realista es ~10-30 ms y `I13` se reescribe. Si el liston se queda en 2 ms, ninguna de las 5 tecnicas pasa y F2/F5 nacen bloqueados. **Decision tuya, y va en el resumen de T0.**

Evidencia que falta para firmar: pills **A vs E** ON/OFF a 100 % sobre fondo Oscuro y Claro; ídem a 75 y 150 %; keycaps A vs E; slider A vs E; un set al 100 % en el 2.º monitor; rejilla de glifos. **Dime qué corrida exacta lanzar y con qué `--pos`, y te traigo los PNG.**

### D6 — `text.primary`

Hoy `theme.ini` dice `FFFFFF` y el log confirma `Texto primario en uso: FFFFFF (theme.ini dice FFFFFF)`. Falta la comparación visual con `E8ECF4` sobre superficie translúcida. Se decide con las mismas capturas de D4: corre una ronda con `theme.ini` en `E8ECF4` y otra en `FFFFFF`.

### Latencias base (paso 4 roto)

Hechos: la copia se escribe en `%TEMP%\latencia_f0\prueba_latencia.ahk`, pasa `/validate` con exit 0, arranca (su ini se escribe), y `_LatBase` **jamás corre** → a los 45 s el watchdog la mata con stderr vacío. Anuladas las líneas 3-6 y con `Suspend(1)` delante, `SetTimer(fn, -2500)` en la posición de la línea 6 queda registrado **al principio** de una sección de auto-ejecución de ~1.500 líneas globales: la hipótesis fuerte es que el auto-exec no llega a quedar libre a los 2,5 s (o muere antes en código que depende de estar elevado), no que el temporizador esté mal escrito.

**No adivines el fix: entrega una versión con diagnóstico.** Concretamente, que la copia escriba tres marcas en `%TEMP%\latencia_f0\huellas.txt`: (1) inmediatamente en la línea 7, (2) al final de la sección de auto-ejecución, (3) dentro de `_LatBase` al entrar. Con eso sabemos en qué punto se atasca. Cambios sugeridos a probar en la misma versión: timer **repetente** `SetTimer(_LatBase, 1000)` con guard `static hecho := false`, subir el desfase a 8.000 ms, y medir en un hilo propio en vez de confiar en el idle del auto-exec. Mantén el watchdog de 45 s y el cierre **por PID del árbol**, nunca por nombre.

---

## 6. TU TAREA (en este orden; entrega lo que puedas y di qué no)

**T0 — Resumen de reencuadre (máximo 15 líneas).** Qué cambió respecto a tu plan, qué decisiones tuyas quedan anuladas por los datos del §3, y qué assumption tuya fue la que generó el hash inventado. Sin esto, el siguiente chat repetirá la entrega.

**T1 — Reparar el paquete.** `spike_latencia.ahk` con D-1 y D-2 corregidos + el diagnóstico de huellas del §5. `PLAN-V2.md` con la línea 25 corregida. `README-SPIKE.md` documentando `--capturas` y `--pos`. `CHANGELOG-F0.md` con la entrada de hoy. Todo en **bloques parcheables**, nunca el archivo entero.

**T2 — Firmar o reabrir V0.** Con el §3: reescribe I12/D1 (ahora con objeto) y **redecide D2** (`_LimpiarAvisos` no existe: o creamos la función en F3, o aceptamos que limpiar avisos destruya el HUD). Dilo como decisión tomada con su motivo, no como nota.

**T3 — Siguiente fase.** Prepara **F1** para que sea aplicable: el bloque `_Tema()` completo (lectura de `theme.ini` con validación `^[0-9A-Fa-f]{6}$` y caída al defecto, regla R1), la integración de `roles_legacy.ahk` (Anexo B) y la detección de fuentes. **Cero cambio visual**, y sin tocar ninguno de los 120 call sites. Entrega: (a) el bloque nuevo, (b) el punto de inserción anclado por nombre de función, (c) `/validate` esperado, (d) cómo verificar que el hash de producción no cambió.
Si F1 depende de D4 (creo que no: F1 es solo tema/tokens), dilo y la sacamos del camino.

**T4 — La pregunta que no puedes resolver tú.** Qué árbol es la fuente de verdad: el canónico de 3.917 en Documents con `_EstabEmitir(tecla,n,pausa := 8)`, o el `XPPEN AHK VERSION ESTABLE.ahk` de 3.958 en Desktop con `ESTAB_RACHA/RITMO` — que es el que Josue ejecuta al dibujar. Dame las dos opciones con su consecuencia práctica (qué anclas se recorren y cuánto), no una recomendación genérica.

**Formato de salida:** un solo `.md`, con los parches en bloques de código etiquetados con `ANCHOR: <nombre de funcion>` y la acción (`INSERT-BEFORE` / `INSERT-AFTER` / `REPLACE-RANGE`). Nada de "adjunto el archivo". Nada de capturas: los PNG se traen en ronda aparte si los pides.

---

## 7. Reglas no negociables (destiladas de CONTEXTO + PLAN-V2 rev 2.1)

**Invariantes:** I1 zero-rewrite, solo anclas únicas · I2 `.bak-olaN-<fecha>` antes de editar, nunca sobrescribir un `.bak` · I3 `/validate` exit 0 siempre · I4 prueba de carga (exit 0, stderr 0 bytes) · **I5 prohibido tocar**: detección de HWND de CSP, zonas de hover, `LoopColorV`/`LoopColorCC`/`ChequearZona*`, `+0x20`/`+E0x08000000`, click-through, `BlockInput`, `_EstabEmitir` y sus constantes de timing · I6 no tocar `#HotIf` ni reordenar hotkeys · I7 presupuesto 3.850-4.050 líneas · I8 no arreglar bugs colaterales (se anotan) · I9 si un cambio estético obliga a tocar I5, el cambio está mal planteado · I10 `posiciones_gui.ini` es UTF-16 y no se escribe · I11 **la elevación de las líneas 3-6 es intencional** (driver XP-Pen + cambio de perfil CSP↔apps); se anula solo en la copia desechable; `#SingleInstance Force` no se quita · I13 función estética nueva ≤ ~2 ms en ruta caliente vs `latencia_base.txt` · I14 se conservan las firmas `IniciarXGUI/ActualizarXGUI/_XGUI_WM_LBUTTONDOWN` y el campo `.g` · I15 el rectángulo exterior de una pill **no cambia de tamaño** (depende de `posiciones_gui.ini`).

**Reglas de método:** R1 `theme.ini` sin comentario en la misma línea que un valor ni texto tras `]` · R2 prohibido ` ;` (espacio+punto y coma) dentro de literales en AHK v2.0.26 · R3 D4 se firma **por captura**, un HR `0x00000000` no prueba nada (DWM devuelve OK y relee "redondeado" sobre una ventana layered con esquinas rectas) · R4 en layered: `BackColor` antes de `Show`, `WinSetTransparent` después · R5 anclas por nombre de función, nunca líneas.

**Entorno real (no lo supongas distinto):** AHK 2.0.26, `C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe`, Windows 10.0.26200, 2 monitores, DPI 96 (factor 1.00), sin elevar en pruebas. Fuentes instaladas y confirmadas por el log: Segoe Fluent Icons, Segoe MDL2 Assets, Segoe UI Variable, Segoe UI Semibold, Cascadia Mono. `/validate` desde Git Bash requiere `MSYS_NO_PATHCONV=1` o el flag `/validate` se convierte en ruta y AHK abre un modal que cuelga la terminal.

---

## Anexos

Todo lo que sigue está copiado literalmente del equipo de Josue, sin editar.

### Anexo A — `theme.ini` (estado actual, raiz del proyecto)
```ini
; theme.ini — tokens de diseño (refactor estético)
; Formato: RRGGBB sin '#'. Valores = captura 1:1 de lo que ya pinta el script.
; La afinación de paleta ocurre en la ola 2, con prueba visual.
; Si este archivo falta, el script usa los valores por defecto del código.

[color]
surface.base     = 12141A
surface.raised   = 1B1E26
surface.overlay  = 20242E
surface.off      = 424242
surface.on       = 636D83
text.primary     = FFFFFF
text.idle        = B2B2B2
text.muted       = 8E97A8
text.disabled    = 5A6273
accent.info      = 00E5FF
accent.success   = 44DD88
accent.warn      = FF6B00
accent.danger    = FF4444
accent.estab     = 9A7BFF
accent.estabSoft = B4C0DE
track.off        = 3A3A45
track.pillOff    = 6A6A6A

[alpha]
pill  = 235
badge = 230
hud   = 215
mini  = 200
icono = 185

[radius]
sm = 6
md = 10
lg = 14

[type]
family       = Segoe UI
family.value = Cascadia Mono
size.caption = 9
size.body    = 11
size.value   = 13

[motion]
fast = 120
base = 180
slow = 240
easing = out-cubic

[fx]
; 0 = region (actual) | 1 = DWM corner | 2 = DWM corner + backdrop
; Decidido en la ola 0.
corners  = 0
backdrop = 0
```

### Anexo B — `roles_legacy.ahk` (bloque F1, sin editar)
```ahk
; roles_legacy.ahk - FASE 1 (se pega como BLOQUE NUEVO, sin editar call sites)
; Mapa hex legado -> rol. SOLO para colores pasados a Mostrar* / ToolTipE / ToolTipCS.
; No aplica a BorderFrame, marcos de enfoque, overlays de calibracion (no son avisos).
; Un hex que no este aqui devuelve "" y el llamador conserva el hex original.
ROL_LEGADO := Map(
    "00E5FF","info", "1C6EA4","info", "1A5276","info", "1A2E5C","info",
    "44DD88","ok", "1E8449","ok", "27AE60","ok", "51D67B","ok",
    "1A5C2A","ok", "32CD32","ok", "2ECC71","ok", "FF6B00","warn",
    "FF8C42","warn", "AA8844","warn", "FFAA33","warn", "FF6F61","warn",
    "FF4444","danger", "C0392B","danger", "E74C3C","danger", "922B21","danger",
    "9A7BFF","estab", "AA44FF","estab", "6C3483","estab", "1A1A2E","neutral",
    "888888","neutral", "555555","neutral", "9AA7C7","neutral", "2B3B32","neutral",
    "222222","neutral", "EEEEEE","neutral", "424949","neutral"
)
_RolDeHex(hex) => ROL_LEGADO.Has(StrUpper(hex)) ? ROL_LEGADO[StrUpper(hex)] : ""
; MostrarTooltipToggle usa "verde"/"rojo" (no hex): verde -> ok, rojo -> danger
```

### Anexo C — canonico, lineas 1501-1778: `_LimpiarGUIs` y las 6 funciones de aviso
Este es el unico codigo de produccion que necesitas para F1 y para la decision D2.
```ahk
_DestruirGui(guiObj) {
    if !IsObject(guiObj)
        return
    try guiObj.Destroy()
}
_LimpiarGUIs() {
    _DestruirGui(floatGui.hud)
    floatGui.hud := 0
    floatGui.hudHwnd := 0
    floatGui.hudLabel := 0
    floatGui.hudBar := 0
    _DestruirGui(floatGui.miniTip)
    floatGui.miniTip := 0
    floatGui.miniTipID := 0
    floatGui.miniTipTick := 0
    _DestruirGui(floatGui.tooltipToggle)
    floatGui.tooltipToggle := 0
    _DestruirGui(floatGui.miniGUI)
    floatGui.miniGUI := 0
    _DestruirGui(floatGui.enfoque)
    floatGui.enfoque := 0
    enfoque.activo := false
    OcultarGUIEnfoque()
    _DestruirGui(floatGui.overlayIcon)
    floatGui.overlayIcon := 0
    floatGui.overlayIconID := 0
}
MostrarBadgeCombo(comboText,toolText,colorAcento := "00E5FF",duracion := 2200) {
    global AVISO_ESC
    if IsObject(floatGui.miniTip)
        _DestruirGui(floatGui.miniTip)
    if IsObject(floatGui.miniGUI)
        _DestruirGui(floatGui.miniGUI)
    if IsObject(floatGui.tooltipToggle)
        _DestruirGui(floatGui.tooltipToggle)
    if IsObject(floatGui.hud)
        floatGui.hud.Hide()
    thisID := A_TickCount
    floatGui.badgeID := thisID
    x := -2247
    y := 30
    w := Round(240 * AVISO_ESC)
    h := Round(62 * AVISO_ESC)
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := "12141A"
    g.MarginX := 0
    g.MarginY := 0
    WinSetTransparent(230,g)
    bLeft := g.Add("Progress","x0 y0 w" Round(5 * AVISO_ESC) " h" h)
    bLeft.Opt("c" colorAcento)
    bLeft.Value := 100
    lblSub := g.Add("Text","x" Round(12 * AVISO_ESC) " y" Round(6 * AVISO_ESC) " w" (w - Round(16 * AVISO_ESC)) " c8E9AA0",comboText)
    lblSub.SetFont("s" Max(6,Round(9 * AVISO_ESC)) " bold","Segoe UI")
    lblMain := g.Add("Text","x" Round(12 * AVISO_ESC) " y" Round(24 * AVISO_ESC) " w" (w - Round(16 * AVISO_ESC)) " cWhite",toolText)
    lblMain.SetFont("s" Max(7,Round(13 * AVISO_ESC)) " bold","Segoe UI")
    bSub := g.Add("Progress","x0 y" Round(58 * AVISO_ESC) " w" w " h" Round(4 * AVISO_ESC))
    bSub.Opt("c" colorAcento)
    bSub.Value := 100
    g.Show("w" w " h" h " NoActivate Hide")
    floatGui.badge := g
    floatGui.badgeHwnd := g.Hwnd
    floatGui.badgeSub := lblSub
    floatGui.badgeMain := lblMain
    floatGui.badgeSubBar := bLeft
    floatGui.badgeBar := bSub
    DllCall("SetWindowPos","Ptr",floatGui.badgeHwnd,"Ptr",-1,"int",x,"int",y,"int",0,"int",0,"uint",0x0040 | 0x0010 | 0x0001)
    floatGui.badge.Show("NoActivate")
    SetTimer(() => _OcultarBadgeSi(thisID),-duracion)
}
_OcultarBadgeSi(targetID) {
    if (IsObject(floatGui.badge) && floatGui.badgeID = targetID)
        floatGui.badge.Hide()
}
MostrarHUD(texto,colorBarra := "00E5FF",duracion := 1200) {
    global AVISO_ESC
    if IsObject(floatGui.miniTip)
        _DestruirGui(floatGui.miniTip)
    if IsObject(floatGui.miniGUI)
        _DestruirGui(floatGui.miniGUI)
    if IsObject(floatGui.tooltipToggle)
        _DestruirGui(floatGui.tooltipToggle)
    x := -2247
    y := 30
    w := Round(208 * AVISO_ESC)
    h := Round(40 * AVISO_ESC)
    if (!IsObject(floatGui.hud) || !floatGui.hudHwnd || !DllCall("IsWindow","Ptr",floatGui.hudHwnd)) {
        g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
        g.BackColor := "1a1a1a"
        g.MarginX := 0
        g.MarginY := 0
        WinSetTransparent(215,g)
        lbl := g.Add("Text","x0 y" Round(7 * AVISO_ESC) " w" w " h" Round(26 * AVISO_ESC) " cWhite +0x200 Center",texto)
        lbl.SetFont("s" Max(6,Round(12 * AVISO_ESC)) " bold","Segoe UI")
        bar := g.Add("Progress","x0 y" Round(35 * AVISO_ESC) " w" w " h" Round(5 * AVISO_ESC))
        bar.Opt("c" colorBarra)
        bar.Value := 100
        g.Show("w" w " h" h " NoActivate Hide")
        floatGui.hud := g
        floatGui.hudLabel := lbl
        floatGui.hudBar := bar
        floatGui.hudHwnd := g.Hwnd
    } else {
        floatGui.hudLabel.Value := texto
        floatGui.hudBar.Opt("c" colorBarra)
        floatGui.hudBar.Value := 100
    }
    DllCall("SetWindowPos","Ptr",floatGui.hudHwnd,"Ptr",-1,"int",x,"int",y,"int",0,"int",0,"uint",0x0040 | 0x0010 | 0x0001)
    hwnd := floatGui.hudHwnd
    SetTimer(() => _OcultarHUDSi(hwnd),-duracion)
}
_OcultarHUDSi(hwnd) {
    if (IsObject(floatGui.hud) && floatGui.hudHwnd = hwnd)
        floatGui.hud.Hide()
}
QuitarToolTip() => ToolTip()
OcultarToolTip() => ToolTip()
OcultarToolTipAltG() => ToolTip()
OcultarToolTipQ() => ToolTip()
OcultarIndicador() => ToolTip()
QuitarToolTipE() => ToolTip()
QuitarToolTipZ() => ToolTip()
MostrarIndicador(texto) {
    ToolTip(texto)
    SetTimer(OcultarIndicador,-2500)
}
MostrarToolTipE(texto,duracion := 2190) => MostrarHUD(texto,"FF4444",duracion)
MostrarIconoHerramienta(tipo,duracion := 700) {
    global AVISO_ESC
    if IsObject(floatGui.overlayIcon)
        _DestruirGui(floatGui.overlayIcon)
    thisID := A_TickCount
    floatGui.overlayIconID := thisID
    lado := Round(110 * AVISO_ESC)
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := "181818"
    g.MarginX := 0
    g.MarginY := 0
    iconoChar := (tipo = "zoom") ? "🔍" : (tipo = "rotar") ? "↻" : "⚙"
    fSize := (tipo = "rotar") ? Round(56 * AVISO_ESC) : Round(50 * AVISO_ESC)
    txt := g.Add("Text","x0 y0 w" lado " h" lado " Center +0x0200 cWhite",iconoChar)
    txt.SetFont("s" fSize " bold","Segoe UI Symbol")
    g.Show("w" lado " h" lado " NoActivate Hide")
    DllCall("SetWindowPos","Ptr",g.Hwnd,"Ptr",-1,"int",PUNTOS[30][1],"int",PUNTOS[30][2],"int",0,"int",0,"uint",0x0040 | 0x0010 | 0x0001)
    try {
        rad := Round(50 * AVISO_ESC)
        rgn := DllCall("Gdi32\CreateRoundRectRgn","int",0,"int",0,"int",lado + 1,"int",lado + 1,"int",rad,"int",rad,"Ptr")
        DllCall("SetWindowRgn","Ptr",g.Hwnd,"Ptr",rgn,"int",1)
    }
    WinSetTransparent(185,"ahk_id " g.Hwnd)
    floatGui.overlayIcon := g
    SetTimer(() => _OcultarIconoSi(thisID),-duracion)
}
_OcultarIconoSi(id) {
    if (floatGui.overlayIconID != id)
        return
    try {
        if IsObject(floatGui.overlayIcon)
            floatGui.overlayIcon.Destroy()
    }
    floatGui.overlayIcon := 0
    floatGui.overlayIconID := 0
}
MostrarToolTipZ(texto,duracion := 800) {
    if InStr(texto,"Z")
        MostrarIconoHerramienta("zoom",duracion)
    else if InStr(texto,"R")
        MostrarIconoHerramienta("rotar",duracion)
    else
        MostrarHUD(texto,"00E5FF",duracion)
}
ToolTipCS(texto,duracion := 800) => MostrarHUD(texto,texto = "🟢 REHACER" ? "44DD88" : "FF4444",duracion)
_AvisoPosicionar(hwnd) {
    DllCall("SetWindowPos","Ptr",hwnd,"Ptr",-1,"int",PUNTOS[30][1],"int",PUNTOS[30][2],"int",0,"int",0,"uint",0x0040 | 0x0010 | 0x0001)
}
MostrarMiniTexto(texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF") {
    _LimpiarGUIs()
    thisID := A_TickCount
    floatGui.miniTipID := thisID
    floatGui.miniTipTick := thisID
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := colorHex
    g.SetFont("s" Max(6,Round(12 * AVISO_ESC)) " Bold","Segoe UI")
    g.AddText("c" colorTexto " Center w" Round(260 * AVISO_ESC),texto)
    g.Show("Hide AutoSize NoActivate")
    _AvisoPosicionar(g.Hwnd)
    WinSetTransparent(200,"ahk_id " g.Hwnd)
    floatGui.miniTip := g
    SetTimer(() => _OcultarMiniTipSi(thisID),-duracion)
}
_OcultarMiniTipSi(id) {
    if (floatGui.miniTipID != id)
        return
    try {
        if IsObject(floatGui.miniTip)
            floatGui.miniTip.Destroy()
    }
    floatGui.miniTip := 0
    floatGui.miniTipID := 0
    floatGui.miniTipTick := 0
}
MostrarMiniTextoOscuro(texto,colorHex := "EEEEEE",duracion := 800) => MostrarMiniTexto(texto,colorHex,duracion,"000000")
MostrarMiniGUI(texto,colorHex := "222222",duracion := 1200) {
    if IsObject(floatGui.miniGUI)
        try floatGui.miniGUI.Destroy()
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := colorHex
    g.SetFont("s" Max(6,Round(12 * AVISO_ESC)) " Bold","Segoe UI")
    g.AddText("cFFFFFF Center w" Round(260 * AVISO_ESC),texto)
    g.Show("Hide AutoSize NoActivate")
    _AvisoPosicionar(g.Hwnd)
    WinSetTransparent(200,"ahk_id " g.Hwnd)
    floatGui.miniGUI := g
    hwndMG := g.Hwnd
    SetTimer(() => _OcultarMiniGUISi(hwndMG),-duracion)
}
_OcultarMiniGUISi(hwndMG) {
    if (IsObject(floatGui.miniGUI) && floatGui.miniGUI.Hwnd = hwndMG) {
        floatGui.miniGUI.Destroy()
        floatGui.miniGUI := 0
    }
}
MostrarTooltipToggle(titulo,simbolo,color) {
    _LimpiarGUIs()
    g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20")
    fs := Max(6,Round(12 * AVISO_ESC))
    if (color = "verde") {
        g.BackColor := "1F4D3A"
        g.SetFont("s" fs " Bold cWhite","Segoe UI")
        simColor := "Lime"
    } else {
        g.BackColor := "D92B2B"
        g.SetFont("s" fs " Bold cWhite","Segoe UI")
        simColor := "White"
    }
    k := AVISO_ESC
    g.AddText("x" Round(8*k) " y" Round(5*k) " w" Round(221*k) " h" Round(23*k) " Center",titulo)
    g.SetFont("s" fs " Bold c" simColor,"Segoe UI")
    g.AddText("x" Round(232*k) " y" Round(4*k) " w" Round(23*k) " h" Round(23*k) " Center",simbolo)
    g.Show("w" Round(260*k) " h" Round(34*k) " NoActivate Hide")
    _AvisoPosicionar(g.Hwnd)
    floatGui.tooltipToggle := g
    hwndT := g.Hwnd
    SetTimer(() => _OcultarToggleSi(hwndT),-1500)
}
_OcultarToggleSi(hwndT) {
    if (IsObject(floatGui.tooltipToggle) && floatGui.tooltipToggle.Hwnd = hwndT) {
        floatGui.tooltipToggle.Destroy()
        floatGui.tooltipToggle := 0
    }
}
QuitarTooltipToggle() {
    if IsObject(floatGui.tooltipToggle)
        try floatGui.tooltipToggle.Destroy()
    floatGui.tooltipToggle := 0
}
AccionEnfoque() {
    enfoque.activo := !enfoque.activo
    MouseGetPos(&origX,&origY)
    Click(PUNTOS[1][1] " " PUNTOS[1][2])
    Click(PUNTOS[2][1] " " PUNTOS[2][2])
    DllCall("SetCursorPos","int",origX,"int",origY)
    _AplicarLayoutPaneles(enfoque.activo ? "Enfoque" : "Normal")
    _NotificarPureRef(enfoque.activo ? 1 : 0)
    if (enfoque.activo) {
        _EstabFocoOcultar()
        if (estabGui.visible && IsObject(estabGui.g))
            try estabGui.g.Show("NoActivate")
        MostrarGUIEnfoque()
        MostrarHUD("🎯 MODO ENFOQUE","00E5FF",900)
        SetTimer(() => SoundPlay(A_WinDir "\Media\Windows Feed Discovered.wav"),-1)
    } else {
        OcultarGUIEnfoque()
        _EstabFocoOcultar()
        if IsObject(estabGui.g)
            try estabGui.g.Hide()
        SetTimer(() => SoundPlay(A_WinDir "\Media\Windows Pop-up Blocked.wav"),-1)
    }
}
```

### Anexo D — `anclas_canonico.txt` (medido por el spike parcheado sobre el canónico)
```text
Lineas: 3917

_FadeAlpha                    def=  539  usos=   7  (hwnd,hasta,pasos := 6,delayMs := 10)
_LimpiarAvisos                def=    0  usos=   0  ()
_LimpiarGUIs                  def= 1506  usos=   4  ()
MostrarHUD                    def= 1574  usos=  70  (texto,colorBarra := "00E5FF",duracion := 1200)
MostrarMiniTexto              def= 1675  usos=  33  (texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")
MostrarBadgeCombo             def= 1528  usos=   5  (comboText,toolText,colorAcento := "00E5FF",duracion := 2200)
MostrarTooltipToggle          def= 1722  usos=   5  (titulo,simbolo,color)
MostrarIconoHerramienta       def= 1627  usos=   3  (tipo,duracion := 700)
MostrarMiniGUI                def= 1702  usos=   1  (texto,colorHex := "222222",duracion := 1200)
_OcultarHUDSi                 def= 1611  usos=   2  (hwnd)
Sanar                         def=    0  usos=   0  ()
IniciarDsGUI                  def= 2205  usos=   3  ()
IniciarCcGUI                  def= 2239  usos=   3  ()
IniciarArGUI                  def= 2286  usos=   3  ()
IniciarHCGUI                  def= 2333  usos=   3  ()
IniciarLockGUI                def= 2380  usos=   3  ()
IniciarFrenteGUI              def= 2427  usos=   3  ()
IniciarEstabBtnGUI            def= 2482  usos=   3  ()
IniciarEstabGUI               def= 2544  usos=   3  ()
ActualizarEstabGUI            def= 2698  usos=  10  (v := -1,forzar := false)
_EstabCalcular                def= 2635  usos=   3  (w,h)
_EstabLayout                  def= 2661  usos=   6  (w,h)
_EstabKnobRegion              def= 2680  usos=   2  ()
_EstabRegion                  def= 2689  usos=   6  (w,h)
_EstabEmitir                  def= 2865  usos=   5  (tecla,n,pausa := 8)
_EstabEnviarDelta             def= 2877  usos=   5  (nuevo)
IniciarReloadGUI              def= 3139  usos=   2  ()
IniciarPuntosGUI              def= 3334  usos=   2  ()
_SetIcono                     def= 3868  usos=  17  (ctrl,nombre)
_RutaIcono                    def= 3874  usos=   2  (nombre)
_IconosB64                    def= 3911  usos=   3  ()
_PosGuiIniPath                def= 2019  usos=  31  ()
_AnclaBloquePaneles           def= 2046  usos=   8  ()
AbrirPanelPuntos              def= 3398  usos=   3  ()
_ArrastrarPanelBloque         def= 2067  usos=   8  (hwndClick,lParam,guiObj)
MostrarGUIEnfoque             def= 1883  usos=   2  ()
IniciarDialGUI                def= 2188  usos=   2  ()

Marcas de hallazgos del PLAN (primera linea | apariciones)
-2247 (ancla fija de avisos)        linea= 1540  n=  2
PUNTOS[30]                          linea= 1643  n=  2
ancho HUD fijo 208*AVISO_ESC        linea= 1584  n=  1

Lectura: _FadeAlpha usos=0 -> I12 sin objeto. _LimpiarAvisos def>0 -> D2 cerrada.
```

### Anexo E — corrida del spike (`latencia_base.txt`) y redibujos del modo oculto
```text
Archivo: C:\Users\jbard\Documents\AntiGravity\Autohotkeys\XxxPPEN_a16pg2_displayAS_secondary.ahk
SHA-256: CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E
Lineas: 3917 (esperadas 3917)
Coincide con el canonico: SI

Anclas escritas en anclas_canonico.txt
MostrarHUD(texto,colorBarra := "00E5FF",duracion := 1200)  ->  MostrarHUD("LAT", "00E5FF", 60)
MostrarMiniTexto(texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")  ->  MostrarMiniTexto("LAT", "00E5FF", 60, "LAT")
ActualizarEstabGUI(v := -1,forzar := false)  ->  ActualizarEstabGUI()
Copia desechable: C:\Users\jbard\AppData\Local\Temp\latencia_f0\prueba_latencia.ahk
/validate de la copia: exit 0

Ejecutando la copia (N=20)...
WATCHDOG: la copia excedio 45 s y se cerro (solo su arbol de procesos).
La copia no escribio salida. Revisa C:\Users\jbard\AppData\Local\Temp\latencia_f0\stderr_latencia.txt

Produccion intacta: SI (hash igual antes y despues)
```
Del log de `galeria.ahk --oculto` (9.844 B, completo en el PC de Josue):
```text
; ﻿=== GALERIA F0 v2 | 2026-11-04 21:14:47 | modo OCULTO ===
; REGLA: HR 0x00000000 no prueba nada. D4 se firma por CAPTURA, no por este log.
; Windows 10.0.26200 (build 26200) | Win11=si | backdrop posible=si
; DPI sistema 96 (factor 1.00) | monitores 2 | AHK 2.0.26 | admin=no
; GDI+ ok
; Tema: theme.ini NO encontrado, se usan defectos
; Texto primario en uso: FFFFFF (theme.ini dice FFFFFF)
; Fuente Segoe Fluent Icons: instalada
; Fuente Segoe MDL2 Assets: instalada
; Fuente Segoe UI Variable: instalada
; Fuente Segoe UI Semibold: instalada
; Fuente Cascadia Mono: instalada
A pill redibujo (OFF): 194.19 ms
A pill redibujo (ON): 78.64 ms
A pill redibujo (ON): 44.27 ms
A pill redibujo (OFF): 58.73 ms
B pill redibujo (OFF): 52.38 ms
B pill redibujo (ON): 52.51 ms
B pill redibujo (ON): 113.39 ms
B pill redibujo (OFF): 61.78 ms
C pill redibujo (OFF): 44.16 ms
C pill redibujo (ON): 46.43 ms
C pill redibujo (ON): 46.76 ms
C pill redibujo (OFF): 102.19 ms
D pill redibujo (OFF): 84.72 ms
D pill redibujo (ON): 64.84 ms
D pill redibujo (ON): 77.53 ms
D pill redibujo (OFF): 56.81 ms
E pill redibujo (OFF): 6.04 ms
E pill redibujo (ON): 5.29 ms
E pill redibujo (ON): 6.70 ms
E pill redibujo (OFF): 6.22 ms
A keys redibujo (OFF): 8.89 ms
A keys redibujo (ON): 95.46 ms
A slider redibujo (val 20): 45.13 ms
A slider redibujo (val 80): 39.88 ms
E keys redibujo (OFF): 9.84 ms
E keys redibujo (ON): 8.62 ms
E slider redibujo (val 20): 16.31 ms
E slider redibujo (val 80): 13.29 ms
A pill redibujo (OFF): 109.30 ms
A pill redibujo (ON): 79.32 ms
A pill redibujo (ON): 180.72 ms
A pill redibujo (OFF): 64.14 ms
B pill redibujo (OFF): 46.29 ms
B pill redibujo (ON): 62.09 ms
B pill redibujo (ON): 80.90 ms
B pill redibujo (OFF): 49.52 ms
C pill redibujo (OFF): 63.08 ms
C pill redibujo (ON): 100.18 ms
C pill redibujo (ON): 64.39 ms
C pill redibujo (OFF): 99.87 ms
D pill redibujo (OFF): 95.23 ms
D pill redibujo (ON): 70.80 ms
D pill redibujo (ON): 32.19 ms
D pill redibujo (OFF): 67.64 ms
E pill redibujo (OFF): 4.64 ms
E pill redibujo (ON): 4.50 ms
E pill redibujo (ON): 6.49 ms
E pill redibujo (OFF): 6.36 ms
A keys redibujo (OFF): 5.47 ms
A keys redibujo (ON): 52.53 ms
A slider redibujo (val 20): 21.01 ms
A slider redibujo (val 80): 18.60 ms
E keys redibujo (OFF): 6.04 ms
E keys redibujo (ON): 6.36 ms
E slider redibujo (val 20): 5.92 ms
E slider redibujo (val 80): 7.26 ms
A pill redibujo (OFF): 51.07 ms
A pill redibujo (ON): 77.11 ms
A pill redibujo (ON): 64.40 ms
A pill redibujo (OFF): 256.25 ms
B pill redibujo (OFF): 64.30 ms
B pill redibujo (ON): 258.44 ms
B pill redibujo (ON): 115.25 ms
B pill redibujo (OFF): 44.76 ms
C pill redibujo (OFF): 46.43 ms
C pill redibujo (ON): 11.65 ms
C pill redibujo (ON): 131.17 ms
C pill redibujo (OFF): 42.55 ms
D pill redibujo (OFF): 34.59 ms
D pill redibujo (ON): 47.54 ms
D pill redibujo (ON): 73.73 ms
D pill redibujo (OFF): 76.72 ms
E pill redibujo (OFF): 14.22 ms
E pill redibujo (ON): 30.52 ms
E pill redibujo (ON): 8.11 ms
E pill redibujo (OFF): 19.97 ms
A keys redibujo (OFF): 120.23 ms
A keys redibujo (ON): 3.57 ms
A slider redibujo (val 20): 75.03 ms
A slider redibujo (val 80): 14.84 ms
E keys redibujo (OFF): 7.36 ms
E keys redibujo (ON): 5.36 ms
E slider redibujo (val 20): 7.89 ms
E slider redibujo (val 80): 7.87 ms
; E slider redibujo (val 80): 7.87 ms
; === FIN modo oculto | errores: 0 ===
```

### Anexo F — canonico, lineas 1-14 (bloque de elevacion, I11)
```ahk
#Requires AutoHotkey v2.0
#SingleInstance Force
if !A_IsAdmin {
    try Run('*RunAs "' A_ScriptFullPath '"')
    ExitApp()
}
try TraySetIcon("C:\Users\jbard\Documents\@Otros\icons\clipstudio.ico")
DllCall("SetThreadDpiAwarenessContext","ptr",-3,"ptr")
SendMode("Input")
KEY_NTILDE := "{vkC0sc027}"
KEY_MENOR := "{vkE2sc056}"
EnviarNtilde() => SendInput(KEY_NTILDE)
EnviarMenor() => SendInput(KEY_MENOR)
SetWorkingDir(A_ScriptDir)
```

---
*Fin del paquete. Anexos generados por script, no transcritos a mano.*
