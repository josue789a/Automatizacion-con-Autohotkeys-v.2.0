# PAQUETE PARA CLAUDE — F0 v2 (todo el contenido inline; no tiene acceso al PC de Josue)

Adjunto binario aparte: artifacts/captura_100_Oscuro_m2_212124.png (unica captura que salio; evidencia del defecto de _Captura).

---

# INFORME QODER — F0 v2 (validaciones y spikes, entorno real AHK 2.0.26)

Fecha: 2026-11-04. Equipo: Windows 10.0.26200, AHK v2.0.26, 2 monitores, DPI 96.
Producción **intacta** en todo momento: `Documents\AntiGravity\Autohotkeys\XxxPPEN_a16pg2_displayAS_secondary.ahk`
SHA-256 `CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E`, 3.917 líneas (verificado antes y después de cada corrida).
Nada se ejecutó elevado. Ninguna prueba registró hotkeys globales; no hubo instancias duplicadas del script vivo.

## 1. Resultado por paso del HANDOFF-F0

| Paso | Pedido | Resultado |
|---|---|---|
| 1 | `/validate` de los dos scripts | galeria.ahk **exit 0**; spike_latencia.ahk **fallaba exit 2** → bug real (ver §2), tras el parche **exit 0** |
| 2 | `galeria.ahk --oculto` | **exit 0, errores: 0**. Log completo en `artifacts/spike_resultados_oculto.txt` |
| 3 | `spike_latencia.ahk` seco | **OK** con `--prod=` explícito: hash coincide, 3.917/3.917, copia validada exit 0. `artifacts/anclas_canonico.txt` |
| 4 | `spike_latencia.ahk --ejecutar` | **FALLA** (ver §4) |
| 5 | Sesión visual con capturas | **Parcial**: 1 PNG generado; el método de captura no es válido como evidencia (ver §5) |
| 6 | `pruebas.ps1 -Modo parse` / `-Modo esteril` | **PASS** en ambos (esteril: copia en 7,29 s, stderr vacío, 0 huérfanos, archivo real intacto) |

## 2. Dos bugs reales en el paquete (parches en `diffs/`)

**a) `spike_latencia.ahk:52` — colisión `REP` / `Rep`.** AHK v2 no distingue mayúsculas en identificadores: el global `REP := ""` choca con la función `Rep(t)` y el script **no carga**.
Error exacto del runtime: `(52) : ==> This Func cannot be used as an output variable. Specifically: Rep`.
Fix aplicado: renombrar el acumulador a `REPTXT` (líneas 52, 184, 185, 191). Ninguna otra línea tocada.
Nota: esto no lo detecta un chequeo estático de llaves/paréntesis — hace falta el `/validate` real.

**b) El hash de la fuente de verdad está corrupto.** `HASH_ESPERADO` en el script (y `PLAN-V2.md:25`, `HANDOFF-F0.md:7`) dice
`CEF745C7685DED9C9BC437FE20CEFFB3688126743A9024D9DE964092EBEA983E`; el digest real del archivo canónico es
`CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E`.
Solo coinciden los 8 primeros hex: el resto se parece al hash de otro archivo. Con el literal actual el paso 1 **siempre** aborta con exit 2 y no genera `anclas_canonico.txt`. Fix aplicado en el script; **falta corregirlo en PLAN-V2.md y HANDOFF-F0.md**.

## 3. Regla V0 — datos para cerrar D1/D2/D3 (medidos sobre el canónico real)

```
_FadeAlpha          def= 539  usos=  7   (hwnd,hasta,pasos := 6,delayMs := 10)
_LimpiarAvisos      def=   0  usos=  0
_LimpiarGUIs        def=1506  usos=  4
MostrarHUD          def=1574  usos= 70   (texto,colorBarra := "00E5FF",duracion := 1200)
MostrarMiniTexto    def=1675  usos= 33   (texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")
ActualizarEstabGUI  def=2698  usos= 10   (v := -1,forzar := false)
_EstabEmitir        def=2865  usos=  5
-2247               linea=1540  n=2      208 * AVISO_ESC  linea=1584  n=1      PUNTOS[30]  linea=1643  n=2
```

Consecuencias para el plan:
- **I12 SÍ tiene objeto**: `_FadeAlpha` existe en la línea 539 con 7 usos. Tu CONTEXTO.md §2 era correcto para el archivo de 3.917.
- **D2 NO está cerrada**: `_LimpiarAvisos` no existe en el canónico (def=0, usos=0). La leyenda que imprime `anclas_canonico.txt` ("_LimpiarAvisos def>0 -> D2 cerrada") contradice el propio dato: hay que corregir la leyenda.
- **Sanar** también sale def=0/usos=0; conviene decir sobre qué invariante estaba abierto.
- El hash de `ArmarLlamada` para `MostrarMiniTexto` genera `("LAT", "00E5FF", 60, "LAT")`: el 4º parámetro se llama `colorTexto` y la rama `txt|texto` gana antes que la de color → llega `"LAT"` como color. Al medir, eso se contará como error en la columna *errores*. Sugerencia: evaluar la rama de color antes que la de texto.

## 4. Paso 4 (`--ejecutar`): la copia arranca pero nunca llega a medir

Tres corridas, mismo resultado:
- `/validate` de la copia: exit 0.
- La copia **sí se ejecuta** (escribe `%TEMP%\latencia_f0\posiciones_gui.ini`, 112 bytes).
- **No aparece `salida_latencia.txt`**, `stderr_latencia.txt` **vacío**, y el watchdog de 45 s cierra el árbol por PID. Producción intacta después.
- Con un latido que añadí para diagnosticar (`diffs/spike_latencia.diff`, marcado *diagnóstico Qoder*), el heartbeat no se escribe ni en la primera línea del autoexec inyectado.

Hipótesis ordenadas por evidencia: (1) el timer one-shot `-2500` nunca se dispara porque el autoexec de producción no llega a terminar — hay 9 `SetTimer` y 10 `IniciarXxxGUI()` entre las líneas 88 y 99, y el bloque de detección recorre ventanas de CSP; (2) en dos corridas el propio spike se quedó **bloqueado antes del paso 3** con 1,5 s de CPU acumulada tras 4 minutos, o sea esperando un `RunWait` (el `certutil` de `Hash()` es el candidato) o un diálogo modal heredado de la corrida anterior.

Sugerencia para Claude (no la apliqué en producción, solo la dejo propuesta): disparar la medición **en línea al final del autoexec de la copia** (insertar la llamada justo antes del primer hotkey, línea 138) en lugar de por timer, y sustituir `certutil` por `FileOpen` + `DllCall(advapi…)` o `Get-FileHash`. Con eso el paso 4 deja de depender de que el script quede ocioso.

## 5. Paso 5: el botón *Captura PNG* no produce evidencia válida para D4

`_Captura()` hace `BitBlt` desde el **DC de pantalla** en el rectángulo del stage. Dos problemas, ambos visibles en `artifacts/captura_100_Oscuro_m2_212124.png`:
1. Captura **lo que haya en esa zona del escritorio**: en mi PNG se ven ventanas de Josue en el borde derecho (los keydials teal). La evidencia llega contaminada y, de paso, fotografía otras aplicaciones.
2. Las columnas de la derecha (E) salen **recortadas** por el ancho del stage, justo la técnica que hay que juzgar.

Fix propuesto: `PrintWindow(hwnd, hdcMem, 2)` por ventana propia (con `PW_RENDERFULLCONTENT`), o mover el stage a una zona despejada y recortar por ventana. Como los windows E se pintan con `UpdateLayeredWindow`, hay que comprobar que `PrintWindow` no devuelva negro; si devuelve negro, la alternativa es una ventana fuera de bordes sobre un fondo liso conocido.

**D4 queda abierto** hasta tener capturas válidas. Lo que sí se pudo medir sin pantalla (modo oculto, 3 escalas) va en §6 y pesa: la técnica E está muy por encima del criterio "< 2 ms".

## 6. Latencias de redibujo desde `--oculto` (únicas cifras duras de la galería)

| Técnica | rango observado | nota |
|---|---|---|
| A (Region) pill | 44–194 ms | primer redibujo caro, luego 44–78 ms |
| B (DWM+alfa) | 52–113 ms | |
| C (DWM opaco) | 11–131 ms | |
| D (Acrylic) | 34–77 ms | |
| **E (GDI+ ULW)** | **8–30 ms** (keys 5–7 ms, slider ~8 ms) | estable, pero **4–15× sobre el objetivo de 2 ms** |

Otros datos del log oculto: `theme.ini` **no encontrado** (usa defectos; la prueba de tema queda pendiente), fuentes Segoe Fluent Icons / Cascadia Mono / Segoe UI Variable **instaladas**, GDI+ ok, build 26200 → backdrop posible sí, `admin=no` ✓.
En la primera reconstrucción el log registra `Foco tras Show NoActivate: CAMBIO (alguna ventana robo el foco)`; en las siguientes, `conservado`. Worth an eye: si la primera Show roba foco, en CSP eso se nota.
ExStyle medido: pills A/B/E `0x80088` (layered+topmost+toolwindow), C/D `0x88`. `click-through=no`, `noactivate=no` en todas — coherente con los checkboxes sin marcar en modo oculto, no es un bug, pero significa que click-through/NoActivate **siguen sin probar**.

## 7. Corrección a una regla de trabajo que estaba mal

`/validate` **sí es seguro** en este equipo: no ejecuta el script (probado con un canario que escribe un marcador; el marcador no aparece). La confusión anterior venía de Git Bash: sin `MSYS_NO_PATHCONV=1`, `/validate` se convierte en `C:/Program Files/Git/validate` y AHK interpreta eso como el script → diálogo modal y códigos de salida incoherentes. Invocación buena:

```bash
MSYS_NO_PATHCONV=1 "/c/Program Files/AutoHotkey/v2/AutoHotkey64.exe" /ErrorStdOut /validate archivo.ahk; echo $?
```

- exit **0** = válido; exit **2** = error de carga, y con `/ErrorStdOut` el mensaje sale por stderr **sin diálogo** (así se encontró el bug §2a).
- Regla del ` ; ` dentro de literales, medida en 2.0.26: `x := "a ; b"` → **exit 2** (rompe); `x := "; texto"` (punto y coma inicial) → **exit 0**; `` x := "a `; b" `` → **exit 0**. Los literales `"; [spike_latencia] ..."` del spike están bien.
- Consecuencia práctica: los diálogos modales de AHK (`Fin()` del spike, o el error de carga sin `/ErrorStdOut`) **bloquean la CLI** y le ponen un cuadro a Josue. Para automatizar, conviene que `Fin()` escriba y salga sin MsgBox, o que acepte `--sin-dialogo`.

## 8. Estado del entorno

- Los dos scripts del paquete quedaron parcheados **solo en la copia de trabajo** `_f0v2/…`; el zip original y tus `docs/ESTETICA` no se tocaron. Diff completo en `diffs/` (2 archivos; los cambios marcados *diagnóstico Qoder* son instrumentación opcional, el resto son los dos fixes).
- Sin procesos residuales de las pruebas (verificado por PID + CommandLine; los `cmd.exe` que siguen vivos son del 2–3 de nov, ajenos).
- Artefactos: `artifacts/anclas_canonico.txt`, `latencia_base.txt`, `spike_resultados_oculto.txt`, `captura_100_Oscuro_m2_212124.png`, copias parcheadas en `artifacts/scripts-parcheados/`.

## 9. Lo que necesito de Claude

1. Confirmar el hash correcto en PLAN-V2/HANDOFF (b) y aceptar el rename `REPTXT` (a).
2. Recetar cómo disparar la medición sin timer (§4) para cerrar I13.
3. Decidir si acepto `PrintWindow` para las capturas (§5) o si la sesión visual la hace Josue manual; **D4 no se puede firmar** con lo que hay.
4. Reescribir D2: `_LimpiarAvisos` no existe en el canónico (§3).

---

# ANEXO 1 — diffs contra el zip original

## diffs/galeria.diff
```diff
--- galeria.ahk
+++ galeria.ahk
@@ -32,10 +32,15 @@
 CoordMode("Mouse", "Screen")
 
 OCULTO := false
+CAPTURAS := false
 TEMA_RUTA_ARG := ""
 for a in A_Args {
     if (a = "--oculto")
         OCULTO := true
+    else if (a = "--capturas") {
+        OCULTO := true
+        CAPTURAS := true
+    }
     else if (SubStr(a, 1, 7) = "--tema=")
         TEMA_RUTA_ARG := SubStr(a, 8)
 }
@@ -63,8 +68,10 @@
     _CrearControl()
 _LogInicial()
 _Reconstruir()
-if OCULTO
+if (OCULTO && !CAPTURAS)
     SetTimer(_AutoOculto, -400)
+else if CAPTURAS
+    SetTimer(_AutoCapturas, -400)
 else
     SetTimer(ExitApp, -600000)
 return
@@ -243,6 +250,36 @@
 }
 
 ; ---------------------------------------------------------------------
+; Modo capturas: same off-screen-safe rebuild, but windows are placed on a
+; real monitor for ~0.5 s each so the platform BitBlt produces valid D4 evidence
+; ---------------------------------------------------------------------
+_AutoCapturas() {
+    S.offx := 0
+    prim := MonitorGetPrimary()
+    otro := MonitorGetCount() > 1 ? (prim = 1 ? 2 : 1) : prim
+    _Log("=== GALERIA F0 v2 | modo CAPTURAS | monprim=" prim " monsec=" otro " ===")
+    _Pasar(prim, [0.75, 1.0, 1.5])
+    if (otro != prim)
+        _Pasar(otro, [1.0])
+    _Log("=== FIN capturas | errores: " S.errores " ===")
+    ExitApp(S.errores ? 1 : 0)
+}
+
+_Pasar(mon, escalas) {
+    S.mon := mon
+    for esc in escalas {
+        S.esc := esc
+        for fi in [1, 3] {
+            S.fondoI := fi
+            _Reconstruir()
+            Sleep(400)
+            _Captura()
+            Sleep(120)
+        }
+    }
+}
+
+; ---------------------------------------------------------------------
 ; Dpi del monitor elegido (para escala correcta en el 2.o monitor)
 ; ---------------------------------------------------------------------
 _DpiMon(idx) {
@@ -291,7 +328,7 @@
     MonitorGetWorkArea(S.mon, &l, &t, &r, &b)
     sx := l + 10 + S.offx
     sy := t + 10 + S.offx
-    if (OCULTO) {
+    if (OCULTO && !CAPTURAS) {
         sx := S.offx
         sy := S.offx
     } else if IsObject(S.ctl) {
@@ -570,7 +607,7 @@
 ; Captura de la plataforma (evidencia valida para D4)
 ; ---------------------------------------------------------------------
 _Captura(*) {
-    if !IsObject(S.stage) || OCULTO
+    if !IsObject(S.stage) || (OCULTO && !CAPTURAS)
         return
     WinGetPos(&x, &y, &w, &h, "ahk_id " S.stage.Hwnd)
     hdcS := DllCall("user32\GetDC", "ptr", 0, "ptr")
```

## diffs/spike_latencia.diff
```diff
--- spike_latencia.ahk
+++ spike_latencia.ahk
@@ -32,7 +32,7 @@
 DllCall("user32\SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
 SetWorkingDir(A_ScriptDir)
 
-HASH_ESPERADO := "CEF745C7685DED9C9BC437FE20CEFFB3688126743A9024D9DE964092EBEA983E"
+HASH_ESPERADO := "CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E"
 LINEAS_ESPERADAS := 3917
 PROD := A_ScriptDir "\..\..\..\XxxPPEN_a16pg2_displayAS_secondary.ahk"
 N := 20
@@ -49,7 +49,7 @@
         N := Max(5, Integer(SubStr(a, 5)))
 }
 
-REP := ""
+REPTXT := ""
 Principal()
 ExitApp()
 
@@ -124,6 +124,7 @@
             nuevo.Push("; [spike_latencia] linea " i " original anulada")
             if (i = 6) {
                 nuevo.Push("Suspend(1)")
+                nuevo.Push('_LatHb("autoexec: Suspend + timer registrados")')
                 nuevo.Push("SetTimer(_LatBase, -2500)")
             }
         } else {
@@ -158,6 +159,8 @@
     ; ---- 5. Ejecutar la copia con watchdog ----
     Rep("")
     Rep("Ejecutando la copia (N=" N ")...")
+    hbq := dir "\heartbeat_latencia.txt"
+    try FileDelete(hbq)
     pid := 0
     Run(A_ComSpec ' /c ""' A_AhkPath '" /ErrorStdOut "' copia '" > "' errf '" 2>&1"', , "Hide", &pid)
     ProcessWaitClose(pid, 45)
@@ -169,6 +172,8 @@
         Rep("`n" FileRead(salida, "UTF-8"))
     else
         Rep("La copia no escribio salida. Revisa " errf)
+    if FileExist(hbq)
+        Rep("Latido de la copia (A_TickCount | etapa):`n" FileRead(hbq, "UTF-8"))
     if FileExist(errf) {
         e := Trim(FileRead(errf, "UTF-8"))
         if (e != "")
@@ -181,14 +186,14 @@
 }
 
 Rep(t) {
-    global REP
-    REP .= t "`r`n"
+    global REPTXT
+    REPTXT .= t "`r`n"
 }
 
 Guardar(nombre) {
     ruta := A_ScriptDir "\" nombre
     try FileDelete(ruta)
-    FileAppend(REP, ruta, "UTF-8")
+    FileAppend(REPTXT, ruta, "UTF-8")
 }
 
 Fin(msg, cod) {
@@ -303,6 +308,9 @@
     c := "
 (
 ; ===== inyectado por spike_latencia.ahk (solo en la copia) =====
+_LatHb(t) {
+    try FileAppend(A_TickCount " | " t "`r`n", "@@HB@@", "UTF-8")
+}
 _LatQPC() {
     static f := 0
     if !f
@@ -312,6 +320,7 @@
     return cc * 1000 / f
 }
 _LatMedir(nombre, fn, n) {
+    _LatHb("empieza " nombre)
     ts := []
     err := 0
     ult := ""
@@ -348,6 +357,7 @@
     return "| " nombre " | " ts.Length " | " Round(med, 3) " | " Round(p95, 3) " | " Round(ts[ts.Length], 3) " | " err " " ult " |``n"
 }
 _LatBase() {
+    _LatHb("_LatBase entro (timer disparado)")
     out := "Latencias base (ms, QPC, copia esteril)``n"
     out .= "| Funcion | N | mediana | p95 | max | errores |``n"
     out .= "|---|---|---|---|---|---|``n"
@@ -355,10 +365,13 @@
     out .= "``nCriterio I13: cada funcion estetica nueva debe sumar <= ~2 ms sobre estas medianas.``n"
     try FileDelete("@@SALIDA@@")
     FileAppend(out, "@@SALIDA@@", "UTF-8")
+    _LatHb("salida escrita")
     ExitApp()
 }
 )"
+    hb := StrReplace(salida, "salida_latencia.txt", "heartbeat_latencia.txt")
     c := StrReplace(c, "@@MEDIR@@", RTrim(medir, "`r`n"))
     c := StrReplace(c, "@@SALIDA@@", salida)
+    c := StrReplace(c, "@@HB@@", hb)
     return "`r`n" c "`r`n"
 }
```

# ANEXO 2 — anclas_canonico.txt (paso 3, para V0)
```text
﻿Anclas del canonico (linea de definicion | usos totales por nombre)
Lineas: 3917

_FadeAlpha                    def=  539  usos=   7  (hwnd,hasta,pasos := 6,delayMs := 10)
_LimpiarAvisos                def=    0  usos=   0  ()
_LimpiarGUIs                  def= 1506  usos=   4  ()
MostrarHUD                    def= 1574  usos=  70  (texto,colorBarra := "00E5FF",duracion := 1200)
MostrarMiniTexto              def= 1675  usos=  33  (texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")
MostrarBadgeCombo             def= 1528  usos=   5  (comboText,toolText,colorAcento := "00E5FF",duracion := 2200)
MostrarTooltipToggle          def= 1722  usos=   5  (titulo,simbolo,color)
MostrarIconoHerramienta       def= 1627  usos=   3  (tipo,duracion := 700)
MostrarMiniGUI                def= 1702  usos=   1  (texto,colorHex := "222222",duracion := 1200)
_OcultarHUDSi                 def= 1611  usos=   2  (hwnd)
Sanar                         def=    0  usos=   0  ()
IniciarDsGUI                  def= 2205  usos=   3  ()
IniciarCcGUI                  def= 2239  usos=   3  ()
IniciarArGUI                  def= 2286  usos=   3  ()
IniciarHCGUI                  def= 2333  usos=   3  ()
IniciarLockGUI                def= 2380  usos=   3  ()
IniciarFrenteGUI              def= 2427  usos=   3  ()
IniciarEstabBtnGUI            def= 2482  usos=   3  ()
IniciarEstabGUI               def= 2544  usos=   3  ()
ActualizarEstabGUI            def= 2698  usos=  10  (v := -1,forzar := false)
_EstabCalcular                def= 2635  usos=   3  (w,h)
_EstabLayout                  def= 2661  usos=   6  (w,h)
_EstabKnobRegion              def= 2680  usos=   2  ()
_EstabRegion                  def= 2689  usos=   6  (w,h)
_EstabEmitir                  def= 2865  usos=   5  (tecla,n,pausa := 8)
_EstabEnviarDelta             def= 2877  usos=   5  (nuevo)
IniciarReloadGUI              def= 3139  usos=   2  ()
IniciarPuntosGUI              def= 3334  usos=   2  ()
_SetIcono                     def= 3868  usos=  17  (ctrl,nombre)
_RutaIcono                    def= 3874  usos=   2  (nombre)
_IconosB64                    def= 3911  usos=   3  ()
_PosGuiIniPath                def= 2019  usos=  31  ()
_AnclaBloquePaneles           def= 2046  usos=   8  ()
AbrirPanelPuntos              def= 3398  usos=   3  ()
_ArrastrarPanelBloque         def= 2067  usos=   8  (hwndClick,lParam,guiObj)
MostrarGUIEnfoque             def= 1883  usos=   2  ()
IniciarDialGUI                def= 2188  usos=   2  ()

Marcas de hallazgos del PLAN (primera linea | apariciones)
-2247 (ancla fija de avisos)        linea= 1540  n=  2
PUNTOS[30]                          linea= 1643  n=  2
ancho HUD fijo 208*AVISO_ESC        linea= 1584  n=  1

Lectura: _FadeAlpha usos=0 -> I12 sin objeto. _LimpiarAvisos def>0 -> D2 cerrada.
```

# ANEXO 3 — latencia_base.txt (paso 3+4, prueba del fallo del timer)
```text
﻿Archivo: C:\Users\jbard\Documents\AntiGravity\Autohotkeys\XxxPPEN_a16pg2_displayAS_secondary.ahk
SHA-256: CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E
Lineas: 3917 (esperadas 3917)
Coincide con el canonico: SI

Anclas escritas en anclas_canonico.txt
MostrarHUD(texto,colorBarra := "00E5FF",duracion := 1200)  ->  MostrarHUD("LAT", "00E5FF", 60)
MostrarMiniTexto(texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")  ->  MostrarMiniTexto("LAT", "00E5FF", 60, "LAT")
ActualizarEstabGUI(v := -1,forzar := false)  ->  ActualizarEstabGUI()
Copia desechable: C:\Users\jbard\AppData\Local\Temp\latencia_f0\prueba_latencia.ahk
/validate de la copia: exit 0

Ejecutando la copia (N=20)...
WATCHDOG: la copia excedio 45 s y se cerro (solo su arbol de procesos).
La copia no escribio salida. Revisa C:\Users\jbard\AppData\Local\Temp\latencia_f0\stderr_latencia.txt

Produccion intacta: SI (hash igual antes y despues)
```

# ANEXO 4 — spike_resultados_oculto.txt (paso 2, log completo)
```text
﻿=== GALERIA F0 v2 | 2026-11-04 21:14:47 | modo OCULTO ===
REGLA: HR 0x00000000 no prueba nada. D4 se firma por CAPTURA, no por este log.
Windows 10.0.26200 (build 26200) | Win11=si | backdrop posible=si
DPI sistema 96 (factor 1.00) | monitores 2 | AHK 2.0.26 | admin=no
GDI+ ok
Tema: theme.ini NO encontrado, se usan defectos
Texto primario en uso: FFFFFF (theme.ini dice FFFFFF)
Fuente Segoe Fluent Icons: instalada
Fuente Segoe MDL2 Assets: instalada
Fuente Segoe UI Variable: instalada
Fuente Segoe UI Semibold: instalada
Fuente Cascadia Mono: instalada
Fuente Consolas: instalada
-> iconos: Segoe Fluent Icons | mono: Cascadia Mono | semibold: Segoe UI Semibold

--- Reconstruccion: escala 100% | monitor 2 (dpi 100%) | fondo Oscuro | pill 112x28 px ---
A pill: creada en 157.2 ms | region aplicada (sin AA)
B pill: creada en 264.4 ms | corner(33)=hr=0x00000000 borde(34)=hr=0x00000000 [HR no prueba nada: ver captura]
C pill: creada en 191.7 ms | corner(33)=hr=0x00000000 borde(34)=hr=0x00000000 [HR no prueba nada: ver captura]
D pill: creada en 406.5 ms | dark(20)=hr=0x00000000 backdrop(38)=hr=0x00000000 extend=hr=0x00000000 [HR no prueba nada: ver captura]
E pill: creada en 186.5 ms | UpdateLayeredWindow=1
A keycaps: creada en 778.2 ms | ventana region aplicada (sin AA) | keycaps region aplicada (sin AA)
A slider: creada en 224.4 ms | ventana region aplicada (sin AA) | knob region aplicada (sin AA) (circulo sin AA)
E keycaps: creada en 172.5 ms | UpdateLayeredWindow=1
E slider: creada en 300.0 ms | UpdateLayeredWindow=1
Foco tras Show NoActivate: CAMBIO (alguna ventana robo el foco)
A pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
B pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
C pill ExStyle=0x88 | layered=no | click-through=no | noactivate=no
D pill ExStyle=0x88 | layered=no | click-through=no | noactivate=no
E pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
A keys ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
A slider ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
E keys ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
E slider ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
--- Reconstruccion: escala 75% | monitor 2 (dpi 100%) | fondo Oscuro | pill 84x21 px ---
A pill: creada en 283.1 ms | region aplicada (sin AA)
B pill: creada en 121.8 ms | corner(33)=hr=0x00000000 borde(34)=hr=0x00000000 [HR no prueba nada: ver captura]
C pill: creada en 125.3 ms | corner(33)=hr=0x00000000 borde(34)=hr=0x00000000 [HR no prueba nada: ver captura]
D pill: creada en 188.4 ms | dark(20)=hr=0x00000000 backdrop(38)=hr=0x00000000 extend=hr=0x00000000 [HR no prueba nada: ver captura]
E pill: creada en 87.8 ms | UpdateLayeredWindow=1
A keycaps: creada en 189.9 ms | ventana region aplicada (sin AA) | keycaps region aplicada (sin AA)
A slider: creada en 114.3 ms | ventana region aplicada (sin AA) | knob region aplicada (sin AA) (circulo sin AA)
E keycaps: creada en 82.1 ms | UpdateLayeredWindow=1
E slider: creada en 228.6 ms | UpdateLayeredWindow=1
Foco tras Show NoActivate: conservado
A pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
B pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
C pill ExStyle=0x88 | layered=no | click-through=no | noactivate=no
D pill ExStyle=0x88 | layered=no | click-through=no | noactivate=no
E pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
A keys ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
A slider ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
E keys ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
E slider ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
A pill redibujo (OFF): 194.19 ms
A pill redibujo (ON): 78.64 ms
A pill redibujo (ON): 44.27 ms
A pill redibujo (OFF): 58.73 ms
B pill redibujo (OFF): 52.38 ms
B pill redibujo (ON): 52.51 ms
B pill redibujo (ON): 113.39 ms
B pill redibujo (OFF): 61.78 ms
C pill redibujo (OFF): 44.16 ms
C pill redibujo (ON): 46.43 ms
C pill redibujo (ON): 46.76 ms
C pill redibujo (OFF): 102.19 ms
D pill redibujo (OFF): 84.72 ms
D pill redibujo (ON): 64.84 ms
D pill redibujo (ON): 77.53 ms
D pill redibujo (OFF): 56.81 ms
E pill redibujo (OFF): 6.04 ms
E pill redibujo (ON): 5.29 ms
E pill redibujo (ON): 6.70 ms
E pill redibujo (OFF): 6.22 ms
A keys redibujo (OFF): 8.89 ms
A keys redibujo (ON): 95.46 ms
A slider redibujo (val 20): 45.13 ms
A slider redibujo (val 80): 39.88 ms
E keys redibujo (OFF): 9.84 ms
E keys redibujo (ON): 8.62 ms
E slider redibujo (val 20): 16.31 ms
E slider redibujo (val 80): 13.29 ms
--- Reconstruccion: escala 100% | monitor 2 (dpi 100%) | fondo Oscuro | pill 112x28 px ---
A pill: creada en 438.0 ms | region aplicada (sin AA)
B pill: creada en 311.1 ms | corner(33)=hr=0x00000000 borde(34)=hr=0x00000000 [HR no prueba nada: ver captura]
C pill: creada en 148.2 ms | corner(33)=hr=0x00000000 borde(34)=hr=0x00000000 [HR no prueba nada: ver captura]
D pill: creada en 204.8 ms | dark(20)=hr=0x00000000 backdrop(38)=hr=0x00000000 extend=hr=0x00000000 [HR no prueba nada: ver captura]
E pill: creada en 188.2 ms | UpdateLayeredWindow=1
A keycaps: creada en 308.8 ms | ventana region aplicada (sin AA) | keycaps region aplicada (sin AA)
A slider: creada en 229.0 ms | ventana region aplicada (sin AA) | knob region aplicada (sin AA) (circulo sin AA)
E keycaps: creada en 93.0 ms | UpdateLayeredWindow=1
E slider: creada en 623.3 ms | UpdateLayeredWindow=1
Foco tras Show NoActivate: CAMBIO (alguna ventana robo el foco)
A pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
B pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
C pill ExStyle=0x88 | layered=no | click-through=no | noactivate=no
D pill ExStyle=0x88 | layered=no | click-through=no | noactivate=no
E pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
A keys ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
A slider ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
E keys ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
E slider ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
A pill redibujo (OFF): 109.30 ms
A pill redibujo (ON): 79.32 ms
A pill redibujo (ON): 180.72 ms
A pill redibujo (OFF): 64.14 ms
B pill redibujo (OFF): 46.29 ms
B pill redibujo (ON): 62.09 ms
B pill redibujo (ON): 80.90 ms
B pill redibujo (OFF): 49.52 ms
C pill redibujo (OFF): 63.08 ms
C pill redibujo (ON): 100.18 ms
C pill redibujo (ON): 64.39 ms
C pill redibujo (OFF): 99.87 ms
D pill redibujo (OFF): 95.23 ms
D pill redibujo (ON): 70.80 ms
D pill redibujo (ON): 32.19 ms
D pill redibujo (OFF): 67.64 ms
E pill redibujo (OFF): 4.64 ms
E pill redibujo (ON): 4.50 ms
E pill redibujo (ON): 6.49 ms
E pill redibujo (OFF): 6.36 ms
A keys redibujo (OFF): 5.47 ms
A keys redibujo (ON): 52.53 ms
A slider redibujo (val 20): 21.01 ms
A slider redibujo (val 80): 18.60 ms
E keys redibujo (OFF): 6.04 ms
E keys redibujo (ON): 6.36 ms
E slider redibujo (val 20): 5.92 ms
E slider redibujo (val 80): 7.26 ms
--- Reconstruccion: escala 150% | monitor 2 (dpi 100%) | fondo Oscuro | pill 168x42 px ---
A pill: creada en 247.5 ms | region aplicada (sin AA)
B pill: creada en 425.7 ms | corner(33)=hr=0x00000000 borde(34)=hr=0x00000000 [HR no prueba nada: ver captura]
C pill: creada en 80.8 ms | corner(33)=hr=0x00000000 borde(34)=hr=0x00000000 [HR no prueba nada: ver captura]
D pill: creada en 195.3 ms | dark(20)=hr=0x00000000 backdrop(38)=hr=0x00000000 extend=hr=0x00000000 [HR no prueba nada: ver captura]
E pill: creada en 242.9 ms | UpdateLayeredWindow=1
A keycaps: creada en 735.7 ms | ventana region aplicada (sin AA) | keycaps region aplicada (sin AA)
A slider: creada en 337.6 ms | ventana region aplicada (sin AA) | knob region aplicada (sin AA) (circulo sin AA)
E keycaps: creada en 272.5 ms | UpdateLayeredWindow=1
E slider: creada en 286.6 ms | UpdateLayeredWindow=1
Foco tras Show NoActivate: CAMBIO (alguna ventana robo el foco)
A pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
B pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
C pill ExStyle=0x88 | layered=no | click-through=no | noactivate=no
D pill ExStyle=0x88 | layered=no | click-through=no | noactivate=no
E pill ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
A keys ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
A slider ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
E keys ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
E slider ExStyle=0x80088 | layered=si | click-through=no | noactivate=no
A pill redibujo (OFF): 51.07 ms
A pill redibujo (ON): 77.11 ms
A pill redibujo (ON): 64.40 ms
A pill redibujo (OFF): 256.25 ms
B pill redibujo (OFF): 64.30 ms
B pill redibujo (ON): 258.44 ms
B pill redibujo (ON): 115.25 ms
B pill redibujo (OFF): 44.76 ms
C pill redibujo (OFF): 46.43 ms
C pill redibujo (ON): 11.65 ms
C pill redibujo (ON): 131.17 ms
C pill redibujo (OFF): 42.55 ms
D pill redibujo (OFF): 34.59 ms
D pill redibujo (ON): 47.54 ms
D pill redibujo (ON): 73.73 ms
D pill redibujo (OFF): 76.72 ms
E pill redibujo (OFF): 14.22 ms
E pill redibujo (ON): 30.52 ms
E pill redibujo (ON): 8.11 ms
E pill redibujo (OFF): 19.97 ms
A keys redibujo (OFF): 120.23 ms
A keys redibujo (ON): 3.57 ms
A slider redibujo (val 20): 75.03 ms
A slider redibujo (val 80): 14.84 ms
E keys redibujo (OFF): 7.36 ms
E keys redibujo (ON): 5.36 ms
E slider redibujo (val 20): 7.89 ms
E slider redibujo (val 80): 7.87 ms
=== FIN modo oculto | errores: 0 ===
```

# ANEXO 5 — lineas 1-8 del canonico (bloque de elevacion: coincide con lo que asume el spike)
```text
#Requires AutoHotkey v2.0
#SingleInstance Force
if !A_IsAdmin {
    try Run('*RunAs "' A_ScriptFullPath '"')
    ExitApp()
}
try TraySetIcon("C:\Users\jbard\Documents\@Otros\icons\clipstudio.ico")
DllCall("SetThreadDpiAwarenessContext","ptr",-3,"ptr")
```
