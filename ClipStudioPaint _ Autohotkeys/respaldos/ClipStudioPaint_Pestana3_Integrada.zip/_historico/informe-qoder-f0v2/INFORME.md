# INFORME QODER — F0 v2 (validaciones y spikes, entorno real AHK 2.0.26)

Fecha: 2026-11-04. Equipo: Windows 10.0.26200, AHK v2.0.26, 2 monitores, DPI 96.
Producción **intacta** en todo momento: `Documents\AntiGravity\Autohotkeys\XxxPPEN_a16pg2_displayAS_secondary.ahk`
SHA-256 `CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E`, 3.917 líneas (verificado antes y después de cada corrida).
Nada se ejecutó elevado. Ninguna prueba registró hotkeys globales; no hubo instancias duplicadas del script vivo.

## 1. Resultado por paso del HANDOFF-F0

| Paso | Pedido | Resultado |
|---|---|---|
| 1 | `/validate` de los dos scripts | galeria.ahk **exit 0**; spike_latencia.ahk **fallaba exit 2** → bug real (ver §2), tras el parche **exit 0** |
| 2 | `galeria.ahk --oculto` | **exit 0, errores: 0**. Log completo en `artifacts/spike_resultados_oculto.txt` |
| 3 | `spike_latencia.ahk` seco | **OK** con `--prod=` explícito: hash coincide, 3.917/3.917, copia validada exit 0. `artifacts/anclas_canonico.txt` |
| 4 | `spike_latencia.ahk --ejecutar` | **FALLA** (ver §4) |
| 5 | Sesión visual con capturas | **Parcial**: 1 PNG generado; el método de captura no es válido como evidencia (ver §5) |
| 6 | `pruebas.ps1 -Modo parse` / `-Modo esteril` | **PASS** en ambos (esteril: copia en 7,29 s, stderr vacío, 0 huérfanos, archivo real intacto) |

## 2. Dos bugs reales en el paquete (parches en `diffs/`)

**a) `spike_latencia.ahk:52` — colisión `REP` / `Rep`.** AHK v2 no distingue mayúsculas en identificadores: el global `REP := ""` choca con la función `Rep(t)` y el script **no carga**.
Error exacto del runtime: `(52) : ==> This Func cannot be used as an output variable. Specifically: Rep`.
Fix aplicado: renombrar el acumulador a `REPTXT` (líneas 52, 184, 185, 191). Ninguna otra línea tocada.
Nota: esto no lo detecta un chequeo estático de llaves/paréntesis — hace falta el `/validate` real.

**b) El hash de la fuente de verdad está corrupto.** `HASH_ESPERADO` en el script (y `PLAN-V2.md:25`, `HANDOFF-F0.md:7`) dice
`CEF745C7685DED9C9BC437FE20CEFFB3688126743A9024D9DE964092EBEA983E`; el digest real del archivo canónico es
`CEF745C7ECDBBF82F3E73558A148790E192862AD7C432B4CEC88924624CDA01E`.
Solo coinciden los 8 primeros hex: el resto se parece al hash de otro archivo. Con el literal actual el paso 1 **siempre** aborta con exit 2 y no genera `anclas_canonico.txt`. Fix aplicado en el script; **falta corregirlo en PLAN-V2.md y HANDOFF-F0.md**.

## 3. Regla V0 — datos para cerrar D1/D2/D3 (medidos sobre el canónico real)

```
_FadeAlpha          def= 539  usos=  7   (hwnd,hasta,pasos := 6,delayMs := 10)
_LimpiarAvisos      def=   0  usos=  0
_LimpiarGUIs        def=1506  usos=  4
MostrarHUD          def=1574  usos= 70   (texto,colorBarra := "00E5FF",duracion := 1200)
MostrarMiniTexto    def=1675  usos= 33   (texto,colorHex := "222222",duracion := 800,colorTexto := "FFFFFF")
ActualizarEstabGUI  def=2698  usos= 10   (v := -1,forzar := false)
_EstabEmitir        def=2865  usos=  5
-2247               linea=1540  n=2      208 * AVISO_ESC  linea=1584  n=1      PUNTOS[30]  linea=1643  n=2
```

Consecuencias para el plan:
- **I12 SÍ tiene objeto**: `_FadeAlpha` existe en la línea 539 con 7 usos. Tu CONTEXTO.md §2 era correcto para el archivo de 3.917.
- **D2 NO está cerrada**: `_LimpiarAvisos` no existe en el canónico (def=0, usos=0). La leyenda que imprime `anclas_canonico.txt` ("_LimpiarAvisos def>0 -> D2 cerrada") contradice el propio dato: hay que corregir la leyenda.
- **Sanar** también sale def=0/usos=0; conviene decir sobre qué invariante estaba abierto.
- El hash de `ArmarLlamada` para `MostrarMiniTexto` genera `("LAT", "00E5FF", 60, "LAT")`: el 4º parámetro se llama `colorTexto` y la rama `txt|texto` gana antes que la de color → llega `"LAT"` como color. Al medir, eso se contará como error en la columna *errores*. Sugerencia: evaluar la rama de color antes que la de texto.

## 4. Paso 4 (`--ejecutar`): la copia arranca pero nunca llega a medir

Tres corridas, mismo resultado:
- `/validate` de la copia: exit 0.
- La copia **sí se ejecuta** (escribe `%TEMP%\latencia_f0\posiciones_gui.ini`, 112 bytes).
- **No aparece `salida_latencia.txt`**, `stderr_latencia.txt` **vacío**, y el watchdog de 45 s cierra el árbol por PID. Producción intacta después.
- Con un latido que añadí para diagnosticar (`diffs/spike_latencia.diff`, marcado *diagnóstico Qoder*), el heartbeat no se escribe ni en la primera línea del autoexec inyectado.

Hipótesis ordenadas por evidencia: (1) el timer one-shot `-2500` nunca se dispara porque el autoexec de producción no llega a terminar — hay 9 `SetTimer` y 10 `IniciarXxxGUI()` entre las líneas 88 y 99, y el bloque de detección recorre ventanas de CSP; (2) en dos corridas el propio spike se quedó **bloqueado antes del paso 3** con 1,5 s de CPU acumulada tras 4 minutos, o sea esperando un `RunWait` (el `certutil` de `Hash()` es el candidato) o un diálogo modal heredado de la corrida anterior.

Sugerencia para Claude (no la apliqué en producción, solo la dejo propuesta): disparar la medición **en línea al final del autoexec de la copia** (insertar la llamada justo antes del primer hotkey, línea 138) en lugar de por timer, y sustituir `certutil` por `FileOpen` + `DllCall(advapi…)` o `Get-FileHash`. Con eso el paso 4 deja de depender de que el script quede ocioso.

## 5. Paso 5: el botón *Captura PNG* no produce evidencia válida para D4

`_Captura()` hace `BitBlt` desde el **DC de pantalla** en el rectángulo del stage. Dos problemas, ambos visibles en `artifacts/captura_100_Oscuro_m2_212124.png`:
1. Captura **lo que haya en esa zona del escritorio**: en mi PNG se ven ventanas de Josue en el borde derecho (los keydials teal). La evidencia llega contaminada y, de paso, fotografía otras aplicaciones.
2. Las columnas de la derecha (E) salen **recortadas** por el ancho del stage, justo la técnica que hay que juzgar.

Fix propuesto: `PrintWindow(hwnd, hdcMem, 2)` por ventana propia (con `PW_RENDERFULLCONTENT`), o mover el stage a una zona despejada y recortar por ventana. Como los windows E se pintan con `UpdateLayeredWindow`, hay que comprobar que `PrintWindow` no devuelva negro; si devuelve negro, la alternativa es una ventana fuera de bordes sobre un fondo liso conocido.

**D4 queda abierto** hasta tener capturas válidas. Lo que sí se pudo medir sin pantalla (modo oculto, 3 escalas) va en §6 y pesa: la técnica E está muy por encima del criterio "< 2 ms".

## 6. Latencias de redibujo desde `--oculto` (únicas cifras duras de la galería)

| Técnica | rango observado | nota |
|---|---|---|
| A (Region) pill | 44–194 ms | primer redibujo caro, luego 44–78 ms |
| B (DWM+alfa) | 52–113 ms | |
| C (DWM opaco) | 11–131 ms | |
| D (Acrylic) | 34–77 ms | |
| **E (GDI+ ULW)** | **8–30 ms** (keys 5–7 ms, slider ~8 ms) | estable, pero **4–15× sobre el objetivo de 2 ms** |

Otros datos del log oculto: `theme.ini` **no encontrado** (usa defectos; la prueba de tema queda pendiente), fuentes Segoe Fluent Icons / Cascadia Mono / Segoe UI Variable **instaladas**, GDI+ ok, build 26200 → backdrop posible sí, `admin=no` ✓.
En la primera reconstrucción el log registra `Foco tras Show NoActivate: CAMBIO (alguna ventana robo el foco)`; en las siguientes, `conservado`. Worth an eye: si la primera Show roba foco, en CSP eso se nota.
ExStyle medido: pills A/B/E `0x80088` (layered+topmost+toolwindow), C/D `0x88`. `click-through=no`, `noactivate=no` en todas — coherente con los checkboxes sin marcar en modo oculto, no es un bug, pero significa que click-through/NoActivate **siguen sin probar**.

## 7. Corrección a una regla de trabajo que estaba mal

`/validate` **sí es seguro** en este equipo: no ejecuta el script (probado con un canario que escribe un marcador; el marcador no aparece). La confusión anterior venía de Git Bash: sin `MSYS_NO_PATHCONV=1`, `/validate` se convierte en `C:/Program Files/Git/validate` y AHK interpreta eso como el script → diálogo modal y códigos de salida incoherentes. Invocación buena:

```bash
MSYS_NO_PATHCONV=1 "/c/Program Files/AutoHotkey/v2/AutoHotkey64.exe" /ErrorStdOut /validate archivo.ahk; echo $?
```

- exit **0** = válido; exit **2** = error de carga, y con `/ErrorStdOut` el mensaje sale por stderr **sin diálogo** (así se encontró el bug §2a).
- Regla del ` ; ` dentro de literales, medida en 2.0.26: `x := "a ; b"` → **exit 2** (rompe); `x := "; texto"` (punto y coma inicial) → **exit 0**; `` x := "a `; b" `` → **exit 0**. Los literales `"; [spike_latencia] ..."` del spike están bien.
- Consecuencia práctica: los diálogos modales de AHK (`Fin()` del spike, o el error de carga sin `/ErrorStdOut`) **bloquean la CLI** y le ponen un cuadro a Josue. Para automatizar, conviene que `Fin()` escriba y salga sin MsgBox, o que acepte `--sin-dialogo`.

## 8. Estado del entorno

- Los dos scripts del paquete quedaron parcheados **solo en la copia de trabajo** `_f0v2/…`; el zip original y tus `docs/ESTETICA` no se tocaron. Diff completo en `diffs/` (2 archivos; los cambios marcados *diagnóstico Qoder* son instrumentación opcional, el resto son los dos fixes).
- Sin procesos residuales de las pruebas (verificado por PID + CommandLine; los `cmd.exe` que siguen vivos son del 2–3 de nov, ajenos).
- Artefactos: `artifacts/anclas_canonico.txt`, `latencia_base.txt`, `spike_resultados_oculto.txt`, `captura_100_Oscuro_m2_212124.png`, copias parcheadas en `artifacts/scripts-parcheados/`.

## 9. Lo que necesito de Claude

1. Confirmar el hash correcto en PLAN-V2/HANDOFF (b) y aceptar el rename `REPTXT` (a).
2. Recetar cómo disparar la medición sin timer (§4) para cerrar I13.
3. Decidir si acepto `PrintWindow` para las capturas (§5) o si la sesión visual la hace Josue manual; **D4 no se puede firmar** con lo que hay.
4. Reescribir D2: `_LimpiarAvisos` no existe en el canónico (§3).
