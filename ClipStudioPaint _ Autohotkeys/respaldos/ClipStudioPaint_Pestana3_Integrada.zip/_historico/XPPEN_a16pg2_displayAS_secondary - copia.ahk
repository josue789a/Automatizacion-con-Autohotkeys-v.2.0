; ┌─────────────────────────────────────────────────────────┐
; │  🎨 CSP ARTIST_PRO_16_GEN2 — SCRIPT TABLET ÚNICA  v52     │
; │                                                         │
; │  1. DIRECTIVAS GLOBALES                                 │
; │  2. ESTADO (objetos agrupados)                          │
; │  3. TIMERS                                               │
; │  4. HOTKEYS GLOBALES                                     │
; │  5. HOTKEYS CSP                                          │
; │     a) Selección y reselección                          │
; │     b) Deshacer / Rehacer                               │
; │     c) Herramientas (A E W Q S O R)                      │
; │     d) Atajos con clic derecho                          │
; │     e) Modificadores de capa                             │
; │  6. CLASE BorderFrame                                    │
; │  7. FUNCIONES                                            │
; └─────────────────────────────────────────────────────────┘

; ┌───────────────────────────────────────────────────────┐
; │  1. DIRECTIVAS GLOBALES                               │
; └───────────────────────────────────────────────────────┘
#Requires AutoHotkey v2.0
#SingleInstance Force
; Auto-elevación: CSP puede correr como admin (tras updates); si el script
; no está al mismo nivel, WinSetTransparent/WinSetExStyle fallan con Error 5 (UIPI).
if !A_IsAdmin {
    try {
        Run('*RunAs "' A_ScriptFullPath '"')
    }
    ExitApp()
}
; Icono de la bandeja (system tray) y de la ventana principal
try TraySetIcon("C:\Users\jbard\Documents\@Otros\icons\clipstudio.ico")
; DPI awareness — coordenadas reales sin escalado de Windows
DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
SendMode("Input")

; ── Teclas "ñ" y "<" de CSP, independientes del idioma del teclado ──
; Send("ñ") / Send("<") escriben el CARÁCTER según el teclado activo: con
; inglés internacional, "ñ" sale como AltGr+N y "<" como Shift+coma, y CSP
; ya no ve las teclas que tenía grabadas. Aquí se manda la tecla FÍSICA
; (código virtual + scancode de la distribución española), igual en cualquier
; idioma. Si CSP no las reconoce con el teclado en inglés, cambia estas dos
; líneas (o reasigna esos atajos en CSP a otra tecla y pon aquí esa tecla).
KEY_NTILDE := "{vkC0sc027}"   ; tecla ñ (a la derecha de la L en teclado español)
KEY_MENOR  := "{vkE2sc056}"   ; tecla < (a la izquierda de la Z en teclado ISO)
EnviarNtilde() => SendInput(KEY_NTILDE)
EnviarMenor()  => SendInput(KEY_MENOR)
SetWorkingDir(A_ScriptDir)
SetKeyDelay(-1, -1)
SetMouseDelay(-1)
SetDefaultMouseSpeed(0)
CoordMode("Mouse",   "Screen")
CoordMode("ToolTip", "Screen")
SetTitleMatchMode(2)

; ┌──────────────────────────────────────────────────────────┐
; │  2. ESTADO  (objetos agrupados)                          │
; └──────────────────────────────────────────────────────────┘
sys := { lastModTime: "", modoEscritura: false }
stylus := { altActive: false, rButtonHeld: false, comboUsado: false, upSinteticoTick: 0, botonSostenido: false, smearSend: false, ignorarUpSintetico: false, bSinteticoTick: 0, origX: 0, origY: 0, spaceFlipTimerRunning: 0 }
sel := { estado: 0, estadoAltX: false, estadoC: 0, guiActivo: false, sRapido: false }
colorEstado     := 0   ; 0=primario  1=secundario  2=alpha
UP_SINTETICO_MS := 70
S_RAPIDO_MS     := 400  ; ventana del doble toque de S (ÁREA CON COLOR); el keydial es más lento que un teclado
ESTAB_MIN       := 7
ESTAB_MAX       := 75
E := { procesando: false, last: 0 }
W := { last: 0 }
Z := { last: 0, timerRunning: 0 }
Q := { last: 0, estadoEstab: 0 }
RM := { last: 0 }   ; RButton & - (envía "t"/Regla): doble toque rápido → ocultar regla (Alt+T)
A_state := { lastPress: 0 }
AltS_state    := { lastPress: 0 }
AltB_s_state  := { lastPress: 0, timerRunning: 0 }
AltB_a_state  := { lastPress: 0, timerRunning: 0 }
AltF_state    := { lastPress: 0, timerRunning: 0, held: false }
S := { estadoCaracter: 0, skipNext: false, lastTick: 0 }
O := { ciclo: 0 }
N6 := { estadoEscala: 0, layerVis: 1 }
hist := { abierto: false, modo: 1, id: 0 }
btn := { b1: false, b2: false, b3: false }
botDer := { b1: false, b2: false, b3: false }
colorV := {
    dsID: 0, dsVis: false, bDS: 0, hover: true, cspHwnd: 0,
    dsX: 0, dsY: 0, dsW: 0, dsH: 0, supresionHasta: 0
}
; Círculo de colores — ventana flotante independiente (igual que deslizador)
colorCC := {
    id: 0, dsVis: false, bCC: 0, hover: false,
    ccX: 0, ccY: 0, ccW: 0, ccH: 0, supresionHasta: 0
}
ar := { id: 0, dsVis: false, bAR: 0, hover: false }
floatGui := { miniTip: 0, miniGUI: 0, tooltipToggle: 0, enfoque: 0, miniTipTick: 0, miniTipID: 0, hud: 0, hudLabel: 0, hudBar: 0, hudHwnd: 0, overlayIcon: 0, overlayIconID: 0, badge: 0, badgeHwnd: 0, badgeSub: 0, badgeMain: 0, badgeSubBar: 0, badgeBar: 0, badgeID: 0 }
enfoque := { activo: false }
shiftSostenido := { activo: false }
; Nivel de opacidad rastreado por el script (CSP no lo expone para leerlo
; de vuelta). Arranca en 100 porque es el valor por defecto de una capa
; nueva. RButton+1/+2 lo mueven de a 10 en 10 y mandan Shift+<dígito>;
; si usas RButton+3..RButton+0 para saltar directo a un valor, el nivel
; se sincroniza también, así los pasos relativos siguen desde ahí.
opacidad := { nivel: 100 }
boost := { holdDelay: 300, maxBoost: 5 }
spc := { last: 0, downTick: 0, selectArmed: false, rotOn: false }
dial := { modo: 1, g: 0, icono: 0, label: 0, barra: 0 }
dsGui := { g: 0, icono: 0, label: 0, barra: 0 }
ccGui := { g: 0, icono: 0, label: 0, barra: 0 }
arGui := { g: 0, icono: 0, label: 0, barra: 0 }
hcGui := { g: 0, icono: 0, label: 0, barra: 0 }
reloadGui := { g: 0, icono: 0, label: 0, barra: 0 }
puntosGui := { g: 0, icono: 0, barra: 0 }   ; botón 📍 que abre el panel de calibración
ptsEd := { g: 0, lv: 0, ex: 0, ey: 0, dx: 0, dy: 0, hAlto: 0, eEsc: 0, eEscAv: 0, st: 0, bCap: 0, sel: 0, capturando: false, ovl: [] }
lockGui := { g: 0, icono: 0, barra: 0 }
; Bloque de paneles ON/OFF (Slider, Circle, Quick, HC + botón de fijar).
; locked=true: no se pueden arrastrar (el clic sigue funcionando).
; El valor real se lee del .ini en IniciarLockGUI (por defecto: fijado).
panelBlk := { locked: true }
; Separación (px) entre paneles del bloque Slider/Circle/Quick. Antes se
; usaban offsets fijos (+84/+168) asumiendo 80px reales por panel; con
; escalado de Windows (DPI) eso no siempre se cumplía y los paneles
; terminaban pisándose. Ahora cada panel se coloca a partir del ancho
; REAL del anterior (medido con WinGetPos), y esta constante es solo el
; margen que se deja entre uno y el siguiente.
PANEL_GAP := 6

; Layouts fijos de los 3 paneles flotantes (Deslizador/Circulo/AccesoRapido)
; VALORES POR DEFECTO (respaldo calibrado en Artist Pro 16 Gen2 x: -2560 a -853)
; El layout real se guarda con Ctrl+F11 (Normal) / Ctrl+F12 (Enfoque).
LAYOUT_NORMAL := {
    ds: {x: -1059, y: 143, w: 383, h: 185},
    cc: {x: -676,  y: 143, w: 359, h: 295},
    ar: {x: -537,  y: 438, w: 220, h: 483},
    hc: {x: -2240, y: 1253, w: 1905, h: 104}
}
LAYOUT_ENFOQUE := {
    ds: {x: -836,  y: 136, w: 383, h: 185},
    cc: {x: -453,  y: 118, w: 359, h: 295},
    ar: {x: -317,  y: 413, w: 223, h: 483},
    hc: {x: -2240, y: 1253, w: 1905, h: 104}
}

; ┌──────────────────────────────────────────────────────────────────────┐
; │  PUNTOS DE CALIBRACIÓN — Artist Pro 16 Gen2 como 2do monitor          │
; │  (coordenadas absolutas de pantalla, DPI-aware)                       │
; │                                                                      │
; │  P1-P2    ocultar/mostrar (clics de AccionEnfoque: izq / der)         │
; │  P3-P14   3 botones IZQUIERDA, 4 puntos-esquina por botón             │
; │  P15-P26  3 botones DERECHA,   4 puntos-esquina por botón             │
; │  P27-P28  franja "peek" del historial de color (borde superior)       │
; │  P29      zona segura fuera del lienzo (rehacer con RButton)          │
; │  P30      AVISOS: esquina sup. izq. del HUD y del icono zoom/rotar    │
; │                                                                      │
; │  Los defaults corresponden al perfil 1 (Laptop + tableta).
; │  Estos son los VALORES POR DEFECTO. Los reales se editan desde el     │
; │  panel 📍 (botón junto al de recarga, o Ctrl+F10) y se guardan en      │
; │  posiciones_gui.ini [Puntos]; el .ini manda sobre estos valores.      │
; └──────────────────────────────────────────────────────────────────────┘
PUNTOS_DEF := [
    [1970, -154], [4437, -154],                                          ; P1-P2   ocultar / mostrar
    [1924, -132], [1976, -130], [1923,  -95], [1973,  -94],              ; P3-P6   izq B1
    [1925,  -91], [1973,  -89], [1926,  -55], [1975,  -55],              ; P7-P10  izq B2
    [1927,  -47], [1974,  -46], [1924,  -15], [1976,  -10],              ; P11-P14 izq B3
    [4423, -132], [4473, -131], [4423,  -99], [4476,  -98],              ; P15-P18 der B1
    [4425,  -90], [4474,  -89], [4423,  -55], [4473,  -55],              ; P19-P22 der B2
    [4426,  -47], [4472,  -47], [4424,  -13], [4475,  -10],              ; P23-P26 der B3
    [2246, 1158], [4136, 1156],                                          ; P27-P28 historial
    [2011, -225],                                                        ; P29     zona segura (derivada del P31 viejo + desplazamiento de P1)
    [2239,  -98]                                                         ; P30     avisos (HUD / icono zoom-rotar): esquina superior izquierda
]
PUNTOS    := []       ; valores vivos (defaults + .ini); los edita el panel 📍
AVISO_ESC := 1.0      ; escala de los avisos (HUD, mini-textos, toggles, icono zoom/rotar); por perfil, se edita en el panel 📍
HIST_ALTO := 104      ; alto (px) de la franja del historial bajo P27-P28; negativo = hacia arriba
ZONAS     := {}       ; rectángulos precalculados por RecalcularZonas()
; Perfiles de equipo: cada uno guarda SU juego de puntos y SUS posiciones de
; botones en el .ini ([Puntos1], [Puntos2]…). Se elige en el panel 📍; además,
; si la disposición de monitores cambia, se auto-selecciona el que coincida.
PERFILES := ["Laptop + tableta", "Monitor + tableta"]
PERFIL   := 1
ElegirPerfil()
; Escala de los botones flotantes (Slider/Circle/Quick/HC/🔒/🔄/📍), por perfil.
; 1.0 = tamaño original (el de Monitor + tableta). Se edita en el panel 📍.
ESC := 1.0
CargarEscala()
CargarEscalaAvisos()
CargarPuntos()

; ┌──────────────────────────────────────────────────────────────────────┐
; │  3. TIMERS                                                           │
; └──────────────────────────────────────────────────────────────────────┘
SetTimer(CheckReload,            600)
SetTimer(ChequearZonaHistorial,  200)
SetTimer(ChequearZonaAltA,        35)
SetTimer(ChequearZonaDerecha,     35)
SetTimer(LoopColorV,              80)
SetTimer(LoopColorCC,             80)
SetTimer(LoopAccesoRapido,        80)
; SetTimer(ResetEnfoque,         10000) ; DESACTIVADO: revertía enfoque.activo a false a los 10s y desincronizaba layouts
SetTimer(ResetAlphaStates,       500)
SetTimer(LimpiarAltPegadoPureRef, 150)
IniciarDeteccion()
; IniciarDialGUI() ; Desactivado a pedido: ya no se usa el GUI de tamaño/opacidad del dial
IniciarDsGUI()
IniciarCcGUI()
IniciarArGUI()
IniciarHCGUI()
IniciarLockGUI()
IniciarReloadGUI()
IniciarPuntosGUI()

; ┌──────────────────────────────────────────────────────┐
; │  4. HOTKEYS GLOBALES                                 │
; └──────────────────────────────────────────────────────┘
EsEditorTexto() => WinActive("ahk_exe notepad++.exe") || WinActive("ahk_exe notepad.exe")

#HotIf EsEditorTexto()
^s:: {
    SendInput("^s")
    Sleep(200)
    Reload()
}
^g:: {
    ; Doble chequeo: abortar si no es un editor de texto permitido
    if !(WinActive("ahk_exe notepad++.exe") || WinActive("ahk_exe notepad.exe"))
        return
    ts       := FormatTime(, "yyyy-MM-dd_HH-mm-ss")
    repoPath := "C:\Users\JOSUE\Desktop\AHK-global-main"
    gitExe   := "git"
    cmd      := gitExe ' -C "' repoPath '" add -A'
             .  ' && ' gitExe ' -C "' repoPath '" commit -m "auto_' ts '"'
             .  ' && ' gitExe ' -C "' repoPath '" push'
    Run('cmd /k "' cmd ' && timeout /t 3 && exit"', , "")
    SetTimer(_CheckGitDone, -5000)
}
#HotIf

#SuspendExempt
`:: {
    sys.modoEscritura := !sys.modoEscritura
    if (sys.modoEscritura) {
        Suspend(1)
        MostrarIndicador("🔴📝 MODO ESCRITURA — puedes escribir libremente 📝🔴")
    } else {
        Suspend(0)
        MostrarIndicador("🟢✅ MODO AHK ACTIVO — hotkeys habilitadas ✅🟢")
    }
}
#SuspendExempt False

; ┌──────────────────────────────────────────┐
; │  5a. RBUTTON GLOBAL — fuera de #HotIf   │
; │  Sin #HotIf para que Space & RButton    │
; │  no anule el standalone como prefix key │
; └──────────────────────────────────────────┘
; ┌──────────────────┐
; │  5. HOTKEYS CSP  │
; └──────────────────┘
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")

RButton:: {
    stylus.rButtonHeld     := true
    stylus.comboUsado      := false
    stylus.upSinteticoTick := 0
    ; Sin tilde — bloquea el down completamente, CSP no ve nada.
}
RButton up:: {
    elapsed := (stylus.upSinteticoTick > 0) ? (A_TickCount - stylus.upSinteticoTick) : 9999
    if (elapsed < UP_SINTETICO_MS) {
        stylus.rButtonHeld     := true
        stylus.upSinteticoTick := 0
        return
    }
    stylus.rButtonHeld := false
    if (!stylus.comboUsado)
        SendInput("{RButton}")   ; cuentagotas al soltar
}

Space & RButton:: {
    stylus.comboUsado := true
    _InvSeleccionConGUI()
}

Numpad0:: {
    hcOn := _ToggleHistorialColor()
    ActualizarHCGUI()
    MostrarHUD(hcOn ? "🟢 DYNAMIC HISTORY" : "🔒 HISTORY LOCKED", hcOn ? "00E5FF" : "FF6B00", 5000)
}

; Devuelve true si el historial quedó dinámico (ON), false si bloqueado (OFF).
_ToggleHistorialColor() {
    hist.modo := (hist.modo = 1) ? 2 : 1
    if (hist.modo = 2 && hist.abierto) {
        hist.abierto := false
        Send("{Numpad9}")
    }
    return (hist.modo = 1)
}

^s:: {
    SendInput("^s")
    SetTimer(() => SoundPlay(A_WinDir "\Media\notify.wav"), -1)
    MostrarHUD("💾 GUARDADO Y MODIFICADO", "44DD88", 800)
}

; ══════════════════════════════════════════════════════════════════
; RButton del stylus — LÓGICA GENERAL
;
; El driver reporta el clic derecho del stylus como INSTANTÁNEO
; (0-15ms). La lógica es: armar rButtonHeld al presionar, diferir
; la acción al soltar según si hubo combo o no.
;   sin combo → soltar manda {RButton} → cuentagotas en CSP
;   con combo → soltar no manda nada → cuentagotas absorbido
;
; POR QUÉ SIN TILDE EN RButton:: Y RButton up::
; Con tilde, el down nativo pasa a CSP y activa el cuentagotas
; inmediatamente al presionar, antes de saber si viene combo.
; Sin tilde, AHK intercepta el down antes de que llegue a CSP.
; Los combos ~RButton & X tienen su propia tilde y funcionan
; independientemente — quitarla aquí no los afecta.
;
; POR QUÉ comboUsado := true EN CADA ~RButton & X
; Si un combo no lo marca, al soltar RButton up:: ve comboUsado=false
; y manda el cuentagotas igual, aunque se haya usado un combo.
; Regla: todo hotkey ~RButton & X debe tener esa línea al inicio.
;
; ── REHACER (RButton + Ctrl+Z del miniteclado) ──────────────────
;
; POR QUÉ {RButton up} SINTÉTICO ANTES DE ^y
; CSP ignora atajos de historial mientras RButton está físicamente
; sostenido — lo trata como herramienta temporal activa. Solución:
; mandar {RButton up} sintético para que CSP "vea" el botón soltado.
; Ese up sintético también dispara RButton up:: — hay que ignorarlo
; sin resetear rButtonHeld (de lo contrario se rompe rehacer múltiple).
;
; POR QUÉ EL CURSOR SE MUEVE A (2775, 11) ANTES DEL UP SINTÉTICO
; Sin tilde el down no llegó a CSP, pero el up sintético sí llegaría
; como un up huérfano que CSP podría interpretar de formas raras.
; Moverlo a zona segura fuera del lienzo lo hace inofensivo.
;
; CÓMO SE DISTINGUE UP SINTÉTICO VS UP REAL (upSinteticoTick)
; Se marca upSinteticoTick = A_TickCount justo antes del up sintético.
; En RButton up:: elapsed = A_TickCount - upSinteticoTick.
; Sintético llega en 20-40ms, real en ≥100ms. Umbral = UP_SINTETICO_MS.
; elapsed < umbral → sintético: re-afirmar rButtonHeld, ignorar.
; elapsed ≥ umbral → real: resetear y procesar normalmente.
;
; botonSostenido: evita mandar up sintético en cada repetición de
; key repeat de Ctrl+Z. Solo el primer tap lo manda; las repeticiones
; van directo a ^y porque CSP ya "vio" el botón soltado.
; Se resetea en $^z up:: al soltar la tecla.
;
; CAMINOS DESCARTADOS
; ignorarProximoUp — bandera consumible, se desincronizaba con
;   key repeat (varios ups sintéticos consecutivos).
; GetKeyState("RButton","P") — el up sintético también lo afecta,
;   reporta "soltado" aunque el físico siga abajo.
; MODO_REHACER_MS — timer de expiración, funcional pero con espera
;   artificial de 200-600ms antes de poder volver a deshacer.
; ══════════════════════════════════════════════════════════════════
; Puntos de estabilización en CSP:
; Rango de trabajo definido por el usuario: Mínimo = 7, Máximo = 75.
; Para garantizar que NUNCA se quede en un estado intermedio (15, 35, 55) ni se desincronice,
; reseteamos a 0 con {j 100} y luego alcanzamos el valor objetivo.


~!b:: {
    ; Ignorar el "down" sintético que nosotros mismos generamos en
    ; __AltF_SEND_NORMAL (forzar {b up}{b down} porque "Smear" en CSP
    ; es justo la tecla "b" — la misma que sostienes para este combo).
    ; Mismo criterio que RButton up:: (upSinteticoTick / UP_SINTETICO_MS).
    elapsedB := (stylus.bSinteticoTick > 0) ? (A_TickCount - stylus.bSinteticoTick) : 9999
    if (elapsedB < UP_SINTETICO_MS) {
        stylus.bSinteticoTick := 0
        return
    }
    if (stylus.smearSend)
        return
    stylus.altActive := true
}
~!b up:: {
    ; Mismo filtro que arriba, para el "up" sintético del mismo forzado.
    elapsedB := (stylus.bSinteticoTick > 0) ? (A_TickCount - stylus.bSinteticoTick) : 9999
    if (elapsedB < UP_SINTETICO_MS) {
        stylus.bSinteticoTick := 0
        return
    }
    ; Forzamos el estado real de Alt a "arriba" justo aquí, sin importar
    ; qué haya dejado cualquier SendEvent("{Alt up}X{Alt down}") de los
    ; handlers de arriba (x/w/-/e/s con Alt+B sostenido). Esto evita que
    ; stylus.altActive se quede pegado en true si el "up" físico llega
    ; justo en medio de uno de esos toggles sintéticos.
    Send("{Alt up}")
    stylus.altActive := false
    if (stylus.smearSend) {
        stylus.smearSend := false
        SendInput("b")
        MostrarHUD("SMEAR", "AA44FF", 950)
    }
}

; ┌───────────────────────────────┐
; │  5a. SELECCIÓN Y RESELECCIÓN  │
; └───────────────────────────────┘

c:: _InvSeleccionConGUI()

; Misma lógica de la tecla c pura (icono 🔄/🔁 + color rojo/verde que
; alterna, más los beeps). La comparten c:: y Space & RButton, así
; comparten también el estado sel.estadoC.
_InvSeleccionConGUI() {
    if (sel.estadoC = 0) {
        MostrarMiniTexto("🔄 INV. ÁREA SELECC.", "FF6F61", 900)
        SoundBeep(280, 120)
        SoundBeep(220, 160)
        sel.estadoC := 1
        SetTimer(__ResetEstadoC, -2000)
    } else {
        MostrarMiniTexto("🔁 INV. ÁREA SELECC.", "32CD32", 900)
        sel.estadoC := 0
        SetTimer(__ResetEstadoC, 0)
    }
    Send("c")
}

x:: {
    if stylus.altActive
        return
    if (sel.sRapido) {
        sel.sRapido := false
        MostrarMiniTexto("❌ DESELECCIÓN", "C0392B", 700)
        Send("x")
        sel.estado := 1
        return
    }
    if (sel.estado = 0) {
        MostrarMiniTexto("❌ DESELECCIÓN", "C0392B", 700)
        Send("x")
        sel.estado := 1
    } else {
        MostrarMiniTexto("✅ RESELECCIÓN", "27AE60", 1200)
        Send("{F10}")
        sel.estado := 0
    }
}

; ┌──────────────────────────┐
; │  5b. DESHACER / REHACER  │
; └──────────────────────────┘
$^z:: _DeshacerRehacer()

; Mask (Alt+M) — RButton + Ctrl+Z. botonSostenido evita que el auto-repeat
; de la tecla mantenida vuelva a alternar la máscara; se libera en
; "$^z up" / "~RButton & z up".
_MaskRButton() {
    stylus.comboUsado := true
    if (stylus.botonSostenido)
        return
    stylus.botonSostenido := true
    Send("!m")
    MostrarHUD("MASK (ALT+M)", "00E5FF", 900)
}

; Lógica compartida por $^z y ~RButton & z (cuando Ctrl está abajo).
_DeshacerRehacer() {
    ; De momento, con RButton sostenido este botón (K10, Ctrl+Z del
    ; keydial) es Mask (Alt+M) en vez de rehacer. Alt+B sigue rehaciendo.
    if (stylus.rButtonHeld) {
        _MaskRButton()
        return
    }
    if (stylus.rButtonHeld || stylus.altActive) {
        stylus.comboUsado := true
        if (!stylus.botonSostenido) {
            stylus.botonSostenido := true
            if (stylus.rButtonHeld) {
                ; RButton: mandar up sintético para desbloquear CSP
                stylus.upSinteticoTick := A_TickCount
                MouseGetPos(&origX, &origY)
                MouseMove(PUNTOS[29][1], PUNTOS[29][2], 0)   ; zona segura fuera del lienzo (P29, editable en el panel 📍) — no cambia color
                SendInput("{RButton up}")     ; libera RButton a nivel de CSP
                SendInput("^y")
                MouseMove(origX, origY, 0)
            } else {
                ; altActive (Alt+B): no hay RButton sostenido, rehacer directo
                SendInput("^y")
            }
        } else {
            ; Key repeat — CSP ya "vio" el botón soltado, solo rehacer
            SendInput("^y")
        }
        ToolTipCS("🟢 REHACER", 600)
    } else {
        SendInput("^z")
        ToolTipCS("🔴 DESHACER", 300)
    }
}
$^z up:: {
    stylus.botonSostenido := false
}
!z:: {
    SendInput("^c")
    SoundPlay(A_WinDir "\Media\ding.wav")
    ToolTipCS("📋 COPIAR", 600)
}
; Alt+B (altActive) + Ctrl+Z — Alt físico sostenido intercepta antes de $^z,
; por eso se registra como !^z separado. botonSostenido comparte el mismo flag
; para que key repeat funcione igual que con RButton.
!^z:: {
    if (!stylus.botonSostenido) {
        stylus.botonSostenido := true
        SendInput("^y")
    } else {
        SendInput("^y")
    }
    ToolTipCS("🟢 REHACER", 600)
}
!^z up:: {
    stylus.botonSostenido := false
}

; Excluye PureRef: este bloque es GLOBAL (sin ventana). Si altActive quedaba pegado,
; la Z / Alt+Space en PureRef caían aquí (z → Ctrl+C se veía como Alt+C, y Alt+Space → flip).
#HotIf stylus.altActive && !WinActive("ahk_exe PureRef.exe")
z:: {
    SendInput("^c")
    SoundPlay(A_WinDir "\Media\ding.wav")
    ToolTipCS("📋 COPIAR", 600)
}
w:: {
    Send("+s")
    MostrarHUD("SHIFT+S", "00E5FF", 800)
}
-:: {
    _CicloO()
}
e:: {
    MostrarHUD("ALL LAYERS ERASER", "FF4444", 800)
    Send("{F5}")
}
; SWAP: x/a ahora disparan color mix/smudge (antes era layer/all layers);
; s ahora dispara layer/all layers (antes era color mix/smudge).
x:: {
    if (AltB_a_state.lastPress = 1) {
        AltB_a_state.lastPress := 0
        SendEvent("p")
        MostrarHUD("SMUDGE  (P)", "FF6B00", 950)
    } else {
        AltB_a_state.lastPress := 1
        SendEvent("d")
        MostrarHUD("COLOR MIX  (D)", "FF8C42", 950)
    }
}
a:: {
    now := A_TickCount
    if (now - AltB_a_state.lastPress < 2400) {
        AltB_a_state.lastPress := 0
        Send("p")
        MostrarHUD("SMUDGE  (P)", "FF6B00", 950)
    } else {
        AltB_a_state.lastPress := now
        Send("d")
        MostrarHUD("COLOR MIX  (D)", "FF8C42", 950)
    }
}
s:: {
    now := A_TickCount
    if (now - AltB_s_state.lastPress < 2400) {
        AltB_s_state.lastPress := 0
        SendInput("{F7}")
        MostrarHUD("ALL LAYERS (2)", "FF6B00", 3140)
    } else {
        AltB_s_state.lastPress := now
        SendInput("{Blind}a")
        MostrarHUD("LAYER CURRENT (1)", "00E5FF", 950)
    }
}
; Respaldo bare (sin Alt detectado por Windows) para smear — mismo patrón
; EXACTO que s:: de arriba, solo con los valores intercambiados, más el
; bloqueo de auto-repeat (F se usa sostenida, s/x no).
f:: {
    if AltF_state.held
        return
    AltF_state.held := true
    now := A_TickCount
    if (now - AltF_state.lastPress < 2400) {
        AltF_state.lastPress := 0
        SendInput("{NumpadEnd}")
        MostrarHUD("SMEAR SOFT  (2)", "FF6B00", 950)
    } else {
        AltF_state.lastPress := now
        ; Mismo choque que en __AltF_SEND_NORMAL: "b" es la misma tecla
        ; que sostienes para el combo, así que forzamos {b up}{b down}
        ; marcado como sintético para que ~!b::/~!b up:: lo ignoren.
        stylus.bSinteticoTick := A_TickCount
        SendInput("{Blind}{b up}{b down}")
        MostrarHUD("SMEAR  (1)", "00E5FF", 950)
    }
}
f up:: {
    AltF_state.held := false
}

; FLIP HORIZONTAL (Alt+B del stylus + Space)
; Reacciona inmediatamente para invertir el lienzo con respuesta ultra-rápida.
$!Space::
$Space:: {
    stylus.comboUsado := true
    SendInput("!g")
    MostrarHUD("FLIP HORIZONTAL", "888888", 700)
    SoundBeep(800, 100)
}
#HotIf

#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")

; ┌────────────────────┐
; │  5c. HERRAMIENTAS  │
; └────────────────────┘

; ╔═══╗
; ║ A ║
; ╚═══╝
$a:: {
    if stylus.altActive
        return
    now := A_TickCount
    if (now - A_state.lastPress < 2400) {
        A_state.lastPress := 0
        SendInput("{F7}")
        MostrarHUD("ALL LAYERS (2)", "FF6B00", 3140)
    } else {
        A_state.lastPress := now
        SendInput("{Blind}a")
        MostrarHUD("LAYER CURRENT (1)", "00E5FF", 950)
    }
}

~RButton & a:: {
    stylus.comboUsado := true
    EnviarNtilde()
    MostrarHUD("REFERENCE LAYER", "AA44FF", 1680)
}

; ╔═══╗
; ║ E ║
; ╚═══╝
$e:: {
    global colorEstado
    now := A_TickCount
    if GetKeyState("Shift") {
        Send("e")
        return
    }
    ; Doble-tap (<300ms): cancelar el e ya enviado y lanzar l (soft eraser)
    if (now - E.last < 300) {
        E.last := 0
        SendInput("{e up}")
        if (colorEstado = 2) {
            Send("k")
            colorEstado := 0
        }
        Send("l")
        MostrarToolTipE("SOFT ERASER  (2)")
        return
    }
    ; Tap simple: mandar e inmediatamente
    E.last := now
    if (colorEstado = 2) {
        Send("k")
        colorEstado := 0
    }
    Send("e")
    MostrarToolTipE("ERASER  (1)")
}

~RButton & e:: {
    stylus.comboUsado := true
    Send("{F12}")
    SoundPlay(A_WinDir "\Media\Windows Recycle.wav")
    MostrarHUD("ERASER LAZO", "FF4444", 1200)
}

^e:: {
    MostrarHUD("ALL LAYERS ERASER", "FF4444", 800)
    Send("{F5}")
}

!e:: {
    MostrarHUD("ALL LAYERS ERASER", "FF4444", 800)
    Send("{F5}")
}

!q:: {
    Send("y")
    MostrarBadgeCombo("ALT + Q", "SOFT BRUSH", "FF6B00", 2200)
}

; Alt+1 = subir opacidad 10% (empieza en 100% asumido). Alt+2 = bajarla.
; Pensado para el keydial: cada "clic" del dial dispara un lanzamiento,
; así que cada giro mueve la opacidad de a 10 en 10 — 100→90 (Shift+9),
; otro giro→80 (Shift+8), y así, hasta un piso de 10% (CSP no tiene
; forma de mandar 0% con este atajo de un solo dígito).
; Alt como tecla PREFIJO (igual que RButton), no como modificador "!":
; así cada clic del dial dispara de nuevo mientras Alt siga sostenido,
; sin tener que soltarlo entre paso y paso.
~LAlt & 1::
~RAlt & 1:: {
    opacidad.nivel := Min(opacidad.nivel + 10, 100)
    _EnviarOpacidad()
}

~LAlt & 2::
~RAlt & 2:: {
    opacidad.nivel := Max(opacidad.nivel - 10, 10)
    _EnviarOpacidad()
}

; Acceso rápido (mismo destino que la tecla física PageDown).
!Home:: {
    Send("{PageDown}")
    MostrarHUD("ACCESO RÁPIDO", "AA8844", 800)
}

!-:: {
    _CicloO()
}

; ╔═══╗
; ║ W ║
; ╚═══╝
$w:: {
    global colorEstado
    now := A_TickCount
    ; Doble-tap (<300ms): toggle alpha y reseleccionar w
    if (now - W.last < 300) {
        W.last := 0
        if (colorEstado = 2) {
            SendInput("k")
            colorEstado := 0
            SendInput("{Blind}w")
            MostrarMiniTexto("💨 AERÓGRAFO", "1A1A2E", 1200)
        } else {
            if (colorEstado = 1)
                SendInput("^2")
            SendInput("k")
            colorEstado := 2
            SendInput("{Blind}w")
            MostrarMiniTexto("⚪ AERÓGRAFO ALPHA", "1C6EA4", 1200)
            SoundPlay(A_ScriptDir "\sonidos\alpha_short.wav")
        }
        return
    }
    ; Tap simple: mandar w inmediatamente
    W.last := now
    SendInput("{Blind}w")
    MostrarMiniTexto(colorEstado = 2 ? "⚪ AERÓGRAFO ALPHA" : "💨 AERÓGRAFO", colorEstado = 2 ? "1C6EA4" : "1A1A2E", 1200)
}

; ╔═══╗
; ║ Z ║
; ╚═══╝
; z normal (un solo tap) = z INSTANTÁNEO, con tooltip de lupa 🔍
; z rápido (doble-tap, <300ms) = cancela el z ya enviado con {z up}
;   y lanza r, con tooltip de mano ✋. El primer tap nunca espera.
; Solo aplica cuando stylus.altActive = false — cuando es true, el
; z:: bajo #HotIf stylus.altActive (rehacer) tiene prioridad y este
; ni se evalúa.
$z:: {
    now := A_TickCount
    if (now - Z.last < 300) {
        ; Doble-tap: cancelar el z ya enviado y lanzar r
        Z.last         := 0
        Z.timerRunning := 0
        SendInput("{z up}")
        SendInput("r")
        MostrarToolTipZ("✋ R", 800)
        return
    }
    ; Primer tap: disparar z inmediatamente, sin esperar
    Z.last         := now
    Z.timerRunning := 1
    SendInput("{Blind}z")
    MostrarToolTipZ("🔍 Z", 800)
}

; ╔═══╗
; ║ Q ║
; ╚═══╝
$q:: {
    if GetKeyState("Alt", "P") {
        Send("!q")
        return
    }
    now := A_TickCount
    if (now - Q.last < 300) {
        Q.last := 0
        SetTimer(__Q_SEND_NORMAL, 0)
        global colorEstado
        if (colorEstado = 2) {
            Send("k")
            colorEstado := 0
        }
        SendInput("^2")
        if (colorEstado = 0) {
            colorEstado := 1
            MostrarMiniTextoOscuro("🟡 COLOR SECUNDARIO", "51D67B", 1200)
            SoundPlay(A_WinDir "\Media\Windows Notify.wav")
        } else {
            colorEstado := 0
            MostrarMiniTexto("🔵 COLOR PRIMARIO", "2B3B32", 1200)
        }
        return
    }
    Q.last := now
    if GetKeyState("RButton", "P") {
        AlternarEstabilizacion()
        return
    }
    SetTimer(__Q_SEND_NORMAL, -50)
}

$*-:: {
    AlternarEstabilizacion()
}

_ToggleLayerVis() {
    SendEvent("{Alt up}{Shift down}d{Shift up}")
    MostrarHUD(N6.layerVis ? "🚫 HIDE LAYER" : "👁 SHOW LAYER", N6.layerVis ? "FF4444" : "44DD88", 600)
    N6.layerVis := !N6.layerVis
}

+w:: {
    hoverOn := _ToggleHoverPaneles()
    ActualizarDsGUI()
    ActualizarCcGUI()
    ActualizarArGUI()
    if (hoverOn)
        MostrarMiniTexto("🟠 HOVER ON — deslizador + círculo + acceso rápido", "1E8449", 1200)
    else
        MostrarMiniTexto("👁 HOVER OFF — paneles visibles", "1A5276", 1200)
}

+q:: {
    Send("y")
    MostrarHUD("SOFT (Y)", "00E5FF", 800)
}

; ── Alt+J — mismo toggle que +w, refleja el estado en los 3 botones ──
!j:: {
    hoverOn := _ToggleHoverPaneles()
    ActualizarDsGUI()
    ActualizarCcGUI()
    ActualizarArGUI()
    if (hoverOn)
        MostrarTooltipToggle("HOVER ACTIVO", "▶", "verde")
    else
        MostrarTooltipToggle("HOVER PAUSADO", "⏸", "rojo")
}

; ══════════════════════════════════════════════════════════════════
; _SetColorV / _SetColorCC / _SetAR — fuerzan el panel correspondiente
; al estado "on" indicado (true=hover activo, false=panel fijo visible).
; Devuelven el mismo "on" recibido. Son la base de los toggles
; individuales (botones separados) y del toggle combinado (+q/Alt+J).
; ══════════════════════════════════════════════════════════════════
; ══════════════════════════════════════════════════════════════════
; _FadeAlpha — transición gradual de opacidad en vez de un salto
; instantáneo (5→255 o 255→5). El salto brusco es lo que se percibía
; como un "refresh"/destello al activar-desactivar el modo fijo-visible
; de estos paneles reales de CSP. Con 6 pasos de ~10ms (≈60ms total)
; el cambio se ve como un fundido rápido, no como un parpadeo.
; ══════════════════════════════════════════════════════════════════
_FadeAlpha(hwnd, hasta, pasos := 6, delayMs := 10) {
    try actual := WinGetTransparent("ahk_id " hwnd)
    if (actual = "" || !IsNumber(actual))
        actual := hasta
    if (actual = hasta)
        return
    paso := (hasta - actual) / pasos
    valor := actual
    Loop pasos {
        valor += paso
        v := Round(valor)
        v := (v < 0) ? 0 : (v > 255 ? 255 : v)
        try WinSetTransparent(v, "ahk_id " hwnd)
        Sleep(delayMs)
    }
    try WinSetTransparent(hasta, "ahk_id " hwnd)
}

_SetColorV(on) {
    colorV.hover := on
    colorV.dsVis := !on
    if (on)
        colorV.supresionHasta := A_TickCount + 400
    if (colorV.dsID && WinExist("ahk_id " colorV.dsID)) {
        SetTimer(LoopColorV, 0)
        if (on) {
            _FadeAlpha(colorV.dsID, 5)
            try WinSetExStyle("+0x20", "ahk_id " colorV.dsID)
        } else {
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
            try WinSetExStyle("-0x20", "ahk_id " colorV.dsID)
            _FadeAlpha(colorV.dsID, 255)
        }
        SetTimer(LoopColorV, 80)
    }
    return on
}

_SetColorCC(on) {
    colorCC.hover := on
    colorCC.dsVis := !on
    if (on)
        colorCC.supresionHasta := A_TickCount + 400
    if (colorCC.id && WinExist("ahk_id " colorCC.id)) {
        SetTimer(LoopColorCC, 0)
        if (on) {
            _FadeAlpha(colorCC.id, 5)
            try WinSetExStyle("+0x20", "ahk_id " colorCC.id)
        } else {
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
            try WinSetExStyle("-0x20", "ahk_id " colorCC.id)
            _FadeAlpha(colorCC.id, 255)
        }
        SetTimer(LoopColorCC, 80)
    }
    return on
}

_SetAR(on) {
    ar.hover := on
    ar.dsVis := !on
    if (ar.id && WinExist("ahk_id " ar.id)) {
        SetTimer(LoopAccesoRapido, 0)
        if (on) {
            _FadeAlpha(ar.id, 5)
            try WinSetExStyle("+0x20", "ahk_id " ar.id)
        } else {
            if IsObject(ar.bAR)
                ar.bAR.Hide()
            try WinSetExStyle("-0x20", "ahk_id " ar.id)
            _FadeAlpha(ar.id, 255)
        }
        SetTimer(LoopAccesoRapido, 80)
    }
    return on
}

; Toggles individuales — usados por el click de cada botón GUI propio.
_ToggleColorV()  => _SetColorV(!colorV.hover)
_ToggleColorCC() => _SetColorCC(!colorCC.hover)
_ToggleAR()      => _SetAR(!ar.hover)

; ══════════════════════════════════════════════════════════════════
; _ToggleHoverPaneles — pausa/reactiva los 3 paneles flotantes juntos
; (deslizador de color, círculo de colores, acceso rápido), tomando
; colorV como referencia del estado actual. Devuelve true si quedaron
; ON, false si quedaron OFF. Compartida por +q y Alt+J.
; ══════════════════════════════════════════════════════════════════
_ToggleHoverPaneles() {
    target := !colorV.hover
    _SetColorV(target)
    _SetColorCC(target)
    _SetAR(target)
    return target
}

; ╔═══╗

; ║ S ║
; ╚═══╝
; Alt+S (stylus Alt+B + S miniteclado) → mismo toggle que $s con stylus.altActive

; SWAP: !x ahora dispara color mix/smudge (antes layer/all layers);
; !s ahora dispara layer/all layers (antes color mix/smudge).
; Alt+X es el atajo "Borde de selección" de CSP. Este hotkey solo existe con
; Alt+B del stylus sostenido (#HotIf) y usa "$" (hook): así el Alt+X real del
; teclado y el que manda el propio script (S rápido, doble toque de Space, Esc)
; llegan a CSP en vez de ser absorbidos por este hotkey.
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe") && stylus.altActive
$!x:: {
    now := A_TickCount
    if (now - AltB_a_state.lastPress < 300) {
        SetTimer(__AltX_SEND_NORMAL, 0)
        AltB_a_state.timerRunning := 0
        AltB_a_state.lastPress := 0
        SendEvent("{Alt up}p{Alt down}")
        MostrarHUD("SMUDGE  (P)", "FF6B00", 950)
        return
    }
    AltB_a_state.lastPress     := now
    AltB_a_state.timerRunning  := 1
    SetTimer(__AltX_SEND_NORMAL, -250)
}
#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")

__AltX_SEND_NORMAL() {
    if !AltB_a_state.timerRunning
        return
    AltB_a_state.timerRunning := 0
    ; Mismo caso que __AltF_SEND_NORMAL — ver comentario ahí.
    seguiaSostenido := stylus.altActive
    SendEvent("{Alt up}d")
    if (seguiaSostenido)
        SendEvent("{Alt down}")
    MostrarHUD("COLOR MIX  (D)", "FF8C42", 950)
}

!s:: {
    if !stylus.altActive
        return
    now := A_TickCount
    if (now - AltB_s_state.lastPress < 300) {
        SetTimer(__AltS_SEND_NORMAL, 0)
        AltB_s_state.timerRunning := 0
        AltB_s_state.lastPress := 0
        SendEvent("{Alt up}{F7}{Alt down}")
        MostrarHUD("ALL LAYERS (2)", "FF6B00", 3140)
        return
    }
    AltB_s_state.lastPress     := now
    AltB_s_state.timerRunning  := 1
    SetTimer(__AltS_SEND_NORMAL, -250)
}

__AltS_SEND_NORMAL() {
    if !AltB_s_state.timerRunning
        return
    AltB_s_state.timerRunning := 0
    ; Mismo caso que __AltF_SEND_NORMAL — ver comentario ahí.
    seguiaSostenido := stylus.altActive
    SendEvent("{Alt up}a")
    if (seguiaSostenido)
        SendEvent("{Alt down}")
    MostrarHUD("LAYER CURRENT (1)", "00E5FF", 950)
}

$s:: {
    if stylus.altActive
        return
    ; Si Alt físico está presionado (!s lo maneja), no hacer nada
    if GetKeyState("Alt", "P")
        return
    if (stylus.altActive) {
        Send("d")
        MostrarHUD("COLOR MIX  (D)", "FF8C42", 950)
        return
    }
    ; Doble toque rápido de S → ÁREA CON COLOR (Ctrl+X + F7).
    ; Se mide con un tick propio (S.lastTick) en vez de A_PriorHotkey: ese valor
    ; se pisa si cualquier otro hotkey dispara entre los dos toques (y el keydial
    ; puede mandar eventos extra), y con 250 ms el doble toque casi nunca entraba.
    ahora    := A_TickCount
    esRapido := (S.lastTick > 0 && ahora - S.lastTick < S_RAPIDO_MS)
    S.lastTick := esRapido ? 0 : ahora   ; tras disparar se reinicia: un 3.er toque ya no re-dispara
    if (esRapido) {
        S.skipNext := true
        sel.sRapido := true
        MostrarMiniTexto("🟢 ÁREA CON COLOR", "27AE60", 1200)
        SendInput("^x")
        SendEvent("{F7}")
        ; Ocultar borde de selección (Alt+X en CSP: "Borde de selección"). Mismos
        ; flags que el doble toque de Space, para que Esc lo restaure igual.
        Send("{Alt down}{x}{Alt up}")
        sel.guiActivo  := true
        sel.estadoAltX := true
        SetTimer(ResetEstadoAltX, -3000)
        SoundPlay(A_WinDir "\Media\Windows Exclamation.wav")
        return
    }
    if (GetKeyState("Space", "P") || spc.selectArmed) {
        S.skipNext := true
        if (spc.selectArmed)
            SetTimer(_DesarmarSpaceSelect, -500)   ; cada S encadenado reinicia la ventana corta
        if (S.estadoCaracter = 0) {
            Send(",")
            MostrarTooltipToggle("AGREGAR A SELECCION", "+", "verde")
            S.estadoCaracter := 1
        } else {
            Send(".")
            MostrarTooltipToggle("ELIMINAR SELECCIÓN", "–", "rojo")
            S.estadoCaracter := 0
        }
        SetTimer(QuitarTooltipToggle, -1500)
        return
    }
    if S.skipNext {
        S.skipNext := false
        return
    }
    Send("s")
    SetTimer(() => MostrarHUD("LASSO", "FF6B00", 950), -1)
}

; ╔═══╗
; ║ O ║
; ╚═══╝
$o:: {
    _CicloO()
}

_CicloO() {
    O.ciclo := Mod(O.ciclo, 3) + 1
    if (O.ciclo = 1) {
        Send("h")
        MostrarMiniTexto("🔍 BUSCAR CAPAS (1/3)", "1A5276", 1200)
    } else if (O.ciclo = 2) {
        SendInput("{Ctrl down}{Numpad1}{Ctrl up}")
        MostrarMiniTexto("🎨 COLOR CAPA (2/3)", "6C3483", 1200)
    } else {
        SendInput("{Ctrl down}{Numpad2}{Ctrl up}")
        MostrarMiniTexto("🗑 BORRAR COLOR CAPA (3/3)", "424949", 1200)
    }
}

$Escape:: {
    if (O.ciclo != 0) {
        O.ciclo := 0
        MostrarMiniTexto("↺ CICLO O RESETADO", "555555", 900)
    }
    global colorEstado
    if (colorEstado = 2) {
        colorEstado := 0
        Send("k")
        MostrarMiniTexto("🎨 ALPHA RESETEADO", "555555", 900)
    }
    if (sel.guiActivo) {
        sel.guiActivo  := false
        sel.estadoAltX := false
        sel.estado     := 0
        Send("{Alt down}{x}{Alt up}")
        SetTimer(ResetEstadoAltX, 0)
        MostrarMiniTexto("↩ SELECCIÓN CANCELADA", "C0392B", 700)
        Send("x")
        Send("{Escape}")
        return
    }
    Send("{Escape}")
}

+r:: {
    MostrarHUD("REFLEJAR HORIZONTAL", "00E5FF", 1500)
    Send("+r")
}

Tab:: AccionEnfoque()
F3::  AccionEnfoque()

; f nativo para herramientas CSP (modo enfoque eliminado de f por completo)
~f:: {
}

; ┌─────────────────────────────────────┐
; │  5d. ATAJOS CON CLIC DERECHO        │
; └─────────────────────────────────────┘
~RButton & s:: {
    stylus.comboUsado := true
    MostrarHUD("LAZO CON AUTORELLENO", "FF6B00", 1200)
    SoundPlay(A_ScriptDir "\sonidos\fill_loud.wav")
    Send("{F9}")
}

~RButton & q:: {
    stylus.comboUsado := true
    Send("{F6}")
    MostrarBadgeCombo("PEN + Q", "HARD BRUSH", "FF6B00", 2200)
}

; "Shift sostenido": mantiene Shift realmente presionado (a nivel de
; sistema) para poder encadenar varios atajos con Shift sin tener que
; sostenerlo físicamente. Ya no se suelta solo — es un toggle: un
; lanzamiento lo activa, el siguiente lanzamiento lo desactiva.
~RButton & f:: {
    stylus.comboUsado := true
    shiftSostenido.activo := !shiftSostenido.activo
    if (shiftSostenido.activo) {
        Send("{Shift down}")
        SoundPlay(A_WinDir "\Media\Windows Foreground.wav")
        MostrarHUD("SHIFT SOSTENIDO", "AA8844", 900)
    } else {
        Send("{Shift up}")
        SoundPlay(A_WinDir "\Media\Windows Background.wav")
        MostrarHUD("SHIFT LIBERADO", "555555", 700)
    }
}

~RButton & w:: {
    stylus.comboUsado := true
    EnviarNtilde()
    MostrarBadgeCombo("PEN + W", "DIFU MIXER 2", "00E5FF", 2200)
}

!w:: {
    EnviarMenor()
    MostrarBadgeCombo("ALT + W", "★ OPC PRESSURE 2", "00E5FF", 2200)
}

; Antes disparaba AlternarEstabilizacion() (igual que "-" suelta); ahora
; el combo con RButton manda directamente "t". "-" suelta (sin RButton)
; sigue intacta más abajo (*-::) para el estabilizador.
~RButton & -:: {
    stylus.comboUsado := true
    now := A_TickCount
    ; Doble toque rápido (<300ms) del mismo combo → ocultar regla (Alt+T)
    if (now - RM.last < 300) {
        RM.last := 0
        Send("!t")
        MostrarHUD("OCULTAR REGLA", "1A1A2E", 800)
        return
    }
    RM.last := now
    Send("t")
    MostrarHUD("Rule", "1A1A2E", 800)
}

~RButton & z:: {
    stylus.comboUsado := true
    ; Ctrl+Z con RButton sostenido también coincide con este combo y
    ; disparaba el pegado. Si Ctrl está abajo, es rehacer, no pegar.
    ; Estado LÓGICO (sin "P"): el keydial manda Ctrl+Z por driver, no como
    ; teclas físicas, así que el estado físico de Ctrl siempre era falso.
    if GetKeyState("Ctrl") {
        _MaskRButton()
        return
    }
    Send("^v")
    SoundPlay(A_WinDir "\Media\notify.wav")
    MostrarHUD("📋 PEGAR (CTRL+V)", "44DD88", 800)
}

~RButton & z up:: {
    stylus.botonSostenido := false
}

~RButton & x:: {
    stylus.comboUsado := true
    Send("u")
    MostrarHUD("GRADIENT (U)", "00E5FF", 900)
}

; RButton+1 = Fill (V). RButton+2 = Advanced fill (F11).
~RButton & 1:: {
    stylus.comboUsado := true
    MostrarToolTipE("FILL  (V)")
    Send("v")
}

~RButton & 2:: {
    stylus.comboUsado := true
    Send("{F11}")
    MostrarHUD("Advanced fill", "AA8844", 800)
}

_EnviarOpacidad() {
    key := (opacidad.nivel = 100) ? "0" : String(opacidad.nivel // 10)
    SendInput("+" key)
    ActualizarDialGUI()
    MostrarHUD("OPACIDAD " opacidad.nivel "%", "00E5FF", 900)
}

~RButton & 3::
~RButton & 4::
~RButton & 5::
~RButton & 6::
~RButton & 7::
~RButton & 8::
~RButton & 9::
~RButton & 0:: {
    stylus.comboUsado := true
    key        := SubStr(A_ThisHotkey, StrLen(A_ThisHotkey))
    porcentaje := (key = "0") ? 100 : Integer(key) * 10
    opacidad.nivel := porcentaje
    SendInput("+" key)
    ActualizarDialGUI()
    MostrarHUD("OPACIDAD " porcentaje "%", "00E5FF", 900)
}

; ┌─────────────────────────────────────┐
; │  5e. DIAL — modo tamaño / opacidad  │
; └─────────────────────────────────────┘
; 1 y 2 = subir/bajar tamaño → modo 1
; 3 y 4 = subir/bajar opacidad → modo 2
; NumpadDiv = toggle manual entre modos
~1:: {
    if (dial.modo != 1) {
        dial.modo := 1
        ActualizarDialGUI()
    }
}
~2:: {
    if (dial.modo != 1) {
        dial.modo := 1
        ActualizarDialGUI()
    }
}
~3:: {
    if (dial.modo != 2) {
        dial.modo := 2
        ActualizarDialGUI()
    }
}
~4:: {
    if (dial.modo != 2) {
        dial.modo := 2
        ActualizarDialGUI()
    }
}
NumpadDiv:: {
    dial.modo := (dial.modo = 1) ? 2 : 1
    ActualizarDialGUI()
}

; ── PANIC BUTTON — reinicio de emergencia de todas las GUIs ──────
Numpad8:: {
    _LimpiarGUIs()
    ; Destruir dial incondicionalmente con fallback nuclear
    dialHwnd := 0
    try dialHwnd := dial.g.Hwnd
    try dial.g.Destroy()
    if (dialHwnd && DllCall("IsWindow", "Ptr", dialHwnd))
        DllCall("DestroyWindow", "Ptr", dialHwnd)
    dial.g     := 0
    dial.icono := 0
    dial.label := 0
    dial.barra := 0
    ; Desregistrar OnMessage antes de recrear, evita acumulación de handlers
    try OnMessage(0x0201, _DialWM_LBUTTONDOWN, 0)
    IniciarDialGUI()
    ; Mismo tratamiento para los botones SLIDER / CIRCLE / QUICK ON-OFF
    dsHwnd := 0
    try dsHwnd := dsGui.g.Hwnd
    try dsGui.g.Destroy()
    if (dsHwnd && DllCall("IsWindow", "Ptr", dsHwnd))
        DllCall("DestroyWindow", "Ptr", dsHwnd)
    dsGui.g     := 0
    dsGui.icono := 0
    dsGui.label := 0
    dsGui.barra := 0
    try OnMessage(0x0201, _DsGUI_WM_LBUTTONDOWN, 0)
    IniciarDsGUI()

    ccHwnd := 0
    try ccHwnd := ccGui.g.Hwnd
    try ccGui.g.Destroy()
    if (ccHwnd && DllCall("IsWindow", "Ptr", ccHwnd))
        DllCall("DestroyWindow", "Ptr", ccHwnd)
    ccGui.g     := 0
    ccGui.icono := 0
    ccGui.label := 0
    ccGui.barra := 0
    try OnMessage(0x0201, _CcGUI_WM_LBUTTONDOWN, 0)
    IniciarCcGUI()

    arHwnd := 0
    try arHwnd := arGui.g.Hwnd
    try arGui.g.Destroy()
    if (arHwnd && DllCall("IsWindow", "Ptr", arHwnd))
        DllCall("DestroyWindow", "Ptr", arHwnd)
    arGui.g     := 0
    arGui.icono := 0
    arGui.label := 0
    arGui.barra := 0
    try OnMessage(0x0201, _ArGUI_WM_LBUTTONDOWN, 0)
    IniciarArGUI()
    ; Mismo tratamiento para el botón HC ON/OFF
    hcHwnd := 0
    try hcHwnd := hcGui.g.Hwnd
    try hcGui.g.Destroy()
    if (hcHwnd && DllCall("IsWindow", "Ptr", hcHwnd))
        DllCall("DestroyWindow", "Ptr", hcHwnd)
    hcGui.g     := 0
    hcGui.icono := 0
    hcGui.label := 0
    hcGui.barra := 0
    try OnMessage(0x0201, _HCGUI_WM_LBUTTONDOWN, 0)
    IniciarHCGUI()
    ; Botón de fijar el bloque
    lockHwnd := 0
    try lockHwnd := lockGui.g.Hwnd
    try lockGui.g.Destroy()
    if (lockHwnd && DllCall("IsWindow", "Ptr", lockHwnd))
        DllCall("DestroyWindow", "Ptr", lockHwnd)
    lockGui.g     := 0
    lockGui.icono := 0
    lockGui.barra := 0
    try OnMessage(0x0201, _LockGUI_WM_LBUTTONDOWN, 0)
    IniciarLockGUI()
    ToolTip("🔄 GUIs reiniciadas")
    SetTimer(() => ToolTip(), -1000)
}

; ┌─────────────────────────────────────┐
; │  5f. MODIFICADORES DE CAPA          │
; └─────────────────────────────────────┘
~Space & NumpadAdd:: {
    Send("+p")
    MostrarMiniTexto("SPACE  +  +", "1E8449", 700)
}

~Space & NumpadSub:: {
    Send("^+p")
    MostrarMiniTexto("SPACE  +  −", "922B21", 700)
}

; Combo del keydial: mantienes Space presionado (pasa igual para la
; panorámica normal) y tocas w/x → Shift+w / Shift+s. Mismo patrón
; EXACTO que Space & NumpadAdd/NumpadSub de arriba.
~Space & w:: {
    Send("+w")
    MostrarMiniTexto("Up", "1E8449", 700)
}

; Mismo patrón EXACTO que Space & w de arriba.
~Space & x:: {
    Send("+s")
    MostrarMiniTexto("Down", "1E8449", 700)
}

; Mismo patrón EXACTO que Space & w / Space & x de arriba.
; Llama a _ToggleLayerVis() directamente — misma acción, mismo estado y
; mismo HUD ("HIDE LAYER"/"SHOW LAYER") que tenía antes Space & RButton.
~Space & e:: {
    _ToggleLayerVis()
}

; Space + q: activa/desactiva MODO ENFOQUE de forma ultra rápida
; Un toque entra a Enfoque (con su GUI y sonido), el siguiente vuelve a Modo Normal
~Space & q:: {
    AccionEnfoque()
}

; Space + s: Bloquear píxeles transparentes (Alpha Lock)
; Atajo asignado en tu CSP: Shift + F
~Space & s:: {
    SendInput("+f")
    SetTimer(() => SoundPlay(A_WinDir "\Media\chord.wav"), -1)
    MostrarHUD("🔒 BLOQUEO TRANSPARENCIA", "00E5FF", 900)
}

; Toggle Previsualización ICC Escala de Grises / Color (CSP nativo)
~Space & f:: {
    static estado := 0
    Send("{Insert}")
    if (estado = 0) {
        MostrarHUD("Gray scale", "888888", 1000)
        estado := 1
    } else {
        MostrarHUD("color", "FF4444", 1000)
        estado := 0
    }
}

~Space & Numpad1::
~Space & Numpad2::
~Space & Numpad3::
~Space & Numpad4::
~Space & Numpad5::
~Space & Numpad6:: {
    tecla := SubStr(A_ThisHotkey, StrLen(A_ThisHotkey))
    tipos := Map("1", "HSV (Hue / Sat / Val)"
               , "2", "Brillo / Contraste"
               , "3", "Equilibrio de color"
               , "4", "Curva de tonos"
               , "5", "Corrección de nivel"
               , "6", "Degradado")
    MostrarHUD("Capa: " tipos[tecla], "AA44FF", 500)
    Send("^!" tecla)
}



$Numpad6:: {
    Send("{Insert}")
    MostrarHUD("Grayscale Toggle", "888888", 800)
}

*Backspace:: {
    if GetKeyState("Space", "P") {
        Send("8")
        MostrarHUD("BORRAR CAPA DE CORRECCIÓN", "FF4444", 1200)
        return
    }
    Send("{Backspace}")
}

~Space:: {
    spc.downTick := A_TickCount
}

~Space up:: {
    held := A_TickCount - spc.downTick
    now  := A_TickCount

    ; Doble-tap de borde: umbral estricto (pensado para teclado físico).
    if (held <= 180) && (now - spc.last < 320) {
        spc.last := 0
        sel.guiActivo := true
        if sel.estadoAltX {
            MostrarMiniTexto("👁 MOSTRAR BORDE", "2ECC71", 1200)
            sel.estadoAltX := false
        } else {
            MostrarMiniTexto("🚫 OCULTAR BORDE", "E74C3C", 1200)
            sel.estadoAltX := true
        }
        Send("{Alt down}{x}{Alt up}")
        SetTimer(ResetEstadoAltX, -3000)
        return
    }
    if (held <= 180)
        spc.last := now

    ; Armar bifurcación Space+S: umbral más permisivo (450ms) porque el
    ; keydial tarda más en registrar el clic que una tecla física — un
    ; hold real de Space (paneo del lienzo) dura bastante más que eso.
    if (held <= 450) {
        spc.selectArmed := true
        SetTimer(_DesarmarSpaceSelect, -500)
    }
}

_DesarmarSpaceSelect() {
    spc.selectArmed := false
}

#HotIf

; ┌────────────────────────────────────────────────────────────────┐
; │  6. CLASE BorderFrame                                          │
; └────────────────────────────────────────────────────────────────┘
class BorderFrame {
    T := 0
    B := 0
    L := 0
    R := 0

    __New(color) {
        opts := "-Caption +AlwaysOnTop +ToolWindow +E0x20"
        for side in ["T", "B", "L", "R"] {
            g := Gui(opts)
            g.BackColor := color
            g.Show("w0 h0 NoActivate")
            this.%side% := g
        }
    }

    Show(x, y, w, h, g := 1) {
        ; Usar SetWindowPos directo (bypass del scaling de Gui.Show).
        ; Gui.Show interpreta coords como lógicas del monitor primario (dpi=120)
        ; y las escala — SetWindowPos recibe coords físicas del sistema directamente.
        SWP_NOACTIVATE := 0x10
        SWP_SHOWWINDOW := 0x40
        flags := SWP_NOACTIVATE | SWP_SHOWWINDOW
        DllCall("SetWindowPos", "Ptr", this.T.Hwnd, "Ptr", -1, "Int", x,       "Int", y,           "Int", w, "Int", g, "UInt", flags)
        DllCall("SetWindowPos", "Ptr", this.B.Hwnd, "Ptr", -1, "Int", x,       "Int", y + h - g,   "Int", w, "Int", g, "UInt", flags)
        DllCall("SetWindowPos", "Ptr", this.L.Hwnd, "Ptr", -1, "Int", x,       "Int", y,           "Int", g, "Int", h, "UInt", flags)
        DllCall("SetWindowPos", "Ptr", this.R.Hwnd, "Ptr", -1, "Int", x + w - g, "Int", y,         "Int", g, "Int", h, "UInt", flags)
        ; Opacidad reducida (120→85 de 255) para que el marco sea más sutil.
        WinSetTransparent(85, "ahk_id " this.T.Hwnd)
        WinSetTransparent(85, "ahk_id " this.B.Hwnd)
        WinSetTransparent(85, "ahk_id " this.L.Hwnd)
        WinSetTransparent(85, "ahk_id " this.R.Hwnd)
    }

    Hide() {
        this.T.Hide()
        this.B.Hide()
        this.L.Hide()
        this.R.Hide()
    }
}

; ┌────────────────────────────────────────────────────────────────┐
; │  7. FUNCIONES                                                  │
; └────────────────────────────────────────────────────────────────┘

; ══════════════════════════════════════════════════════════════════
; ObtenerMonitorCSP — devuelve {x, y, w, h} del monitor donde está
; la ventana principal de CSP. Fallback al monitor primario.
; ══════════════════════════════════════════════════════════════════
ObtenerMonitorCSP() {
    if (colorV.cspHwnd) {
        try {
            WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " colorV.cspHwnd)
            cx := wx + ww // 2
            cy := wy + wh // 2
            loop MonitorGetCount() {
                MonitorGet(A_Index, &mL, &mT, &mR, &mB)
                if (cx >= mL && cx < mR && cy >= mT && cy < mB)
                    return { x: mL, y: mT, w: mR - mL, h: mB - mT }
            }
        }
    }
    ; Fallback: monitor primario
    pri := MonitorGetPrimary()
    MonitorGet(pri, &mL, &mT, &mR, &mB)
    return { x: mL, y: mT, w: mR - mL, h: mB - mT }
}

IniciarDeteccion() {
    bestHwnd := 0
    bestArea := 0
    for hwnd in WinGetList("ahk_exe CLIPStudioPaint.exe") {
        try {
            WinGetPos(&tx, &ty, &tw, &th, "ahk_id " hwnd)
            if (tw * th > bestArea) {
                bestArea := tw * th
                bestHwnd := hwnd
            }
        }
    }
    colorV.cspHwnd := bestHwnd
    colorV.dsID := BuscarVentanaCSP(0, "eslizador", "colores")
    if (colorV.dsID) {
        colorV.bDS   := BorderFrame("44AA66")
        colorV.hover := true
        colorV.dsVis := false
        try WinSetTransparent(5,    "ahk_id " colorV.dsID)
        try WinSetExStyle("+0x20", "ahk_id " colorV.dsID)
    }
    colorCC.id := BuscarVentanaCSP(0, "rculo de colores", "olores")
    if (colorCC.id) {
        colorCC.bCC   := BorderFrame("AA6622")
        colorCC.hover := false
        colorCC.dsVis := true
        try WinSetTransparent(255,  "ahk_id " colorCC.id)
        try WinSetExStyle("-0x20", "ahk_id " colorCC.id)
    }
    ar.id := BuscarVentanaCSP(0, "Acceso r", "pido")
    if (ar.id) {
        ar.bAR   := BorderFrame("AA8844")
        ar.hover := false
        ar.dsVis := true
        try WinSetTransparent(255,  "ahk_id " ar.id)
        try WinSetExStyle("-0x20", "ahk_id " ar.id)
    }
}

BuscarVentanaCSP(idActual, frag1, frag2) {
    if (idActual) {
        try {
            if WinExist("ahk_id " idActual)
                return idActual
        }
    }
    for hwnd in WinGetList("ahk_exe CLIPStudioPaint.exe") {
        try {
            t := WinGetTitle("ahk_id " hwnd)
            if InStr(t, frag1) && InStr(t, frag2)
                return hwnd
        }
    }
    return 0
}

CheckReload() {
    newTime := FileGetTime(A_ScriptFullPath, "M")
    if (sys.lastModTime = "") {
        sys.lastModTime := newTime
        return
    }
    if (newTime != sys.lastModTime) {
        sys.lastModTime := newTime
        mon := ObtenerMonitorCSP()
        x := mon.x + (mon.w // 2) - 120
        y := mon.y + (mon.h // 2) - 20
        ToolTip("💾 Script actualizado y recargado", x, y)
        SoundBeep(750, 180)
        SoundBeep(950, 180)
        SoundBeep(850, 180)
        Sleep(300)
        ToolTip()
        Reload()
    }
}

; ══════════════════════════════════════════════════════════════════
; ChequearZonaHistorial — franja "peek" del panel Historial de color.
;   Zona derivada de P27-P28 (x entre ambos puntos; y desde el borde
;   superior hacia abajo HIST_ALTO px). Editable en el panel 📍.
; ══════════════════════════════════════════════════════════════════
ChequearZonaHistorial() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe")
        return
    if sys.modoEscritura
        return
    if (hist.modo = 2)
        return
    MouseGetPos(&mx, &my)
    z := ZONAS.hist
    enZona := (mx >= z.x1 && mx <= z.x2 && my >= z.y1 && my <= z.y2)
    if (enZona && !hist.abierto) {
        hist.abierto := true
        Send("{Numpad9}")
    } else if (!enZona && hist.abierto) {
        hist.abierto := false
        Send("{Numpad9}")
    }
}

; Si "Alt+B sostenido" quedó pegado y el foco está en PureRef, lo libera.
; El "up" (~!b up) solo se escucha con CSP activo; sin esto, al pasar a PureRef
; con el botón del lápiz sostenido, Alt se quedaba abajo y las teclas cambiaban.
LimpiarAltPegadoPureRef() {
    if !stylus.altActive
        return
    if !WinActive("ahk_exe PureRef.exe")
        return
    stylus.altActive := false
    Send("{Alt up}")
}

; ══════════════════════════════════════════════════════════════════
; ChequearZonaAltA — botones IZQUIERDA (3 zonas).
; Cada zona es el rectángulo que envuelve sus 4 puntos-esquina:
;   Botón 1 (P3-P6)    Botón 2 (P7-P10)    Botón 3 (P11-P14)
; Editable en el panel 📍 (ver PUNTOS / RecalcularZonas).
; ══════════════════════════════════════════════════════════════════
ChequearZonaAltA() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe")
        return
    if sys.modoEscritura
        return
    _ChequearBotones(btn, ZONAS.izq)
}

; ══════════════════════════════════════════════════════════════════
; ChequearZonaDerecha — botones DERECHA (3 zonas).
;   Botón 1 (P15-P18)  Botón 2 (P19-P22)  Botón 3 (P23-P26)
; ══════════════════════════════════════════════════════════════════
ChequearZonaDerecha() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe")
        return
    if sys.modoEscritura
        return
    _ChequearBotones(botDer, ZONAS.der)
}

; Lógica común: al ENTRAR a la zona de un botón se hace un clic ahí mismo;
; el flag (b1/b2/b3) evita repetir el clic mientras el lápiz siga dentro.
_ChequearBotones(estado, zonas) {
    MouseGetPos(&mx, &my)
    Loop 3 {
        z := zonas[A_Index]
        k := "b" A_Index
        enZona := (mx >= z.x1 && mx <= z.x2 && my >= z.y1 && my <= z.y2)
        if (enZona && !estado.%k%) {
            estado.%k% := true
            SendEvent("{Click " mx " " my "}")
        } else if (!enZona && estado.%k%)
            estado.%k% := false
    }
}

LoopColorV() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if (colorV.hover) {
            if (colorV.dsVis && colorV.dsID) {
                colorV.dsVis := false
                try WinSetTransparent(5,   "ahk_id " colorV.dsID)
                try WinSetExStyle("+0x20", "ahk_id " colorV.dsID)
            }
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
        }
        return
    }
    if (!colorV.dsID) {
        colorV.dsID := BuscarVentanaCSP(0, "eslizador", "colores")
        if (colorV.dsID) {
            colorV.bDS   := BorderFrame("44AA66")
            colorV.dsVis := false
            try WinSetTransparent(5,    "ahk_id " colorV.dsID)
            try WinSetExStyle("+0x20", "ahk_id " colorV.dsID)
        }
        return
    }
    try {
        if !WinExist("ahk_id " colorV.dsID) {
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
            colorV.dsID  := 0
            colorV.dsVis := false
            return
        }
        WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " colorV.dsID)
        if (wx != colorV.dsX || wy != colorV.dsY) {
            colorV.dsX := wx
            colorV.dsY := wy
            colorV.dsW := ww
            colorV.dsH := wh
        } else {
            wx := colorV.dsX
            wy := colorV.dsY
            ww := colorV.dsW
            wh := colorV.dsH
        }
    } catch {
        if IsObject(colorV.bDS)
            colorV.bDS.Hide()
        colorV.dsID  := 0
        colorV.dsVis := false
        return
    }
    ; Modo fijo (hover=false): el deslizador ya quedó permanentemente
    ; visible por el propio toggle. Ya refrescamos su posición arriba
    ; (para que el círculo pueda usarla en su propio cruce) — no
    ; tocamos su visibilidad aquí.
    if (!colorV.hover)
        return

    MouseGetPos(&mx, &my)
    enDS := (mx >= wx && mx <= wx+ww && my >= wy && my <= wy+wh)
    ; Zona círculo de colores → deslizador (dirección original pedida):
    ; - Círculo FIJO: se usa su geometría real (colorCC sigue refrescándola
    ;   aunque esté fijo).
    ; - Círculo en HOVER (ambos ocultos por defecto): se usa colorCC.dsVis,
    ;   que ya refleja "el mouse está encima ahora mismo" resuelto por
    ;   LoopColorCC. Así, pasar el mouse por el círculo sigue mostrando el
    ;   deslizador aunque ambos estén ocultos.
    ; Ojo: esto es a propósito unidireccional. El enlace inverso
    ; (deslizador→círculo) solo aplica cuando el deslizador está FIJO
    ; (ver LoopColorCC) — si también reaccionara en modo hover, pasar el
    ; mouse por CUALQUIERA de los dos encendería a los dos.
    enCirculo := false
    if (colorCC.id && colorCC.ccW > 0) {
        if (colorCC.hover)
            enCirculo := colorCC.dsVis
        else
            enCirculo := (mx >= colorCC.ccX && mx <= colorCC.ccX + colorCC.ccW
                       && my >= colorCC.ccY && my <= colorCC.ccY + colorCC.ccH)
    }
    if (A_TickCount < colorV.supresionHasta) {
        enDS := false
        enCirculo := false
    }
    if (enDS || enCirculo) {
        if (!colorV.dsVis) {
            colorV.dsVis := true
            try WinSetTransparent(255,  "ahk_id " colorV.dsID)
            try WinSetExStyle("-0x20", "ahk_id " colorV.dsID)
            if IsObject(colorV.bDS)
                colorV.bDS.Hide()
        }
    } else {
        if (colorV.dsVis) {
            colorV.dsVis := false
            try WinSetTransparent(5,    "ahk_id " colorV.dsID)
            try WinSetExStyle("+0x20", "ahk_id " colorV.dsID)
        }
        if IsObject(colorV.bDS)
            colorV.bDS.Show(wx, wy, ww, wh)
    }
}

; ══════════════════════════════════════════════════════════════════
; LoopColorCC — hover + borde para el Círculo de colores flotante.
; Detecta la ventana dinámica por título ("Circulo de colores"),
; actualiza su posición en colorCC.ccX/Y/W/H para que LoopColorV
; use esas coordenadas reales como zona de activación del deslizador.
; ══════════════════════════════════════════════════════════════════
LoopColorCC() {
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if (colorCC.hover) {
            if (colorCC.dsVis && colorCC.id) {
                colorCC.dsVis := false
                try WinSetTransparent(5,   "ahk_id " colorCC.id)
                try WinSetExStyle("+0x20", "ahk_id " colorCC.id)
            }
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
        }
        colorCC.ccW := 0
        return
    }
    if (!colorCC.id) {
        colorCC.id := BuscarVentanaCSP(0, "rculo de colores", "olores")
        if (colorCC.id) {
            colorCC.bCC   := BorderFrame("AA6622")
            colorCC.dsVis := false
            try WinSetTransparent(5,    "ahk_id " colorCC.id)
            try WinSetExStyle("+0x20", "ahk_id " colorCC.id)
        }
        return
    }
    try {
        if !WinExist("ahk_id " colorCC.id) {
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
            colorCC.id   := 0
            colorCC.dsVis := false
            colorCC.ccW  := 0
            return
        }
        WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " colorCC.id)
        colorCC.ccX := wx
        colorCC.ccY := wy
        colorCC.ccW := ww
        colorCC.ccH := wh
    } catch {
        if IsObject(colorCC.bCC)
            colorCC.bCC.Hide()
        colorCC.id   := 0
        colorCC.dsVis := false
        colorCC.ccW  := 0
        return
    }
    ; Modo fijo (hover=false): el panel ya quedó permanentemente visible
    ; por el propio toggle. Ya refrescamos su posición arriba (para el
    ; cruce con el deslizador) — no tocamos su visibilidad aquí.
    if (!colorCC.hover)
        return

    MouseGetPos(&mx, &my)
    dentro := (mx >= wx && mx <= wx+ww && my >= wy && my <= wy+wh)
    ; Cruce con el deslizador: solo cuando el deslizador está FIJO
    ; (hover=false) — ahí sí tiene sentido que pasar el mouse por él
    ; también muestre el círculo. Si el deslizador está en hover (ambos
    ; ocultos por defecto), no se activa el círculo desde acá: el enlace
    ; círculo→deslizador en ese caso es intencionalmente unidireccional
    ; (ver LoopColorV) — así, pasar el mouse por el deslizador solo por
    ; sí solo no enciende también al círculo.
    if (!dentro) {
        enDeslizador := false
        if (!colorV.hover && colorV.dsID && colorV.dsW > 0)
            enDeslizador := (mx >= colorV.dsX && mx <= colorV.dsX + colorV.dsW
                           && my >= colorV.dsY && my <= colorV.dsY + colorV.dsH)
        dentro := enDeslizador
    }
    if (A_TickCount < colorCC.supresionHasta)
        dentro := false
    if (dentro) {
        if (!colorCC.dsVis) {
            colorCC.dsVis := true
            try WinSetTransparent(255,  "ahk_id " colorCC.id)
            try WinSetExStyle("-0x20", "ahk_id " colorCC.id)
            if IsObject(colorCC.bCC)
                colorCC.bCC.Hide()
        }
    } else {
        if (colorCC.dsVis) {
            colorCC.dsVis := false
            try WinSetTransparent(5,    "ahk_id " colorCC.id)
            try WinSetExStyle("+0x20", "ahk_id " colorCC.id)
        }
        if IsObject(colorCC.bCC)
            colorCC.bCC.Show(wx, wy, ww, wh)
    }
}

LoopAccesoRapido() {
    if (!ar.hover)
        return
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if (ar.dsVis && ar.id) {
            ar.dsVis := false
            try WinSetTransparent(5,   "ahk_id " ar.id)
            try WinSetExStyle("+0x20", "ahk_id " ar.id)
        }
        if IsObject(ar.bAR)
            ar.bAR.Hide()
        return
    }
    if (!ar.id) {
        ar.id := BuscarVentanaCSP(0, "Acceso r", "pido")
        if (ar.id) {
            ar.bAR   := BorderFrame("AA8844")
            ar.dsVis := false
            try WinSetTransparent(5,    "ahk_id " ar.id)
            try WinSetExStyle("+0x20", "ahk_id " ar.id)
        }
        return
    }
    try {
        if !WinExist("ahk_id " ar.id) {
            if IsObject(ar.bAR)
                ar.bAR.Hide()
            ar.id    := 0
            ar.dsVis := false
            return
        }
        WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " ar.id)
    } catch {
        if IsObject(ar.bAR)
            ar.bAR.Hide()
        ar.id    := 0
        ar.dsVis := false
        return
    }
    MouseGetPos(&mx, &my)
    dentro := (mx >= wx && mx <= wx+ww && my >= wy && my <= wy+wh)
    if (dentro) {
        if (!ar.dsVis) {
            ar.dsVis := true
            try WinSetTransparent(255,  "ahk_id " ar.id)
            try WinSetExStyle("-0x20", "ahk_id " ar.id)
            if IsObject(ar.bAR)
                ar.bAR.Hide()
        }
    } else {
        if (ar.dsVis) {
            ar.dsVis := false
            try WinSetTransparent(5,    "ahk_id " ar.id)
            try WinSetExStyle("+0x20", "ahk_id " ar.id)
        }
        if IsObject(ar.bAR)
            ar.bAR.Show(wx, wy, ww, wh)
    }
}

; ══════════════════════════════════════════════════════════════════
; VigilarAltPegado — red de seguridad contra el bug de "Alt atorado".
; Si stylus.altActive quedó en true pero el Alt físico ya no está
; realmente presionado (GetKeyState dice que no), lo corrige solo.
; Esto es lo que evitaba que E/-/W/Z/X/A/S se quedaran disparando la
; versión "Alt+B sostenido" de esas teclas para siempre.
; ══════════════════════════════════════════════════════════════════
; VigilarAltPegado eliminada — no existía en la Artist Pro 14 Gen2 y
; era la única causa real de que se cortara el hold-and-repeat de
; Alt+B con el keydial. Port 1:1 del comportamiento de la 14.

ResetProcesando() => E.procesando := false


__Q_SEND_NORMAL() {
    global colorEstado
    SendInput("q")
    if (colorEstado = 1)
        MostrarMiniTextoOscuro("🟡 COLOR SECUNDARIO", "51D67B", 800)
    else if (colorEstado = 2)
        MostrarMiniTexto("⚪ ALPHA TRANSPARENTE", "1C6EA4", 800)
    else
        MostrarMiniTexto("🔵 COLOR PRIMARIO", "2B3B32", 800)
}

AlternarEstabilizacion() {
    static ocupado := false
    static lastTick := 0
    static lastPressTime := 0
    now := A_TickCount

    ; Debounce ultra-rápido (80ms) para evitar rebotes físicos accidentales
    if (ocupado || (now - lastTick < 80))
        return

    ; Si el lápiz o ratón está presionado (dibujando un trazo en CSP), abortar inmediatamente.
    ; NO envía teclas, NO modifica estado, NO muestra GUI y NO emite sonido.
    if GetKeyState("LButton", "P") || GetKeyState("RButton", "P")
        return

    lastTick := now
    ocupado := true

    esDobleTap := (now - lastPressTime < 350)
    lastPressTime := esDobleTap ? 0 : now

    delta := ESTAB_MAX - ESTAB_MIN  ; 75 - 7 = 68 pasos

    try {
        BlockInput(true)
        if (esDobleTap) {
            ; DOBLE TOQUE RÁPIDO (<350ms): Reseteo absoluto forzado a 0 y re-sincronización exacta
            if (Q.estadoEstab = 0) {
                SendInput("{j 80}{- " ESTAB_MAX "}")
                Q.estadoEstab := 1
                MostrarMiniTexto("🔄 RE-SINCRONIZADO: ALTA (" ESTAB_MAX ")", "1A5C2A", 1000)
                SetTimer(_BeepEstabAlta, -1)
            } else {
                SendInput("{j 80}{- " ESTAB_MIN "}")
                Q.estadoEstab := 0
                MostrarMiniTexto("🔄 RE-SINCRONIZADO: BAJA (" ESTAB_MIN ")", "1A2E5C", 1000)
                SetTimer(_BeepEstabBaja, -1)
            }
        } else {
            ; TAP SIMPLE: Salto directo ultra-rápido (68 teclas, casi instantáneo)
            if (Q.estadoEstab = 0) {
                SendInput("{- " delta "}")
                Q.estadoEstab := 1
                MostrarMiniTexto("🟢 ESTABILIZACIÓN ALTA (" ESTAB_MAX ")", "1A5C2A", 700)
                SetTimer(_BeepEstabAlta, -1)
            } else {
                SendInput("{j " delta "}")
                Q.estadoEstab := 0
                MostrarMiniTexto("🔵 ESTABILIZACIÓN BAJA (" ESTAB_MIN ")", "1A2E5C", 700)
                SetTimer(_BeepEstabBaja, -1)
            }
        }
    } catch {
        ; En caso de error, el estado no cambia
    } finally {
        BlockInput(false)
        ocupado := false
    }
}

_BeepEstabAlta() {
    SoundPlay(A_WinDir "\Media\Windows Ding.wav")
}

_BeepEstabBaja() {
    SoundPlay(A_WinDir "\Media\Windows Balloon.wav")
}

_CheckGitDone() {
    MostrarHUD("✅ GitHub actualizado", "44DD88", 2000)
    SoundPlay(A_WinDir "\Media\Windows Navigation Start.wav")
}

ResetEstadoAltX() {
    sel.estadoAltX := false
    sel.guiActivo  := false
}

__ResetEstadoC() {
    sel.estadoC := 0
}

; ── ToolTips / HUD ───────────────────────────────────────────────
; Slot 1 : ToolTip nativo — solo CheckReload y ^g (notepad++)
; HUD    : MostrarHUD — GUI estilo dial para todas las herramientas

; ══════════════════════════════════════════════════════════════════
; MostrarHUD — GUI unificada estilo dial para feedback de hotkeys
; Fondo oscuro 1a1a1a, texto bold blanco, barra de color abajo.
; Posición: esquina sup. izq. en P30 (panel 📍) — antes centrada en el monitor
; Esta es la caja de avisos rápidos
; (E, E rápido, Alt+Q/W/E, etc.) — distinta del GUI permanente del
; dial (Tamaño/Opacidad), que va arriba.
; colorBarra: hex sin # (ej. "00E5FF"). duracion en ms.
; ══════════════════════════════════════════════════════════════════
_DestruirGui(guiObj) {
    if !IsObject(guiObj)
        return
    hwnd := 0
    try hwnd := guiObj.Hwnd
    try guiObj.Destroy()
    ; Fallback nuclear: si la ventana sigue viva después de Destroy(), cerrarla por hwnd
    if (hwnd && DllCall("IsWindow", "Ptr", hwnd))
        DllCall("DestroyWindow", "Ptr", hwnd)
}

_LimpiarGUIs() {
    _DestruirGui(floatGui.hud)
    floatGui.hud := 0
    floatGui.hudHwnd := 0
    floatGui.hudLabel := 0
    floatGui.hudBar := 0

    _DestruirGui(floatGui.miniTip)
    floatGui.miniTip     := 0
    floatGui.miniTipID   := 0
    floatGui.miniTipTick := 0

    _DestruirGui(floatGui.tooltipToggle)
    floatGui.tooltipToggle := 0

    _DestruirGui(floatGui.miniGUI)
    floatGui.miniGUI := 0

    _DestruirGui(floatGui.enfoque)
    floatGui.enfoque := 0
    enfoque.activo   := false
    OcultarGUIEnfoque()

    _DestruirGui(floatGui.overlayIcon)
    floatGui.overlayIcon   := 0
    floatGui.overlayIconID := 0
}

; GUI distintivo para variaciones de Q y W (RButton / Alt)
; Diseño de tarjeta de alta visibilidad, con encabezado de acción, etiqueta y duración extendida.
MostrarBadgeCombo(comboText, toolText, colorAcento := "00E5FF", duracion := 2200) {
    global PUNTOS, AVISO_ESC, floatGui
    if IsObject(floatGui.miniTip)
        _DestruirGui(floatGui.miniTip)
    if IsObject(floatGui.miniGUI)
        _DestruirGui(floatGui.miniGUI)
    if IsObject(floatGui.tooltipToggle)
        _DestruirGui(floatGui.tooltipToggle)
    if IsObject(floatGui.hud)
        floatGui.hud.Hide()

    thisID := A_TickCount
    floatGui.badgeID := thisID

    ; Posición fija desacoplada del punto 30 (independiente de la calibración)
    ; Coordenadas capturadas: (-2247, 30)
    x := -2247
    y := 30
    w := Round(240 * AVISO_ESC), h := Round(62 * AVISO_ESC)

    if (!IsObject(floatGui.badge) || !floatGui.badgeHwnd || !DllCall("IsWindow", "Ptr", floatGui.badgeHwnd)) {
        g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
        g.BackColor := "12141A"
        g.MarginX := 0
        g.MarginY := 0
        WinSetTransparent(230, g)

        ; Barra de acento izquierda
        bLeft := g.Add("Progress", "x0 y0 w" Round(5 * AVISO_ESC) " h" h " Background12141A")
        bLeft.Opt("c" colorAcento)
        bLeft.Value := 100

        ; Subtítulo / Origen del comando
        lblSub := g.Add("Text", "x" Round(12 * AVISO_ESC) " y" Round(6 * AVISO_ESC) " w" (w - Round(16 * AVISO_ESC)) " h" Round(18 * AVISO_ESC) " c8E9AA0", comboText)
        lblSub.SetFont("s" Max(6, Round(9 * AVISO_ESC)) " bold", "Segoe UI")

        ; Título principal de la herramienta
        lblMain := g.Add("Text", "x" Round(12 * AVISO_ESC) " y" Round(24 * AVISO_ESC) " w" (w - Round(16 * AVISO_ESC)) " h" Round(28 * AVISO_ESC) " cWhite", toolText)
        lblMain.SetFont("s" Max(7, Round(13 * AVISO_ESC)) " bold", "Segoe UI")

        ; Barra inferior de progreso/duración
        bSub := g.Add("Progress", "x0 y" Round(58 * AVISO_ESC) " w" w " h" Round(4 * AVISO_ESC) " Background1E222D")
        bSub.Opt("c" colorAcento)
        bSub.Value := 100

        g.Show("w" w " h" h " NoActivate Hide")
        floatGui.badge := g
        floatGui.badgeHwnd := g.Hwnd
        floatGui.badgeSub := lblSub
        floatGui.badgeMain := lblMain
        floatGui.badgeSubBar := bLeft
        floatGui.badgeBar := bSub
    } else {
        floatGui.badgeSub.Value := comboText
        floatGui.badgeMain.Value := toolText
        floatGui.badgeSubBar.Opt("c" colorAcento)
        floatGui.badgeSubBar.Value := 100
        floatGui.badgeBar.Opt("c" colorAcento)
        floatGui.badgeBar.Value := 100
    }

    DllCall("SetWindowPos", "Ptr", floatGui.badgeHwnd, "Ptr", -1
        , "int", x, "int", y, "int", 0, "int", 0
        , "uint", 0x0040 | 0x0010 | 0x0001)
    
    floatGui.badge.Show("NoActivate")
    SetTimer(() => _OcultarBadgeSi(thisID), -duracion)
}

_OcultarBadgeSi(targetID) {
    global floatGui
    try {
        if (IsObject(floatGui.badge) && floatGui.badgeID = targetID) {
            floatGui.badge.Hide()
        }
    }
}

MostrarHUD(texto, colorBarra := "00E5FF", duracion := 1200) {
    global PUNTOS, AVISO_ESC
    if IsObject(floatGui.miniTip)
        _DestruirGui(floatGui.miniTip)
    if IsObject(floatGui.miniGUI)
        _DestruirGui(floatGui.miniGUI)
    if IsObject(floatGui.tooltipToggle)
        _DestruirGui(floatGui.tooltipToggle)

    ; Posición: esquina superior izquierda = P30 (editable en el panel 📍).
    ; Se coloca con SetWindowPos (píxeles reales), sin pasar por el escalado de Gui.Show.
    ; Posición fija desacoplada del punto 30 (independiente de la calibración)
    ; Coordenadas capturadas: (-2247, 30)
    x := -2247
    y := 30
    w := Round(208 * AVISO_ESC), h := Round(40 * AVISO_ESC)

    if (!IsObject(floatGui.hud) || !floatGui.hudHwnd || !DllCall("IsWindow", "Ptr", floatGui.hudHwnd)) {
        g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
        g.BackColor := "1a1a1a"
        g.MarginX := 0
        g.MarginY := 0
        WinSetTransparent(215, g)
        lbl := g.Add("Text", "x0 y" Round(7 * AVISO_ESC) " w" w " h" Round(26 * AVISO_ESC) " cWhite +0x200 Center", texto)
        lbl.SetFont("s" Max(6, Round(12 * AVISO_ESC)) " bold", "Segoe UI")
        bar := g.Add("Progress", "x0 y" Round(35 * AVISO_ESC) " w" w " h" Round(5 * AVISO_ESC) " Background333333")
        bar.Opt("c" colorBarra)
        bar.Value := 100
        g.Show("w" w " h" h " NoActivate Hide")
        floatGui.hud := g
        floatGui.hudLabel := lbl
        floatGui.hudBar := bar
        floatGui.hudHwnd := g.Hwnd
    } else {
        floatGui.hudLabel.Value := texto
        floatGui.hudBar.Opt("c" colorBarra)
        floatGui.hudBar.Value := 100
    }
    DllCall("SetWindowPos", "Ptr", floatGui.hudHwnd, "Ptr", -1
        , "int", x, "int", y, "int", 0, "int", 0
        , "uint", 0x0040 | 0x0010 | 0x0001) ; SWP_SHOWWINDOW | SWP_NOACTIVATE | SWP_NOSIZE
    hwnd := floatGui.hudHwnd
    SetTimer(() => _OcultarHUDSi(hwnd), -duracion)
}

_OcultarHUDSi(hwnd) {
    try {
        if (IsObject(floatGui.hud) && floatGui.hudHwnd = hwnd) {
            floatGui.hud.Hide()
        }
    } catch {
        floatGui.hud := 0
        floatGui.hudHwnd := 0
    }
}

QuitarToolTip()      => ToolTip()
OcultarToolTip()     => ToolTip()
OcultarToolTipAltG() => ToolTip()
OcultarToolTipQ()    => ToolTip()
OcultarIndicador()   => ToolTip()
QuitarToolTipE()     => ToolTip(, , , 3)
QuitarToolTipZ()     => ToolTip(, , , 4)

MostrarIndicador(texto) {
    ToolTip(texto)
    SetTimer(OcultarIndicador, -2500)
}

; Slot 3 exclusivo — no interfiere con QuitarToolTip (slot 1)
MostrarToolTipE(texto, duracion := 2190) {
    MostrarHUD(texto, "FF4444", duracion)
}

; Icono Overlay central con badge oscuro semitransparente para visibilidad en fondos blancos y oscuros
MostrarIconoHerramienta(tipo, duracion := 700) {
    global PUNTOS, AVISO_ESC
    if IsObject(floatGui.overlayIcon)
        _DestruirGui(floatGui.overlayIcon)

    thisID := A_TickCount
    floatGui.overlayIconID := thisID

    lado := Round(110 * AVISO_ESC)
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := "181818"
    g.MarginX := 0
    g.MarginY := 0

    ; Iconos vectoriales Unicode limpios y reconocibles
    iconoChar := (tipo = "zoom")  ? "🔍"
               : (tipo = "rotar") ? "↻"
               : "⚙"

    ; Centrado exacto tanto horizontal (Center) como vertical (+0x0200 SS_CENTERIMAGE)
    fSize := (tipo = "rotar") ? Round(56 * AVISO_ESC) : Round(50 * AVISO_ESC)
    txt := g.Add("Text", "x0 y0 w" lado " h" lado " Center +0x0200 cWhite", iconoChar)
    txt.SetFont("s" fSize " bold", "Segoe UI Symbol")

    ; Esquina superior izquierda = P30 (editable en el panel 📍), en píxeles reales.
    g.Show("w" lado " h" lado " NoActivate Hide")
    DllCall("SetWindowPos", "Ptr", g.Hwnd, "Ptr", -1
        , "int", PUNTOS[30][1], "int", PUNTOS[30][2], "int", 0, "int", 0
        , "uint", 0x0040 | 0x0010 | 0x0001)

    ; Bordes súper redondeados elegantes (casi circulares / cápsula suave)
    try {
        rad := Round(50 * AVISO_ESC)
        rgn := DllCall("Gdi32\CreateRoundRectRgn", "int", 0, "int", 0, "int", lado + 1, "int", lado + 1, "int", rad, "int", rad, "Ptr")
        DllCall("SetWindowRgn", "Ptr", g.Hwnd, "Ptr", rgn, "int", 1)
    }

    ; Fondo translúcido elegante (~185/255 opacidad)
    WinSetTransparent(185, "ahk_id " g.Hwnd)
    floatGui.overlayIcon := g

    SetTimer(() => _OcultarIconoSi(thisID), -duracion)
}

_OcultarIconoSi(id) {
    if (floatGui.overlayIconID != id)
        return
    try {
        if IsObject(floatGui.overlayIcon)
            floatGui.overlayIcon.Destroy()
    }
    floatGui.overlayIcon   := 0
    floatGui.overlayIconID := 0
}

; Slot 4 exclusivo — no interfiere con slot 1 ni con MostrarToolTipE (slot 3)
MostrarToolTipZ(texto, duracion := 800) {
    ; Si es zoom o rotar, mostramos el nuevo icono overlay semitransparente (15%)
    if InStr(texto, "Z") {
        MostrarIconoHerramienta("zoom", duracion)
    } else if InStr(texto, "R") {
        MostrarIconoHerramienta("rotar", duracion)
    } else {
        MostrarHUD(texto, "00E5FF", duracion)
    }
}

ToolTipCS(texto, duracion := 800) {
    MostrarHUD(texto, texto = "🟢 REHACER" ? "44DD88" : "FF4444", duracion)
}

CustomToolTip(text, duration := 1500) {
    ToolTip(text, , , 2)
    SetTimer(RemoveCustomToolTip, -duration)
}

RemoveCustomToolTip() => ToolTip(, , , 2)

; Coloca una ventana de aviso con su esquina sup. izq. en P30 (píxeles reales)
; y la muestra sin activarla.
_AvisoPosicionar(hwnd) {
    global PUNTOS
    DllCall("SetWindowPos", "Ptr", hwnd, "Ptr", -1
        , "int", PUNTOS[30][1], "int", PUNTOS[30][2], "int", 0, "int", 0
        , "uint", 0x0040 | 0x0010 | 0x0001)
}

MostrarMiniTexto(texto, colorHex := "222222", duracion := 800, colorTexto := "FFFFFF") {
    _LimpiarGUIs()
    thisID := A_TickCount
    floatGui.miniTipID   := thisID
    floatGui.miniTipTick := thisID
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := colorHex
    g.SetFont("s" Max(6, Round(12 * AVISO_ESC)) " Bold", "Segoe UI")
    g.AddText("c" colorTexto " Center w" Round(260 * AVISO_ESC), texto)
    g.Show("Hide AutoSize NoActivate")
    _AvisoPosicionar(g.Hwnd)
    WinSetTransparent(200, "ahk_id " g.Hwnd)
    floatGui.miniTip := g
    capturedID := thisID
    SetTimer(() => _OcultarMiniTipSi(capturedID), -duracion)
}

_OcultarMiniTipSi(id) {
    if (floatGui.miniTipID != id)
        return
    try {
        if IsObject(floatGui.miniTip)
            floatGui.miniTip.Destroy()
    }
    floatGui.miniTip     := 0
    floatGui.miniTipID   := 0
    floatGui.miniTipTick := 0
}

MostrarMiniTextoOscuro(texto, colorHex := "EEEEEE", duracion := 800) {
    MostrarMiniTexto(texto, colorHex, duracion, "000000")
}

OcultarMiniTip() {
    try {
        if IsObject(floatGui.miniTip)
            floatGui.miniTip.Destroy()
    }
    floatGui.miniTip     := 0
    floatGui.miniTipID   := 0
    floatGui.miniTipTick := 0
}

MostrarMiniGUI(texto, colorHex := "222222", duracion := 1200) {
    if IsObject(floatGui.miniGUI)
        try floatGui.miniGUI.Destroy()
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := colorHex
    g.SetFont("s" Max(6, Round(12 * AVISO_ESC)) " Bold", "Segoe UI")
    g.AddText("cFFFFFF Center w" Round(260 * AVISO_ESC), texto)
    g.Show("Hide AutoSize NoActivate")
    _AvisoPosicionar(g.Hwnd)
    WinSetTransparent(200, "ahk_id " g.Hwnd)
    floatGui.miniGUI := g
    hwndMG := g.Hwnd
    SetTimer(() => _OcultarMiniGUISi(hwndMG), -duracion)
}

_OcultarMiniGUISi(hwndMG) {
    try {
        if (IsObject(floatGui.miniGUI) && floatGui.miniGUI.Hwnd = hwndMG) {
            floatGui.miniGUI.Destroy()
            floatGui.miniGUI := 0
        }
    } catch {
        floatGui.miniGUI := 0
    }
}

OcultarMiniGUI() {
    if IsObject(floatGui.miniGUI)
        try floatGui.miniGUI.Destroy()
    floatGui.miniGUI := 0
}

MostrarTooltipToggle(titulo, simbolo, color) {
    _LimpiarGUIs()
    g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20")
    fs := Max(6, Round(12 * AVISO_ESC))
    if (color = "verde") {
        g.BackColor := "1F4D3A"
        g.SetFont("s" fs " Bold cWhite", "Segoe UI")
        simColor := "Lime"
    } else {
        g.BackColor := "D92B2B"
        g.SetFont("s" fs " Bold cWhite", "Segoe UI")
        simColor := "White"
    }
    k := AVISO_ESC
    g.AddText("x" Round(8*k) " y" Round(5*k) " w" Round(221*k) " h" Round(23*k) " Center", titulo)
    g.SetFont("s" fs " Bold c" simColor, "Segoe UI")
    g.AddText("x" Round(232*k) " y" Round(4*k) " w" Round(23*k) " h" Round(23*k) " Center", simbolo)
    g.Show("w" Round(260*k) " h" Round(34*k) " NoActivate Hide")
    _AvisoPosicionar(g.Hwnd)
    floatGui.tooltipToggle := g
    hwndT := g.Hwnd
    SetTimer(() => _OcultarToggleSi(hwndT), -1500)
}

_OcultarToggleSi(hwndT) {
    try {
        if (IsObject(floatGui.tooltipToggle) && floatGui.tooltipToggle.Hwnd = hwndT) {
            floatGui.tooltipToggle.Destroy()
            floatGui.tooltipToggle := 0
        }
    } catch {
        floatGui.tooltipToggle := 0
    }
}

QuitarTooltipToggle() {
    if IsObject(floatGui.tooltipToggle)
        try floatGui.tooltipToggle.Destroy()
    floatGui.tooltipToggle := 0
}

SendKeyWithBoost(key, startTick) {
    elapsed := A_TickCount - startTick
    if (elapsed < boost.holdDelay)
        return
    ratio := Min((elapsed - boost.holdDelay) / 100, 1)
    b     := Max(Round(boost.maxBoost * (ratio ** 0.1)), 1)
    Loop b
        SendInput("{Blind}" key)
}

; ══════════════════════════════════════════════════════════════════
; AccionEnfoque — clicks de modo enfoque en los puntos P1 (izquierdo) y
; P2 (derecho) de la Artist Pro 16 Gen2. Editables en el panel 📍.
; ══════════════════════════════════════════════════════════════════
AccionEnfoque() {
    enfoque.activo := !enfoque.activo

    ; 1. Clics ultra-rápidos en las esquinas de CSP sin mover el cursor físico
    ; (izquierdo = P1, derecho = P2).
    MouseGetPos(&origX, &origY)
    Click(PUNTOS[1][1] " " PUNTOS[1][2])
    Click(PUNTOS[2][1] " " PUNTOS[2][2])
    DllCall("SetCursorPos", "int", origX, "int", origY)

    ; 2. Mover ventanas flotantes por SetWindowPos en paralelo (sin bloqueo WinMove)
    _AplicarLayoutPaneles(enfoque.activo ? "Enfoque" : "Normal")

    ; 2b. Sincronizar PureRef_layout (mensaje 0x5501: 1 = Enfoque, 0 = Normal)
    _NotificarPureRef(enfoque.activo ? 1 : 0)

    ; 3. Borde iluminado y Sonido en segundo plano (asíncrono)
    if (enfoque.activo) {
        MostrarGUIEnfoque()
        MostrarHUD("🎯 MODO ENFOQUE", "00E5FF", 900)
        SetTimer(() => SoundPlay(A_WinDir "\Media\Windows Feed Discovered.wav"), -1)
    } else {
        OcultarGUIEnfoque()
        SetTimer(() => SoundPlay(A_WinDir "\Media\Windows Pop-up Blocked.wav"), -1)
    }
}

_NotificarPureRef(modo) {
    prevDHW := A_DetectHiddenWindows
    DetectHiddenWindows(true)
    for hwnd in WinGetList("ahk_class AutoHotkey") {
        try {
            title := WinGetTitle("ahk_id " hwnd)
            if InStr(title, "PureRef_layout.ahk")
                PostMessage(0x5501, modo, 0,, "ahk_id " hwnd)
        }
    }
    DetectHiddenWindows(prevDHW)
}

; ══════════════════════════════════════════════════════════════════
; Layouts de los 3 paneles flotantes (Deslizador / Círculo / Acceso rápido)
; por modo: "Normal" y "Enfoque". Se aplican al alternar enfoque.
;
; Se GUARDAN en posiciones_gui.ini (sección LayoutNormal / LayoutEnfoque)
; como distancia desde la esquina del monitor de CSP, así sobreviven a
; recargas y a cambios de monitor. Si no hay nada guardado para un panel,
; se usan los valores por defecto de LAYOUT_NORMAL / LAYOUT_ENFOQUE.
;
;   Ctrl+F11 = guarda las posiciones ACTUALES como layout Normal
;   Ctrl+F12 = guarda las posiciones ACTUALES como layout Enfoque
;
; Al aplicar, la posición se recorta para que el panel SIEMPRE quede
; dentro del monitor de CSP: nunca puede irse fuera de pantalla.
; ══════════════════════════════════════════════════════════════════
_IdsPaneles() {
    global colorV, colorCC, ar, hist
    try {
        if (!colorV.dsID || !WinExist("ahk_id " colorV.dsID))
            colorV.dsID := BuscarVentanaCSP(0, "eslizador", "colores")
        if (!colorCC.id || !WinExist("ahk_id " colorCC.id))
            colorCC.id := BuscarVentanaCSP(0, "rculo de colores", "olores")
        if (!ar.id || !WinExist("ahk_id " ar.id))
            ar.id := BuscarVentanaCSP(0, "Acceso r", "pido")
        if (!hist.id || !WinExist("ahk_id " hist.id))
            hist.id := BuscarVentanaCSP(0, "istorial", "color")
    }
    ids := Map()
    ids["ds"] := colorV.dsID
    ids["cc"] := colorCC.id
    ids["ar"] := ar.id
    ids["hc"] := hist.id
    return ids
}

_LayoutPanelGuardado(nombre, clave, mon) {
    ini := _PosGuiIniPath()
    sec := "Layout" nombre
    x := IniRead(ini, sec, clave "x", "")
    y := IniRead(ini, sec, clave "y", "")
    w := IniRead(ini, sec, clave "w", "")
    h := IniRead(ini, sec, clave "h", "")
    if (x = "" || y = "" || w = "" || h = "")
        return 0
    return { x: mon.x + Integer(x), y: mon.y + Integer(y), w: Integer(w), h: Integer(h) }
}

_AplicarLayoutPaneles(nombre) {
    global LAYOUT_NORMAL, LAYOUT_ENFOQUE, colorV, colorCC
    mon := ObtenerMonitorCSP()
    def := (nombre = "Enfoque") ? LAYOUT_ENFOQUE : LAYOUT_NORMAL
    SWP_FLAGS := 0x0004 | 0x0010 ; SWP_NOZORDER | SWP_NOACTIVATE
    for clave, id in _IdsPaneles() {
        if (!id || !WinExist("ahk_id " id))
            continue
        r := _LayoutPanelGuardado(nombre, clave, mon)
        if (!r)
            r := def.%clave%
        x := Max(mon.x, Min(r.x, mon.x + mon.w - r.w))
        y := Max(mon.y, Min(r.y, mon.y + mon.h - r.h))
        try {
            DllCall("SetWindowPos", "Ptr", id, "Ptr", 0
                , "int", x, "int", y, "int", r.w, "int", r.h
                , "uint", SWP_FLAGS)
            if (clave = "ds") {
                colorV.dsX := x, colorV.dsY := y, colorV.dsW := r.w, colorV.dsH := r.h
            } else if (clave = "cc") {
                colorCC.ccX := x, colorCC.ccY := y, colorCC.ccW := r.w, colorCC.ccH := r.h
            }
        }
    }
}

_CapturarLayout(nombre) {
    global colorV, colorCC, ar, hist
    ; Feedback inmediato (sonido + tooltip) para saber que el atajo sí
    ; llegó al script, aunque después falle algo más abajo.
    SetTimer(() => SoundPlay(A_WinDir "\Media\ding.wav"), -1)
    ToolTip("Guardando layout " nombre "...")
    SetTimer(() => ToolTip(), -1500)
    ; Si algún panel todavía no se ha resuelto (no le has pasado el mouse),
    ; se intenta encontrar por título.
    try {
        if (!colorV.dsID)
            colorV.dsID := BuscarVentanaCSP(0, "eslizador", "colores")
        if (!colorCC.id)
            colorCC.id := BuscarVentanaCSP(0, "rculo de colores", "olores")
        if (!ar.id)
            ar.id := BuscarVentanaCSP(0, "Acceso r", "pido")
        if (!hist.id)
            hist.id := BuscarVentanaCSP(0, "istorial", "color")
    }
    mon := ObtenerMonitorCSP()
    ini := _PosGuiIniPath()
    sec := "Layout" nombre
    guardados := 0
    totalEsperados := 4
    for clave, id in _IdsPaneles() {
        if (!id || !WinExist("ahk_id " id))
            continue
        try {
            WinGetPos(&x, &y, &w, &h, "ahk_id " id)
            IniWrite(x - mon.x, ini, sec, clave "x")
            IniWrite(y - mon.y, ini, sec, clave "y")
            IniWrite(w, ini, sec, clave "w")
            IniWrite(h, ini, sec, clave "h")
            guardados++
        }
    }
    MostrarHUD("LAYOUT " StrUpper(nombre) " GUARDADO (" guardados "/" totalEsperados ")", guardados = totalEsperados ? "44DD88" : "FF6B00", 1600)
}

$^F11:: _CapturarLayout("Normal")
$^F12:: _CapturarLayout("Enfoque")
$^F10:: AbrirPanelPuntos()   ; panel de calibración de puntos (también el botón 📍)

MostrarGUIEnfoque() {
    mon := ObtenerMonitorCSP()
    opts := "-Caption +AlwaysOnTop +ToolWindow +E0x20"
    flags := 0x0010 | 0x0040 ; SWP_NOACTIVATE | SWP_SHOWWINDOW
    x := mon.x, y := mon.y, w := mon.w, h := mon.h

    ; Inicializar las 8 barras (2 capas de 4 lados) una sola vez (pool de memoria reutilizable)
    ; Capa 1: Halo exterior difuminado (6px, opacidad muy tenue ~18%)
    ; Capa 2: Borde interior visible pero suave (3px, opacidad moderada ~30%)
    if (!HasProp(floatGui, "enfoqueGuis") || !IsObject(floatGui.enfoqueGuis) || floatGui.enfoqueGuis.Length != 8) {
        floatGui.enfoqueGuis := []
        ; Capa exterior (halo suave)
        Loop 4 {
            g := Gui(opts)
            g.BackColor := "0077B6" ; Azul translúcido
            g.Show("w0 h0 NoActivate")
            WinSetTransparent(46, g) ; ~18% opacidad
            floatGui.enfoqueGuis.Push(g)
        }
        ; Capa interior (borde más nítido a mitad de grosor)
        Loop 4 {
            g := Gui(opts)
            g.BackColor := "00B4D8" ; Cyan equilibrado sin destellos cegadores
            g.Show("w0 h0 NoActivate")
            WinSetTransparent(76, g) ; ~30% opacidad
            floatGui.enfoqueGuis.Push(g)
        }
    }

    ; Capa 1: 6px exterior difuminado
    DllCall("SetWindowPos", "Ptr", floatGui.enfoqueGuis[1].Hwnd, "Ptr", -1, "Int", x, "Int", y, "Int", w, "Int", 6, "UInt", flags)
    DllCall("SetWindowPos", "Ptr", floatGui.enfoqueGuis[2].Hwnd, "Ptr", -1, "Int", x, "Int", y + h - 6, "Int", w, "Int", 6, "UInt", flags)
    DllCall("SetWindowPos", "Ptr", floatGui.enfoqueGuis[3].Hwnd, "Ptr", -1, "Int", x, "Int", y, "Int", 6, "Int", h, "UInt", flags)
    DllCall("SetWindowPos", "Ptr", floatGui.enfoqueGuis[4].Hwnd, "Ptr", -1, "Int", x + w - 6, "Int", y, "Int", 6, "Int", h, "UInt", flags)

    ; Capa 2: 3px interior concentrado
    DllCall("SetWindowPos", "Ptr", floatGui.enfoqueGuis[5].Hwnd, "Ptr", -1, "Int", x, "Int", y, "Int", w, "Int", 3, "UInt", flags)
    DllCall("SetWindowPos", "Ptr", floatGui.enfoqueGuis[6].Hwnd, "Ptr", -1, "Int", x, "Int", y + h - 3, "Int", w, "Int", 3, "UInt", flags)
    DllCall("SetWindowPos", "Ptr", floatGui.enfoqueGuis[7].Hwnd, "Ptr", -1, "Int", x, "Int", y, "Int", 3, "Int", h, "UInt", flags)
    DllCall("SetWindowPos", "Ptr", floatGui.enfoqueGuis[8].Hwnd, "Ptr", -1, "Int", x + w - 3, "Int", y, "Int", 3, "Int", h, "UInt", flags)
}

OcultarGUIEnfoque() {
    if (HasProp(floatGui, "enfoqueGuis") && IsObject(floatGui.enfoqueGuis)) {
        for g in floatGui.enfoqueGuis {
            try DllCall("ShowWindow", "Ptr", g.Hwnd, "Int", 0) ; SW_HIDE instantáneo (0ms)
        }
    }
}

ResetEnfoque() {
    if (enfoque.activo) {
        enfoque.activo := false
        OcultarGUIEnfoque()
    }
}

ResetAlphaStates() {
    global colorEstado
    if !WinActive("ahk_exe CLIPStudioPaint.exe") {
        if (colorEstado = 2)
            Send("k")
        if (colorEstado = 1)
            SendInput("^2")
        colorEstado := 0
        if IsObject(dial.g)
            dial.g.Hide()
        if IsObject(dsGui.g)
            dsGui.g.Hide()
        if IsObject(ccGui.g)
            ccGui.g.Hide()
        if IsObject(arGui.g)
            arGui.g.Hide()
        if IsObject(hcGui.g)
            hcGui.g.Hide()
        if IsObject(lockGui.g)
            lockGui.g.Hide()
        if IsObject(reloadGui.g)
            reloadGui.g.Hide()
        return
    }
    ; Restaurar dial, dsGui/ccGui/arGui, hcGui y reloadGui si CSP recuperó el foco
    if IsObject(dial.g) {
        try {
            if !DllCall("IsWindowVisible", "Ptr", dial.g.Hwnd)
                dial.g.Show("NoActivate")
        }
    }
    if IsObject(dsGui.g) {
        try {
            if !DllCall("IsWindowVisible", "Ptr", dsGui.g.Hwnd)
                dsGui.g.Show("NoActivate")
        }
    }
    if IsObject(ccGui.g) {
        try {
            if !DllCall("IsWindowVisible", "Ptr", ccGui.g.Hwnd)
                ccGui.g.Show("NoActivate")
        }
    }
    if IsObject(arGui.g) {
        try {
            if !DllCall("IsWindowVisible", "Ptr", arGui.g.Hwnd)
                arGui.g.Show("NoActivate")
        }
    }
    if IsObject(hcGui.g) {
        try {
            if !DllCall("IsWindowVisible", "Ptr", hcGui.g.Hwnd)
                hcGui.g.Show("NoActivate")
        }
    }
    if IsObject(lockGui.g) {
        try {
            if !DllCall("IsWindowVisible", "Ptr", lockGui.g.Hwnd)
                lockGui.g.Show("NoActivate")
        }
    }
    if IsObject(reloadGui.g) {
        try {
            if !DllCall("IsWindowVisible", "Ptr", reloadGui.g.Hwnd)
                reloadGui.g.Show("NoActivate")
        }
    }
    ; Watchdog miniTip
    if (floatGui.miniTipID != 0 && floatGui.miniTipTick != 0) {
        if (A_TickCount - floatGui.miniTipTick > 4000) {
            try {
                if IsObject(floatGui.miniTip)
                    try floatGui.miniTip.Destroy()
            }
            floatGui.miniTip     := 0
            floatGui.miniTipID   := 0
            floatGui.miniTipTick := 0
        }
    }
}

#HotIf WinActive("ahk_exe CLIPStudioPaint.exe")
; Sin SetTimer/diferido: responde de inmediato en cada toque real, sin el
; lag de 250ms. AltF_state.held bloquea el auto-repeat de Windows mientras
; F sigue físicamente abajo (F se usa sostenida, a diferencia de s/x).
; La ventana de 300ms (igual que s/x) decide si el toque cuenta como
; "rápido" (SMEAR SOFT) o "suelto" (SMEAR). El choque con la "b" del combo
; Alt+B sigue resuelto igual: forzamos {b up}{b down} marcado como sintético.
!f:: {
    if !stylus.altActive
        return
    if AltF_state.held
        return
    AltF_state.held := true
    now := A_TickCount
    if (now - AltF_state.lastPress < 300) {
        AltF_state.lastPress := 0
        seguiaSostenido := stylus.altActive
        SendEvent("{Alt up}{NumpadEnd}")
        if (seguiaSostenido)
            SendEvent("{Alt down}")
        MostrarHUD("SMEAR SOFT  (2)", "FF6B00", 950)
    } else {
        AltF_state.lastPress := now
        stylus.bSinteticoTick := A_TickCount
        seguiaSostenido := stylus.altActive
        SendEvent("{Alt up}{b up}{b down}")
        if (seguiaSostenido)
            SendEvent("{Alt down}")
        MostrarHUD("SMEAR  (1)", "00E5FF", 950)
    }
}
!f up:: {
    AltF_state.held := false
}

~b & k:: {
    global colorEstado
    if (colorEstado = 1)
        SendInput("^2")
    Send("k")
    Send("k")
    colorEstado := 0
    MostrarMiniTexto("🔄 RESET → COLOR PRIMARIO", "1A1A2E", 1200)
}
#HotIf

; ┌──────────────────────────────────────────────────────────┐
; │  DIAL GUI — indicador permanente de modo del dial        │
; │  (tamaño 50% mayor y posición P5, Artist Pro 16 Gen2)     │
; └──────────────────────────────────────────────────────────┘
; ══════════════════════════════════════════════════════════════════
; GuardarPosicionGUI / LeerPosicionGUI — persisten la posición de los
; paneles arrastrables (dial, dsGui/ccGui/arGui) en un .ini junto al script,
; para que recuerden dónde los dejaste entre sesiones.
; ══════════════════════════════════════════════════════════════════
; Función en vez de variable global: una asignación suelta aquí nunca
; se ejecutaría, porque en AHK v2 la sección de auto-ejecución termina
; en el primer hotkey del script, y esto está muy por debajo de esa
; línea — quedaría vacía. Como función, se calcula cada vez que se llama.
_PosGuiIniPath() => A_ScriptDir "\posiciones_gui.ini"

GuardarPosicionGUI(nombre, hwnd) {
    global PERFIL
    sec := nombre "_p" PERFIL          ; posición propia de cada perfil de equipo
    rc := Buffer(16, 0)
    DllCall("GetWindowRect", "Ptr", hwnd, "Ptr", rc)
    IniWrite(NumGet(rc, 0, "int"), _PosGuiIniPath(), sec, "x")
    IniWrite(NumGet(rc, 4, "int"), _PosGuiIniPath(), sec, "y")
}

; Devuelve un objeto {x, y} si hay posición guardada, o 0 si no.
LeerPosicionGUI(nombre) {
    global PERFIL
    ; Primero la posición del perfil activo; si no hay, la guardada antes de
    ; existir perfiles (sección sin sufijo).
    for sec in [nombre "_p" PERFIL, nombre] {
        x := IniRead(_PosGuiIniPath(), sec, "x", "")
        y := IniRead(_PosGuiIniPath(), sec, "y", "")
        if (x != "" && y != "")
            return { x: Integer(x), y: Integer(y) }
    }
    return 0
}

; Verdadero si el punto (x,y) cae dentro de algún monitor conectado.
; Protege contra posiciones guardadas que quedaron fuera de pantalla
; (monitor desconectado, resolución cambiada, guardado corrupto, etc.)
; — sin esto, un GUI "invisible" no tiene forma fácil de recuperarse.
_PosicionValidaEnPantalla(x, y) {
    Loop MonitorGetCount() {
        MonitorGet(A_Index, &l, &t, &r, &b)
        if (x >= l && x <= r && y >= t && y <= b)
            return true
    }
    return false
}

; ══════════════════════════════════════════════════════════════════
; BLOQUE Slider + Circle + Quick — se comportan como una sola unidad.
; Arrastrar cualquiera de los tres mueve a los tres juntos. Solo se
; persiste el ancla (posición de dsGui); cc/ar se calculan siempre
; como offsets fijos desde el ancla, así que al reabrir el script
; SIEMPRE vuelven a quedar alineados en bloque, sin importar qué se
; haya hecho en la sesión anterior.
;
; Ahora el bloque incluye también HC y el botón de fijar (🔒/🔓). Con el
; bloque FIJADO no se puede arrastrar nada (el clic sigue funcionando).
; Se eliminó el arrastre suelto con Ctrl: el bloque siempre va unido.
; ══════════════════════════════════════════════════════════════════
_AnclaBloquePaneles() {
    static ancla := 0
    if IsObject(ancla)
        return ancla
    mon := ObtenerMonitorCSP()
    ; Ancho total del bloque horizontal (estimado, solo para centrar el
    ; primer panel): 3 paneles de 80px lógicos + 2 separaciones. El
    ; posicionamiento real de ccGui/arGui ya no depende de este valor
    ; (ver PANEL_GAP e IniciarCcGUI/IniciarArGUI), así que un desajuste
    ; aquí como mucho descentra un poco el bloque, no lo superpone.
    anchoBloque := _E(104) + PANEL_GAP + _E(104) + PANEL_GAP + _E(104)
    defX := mon.x + (mon.w - anchoBloque) // 2
    defY := mon.y + Round(mon.h * 0.02) + 42 + 4
    guardada := LeerPosicionGUI("PanelBlock")
    if IsObject(guardada) && _PosicionValidaEnPantalla(guardada.x, guardada.y) {
        ancla := guardada
        return ancla
    }
    ; Migración: si ya existía una posición individual guardada del
    ; slider (de antes de agrupar los paneles), se usa como ancla
    ; inicial para no perder la ubicación que ya se había encontrado.
    vieja := LeerPosicionGUI("Slider")
    if IsObject(vieja) && _PosicionValidaEnPantalla(vieja.x, vieja.y) {
        ancla := vieja
        return ancla
    }
    ancla := { x: defX, y: defY }
    return ancla
}

; Manejador compartido de arrastre del BLOQUE (dsGui, ccGui, arGui, hcGui
; y el botón de fijar). guiObj es el panel sobre el que se hizo clic.
; - Bloque FIJADO (panelBlk.locked): el arrastre no mueve nada; un clic
;   corto sigue haciendo el toggle propio del panel.
; - Bloque libre: arrastrar cualquiera mueve los cinco juntos y se
;   persiste solo el ancla (dsGui). Ya no hay arrastre suelto con Ctrl.
_ArrastrarPanelBloque(hwndClick, lParam, guiObj) {
    global dsGui, ccGui, arGui, hcGui, lockGui, panelBlk
    static arrastrando := false
    if (arrastrando)
        return
    if !IsObject(guiObj.g)
        return
    if !(hwndClick = guiObj.g.Hwnd || guiObj.g.Hwnd = DllCall("GetParent", "Ptr", hwndClick, "Ptr"))
        return
    arrastrando := true

    pt := Buffer(8, 0)
    NumPut("int", lParam & 0xFFFF,        pt, 0)
    NumPut("int", (lParam >> 16) & 0xFFFF, pt, 4)
    DllCall("ClientToScreen", "Ptr", hwndClick, "Ptr", pt)
    clickX := NumGet(pt, 0, "int")
    clickY := NumGet(pt, 4, "int")

    rc := Buffer(16, 0)
    DllCall("GetWindowRect", "Ptr", guiObj.g.Hwnd, "Ptr", rc)
    origX := NumGet(rc, 0, "int")
    origY := NumGet(rc, 4, "int")
    offX := clickX - origX
    offY := clickY - origY

    SWP_NOSIZE := 0x0001, SWP_NOZORDER := 0x0004, SWP_NOACTIVATE := 0x0010
    cur := Buffer(8, 0)
    movido := false
    while GetKeyState("LButton", "P") {
        DllCall("GetCursorPos", "Ptr", cur)
        mx := NumGet(cur, 0, "int"), my := NumGet(cur, 4, "int")
        if (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4) {
            movido := true
            if !panelBlk.locked {
                newX := mx - offX
                newY := my - offY
                DllCall("SetWindowPos", "Ptr", guiObj.g.Hwnd, "Ptr", 0
                    , "int", newX, "int", newY, "int", 0, "int", 0
                    , "uint", SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE)
            }
        }
        Sleep(8)
    }

    if !movido {
        ; Click corto → toggle propio de este panel.
        if (guiObj.g.Hwnd = dsGui.g.Hwnd) {
            _ToggleColorV()
            ActualizarDsGUI()
        } else if (guiObj.g.Hwnd = ccGui.g.Hwnd) {
            _ToggleColorCC()
            ActualizarCcGUI()
        } else if (guiObj.g.Hwnd = arGui.g.Hwnd) {
            _ToggleAR()
            ActualizarArGUI()
        } else if (guiObj.g.Hwnd = hcGui.g.Hwnd) {
            _ToggleHistorialColor()
            ActualizarHCGUI()
        } else {
            _ToggleBloqueo()
        }
    } else if !panelBlk.locked {
        ; Guardar posición individual de cada botón movido
        if (guiObj.g.Hwnd = dsGui.g.Hwnd) {
            GuardarPosicionGUI("Slider", dsGui.g.Hwnd)
            GuardarPosicionGUI("PanelBlock", dsGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = ccGui.g.Hwnd) {
            GuardarPosicionGUI("Circle", ccGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = arGui.g.Hwnd) {
            GuardarPosicionGUI("Quick", arGui.g.Hwnd)
        } else if (guiObj.g.Hwnd = hcGui.g.Hwnd) {
            GuardarPosicionGUI("HC", hcGui.g.Hwnd)
            _GuardarOffsetHC()
            MostrarHUD("HC REPOSICIONADO", "9AA7C7", 900)
        } else if (guiObj.g.Hwnd = lockGui.g.Hwnd) {
            GuardarPosicionGUI("Lock", lockGui.g.Hwnd)
        }
    }
    arrastrando := false
}

; Guarda dónde quedó HC relativo al ancla (dsGui): sección PanelBlock, hcdx/hcdy.
; Así HC sigue al bloque cuando este se mueve, pero conserva su sitio propio.
_GuardarOffsetHC() {
    global dsGui, hcGui, PERFIL
    ini := _PosGuiIniPath()
    sec := "PanelBlock_p" PERFIL
    rd := Buffer(16, 0), rh := Buffer(16, 0)
    DllCall("GetWindowRect", "Ptr", dsGui.g.Hwnd, "Ptr", rd)
    DllCall("GetWindowRect", "Ptr", hcGui.g.Hwnd, "Ptr", rh)
    IniWrite(NumGet(rh, 0, "int") - NumGet(rd, 0, "int"), ini, sec, "hcdx")
    IniWrite(NumGet(rh, 4, "int") - NumGet(rd, 4, "int"), ini, sec, "hcdy")
}

; Fijar / liberar el bloque. Se guarda en el .ini (sección PanelBlock).
_ToggleBloqueo() {
    global panelBlk
    panelBlk.locked := !panelBlk.locked
    IniWrite(panelBlk.locked ? 1 : 0, _PosGuiIniPath(), "PanelBlock", "locked")
    ActualizarLockGUI()
    MostrarHUD(panelBlk.locked ? "🔒 BLOQUE FIJADO" : "🔓 BLOQUE LIBRE — arrastra para mover (HC va por separado)"
             , panelBlk.locked ? "44DD88" : "FF6B00", 1200)
}

; Offset del botón HC respecto al ancla del bloque (dsGui). Si no hay
; offset guardado, se migra desde la posición absoluta que tenía HC
; (así no cambia donde ya lo tenías) o, si no hay, va justo debajo.
_HcOffsetBloque() {
    global dsGui, PERFIL, ESC
    ini := _PosGuiIniPath()
    sec := "PanelBlock_p" PERFIL            ; offset propio de cada perfil de equipo
    dx := IniRead(ini, sec, "hcdx", "")
    dy := IniRead(ini, sec, "hcdy", "")
    if (dx != "" && dy != "")
        return { dx: Integer(dx), dy: Integer(dy) }
    ; Offset de antes de los perfiles (hecho a escala 100%): se adapta a la escala actual.
    dx := IniRead(ini, "PanelBlock", "hcdx", "")
    dy := IniRead(ini, "PanelBlock", "hcdy", "")
    if (dx != "" && dy != "") {
        dx := Round(Integer(dx) * ESC)
        dy := Round(Integer(dy) * ESC)
        IniWrite(dx, ini, sec, "hcdx")
        IniWrite(dy, ini, sec, "hcdy")
        return { dx: dx, dy: dy }
    }
    rc := Buffer(16, 0)
    DllCall("GetWindowRect", "Ptr", dsGui.g.Hwnd, "Ptr", rc)
    ax := NumGet(rc, 0, "int"), ay := NumGet(rc, 4, "int")
    ah := NumGet(rc, 12, "int") - ay
    vieja := LeerPosicionGUI("HC")
    if IsObject(vieja) && _PosicionValidaEnPantalla(vieja.x, vieja.y) {
        dx := vieja.x - ax
        dy := vieja.y - ay
    } else {
        dx := 0
        dy := ah + PANEL_GAP
    }
    IniWrite(dx, ini, sec, "hcdx")
    IniWrite(dy, ini, sec, "hcdy")
    return { dx: dx, dy: dy }
}

IniciarDialGUI() {
    ; Desactivado a pedido: ya no se usa el panel permanente de Tamaño/Opacidad
    return
}

ActualizarDialGUI() {
    global opacidad, dial
    if (!IsObject(dial.g) || !dial.icono)
        return
    if (dial.modo = 1) {
        dial.icono.Value := "🖌"
        dial.label.Value := "Tamaño"
        dial.barra.Opt("c00e5ff")
        dial.barra.Value := 100
    } else {
        dial.icono.Value := "◑"
        dial.label.Value := "Opacidad " opacidad.nivel "%"
        dial.barra.Opt("cff6b00")
        dial.barra.Value := opacidad.nivel
    }
}

; ══════════════════════════════════════════════════════════════════
; _DialWM_LBUTTONDOWN — arrastre manual del dial GUI.
; El truco anterior (PostMessage WM_NCLBUTTONDOWN/HTCAPTION) delegaba
; el drag a Windows, pero al soltar el botón la posición se revertía
; (la ventana -ToolWindow +AlwaysOnTop nunca confirmaba el nuevo punto
; ante el propio sistema). Ahora se sigue el mouse a mano con WinMove
; en cada iteración y se corta al soltar el botón — la posición final
; queda fija de verdad, sin snap-back.
; ══════════════════════════════════════════════════════════════════
_DialWM_LBUTTONDOWN(wParam, lParam, msg, hwnd) {
    global dial
    static arrastrando := false
    if (arrastrando)
        return
    if (hwnd = dial.g.Hwnd || dial.g.Hwnd = DllCall("GetParent", "Ptr", hwnd, "Ptr")) {
        arrastrando := true
        ; Todo el arrastre usa API de Windows en crudo (Get/SetCursorPos,
        ; GetWindowRect, SetWindowPos) — antes se mezclaba ClientToScreen
        ; (crudo) con MouseGetPos/Gui.Move (con su propio ajuste de DPI de
        ; AHK), lo que dejaba un desfase residual. SWP_NOZORDER además evita
        ; que el dial reclame "encima" en cada tick, que era lo que hacía
        ; parpadear a los paneles de hover (deslizador/círculo/acceso rápido)
        ; mientras se arrastraba.
        pt := Buffer(8, 0)
        NumPut("int", lParam & 0xFFFF,        pt, 0)
        NumPut("int", (lParam >> 16) & 0xFFFF, pt, 4)
        DllCall("ClientToScreen", "Ptr", hwnd, "Ptr", pt)
        clickX := NumGet(pt, 0, "int")
        clickY := NumGet(pt, 4, "int")

        rc := Buffer(16, 0)
        DllCall("GetWindowRect", "Ptr", dial.g.Hwnd, "Ptr", rc)
        offX := clickX - NumGet(rc, 0, "int")
        offY := clickY - NumGet(rc, 4, "int")

        cur := Buffer(8, 0)
        SWP_NOSIZE := 0x0001, SWP_NOZORDER := 0x0004, SWP_NOACTIVATE := 0x0010
        while GetKeyState("LButton", "P") {
            DllCall("GetCursorPos", "Ptr", cur)
            mx := NumGet(cur, 0, "int"), my := NumGet(cur, 4, "int")
            DllCall("SetWindowPos", "Ptr", dial.g.Hwnd, "Ptr", 0
                , "int", mx - offX, "int", my - offY, "int", 0, "int", 0
                , "uint", SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE)
            Sleep(8)
        }
        GuardarPosicionGUI("Dial", dial.g.Hwnd)
        arrastrando := false
    }
}

; ┌──────────────────────────────────────────────────────────┐
; │  DS / CC / AR GUI — 3 botones permanentes (deslizador de   │
; │  color, círculo de colores, acceso rápido), mismo estilo    │
; │  visual que el dial (icono + label + barra). Un click corto │
; │  en cada uno alterna SOLO ese panel; +q / Alt+J siguen       │
; │  alternando los 3 juntos y refrescan los 3 botones.          │
; │  Se comportan como UN BLOQUE al arrastrarlos (ver             │
; │  _ArrastrarPanelBloque / _AnclaBloquePaneles más arriba):     │
; │  mover cualquiera mueve a los tres, y solo se persiste el     │
; │  ancla — así siempre se reagrupan al reabrir el script.        │
; │  Ctrl+arrastre mueve un panel suelto de forma puntual (no      │
; │  se guarda).                                                    │
; └──────────────────────────────────────────────────────────┘
IniciarDsGUI() {
    global dsGui
    dsGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow", "")
    dsGui.g.BackColor := "424242"
    dsGui.g.MarginX := 0
    dsGui.g.MarginY := 0
    WinSetTransparent(235, dsGui.g)

    dsGui.icono := dsGui.g.Add("Picture", "x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20), "")

    dsGui.label := dsGui.g.Add("Text", "x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite", "")
    dsGui.label.SetFont("s" _FS(9) " bold", "Segoe UI")

    dsGui.barra := dsGui.g.Add("Progress", "x0 y" _E(22) " w" _E(104) " h" _E(3) " Background2E2E2E")

    OnMessage(0x0201, _DsGUI_WM_LBUTTONDOWN)

    posDs := LeerPosicionGUI("Slider")
    if !(IsObject(posDs) && _PosicionValidaEnPantalla(posDs.x, posDs.y))
        posDs := _AnclaBloquePaneles()
    dsGui.g.Show("x" posDs.x " y" posDs.y " w" _E(104) " h" _E(25) " NoActivate")
    ActualizarDsGUI()
}

ActualizarDsGUI() {
    if (colorV.hover) {
        _SetIcono(dsGui.icono, "slider_on")
        dsGui.label.Value := "SLIDER ON"
        dsGui.barra.Opt("cB4C0DE")
        dsGui.g.BackColor := "636D83"
        dsGui.label.SetFont("s" _FS(9) " bold cFFFFFF", "Segoe UI")
        dsGui.barra.Value := 100
    } else {
        _SetIcono(dsGui.icono, "slider_off")
        dsGui.label.Value := "SLIDER OFF"
        dsGui.barra.Opt("c6A6A6A")
        dsGui.g.BackColor := "424242"
        dsGui.label.SetFont("s" _FS(9) " bold cB2B2B2", "Segoe UI")
        dsGui.barra.Value := 100
    }
}

_DsGUI_WM_LBUTTONDOWN(wParam, lParam, msg, hwnd) {
    global dsGui
    _ArrastrarPanelBloque(hwnd, lParam, dsGui)
}

IniciarCcGUI() {
    global ccGui
    ccGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow", "")
    ccGui.g.BackColor := "424242"
    ccGui.g.MarginX := 0
    ccGui.g.MarginY := 0
    WinSetTransparent(235, ccGui.g)

    ccGui.icono := ccGui.g.Add("Picture", "x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20), "")

    ccGui.label := ccGui.g.Add("Text", "x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite", "")
    ccGui.label.SetFont("s" _FS(9) " bold", "Segoe UI")

    ccGui.barra := ccGui.g.Add("Progress", "x0 y" _E(22) " w" _E(104) " h" _E(3) " Background2E2E2E")

    OnMessage(0x0201, _CcGUI_WM_LBUTTONDOWN)

    posCc := LeerPosicionGUI("Circle")
    if (IsObject(posCc) && _PosicionValidaEnPantalla(posCc.x, posCc.y)) {
        ccX := posCc.x, ccY := posCc.y
    } else {
        try {
            WinGetPos(&dsX, &dsY, &dsW, &dsH, "ahk_id " dsGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            dsX := ancla.x, dsY := ancla.y, dsW := _E(104)
        }
        ccX := dsX + dsW + PANEL_GAP, ccY := dsY
    }
    ccGui.g.Show("x" ccX " y" ccY " w" _E(104) " h" _E(25) " NoActivate")
    ActualizarCcGUI()
}

ActualizarCcGUI() {
    if (colorCC.hover) {
        _SetIcono(ccGui.icono, "circle_on")
        ccGui.label.Value := "CIRCLE ON"
        ccGui.barra.Opt("cB4C0DE")
        ccGui.g.BackColor := "636D83"
        ccGui.label.SetFont("s" _FS(9) " bold cFFFFFF", "Segoe UI")
        ccGui.barra.Value := 100
    } else {
        _SetIcono(ccGui.icono, "circle_off")
        ccGui.label.Value := "CIRCLE OFF"
        ccGui.barra.Opt("c6A6A6A")
        ccGui.g.BackColor := "424242"
        ccGui.label.SetFont("s" _FS(9) " bold cB2B2B2", "Segoe UI")
        ccGui.barra.Value := 100
    }
}

_CcGUI_WM_LBUTTONDOWN(wParam, lParam, msg, hwnd) {
    global ccGui
    _ArrastrarPanelBloque(hwnd, lParam, ccGui)
}

IniciarArGUI() {
    global arGui
    arGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow", "")
    arGui.g.BackColor := "424242"
    arGui.g.MarginX := 0
    arGui.g.MarginY := 0
    WinSetTransparent(235, arGui.g)

    arGui.icono := arGui.g.Add("Picture", "x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20), "")

    arGui.label := arGui.g.Add("Text", "x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite", "")
    arGui.label.SetFont("s" _FS(9) " bold", "Segoe UI")

    arGui.barra := arGui.g.Add("Progress", "x0 y" _E(22) " w" _E(104) " h" _E(3) " Background2E2E2E")

    OnMessage(0x0201, _ArGUI_WM_LBUTTONDOWN)

    posAr := LeerPosicionGUI("Quick")
    if (IsObject(posAr) && _PosicionValidaEnPantalla(posAr.x, posAr.y)) {
        arX := posAr.x, arY := posAr.y
    } else {
        try {
            WinGetPos(&ccX, &ccY, &ccW, &ccH, "ahk_id " ccGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            ccX := ancla.x + _E(104) + PANEL_GAP, ccY := ancla.y, ccW := _E(104)
        }
        arX := ccX + ccW + PANEL_GAP, arY := ccY
    }
    arGui.g.Show("x" arX " y" arY " w" _E(104) " h" _E(25) " NoActivate")
    ActualizarArGUI()
}

ActualizarArGUI() {
    if (ar.hover) {
        _SetIcono(arGui.icono, "quick_on")
        arGui.label.Value := "QUICK ON"
        arGui.barra.Opt("cB4C0DE")
        arGui.g.BackColor := "636D83"
        arGui.label.SetFont("s" _FS(9) " bold cFFFFFF", "Segoe UI")
        arGui.barra.Value := 100
    } else {
        _SetIcono(arGui.icono, "quick_off")
        arGui.label.Value := "QUICK OFF"
        arGui.barra.Opt("c6A6A6A")
        arGui.g.BackColor := "424242"
        arGui.label.SetFont("s" _FS(9) " bold cB2B2B2", "Segoe UI")
        arGui.barra.Value := 100
    }
}

_ArGUI_WM_LBUTTONDOWN(wParam, lParam, msg, hwnd) {
    global arGui
    _ArrastrarPanelBloque(hwnd, lParam, arGui)
}

; ┌──────────────────────────────────────────────────────────┐
; │  HC GUI — botón permanente HC ON/OFF (Historial de Color  │
; │  dinámico). Mismo tamaño/estilo que dsGui/ccGui/arGui. Un    │
; │  corto = mismo efecto que Numpad0. Se apila debajo de      │
; │  arGui y también se puede arrastrar para reposicionar.     │
; └──────────────────────────────────────────────────────────┘
IniciarHCGUI() {
    global hcGui
    hcGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow", "")
    hcGui.g.BackColor := "424242"
    hcGui.g.MarginX := 0
    hcGui.g.MarginY := 0
    WinSetTransparent(235, hcGui.g)

    hcGui.icono := hcGui.g.Add("Picture", "x" _E(4) " y" _E(2) " w" _E(20) " h" _E(20), "")

    hcGui.label := hcGui.g.Add("Text", "x" _E(26) " y" _E(3) " w" _E(76) " h" _E(19) " cWhite", "")
    hcGui.label.SetFont("s" _FS(9) " bold", "Segoe UI")

    hcGui.barra := hcGui.g.Add("Progress", "x0 y" _E(22) " w" _E(104) " h" _E(3) " Background2E2E2E")

    OnMessage(0x0201, _HCGUI_WM_LBUTTONDOWN)

    posHc := LeerPosicionGUI("HC")
    if (IsObject(posHc) && _PosicionValidaEnPantalla(posHc.x, posHc.y)) {
        x := posHc.x, y := posHc.y
    } else {
        try {
            WinGetPos(&aX, &aY, , , "ahk_id " dsGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            aX := ancla.x, aY := ancla.y
        }
        off := _HcOffsetBloque()
        x := aX + off.dx
        y := aY + off.dy
    }
    hcGui.g.Show("x" x " y" y " w" _E(104) " h" _E(25) " NoActivate")
    ActualizarHCGUI()
}

ActualizarHCGUI() {
    if (hist.modo = 1) {
        _SetIcono(hcGui.icono, "hist_on")
        hcGui.label.Value := "HC ON"
        hcGui.barra.Opt("cB4C0DE")
        hcGui.g.BackColor := "636D83"
        hcGui.label.SetFont("s" _FS(9) " bold cFFFFFF", "Segoe UI")
        hcGui.barra.Value := 100
    } else {
        _SetIcono(hcGui.icono, "hist_off")
        hcGui.label.Value := "HC OFF"
        hcGui.barra.Opt("c6A6A6A")
        hcGui.g.BackColor := "424242"
        hcGui.label.SetFont("s" _FS(9) " bold cB2B2B2", "Segoe UI")
        hcGui.barra.Value := 100
    }
}

; Click corto = toggle (como Numpad0). Arrastre = mueve el bloque (si
; no está fijado); todo lo maneja _ArrastrarPanelBloque.
_HCGUI_WM_LBUTTONDOWN(wParam, lParam, msg, hwnd) {
    global hcGui
    _ArrastrarPanelBloque(hwnd, lParam, hcGui)
}

; ┌──────────────────────────────────────────────────────────┐
; │  LOCK GUI — botón de fijar el bloque. Va a la derecha de   │
; │  arGui y forma parte del bloque (se mueve con él cuando    │
; │  está libre). 🔒 = fijado (no se puede arrastrar),         │
; │  🔓 = libre. Click corto = alternar. Se guarda en el .ini. │
; └──────────────────────────────────────────────────────────┘
IniciarLockGUI() {
    global lockGui, panelBlk
    panelBlk.locked := (IniRead(_PosGuiIniPath(), "PanelBlock", "locked", "1") = "1")
    lockGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow", "")
    lockGui.g.BackColor := "424242"
    lockGui.g.MarginX := 0
    lockGui.g.MarginY := 0
    WinSetTransparent(235, lockGui.g)

    lockGui.icono := lockGui.g.Add("Picture", "x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19), "")
    lockGui.barra := lockGui.g.Add("Progress", "x0 y" _E(22) " w" _E(31) " h" _E(3) " Background2E2E2E")

    OnMessage(0x0201, _LockGUI_WM_LBUTTONDOWN)

    posLock := LeerPosicionGUI("Lock")
    if (IsObject(posLock) && _PosicionValidaEnPantalla(posLock.x, posLock.y)) {
        lockX := posLock.x, lockY := posLock.y
    } else {
        try {
            WinGetPos(&arX, &arY, &arW, &arH, "ahk_id " arGui.g.Hwnd)
        } catch {
            ancla := _AnclaBloquePaneles()
            arX := ancla.x + 2 * (_E(104) + PANEL_GAP), arY := ancla.y, arW := _E(104)
        }
        lockX := arX + arW + PANEL_GAP, lockY := arY
    }
    lockGui.g.Show("x" lockX " y" lockY " w" _E(31) " h" _E(25) " NoActivate")
    ActualizarLockGUI()
}

ActualizarLockGUI() {
    if (panelBlk.locked) {
        _SetIcono(lockGui.icono, "lock_closed")
        lockGui.barra.Opt("c6A6A6A")
        lockGui.g.BackColor := "424242"
    } else {
        _SetIcono(lockGui.icono, "lock_open")
        lockGui.barra.Opt("cB4C0DE")
        lockGui.g.BackColor := "636D83"
    }
    lockGui.barra.Value := 100
}

_LockGUI_WM_LBUTTONDOWN(wParam, lParam, msg, hwnd) {
    global lockGui
    _ArrastrarPanelBloque(hwnd, lParam, lockGui)
}

; ┌──────────────────────────────────────────────────────────┐
; │  RELOAD GUI — botón permanente para recargar el script.   │
; │  Mismo tamaño/estilo que dsGui/hcGui. Un click corto        │
; │  llama a Reload() directo — NO es el botón de pánico       │
; │  (Numpad8), es un reload limpio y simple. Se apila debajo  │
; │  de hcGui y también se puede arrastrar para reposicionar.  │
; └──────────────────────────────────────────────────────────┘
IniciarReloadGUI() {
    global reloadGui
    reloadGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow", "")
    reloadGui.g.BackColor := "3B7A4B"      ; verde: destaca como botón de recarga
    reloadGui.g.MarginX := 0
    reloadGui.g.MarginY := 0
    WinSetTransparent(235, reloadGui.g)

    ; Solo el símbolo, centrado — botón ajustado al tamaño del icono.
    reloadGui.icono := reloadGui.g.Add("Picture", "x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19), "")
    _SetIcono(reloadGui.icono, "reload_g")

    reloadGui.barra := reloadGui.g.Add("Progress", "x0 y" _E(22) " w" _E(31) " h" _E(3) " Background2E2E2E c8FE6AA")
    reloadGui.barra.Value := 100

    OnMessage(0x0201, _ReloadGUI_WM_LBUTTONDOWN)

    ; Justo debajo de hcGui, alineado a la izquierda de esa columna
    ; (mismo x que los otros paneles, sin recentrar por su propio ancho
    ; angosto), salvo que haya una posición guardada de un arrastre anterior.
    mon := ObtenerMonitorCSP()
    x := mon.x + (mon.w - _E(104)) // 2
    y := mon.y + Round(mon.h * 0.02) + 42 + 4 + _E(25) + 4 + _E(25) + 4 + _E(25) + 4 + _E(25) + 4
    guardada := LeerPosicionGUI("Reload")
    if IsObject(guardada) && _PosicionValidaEnPantalla(guardada.x, guardada.y) {
        x := guardada.x
        y := guardada.y
    }
    reloadGui.g.Show("x" x " y" y " w" _E(31) " h" _E(25) " NoActivate")
}

; Click corto = Reload() directo. Arrastre = mover el botón.
_ReloadGUI_WM_LBUTTONDOWN(wParam, lParam, msg, hwnd) {
    global reloadGui
    static arrastrando := false
    if (arrastrando)
        return
    if (hwnd = reloadGui.g.Hwnd || reloadGui.g.Hwnd = DllCall("GetParent", "Ptr", hwnd, "Ptr")) {
        arrastrando := true
        pt := Buffer(8, 0)
        NumPut("int", lParam & 0xFFFF,        pt, 0)
        NumPut("int", (lParam >> 16) & 0xFFFF, pt, 4)
        DllCall("ClientToScreen", "Ptr", hwnd, "Ptr", pt)
        clickX := NumGet(pt, 0, "int")
        clickY := NumGet(pt, 4, "int")

        rc := Buffer(16, 0)
        DllCall("GetWindowRect", "Ptr", reloadGui.g.Hwnd, "Ptr", rc)
        offX := clickX - NumGet(rc, 0, "int")
        offY := clickY - NumGet(rc, 4, "int")

        cur := Buffer(8, 0)
        SWP_NOSIZE := 0x0001, SWP_NOZORDER := 0x0004, SWP_NOACTIVATE := 0x0010
        movido := false
        while GetKeyState("LButton", "P") {
            DllCall("GetCursorPos", "Ptr", cur)
            mx := NumGet(cur, 0, "int"), my := NumGet(cur, 4, "int")
            if (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4) {
                movido := true
                DllCall("SetWindowPos", "Ptr", reloadGui.g.Hwnd, "Ptr", 0
                    , "int", mx - offX, "int", my - offY, "int", 0, "int", 0
                    , "uint", SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE)
            }
            Sleep(8)
        }
        if !movido {
            SoundBeep(700, 60)
            Reload()
        } else {
            GuardarPosicionGUI("Reload", reloadGui.g.Hwnd)
        }
        arrastrando := false
    }
}


; ┌──────────────────────────────────────────────────────────────────────┐
; │  PUNTOS DE CALIBRACIÓN — carga / guardado / zonas derivadas           │
; │  .ini: [Puntos1], [Puntos2]…  P1x, P1y … P30x, P30y, HistAlto, firma
; │        [Perfil]  actual, ultimaFirma                      │
; └──────────────────────────────────────────────────────────────────────┘
PuntosPorDefecto() {
    global PUNTOS_DEF
    r := []
    for p in PUNTOS_DEF
        r.Push([p[1], p[2]])
    return r
}

CargarPuntos() {
    global PUNTOS, PUNTOS_DEF, HIST_ALTO, PERFIL
    ini := _PosGuiIniPath()
    sec := "Puntos" PERFIL
    PUNTOS := []
    for i, p in PUNTOS_DEF {
        x := IniRead(ini, sec, "P" i "x", "")
        y := IniRead(ini, sec, "P" i "y", "")
        if ((x = "" || y = "") && PERFIL = 1) {
            ; Migración: la versión anterior guardaba en [Puntos] (sin perfil).
            x := IniRead(ini, "Puntos", "P" i "x", "")
            y := IniRead(ini, "Puntos", "P" i "y", "")
        }
        if (IsInteger(x) && IsInteger(y))
            PUNTOS.Push([Integer(x), Integer(y)])
        else
            PUNTOS.Push([p[1], p[2]])
    }
    h := IniRead(ini, sec, "HistAlto", "")
    if (h = "" && PERFIL = 1)
        h := IniRead(ini, "Puntos", "HistAlto", "")
    HIST_ALTO := IsInteger(h) ? Integer(h) : 104
    RecalcularZonas()
}

; conFirma=true también anota la disposición de monitores actual en el
; perfil (así podrá auto-seleccionarse cuando vuelvas a esa configuración).
GuardarPuntos(conFirma := true) {
    global PUNTOS, HIST_ALTO, PERFIL
    ini := _PosGuiIniPath()
    sec := "Puntos" PERFIL
    for i, p in PUNTOS {
        IniWrite(p[1], ini, sec, "P" i "x")
        IniWrite(p[2], ini, sec, "P" i "y")
    }
    IniWrite(HIST_ALTO, ini, sec, "HistAlto")
    if (conFirma)
        IniWrite(_FirmaMonitores(), ini, sec, "firma")
}

; ── Escala de los botones (por perfil) ───────────────────────────
; Valor en % guardado en [Puntos<perfil>] escala=. Por defecto: 75 % para
; "Laptop + tableta" (pantalla más chica) y 100 % para "Monitor + tableta".
CargarEscala() {
    global ESC, PERFIL
    v := IniRead(_PosGuiIniPath(), "Puntos" PERFIL, "escala", "")
    if (!IsNumber(v) || Number(v) < 40 || Number(v) > 200)
        v := (PERFIL = 1) ? 75 : 100
    ESC := Number(v) / 100
}

; Escala de los avisos (HUD, mini-textos, toggles, icono zoom/rotar), por perfil.
; Se guarda en [Puntos<perfil>] escalaAvisos= (%). Por defecto: 10 % sobre la
; escala de botones (75 % -> 83 %, 100 % -> 110 %).
CargarEscalaAvisos() {
    global AVISO_ESC, ESC, PERFIL
    v := IniRead(_PosGuiIniPath(), "Puntos" PERFIL, "escalaAvisos", "")
    if (!IsNumber(v) || Number(v) < 40 || Number(v) > 250)
        v := Round(ESC * 110)
    AVISO_ESC := Number(v) / 100
}

; Tamaño en píxeles lógicos y en puntos de fuente, ya escalados.
_E(n)  => Max(1, Round(n * ESC))
_FS(n) => Max(6, Round(n * ESC))

; ── Perfiles ─────────────────────────────────────────────────────
; Firma = rectángulos de todos los monitores (ordenados). Cambia al
; conectar/desconectar el monitor o mover la tableta de sitio.
_FirmaMonitores() {
    f := ""
    Loop MonitorGetCount() {
        MonitorGet(A_Index, &l, &t, &r, &b)
        f .= (f = "" ? "" : ";") l "," t "," r "," b
    }
    f := Sort(f, "D;")
    return f
}

; Decide el perfil activo al arrancar: el último elegido, salvo que la
; disposición de monitores haya cambiado desde la última vez y exista un
; perfil guardado con esa misma firma (entonces cambia solo).
ElegirPerfil() {
    global PERFIL, PERFILES
    ini := _PosGuiIniPath()
    act := IniRead(ini, "Perfil", "actual", "1")
    PERFIL := (IsInteger(act) && Integer(act) >= 1 && Integer(act) <= PERFILES.Length) ? Integer(act) : 1
    firma := _FirmaMonitores()
    previa := IniRead(ini, "Perfil", "ultimaFirma", "")
    if (previa = firma)
        return
    IniWrite(firma, ini, "Perfil", "ultimaFirma")
    primera := (previa = "")      ; primer arranque con perfiles: no avisar
    for i, nombre in PERFILES {
        if (IniRead(ini, "Puntos" i, "firma", "") = firma) {
            PERFIL := i
            IniWrite(i, ini, "Perfil", "actual")
            msg := "PERFIL AUTO: " nombre
            SetTimer(() => MostrarHUD(msg, "9AA7C7", 2500), -1800)
            return
        }
    }
    if (primera)
        return
    msg := "MONITORES CAMBIARON — elige perfil en 📍 (actual: " PERFILES[PERFIL] ")"
    SetTimer(() => MostrarHUD(msg, "9AA7C7", 3500), -1800)
}

; Rectángulo que envuelve n puntos consecutivos a partir de "desde".
_ZonaDePuntos(desde, n) {
    global PUNTOS
    x1 := PUNTOS[desde][1], x2 := x1
    y1 := PUNTOS[desde][2], y2 := y1
    Loop n - 1 {
        p := PUNTOS[desde + A_Index]
        x1 := Min(x1, p[1]), x2 := Max(x2, p[1])
        y1 := Min(y1, p[2]), y2 := Max(y2, p[2])
    }
    return { x1: x1, y1: y1, x2: x2, y2: y2 }
}

; Recalcula (y deja en caché) las 7 zonas. Se llama tras cualquier cambio.
RecalcularZonas() {
    global ZONAS, HIST_ALTO
    izq := [], der := []
    Loop 3 {
        izq.Push(_ZonaDePuntos(3 + (A_Index - 1) * 4, 4))
        der.Push(_ZonaDePuntos(15 + (A_Index - 1) * 4, 4))
    }
    h := _ZonaDePuntos(27, 2)
    if (HIST_ALTO >= 0)
        h.y2 := h.y2 + HIST_ALTO
    else
        h.y1 := h.y1 + HIST_ALTO
    ZONAS := { izq: izq, der: der, hist: h }
}

_NombrePunto(i) {
    if (i <= 2)
        return "Ocultar/mostrar · " (i = 1 ? "izq" : "der")
    if (i <= 14)
        return "Izq B" ((i - 3) // 4 + 1) " · esq " (Mod(i - 3, 4) + 1)
    if (i <= 26)
        return "Der B" ((i - 15) // 4 + 1) " · esq " (Mod(i - 15, 4) + 1)
    if (i = 27)
        return "Historial · izq"
    if (i = 28)
        return "Historial · der"
    if (i = 29)
        return "Zona segura (rehacer)"
    return "Avisos · esq. sup. izq. (HUD)"
}

; ┌──────────────────────────────────────────────────────────┐
; │  PUNTOS GUI — botón 📍 junto al de recarga. Click corto   │
; │  abre el panel de calibración; arrastrar lo reposiciona   │
; │  (se guarda en el .ini). Atajo: Ctrl+F10.                 │
; └──────────────────────────────────────────────────────────┘
IniciarPuntosGUI() {
    global puntosGui, reloadGui
    puntosGui.g := Gui("+AlwaysOnTop -Caption +ToolWindow", "")
    puntosGui.g.BackColor := "424242"
    puntosGui.g.MarginX := 0
    puntosGui.g.MarginY := 0
    WinSetTransparent(235, puntosGui.g)

    puntosGui.icono := puntosGui.g.Add("Picture", "x" _E(6) " y" _E(2) " w" _E(19) " h" _E(19), "")
    _SetIcono(puntosGui.icono, "calib")
    puntosGui.barra := puntosGui.g.Add("Progress", "x0 y" _E(22) " w" _E(31) " h" _E(3) " Background2E2E2E c636D83")
    puntosGui.barra.Value := 100

    OnMessage(0x0201, _PuntosGUI_WM_LBUTTONDOWN)

    ; Por defecto: justo a la derecha del botón de recarga (misma fila).
    mon := ObtenerMonitorCSP()
    x := mon.x + (mon.w - _E(104)) // 2 + _E(31) + PANEL_GAP
    y := mon.y + Round(mon.h * 0.02)
    try {
        WinGetPos(&rX, &rY, &rW, &rH, "ahk_id " reloadGui.g.Hwnd)
        x := rX + rW + PANEL_GAP
        y := rY
    }
    guardada := LeerPosicionGUI("PuntosBtn")
    if IsObject(guardada) && _PosicionValidaEnPantalla(guardada.x, guardada.y) {
        x := guardada.x
        y := guardada.y
    }
    puntosGui.g.Show("x" x " y" y " w" _E(31) " h" _E(25) " NoActivate")
}

; Click corto = abrir panel. Arrastre = mover el botón.
_PuntosGUI_WM_LBUTTONDOWN(wParam, lParam, msg, hwnd) {
    global puntosGui
    static arrastrando := false
    if (arrastrando)
        return
    if !IsObject(puntosGui.g)
        return
    if (hwnd = puntosGui.g.Hwnd || puntosGui.g.Hwnd = DllCall("GetParent", "Ptr", hwnd, "Ptr")) {
        arrastrando := true
        pt := Buffer(8, 0)
        NumPut("int", lParam & 0xFFFF,         pt, 0)
        NumPut("int", (lParam >> 16) & 0xFFFF, pt, 4)
        DllCall("ClientToScreen", "Ptr", hwnd, "Ptr", pt)
        clickX := NumGet(pt, 0, "int")
        clickY := NumGet(pt, 4, "int")

        rc := Buffer(16, 0)
        DllCall("GetWindowRect", "Ptr", puntosGui.g.Hwnd, "Ptr", rc)
        offX := clickX - NumGet(rc, 0, "int")
        offY := clickY - NumGet(rc, 4, "int")

        cur := Buffer(8, 0)
        SWP_NOSIZE := 0x0001, SWP_NOZORDER := 0x0004, SWP_NOACTIVATE := 0x0010
        movido := false
        while GetKeyState("LButton", "P") {
            DllCall("GetCursorPos", "Ptr", cur)
            mx := NumGet(cur, 0, "int"), my := NumGet(cur, 4, "int")
            if (Abs(mx - clickX) > 4 || Abs(my - clickY) > 4) {
                movido := true
                DllCall("SetWindowPos", "Ptr", puntosGui.g.Hwnd, "Ptr", 0
                    , "int", mx - offX, "int", my - offY, "int", 0, "int", 0
                    , "uint", SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE)
            }
            Sleep(8)
        }
        if !movido
            AbrirPanelPuntos()
        else
            GuardarPosicionGUI("PuntosBtn", puntosGui.g.Hwnd)
        arrastrando := false
    }
}

; ┌──────────────────────────────────────────────────────────────────────┐
; │  PANEL DE CALIBRACIÓN — editar los 30 puntos desde el GUI             │
; │   · Lista P1-P30 (X, Y). Selecciona uno y edita X / Y abajo.          │
; │   · Desplazar TODOS: ΔX / ΔY (cuando la tableta se movió entera).     │
; │   · Captura (F1): con el lápiz sobre el punto, F1 lo guarda y pasa    │
; │     al siguiente; F2 termina. Igual que el calibrador.                │
; │   · Ver zonas: dibuja las zonas calculadas unos segundos.             │
; │   · Los cambios se aplican EN VIVO; se guardan al "Guardar y cerrar". │
; └──────────────────────────────────────────────────────────────────────┘
AbrirPanelPuntos() {
    global ptsEd, PUNTOS, HIST_ALTO, PERFIL, PERFILES, ESC, AVISO_ESC, panelBlk
    if IsObject(ptsEd.g) {
        try {
            ptsEd.g.Show()
            return
        }
        ptsEd.g := 0
    }
    g := Gui("+AlwaysOnTop", "📍 Calibración de puntos")
    g.SetFont("s9", "Segoe UI")

    g.Add("Text", "xm y+4", "Perfil de equipo:")
    ddl := g.Add("DropDownList", "x+8 yp-3 w230 Choose" PERFIL, PERFILES)
    ddl.OnEvent("Change", _PtsCambiarPerfil)

    g.Add("Text", "xm y+8", "Escala de botones (%):")
    eEsc := g.Add("Edit", "x+8 yp-3 w55", Round(ESC * 100))
    g.Add("Text", "x+8 yp+3", "(se aplica al guardar; recarga el script)")

    g.Add("Text", "xm y+8", "Escala de avisos (%):")
    eEscAv := g.Add("Edit", "x+8 yp-3 w55", Round(AVISO_ESC * 100))
    g.Add("Text", "x+8 yp+3", "(HUD, mini-textos, icono zoom/rotar; igual: al guardar)")

    lv := g.Add("ListView", "xm y+8 w440 r11 -Multi NoSortHdr Grid", ["#", "Punto", "X", "Y"])
    for i, p in PUNTOS
        lv.Add("", "P" i, _NombrePunto(i), p[1], p[2])
    lv.ModifyCol(1, 40)
    lv.ModifyCol(2, 220)
    lv.ModifyCol(3, 70)
    lv.ModifyCol(4, 70)

    g.Add("Text", "xm y+10", "Seleccionado:   X")
    ex := g.Add("Edit", "x+6 yp-3 w70", "")
    g.Add("Text", "x+12 yp+3", "Y")
    ey := g.Add("Edit", "x+6 yp-3 w70", "")

    g.Add("Text", "xm y+10", "Desplazar TODOS:   ΔX")
    dx := g.Add("Edit", "x+6 yp-3 w60", "0")
    g.Add("Text", "x+12 yp+3", "ΔY")
    dy := g.Add("Edit", "x+6 yp-3 w60", "0")
    bDelta := g.Add("Button", "x+12 yp-2 w80", "Aplicar Δ")

    g.Add("Text", "xm y+10", "Alto franja historial (px; negativo = hacia arriba):")
    hAlto := g.Add("Edit", "x+6 yp-3 w60", HIST_ALTO)

    g.Add("Text", "xm y+12", "📌 Ubicar GUI — botones del script:")
    bMover := g.Add("Button", "x+8 yp-4 w135", panelBlk.locked ? "🔓 Mover botones" : "🔒 Fijar botones")
    bReub  := g.Add("Button", "x+6 yp w135", "↺ Reubicar botones")
    g.Add("Text", "xm y+8", "📌 Ubicar GUI — paneles de CSP:")
    bLN := g.Add("Button", "x+8 yp-4 w125", "💾 Guardar Normal")
    bLE := g.Add("Button", "x+6 yp w125", "💾 Guardar Enfoque")
    bLA := g.Add("Button", "x+6 yp w90", "▶ Aplicar")

    bCap  := g.Add("Button", "xm y+12 w115", "🎯 Captura (F1)")
    bVer  := g.Add("Button", "x+6 yp w90", "👁 Ver zonas")
    bDef  := g.Add("Button", "x+6 yp w120", "↺ Puntos por defecto")
    bOk   := g.Add("Button", "x+6 yp w125 Default", "💾 Guardar y cerrar")
    bRei  := g.Add("Button", "xm y+8 w140", "🔄 Reiniciar script")
    st    := g.Add("Text", "xm y+10 w440 h34", "")

    ptsEd.g := g, ptsEd.lv := lv, ptsEd.ex := ex, ptsEd.ey := ey
    ptsEd.dx := dx, ptsEd.dy := dy, ptsEd.hAlto := hAlto, ptsEd.eEsc := eEsc, ptsEd.eEscAv := eEscAv, ptsEd.st := st
    ptsEd.bCap := bCap, ptsEd.sel := 0, ptsEd.capturando := false
    st.Value := "Perfil activo: " PERFILES[PERFIL] ". Selecciona un punto de la lista."

    lv.OnEvent("ItemSelect", _PtsSel)
    ex.OnEvent("Change", _PtsEditChange)
    ey.OnEvent("Change", _PtsEditChange)
    hAlto.OnEvent("Change", _PtsAltoChange)
    bDelta.OnEvent("Click", _PtsDesplazar)
    bMover.OnEvent("Click", (ctrl, *) => _PtsMoverBotones(ctrl))
    bReub.OnEvent("Click", _PtsReubicar)
    bLN.OnEvent("Click", (*) => _CapturarLayout("Normal"))
    bLE.OnEvent("Click", (*) => _CapturarLayout("Enfoque"))
    bLA.OnEvent("Click", (*) => _AplicarLayoutPaneles(enfoque.activo ? "Enfoque" : "Normal"))
    bCap.OnEvent("Click", _PtsToggleCaptura)
    bVer.OnEvent("Click", (*) => MostrarZonasCalibracion(3500))
    bDef.OnEvent("Click", _PtsDefecto)
    bRei.OnEvent("Click", _PtsReiniciar)
    bOk.OnEvent("Click", _PtsCerrar)
    g.OnEvent("Close", _PtsCerrar)
    g.OnEvent("Escape", _PtsCerrar)

    g.Show("AutoSize")
    lv.Modify(1, "Select Focus")
    _PtsSel(lv, 1, true)
}

_PtsSel(ctrl, item, selected) {
    global ptsEd, PUNTOS
    if (!selected || item < 1)
        return
    ptsEd.sel := item
    ptsEd.ex.Value := PUNTOS[item][1]
    ptsEd.ey.Value := PUNTOS[item][2]
    if (ptsEd.capturando)
        _PtsEstadoCaptura()
    else
        ptsEd.st.Value := "P" item " — " _NombrePunto(item)
}

; Editar X/Y del punto seleccionado. Idempotente: si los valores ya son
; los guardados (p. ej. al cargar la selección) no hace nada.
_PtsEditChange(*) {
    global ptsEd, PUNTOS
    i := ptsEd.sel
    if (i < 1)
        return
    x := Trim(ptsEd.ex.Value), y := Trim(ptsEd.ey.Value)
    if (!IsInteger(x) || !IsInteger(y))
        return
    x := Integer(x), y := Integer(y)
    if (PUNTOS[i][1] = x && PUNTOS[i][2] = y)
        return
    PUNTOS[i][1] := x
    PUNTOS[i][2] := y
    ptsEd.lv.Modify(i, "", "P" i, _NombrePunto(i), x, y)
    RecalcularZonas()
}

_PtsAltoChange(*) {
    global ptsEd, HIST_ALTO
    v := Trim(ptsEd.hAlto.Value)
    if (!IsInteger(v) || Integer(v) = HIST_ALTO)
        return
    HIST_ALTO := Integer(v)
    RecalcularZonas()
}

_PtsDesplazar(*) {
    global ptsEd, PUNTOS
    dx := Trim(ptsEd.dx.Value), dy := Trim(ptsEd.dy.Value)
    if (!IsInteger(dx) || !IsInteger(dy)) {
        ptsEd.st.Value := "ΔX y ΔY deben ser números enteros."
        return
    }
    dx := Integer(dx), dy := Integer(dy)
    for p in PUNTOS {
        p[1] += dx
        p[2] += dy
    }
    _PtsRefrescar()
    ptsEd.dx.Value := "0"
    ptsEd.dy.Value := "0"
    ptsEd.st.Value := "Desplazados los 30 puntos: ΔX=" dx "  ΔY=" dy
}

; Vuelca PUNTOS / HIST_ALTO a la lista y a los campos, y recalcula zonas.
_PtsRefrescar() {
    global ptsEd, PUNTOS, HIST_ALTO
    for i, p in PUNTOS
        ptsEd.lv.Modify(i, "", "P" i, _NombrePunto(i), p[1], p[2])
    ptsEd.hAlto.Value := HIST_ALTO
    if (ptsEd.sel >= 1) {
        ptsEd.ex.Value := PUNTOS[ptsEd.sel][1]
        ptsEd.ey.Value := PUNTOS[ptsEd.sel][2]
    }
    RecalcularZonas()
}

; Reinicia el script (Reload). Guarda antes lo que haya en el panel.
_PtsReiniciar(*) {
    _PtsCapturaOff()
    GuardarPuntos()
    ToolTip("🔄 Reiniciando script…")
    Sleep(250)
    Reload()
}

_PtsDefecto(*) {
    global PUNTOS, HIST_ALTO, ptsEd
    PUNTOS := PuntosPorDefecto()
    HIST_ALTO := 104
    _PtsRefrescar()
    ptsEd.st.Value := "Cargados los puntos por defecto del script (se guardan con 💾 Guardar y cerrar)."
}

; ── Ubicar GUI ───────────────────────────────────────────────────
; "Mover botones": abre/cierra el candado del bloque (igual que el 🔒/🔓).
_PtsMoverBotones(ctrl) {
    global panelBlk
    _ToggleBloqueo()
    ctrl.Text := panelBlk.locked ? "🔓 Mover botones" : "🔒 Fijar botones"
}

_PtsReubicar(*) {
    global ptsEd
    ReubicarBotones()
    ptsEd.st.Value := "Botones reubicados para este perfil (arriba, centrados en el monitor de CSP)."
}

; Devuelve los botones del script a su sitio por defecto en el monitor de CSP,
; ya con la escala del perfil: fila Slider/Circle/Quick/🔒, HC debajo del
; Slider, y 🔄 + 📍 debajo de HC. Guarda las posiciones del perfil activo.
ReubicarBotones() {
    global dsGui, ccGui, arGui, hcGui, lockGui, reloadGui, puntosGui
    mon := ObtenerMonitorCSP()
    F := 0x0001 | 0x0004 | 0x0010          ; NOSIZE | NOZORDER | NOACTIVATE
    ancho := _E(104) * 3 + PANEL_GAP * 2
    x0 := mon.x + (mon.w - ancho) // 2
    y0 := mon.y + Round(mon.h * 0.02) + 42 + 4
    sx := x0
    for g in [dsGui, ccGui, arGui, lockGui] {
        if !IsObject(g.g)
            continue
        DllCall("SetWindowPos", "Ptr", g.g.Hwnd, "Ptr", 0, "int", sx, "int", y0, "int", 0, "int", 0, "uint", F)
        WinGetPos(&gx, &gy, &gw, &gh, "ahk_id " g.g.Hwnd)
        sx += gw + PANEL_GAP
    }
    WinGetPos(&gx, &gy, &gw, &dsH, "ahk_id " dsGui.g.Hwnd)
    hcY := y0 + dsH + PANEL_GAP
    DllCall("SetWindowPos", "Ptr", hcGui.g.Hwnd, "Ptr", 0, "int", x0, "int", hcY, "int", 0, "int", 0, "uint", F)
    WinGetPos(&gx, &gy, &gw, &hcH, "ahk_id " hcGui.g.Hwnd)
    ry := hcY + hcH + PANEL_GAP
    DllCall("SetWindowPos", "Ptr", reloadGui.g.Hwnd, "Ptr", 0, "int", x0, "int", ry, "int", 0, "int", 0, "uint", F)
    WinGetPos(&gx, &gy, &rw, &rh, "ahk_id " reloadGui.g.Hwnd)
    DllCall("SetWindowPos", "Ptr", puntosGui.g.Hwnd, "Ptr", 0, "int", x0 + rw + PANEL_GAP, "int", ry, "int", 0, "int", 0, "uint", F)
    GuardarPosicionGUI("PanelBlock", dsGui.g.Hwnd)
    GuardarPosicionGUI("Slider", dsGui.g.Hwnd)
    GuardarPosicionGUI("Circle", ccGui.g.Hwnd)
    GuardarPosicionGUI("Quick", arGui.g.Hwnd)
    GuardarPosicionGUI("Lock", lockGui.g.Hwnd)
    GuardarPosicionGUI("HC", hcGui.g.Hwnd)
    _GuardarOffsetHC()
    GuardarPosicionGUI("Reload", reloadGui.g.Hwnd)
    GuardarPosicionGUI("PuntosBtn", puntosGui.g.Hwnd)
}

; Cambiar de perfil: guarda los puntos del actual, apunta el nuevo en el .ini
; y recarga el script (así los botones también cargan sus posiciones).
_PtsCambiarPerfil(ctrl, *) {
    global PERFIL, PERFILES
    nuevo := ctrl.Value
    if (nuevo < 1 || nuevo = PERFIL)
        return
    _PtsCapturaOff()
    GuardarPuntos(false)
    ini := _PosGuiIniPath()
    IniWrite(nuevo, ini, "Perfil", "actual")
    IniWrite(_FirmaMonitores(), ini, "Perfil", "ultimaFirma")
    OcultarZonasCalibracion()
    ToolTip("🔄 Perfil: " PERFILES[nuevo])
    Sleep(300)
    Reload()
}

; ── Captura con F1 (lápiz sobre el punto) ─────────────────────────
_PtsToggleCaptura(*) {
    global ptsEd
    if (ptsEd.capturando)
        _PtsCapturaOff()
    else
        _PtsCapturaOn()
}

_PtsCapturaOn(*) {
    global ptsEd
    if (ptsEd.sel < 1) {
        ptsEd.lv.Modify(1, "Select Focus")
        ptsEd.sel := 1
    }
    ptsEd.capturando := true
    ptsEd.bCap.Text := "⏹ Terminar (F2)"
    HotIf()
    Hotkey("$F1", _PtsCapturar, "On")
    Hotkey("$F2", _PtsCapturaOff, "On")
    _PtsEstadoCaptura()
}

_PtsCapturaOff(*) {
    global ptsEd
    ptsEd.capturando := false
    HotIf()
    try Hotkey("$F1", "Off")
    try Hotkey("$F2", "Off")
    if IsObject(ptsEd.g) {
        try {
            ptsEd.bCap.Text := "🎯 Captura (F1)"
            ptsEd.st.Value := "Captura terminada."
        }
    }
}

_PtsEstadoCaptura() {
    global ptsEd
    i := ptsEd.sel
    ptsEd.st.Value := "CAPTURA: lápiz sobre P" i " (" _NombrePunto(i) ") y pulsa F1.  F2 = terminar."
}

_PtsCapturar(*) {
    global ptsEd, PUNTOS
    i := ptsEd.sel
    if (i < 1 || !IsObject(ptsEd.g))
        return
    MouseGetPos(&mx, &my)
    PUNTOS[i][1] := mx
    PUNTOS[i][2] := my
    ptsEd.lv.Modify(i, "", "P" i, _NombrePunto(i), mx, my)
    RecalcularZonas()
    SoundBeep(1000, 50)
    if (i < PUNTOS.Length) {
        ptsEd.sel := i + 1
        ptsEd.lv.Modify(i + 1, "Select Focus Vis")
        ptsEd.ex.Value := PUNTOS[i + 1][1]
        ptsEd.ey.Value := PUNTOS[i + 1][2]
        _PtsEstadoCaptura()
    } else {
        _PtsCapturaOff()
        ptsEd.st.Value := "Captura completa: los 30 puntos quedaron en memoria (💾 Guardar y cerrar para persistir)."
    }
}

; Guardar y cerrar (también al cerrar con la X o Esc).
_PtsCerrar(*) {
    global ptsEd, ESC, AVISO_ESC, PERFIL
    _PtsCapturaOff()
    GuardarPuntos()
    OcultarZonasCalibracion()
    recargar := false
    try {
        v := Trim(ptsEd.eEsc.Value)
        if (IsNumber(v) && Number(v) >= 40 && Number(v) <= 200 && Abs(Number(v) - ESC * 100) >= 0.5) {
            IniWrite(Round(Number(v)), _PosGuiIniPath(), "Puntos" PERFIL, "escala")
            recargar := true
        }
    }
    try {
        v := Trim(ptsEd.eEscAv.Value)
        if (IsNumber(v) && Number(v) >= 40 && Number(v) <= 250 && Abs(Number(v) - AVISO_ESC * 100) >= 0.5) {
            IniWrite(Round(Number(v)), _PosGuiIniPath(), "Puntos" PERFIL, "escalaAvisos")
            recargar := true
        }
    }
    try ptsEd.g.Destroy()
    ptsEd.g := 0
    ptsEd.sel := 0
    if (recargar) {
        ToolTip("🔄 Aplicando escala…")
        Sleep(250)
        Reload()
    }
    SetTimer(() => SoundBeep(900, 70), -1)
}

; ── Vista previa de zonas (rectángulos translúcidos click-through) ──
MostrarZonasCalibracion(ms := 3000) {
    global ptsEd, ZONAS, PUNTOS
    OcultarZonasCalibracion()
    for z in ZONAS.izq
        ptsEd.ovl.Push(_CrearRectOverlay(z.x1, z.y1, z.x2 - z.x1 + 1, z.y2 - z.y1 + 1, "2ECC71"))
    for z in ZONAS.der
        ptsEd.ovl.Push(_CrearRectOverlay(z.x1, z.y1, z.x2 - z.x1 + 1, z.y2 - z.y1 + 1, "3498DB"))
    h := ZONAS.hist
    ptsEd.ovl.Push(_CrearRectOverlay(h.x1, h.y1, h.x2 - h.x1 + 1, h.y2 - h.y1 + 1, "E67E22"))
    ; marcas puntuales: P1 / P2 (ocultar-mostrar), P29 (zona segura) y P30 (avisos)
    for i in [1, 2, 29, 30]
        ptsEd.ovl.Push(_CrearRectOverlay(PUNTOS[i][1] - 8, PUNTOS[i][2] - 8, 16, 16, i = 29 ? "F1C40F" : (i = 30 ? "9B59B6" : "E74C3C")))
    SetTimer(OcultarZonasCalibracion, -ms)
}

OcultarZonasCalibracion() {
    global ptsEd
    for g in ptsEd.ovl
        try g.Destroy()
    ptsEd.ovl := []
}

_CrearRectOverlay(x, y, w, h, color) {
    g := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 -DPIScale", "")
    g.BackColor := color
    g.Show("x" x " y" y " w" Max(w, 4) " h" Max(h, 4) " NoActivate")
    WinSetTransparent(140, g)
    return g
}

; ══════════════════════════════════════════════════════════════════
; ICONOS de los paneles — PNG planos al estilo de CSP. Van EMBEBIDOS en
; este script (base64, al final del archivo), así que no hace falta copiar
; ninguna carpeta. Orden de búsqueda de cada icono:
;   1) <carpeta del script>\iconos\csp2_<nombre>.png   (puedes reemplazarlos por los tuyos)
;   2) <carpeta del script>\csp2_<nombre>.png           (PNG sueltos junto al .ahk)
;   3) si no existe ninguno, se extrae del script a la carpeta \iconos
; Cada PNG trae el color de fondo de su botón (verde ON / rojo OFF / ámbar).
; Para volver a los originales: borra la carpeta \iconos y recarga.
; ══════════════════════════════════════════════════════════════════
_SetIcono(ctrl, nombre) {
    ruta := _RutaIcono(nombre)
    if (ruta = "")
        return
    try ctrl.Value := ruta
}

_RutaIcono(nombre) {
    arch := "csp2_" nombre ".png"      ; prefijo de versión: ignora iconos de versiones anteriores
    ruta := A_ScriptDir "\iconos\" arch
    if FileExist(ruta)
        return ruta
    suelto := A_ScriptDir "\" arch
    if FileExist(suelto)
        return suelto
    if _IconoExtraer(nombre, ruta)
        return ruta
    ; Carpeta del script sin permiso de escritura: usar temporal.
    tmp := A_Temp "\csp_iconos\" arch
    if FileExist(tmp)
        return tmp
    if _IconoExtraer(nombre, tmp)
        return tmp
    return ""
}

_IconoExtraer(nombre, ruta) {
    mapa := _IconosB64()
    if !mapa.Has(nombre)
        return false
    b64 := mapa[nombre]
    try {
        DirCreate(RegExReplace(ruta, "\\[^\\]+$"))
        n := 0
        if !DllCall("Crypt32\CryptStringToBinaryW", "Str", b64, "UInt", 0, "UInt", 1, "Ptr", 0, "UInt*", &n, "Ptr", 0, "Ptr", 0)
            return false
        buf := Buffer(n)
        if !DllCall("Crypt32\CryptStringToBinaryW", "Str", b64, "UInt", 0, "UInt", 1, "Ptr", buf, "UInt*", &n, "Ptr", 0, "Ptr", 0)
            return false
        f := FileOpen(ruta, "w")
        f.RawWrite(buf, n)
        f.Close()
        return true
    }
    return false
}

_IconosB64() {
    static m := 0
    if IsObject(m)
        return m
    m := Map()
    m["slider_on"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABIFBMVEX9/v78/Pz7+/v6+vn39/f39/b19fTz8/Tz9PL09sLy8vD27vTu7+/t7e3r7Ozx5mrv2Grq7Ozd7GrB7YzS9Gnk5ObW192j7nel9GmN7mp972pt8XJj8YNq63bjyZPuuWrGypDGuozmqWvjnWzikmy0tsufzHB2zHpnzH2oqreVmaKIjJvxfWmmeHd8gpdxdoJrdIllb4Vlb4RlboRkb4RkboRkboNjboNkb4B8bYtlbYNkbYRkbYNjbYRjbYNhbX9ebYBcbX7RavG5au6nau+ha7KRau+Ua8l4Z+6AbMJpZ7hiaIRgaIRfaIRda4RdaYRia4BeaH9fZnVba4NcZn1aZXxYXnIzMzMpKSkoKCgnJycmJiYjIyMcHBwYGBgTExOlUxHvAAACBklEQVR42u3V7XeSUBzAcRBBzh2wUXKPpTvL1CagjIux8onmnq1loDCRB/3//4tg1nInZkfqXXzf8znce39cMOMvwzIgAzIgA/43QNc1XU8PaLpp27apo3SArju2KsuyajmGngLQTEuCPE3RPJRMC+0MaJYKCYoBBcDQBFRstCOgWYpAcHmcE/gcwZHs78JPoNcbnG724aH3RgfmORxO5/P5tIGzlKCa+nA47Ec9BQaz2STqW9TXqLu7L+ucRo7HpXAZBEEYKgRHNJyPn+JGo/4TYNJt1+u1WrVaffPuoeOoZrN5zDO4uPRdz/PcxUrGODD+PB7fRHXPNoDepN1q1d4eHR0c7O+/KBaLpVLp1etyuVJ5uQf4ebDw4zzfhQWqcXt9fXl5cXF+tX6HGBhMuq1WfQOIn4+Aw8MK3MuJoeuvc5cSBuBtLETAefes/wPozdqJQDkGMHn5CzjBgfAIXI06/wrYugR8cwly8hK2biItPG6iF8B84iZuO0aGxaSV63q+t3BXJxhH3yQd47ZBioZHWYaBH4SrKcWS0E4epOdG2VQFis2J93PfvRfzDGAVK3mUnwvZCktyuTyEsIBzNCU5aMfPORIgAZgCWWAAIcgO2vlCQZYhQkCSJBBE1UYprrSO4RiKJEkKckwt3aWKDMtxHMtAp+mvdYSQnv0bMyADMiAD/tR327+402K4uf4AAAAASUVORK5CYII="
    m["slider_off"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABIFBMVEW6urq5ubm1tbWwsLCrq6upqamoqKinp6empqalpaWkpKSjo6OioqKhoaGgoKCfn5+enp6bm5uZmZmXl5eWlpaVlZWUlJSTk5OSkpKRkZGQkJCPj4+Ojo6NjY2MjIyLi4uJiYmIiIiHh4eGhoaFhYWEhISBgYGAgIB+fn59fX18fHx6enp5eXl4eHh3d3d2dnZ0dHRzc3NxcXFwcHBvb29ubm5tbW1sbGxqamppaWloaGhnZ2dmZmZlZWVkZGRhYWFfX19eXl5cXFxaWlpZWVlXV1dTU1NPT09MTExJSUlFRUVERERDQ0NCQkJBQUFAQEA/Pz8+Pj49PT08PDw7Ozs6Ojo5OTk4ODg1NTU0NDQzMzMyMjIwMDAsLCwrKyspKSmiJUs3AAACi0lEQVR42u3W11riUBAAYHQNfUFQ2EWlCxZaQHBdinQRMuScJJTQ3/8tlpK4kLIfgbv9mBuu+JNzZiYzuu6RoTsBJ+D/BACOA4Bl4RgAhq/JAXU4AOzruY7UJkiApO7bmTZBcoRB+kyjILlEakBqFKRp1CzICklZAFArEHklygUAxLAsUiYUSlkiAHBMu1lrfmKuC/v1wo6wfHo5dGk2mi/9JYRhv2baEoBph/RGq9VitZqIu5a80JW78UsA5tNJ2E2EzWHXG+wGe1Mm6P52IWwF1V8LfaBcBjvhrdN99BHW24yONoLdrhUBjBFeBcMw61+0EQYQMxDp6Ww6nc5m+aUV5bo0WgbGuwD6KOQyZDL2/BB9eHyKxWMFUeCeHhdjfjQe8aNFlrBZSs1atVouV1poCwDciD8/RAJej9vpcF65fnhub39jQaC46Wi8itGEvzYbI5VC/u1X7oWsb1KyBlA7nUoshaDv1n3t/nlz5/MHvfkvoT9ZA2N+nibMN5VScSm8vpCfSAQAN0ky/hS9D3hvXOvne/2BsL8gCh1B4OcVwnJVfl8BuWyqzsC/gFAkWES7Aj+vKgOKRwhHoqEiM9gW+HmWMHsq77IjKF3i6hD3vjfYeYeJx2QMK12iLI2xRDJFpjOZRGPrHvhFibCZ8kppVCgkIeiPzlAQetO6yaYPsrRiIUlLWQzcytEboYfrF98tthZWKWWVAK6W6grvAMkLc5WjNM5G4BoFoTeHDFntgebhCmy7LeSizzBwwHQGmha/D73OweNd/Wu/736gKuy9YKgJ+28oKoKGFUfM5uE70lo4T+wOB01L1lI41zmP2dKoYcLZRYe/waprJf/XDIB0wJ525RNwAjbxB6ztee+ayAPxAAAAAElFTkSuQmCC"
    m["circle_on"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABIFBMVEXq9J/x7zXX9DXo9zLw12TtvlW19jSV9TR39jRW9jSo6D9h4kQ09eo09s0z+qY19KMz+XE19HA3+T449EA17uc38m442dQ3wOvzpz/1ljnLn4+gmXryfFf6fDKse3Rwf3lncIVpb4Flb4Vkb4JlboE1qPVNp55Ckstdd4Y8e+Fib4Rib4FjboRjboJZb5NdcH93bXlkbYNjbYRjbYNjbYJhbYXtYmzvTk3qOcfwOk70NZ3YNfD0NW70NUbwLuT6MnukX2mpUICGXXdtaX9maIBrXn64NPabNfWsPJaGNfVwNPV4OVZlbIRjbIRjZ4ddZ4k+ZNtlbIJibIJjaX9aY3ZTYHQ1TvQ6O/RPNfRTM/dSTWxNOklFLEk6ICAnExMSDw9JGlIPAAAE6ElEQVR42qWXaVPiShSGg5ajA+MyioKigARkSUgIMYqgqEA5KCRhc0W8//9f3NNrOhi9jvet8oOlz5NzOidJt2T+z0if/rWK8z2BbdtmWSEx+/3+3wmqtglc2aEZ6bo++sAhBV48q5iudnd3e3v7h6Tr9HXd6H9JAHjWHTzd3XHBDaRx020HKt4JANcGT8/Pz37BTaMBDkXvG58Lqibgj09PT/OCBkqz0dKV/mcCK2sMHiFUQA2eoNns9vX+xwILXZ4JngMFzVrbb5D8/MPDw6NQAhcwvlFrNq99BmmeJ4ZgQUOC1Jpd0SC947kBC4QOmk2ga+hHNEgCXyw+zJWgaZrjdP/wAqCBGghqQhdMUEW8zzBwq4pOcux08QKCoIYF9RY38AqMYlE0aDY8Q7bdxzF1vdwVWqjX6/2S4RNY43xRMAysLNDeSsEI62YXGYCvo/BlkFgDuaJn0LKyPT/ioGjVUOokrAkiUMf5XI4pBlrWDnqJ9PW2x9fr4hqoHS2X4wYtawW/O5CB85f0TkheAVShjS1zNEoLyaCkLWRocf7yvMQrqI61HE8e8en0/Vwm9+0hMlxTHEJWQcId5DlftIamMU5Ppi8vU19m046KbhfDL2kPZBFjsRgVaGP4t/T9FN0waQ/nBHJ6ejq7T49QE4Q+h7TRLEhoBbQYDhKgq4DghdF7e8nkyckVE5iGdU5oCO4BCTpHMZY8rhNV4PHJK5QzIoBVYPz5dWFIBXkuwB0ggYcTngkMq03xs7Mzi7RgDmNRJiADxAQJj+/1iAD1gFicQzBIpjosxKIQwKOkAyxIQAScC4aFqwuCX5xViKBTiLLkO3g64C6KfK83L7ggacE99wl+HQmCSqXSQun1/AKrdXExL/jFQgWZyTRF+V7ve4LXChZ4+HT2BUFUFEwmLxikgzz7VBAFWFwDELyIz8JsJgquLmAuTwXBsLAD/CoKF8zm6dnsjQpcNNck5DbCbOys0uyQNwcTvL7OvLyxQTo9YAIySGapwwWrBTxJIPCxszeUCR3lAxwkoKNc6hxxAekhM/aRNFgAHRywXLlDKihgeA2ybpNXnI/8B+dtksGCfS5oUYFpl9Yxvba+voZLUMcU8gUJhlaF8wdt9jRCDwRHgd+PM5MAAVRwbBru/u4u5ffhJrJ3YoHSEFzCaBIQ+M+sm9xF8Tpg34V1ZtjYKDhgyAQE8ZV4fJcq9g3vw4J6oPjvje2Co5jHo3c5Bv4wjkIUSVwA+7TZjP9NDQEBfinuGbJVwxPAnUQ44rchBUd9p5BlN7UUiseZIulmxc87NIFowm9tHdlOuax6tAq4mwiFQkvMsO/Kvv2Bape2Nzi/tbmVchy7DJFxbBddPiQY0HPk26FAEx4Phs1ISqd7ddd1DxPhxVBIMKRoA8IWp+QcbXj81k9IJJLCSYR/LCwuioYE54VtHjWQ62PBysrK8vLyD8gChAlCS6EEWwD/RhMMvAFBwAy8BOANI3CrW3JSc7wo4CX4eP9mW3EK0P6HgkXKy8aH233FUSKAYz5YsJQS+g84cCg2tLG5+U5ADQsJ15I/P/KoimOnIoz3CQA/dGX5Pw9diokUEU8QJnw4Ibu2/KVjHygcBRy8gnA4kUi57kj+8sGzXLZhhuUUzSGMsy3Lf3X0VctEgmPD02h85/DNnkb126f3L+RfWVQe5YAq3PYAAAAASUVORK5CYII="
    m["circle_off"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABIFBMVEW6urq5ubm0tLSwsLCoqKienp6YmJiXl5eVlZWUlJSSkpKQkJCOjo6MjIyLi4uJiYmHh4eGhoaFhYWEhISDg4OCgoKBgYGAgIB/f39+fn59fX18fHx7e3t6enp5eXl4eHh3d3d2dnZ1dXV0dHRzc3NxcXFwcHBvb29tbW1sbGxqamppaWloaGhnZ2dlZWVkZGRjY2NiYmJhYWFgYGBfX19eXl5dXV1cXFxbW1taWlpZWVlYWFhXV1dWVlZVVVVUVFRTU1NSUlJRUVFQUFBPT09OTk5NTU1MTExLS0tKSkpJSUlISEhHR0dGRkZFRUVERERDQ0NCQkJBQUFAQEA/Pz8+Pj49PT08PDw7Ozs6Ojo5OTk3NzczMzMwMDAqKiolJSWDNe+hAAAG0UlEQVR42rWXeVviSBCHZ3cF1GEcRMBACIggl4QEknDfyBWOdNIJDKI73/9bbKWTAF5z7D5bf6mPvzdV1VXV1Z/U/2if/l+ARuzfAUwhUlar1XKFVIzhl98CaKqymI4GvU671Ww0273RXMXabwAQqIeDfr9rAuq1qiQK1d5cw78IUObTyWj0AAQHUJHEMs/Xxu8g3gLQUp7NgGACenuAIJRLRbYywz8FLOeLuQyA8QuACHqeKxYKTYTRDwCaMp3MgDCbTsejBwvQsHIAgCJbLHGijD8GaMvhcDyVFwvZjuEAMB1g+XuGyZdG+COANu/2h6Ox5QKJodclAEiB6QCXcp2cuBKlPn4foMmtTq8/mExmxAUAwClACqqSJIIHXJF1uVIZj6vADfB7ADyvN9vt4QLNJ7Lpwng0nsxkOJFxvynyPF/kkycJQcicMFLxKIo9QFvVqo3GOJZ4RPPpfCHLC8VuBYzV5bDCFvjUSUyS0idxiecPmTx40BCr1Vb0z09JIMxM9XF2sDoW7otuV/zW5SpCPiSkvQLgPi9K4ijxx19/JB+V1evOgX5Su1zWA0nMiHypzHfwS4A25/hyuabukoTwTuchVZ8KXDrFi/CP5XLJqUkbgKsFDsA9dWsRlPc6DC/EslQieqFcf+EBnuRZluV4rqc+/oiwFLgS0QtCaYwPAITF7P09yxaBgA4+oBdGPiSXLDlY/cgDLGezuXweEBw7OkShf9uArcEMMILAQ56oRVEUrKM0AUivpzIZE1EolBRVsaNA69lypSA4Q91Yr799Iz5o9TKRQ2128SEH+VQ6TRC5oY4cwlbJfglSdDyZzhU4QdxsiAuzMpFLklRTHACe3iZTqbs7YLDkM44POh9OpDIgL0v1xnpjudAsE3mlIs00C4CMFnN7SxjJpn5M2GLxNpMn+lb729rK41gAsWniENsAvUjf3NwkErfJ5NQuD4eg1XMsL1TqrV5vawFUpWrpK1Lb9kDVMhGGicXiN7GMfeD6Zk/ocFK10e4NHx5tgNaWKlXTKg1kAbRVPEzTdDTKRFgrArRReGwT1EG11ek/TKY7G4CHUtWy2kojADyLUGGwCB2SDAuw1uI1zSGMu4PRRJ7vARMTUAOrzm3AJGTa9TV11XAAei7ftitqi2SYcitlZ9ghyER9ACA8CVgW9NVtgGGw5dLA6Qu0XMJ4eHIA8zeA8ZVlAV/NAWzEGoynfWchrK+f3nogOx7YgCMPts1ubzCQkUPA260DwLJgFpJpDmAadEIQrEQhfTcYwQUhr5yaVDa7Zwcw5u2OJu1kHuMyckUAIV/ecACzBTQSTFWHsNo+20eMuyzP8XypVCovNLuQEv5QECx0ldDsybFDpAc32/We4JwCrkDbs8UiVxQUze6F3CUBAGJKrk6Enzbb7eMO7Gm7ejmjtFUBJkehwLIFad9MEgBIKfjtSsLPuyewZ7C/dy8ISB+kszkYHflCvmUGRZrpIRCyail4a8WgmUrbvj8tjwgIc8mMOTpy+eyDDYC/xgNmJV5T4WCHuKA9fz+y54MPSJ8koO1hcmQy+aXTjcgo+imQU1Q4lLSS+Pexfd/tT1PV7pkEGR3plICRA8CjEEUsHAlapYBfmHGYD4NraHsTcZcc6ugw1tPBMGW1ZHhoBoFej3SHgPgQQxCJ3NFYR0YnELZbOhyX9fd2SicKzAWjgEgwTevAnLsxHYqAHCxKJefvE+zuxsUQHWWYO3R8tSF9eG3paZqJ3IyMt4stQtgmbPJBOhru2IVpewAHEaRNOYw2hmZqmv4SgZCBW3ZvPoRDkVBeRy/3Aw0lKZroo9FYLJIdYkM7pFJbGz3KlTHAhz9PrqBu6fmr/QCCGBMHQG8O6Ggk05xjcifCtWYsKhGPy+MGQurEd+kPXDoBHK04yGhTptzUx+Kx6HWQvuPqvW6nU7uPXXjcp6fuU3d627/46ru8KO/1RzsSMqqUqWeInqYjIb/P9/Xii/fz2dn5+fnZqcd95klcfL746i0c9Md7IjJqFNHH4kyUjlDXoWDAf2kxzs9MgOfMc+71nueNDzZVuCSjdNxyIBKmDnoAAMFjEuCnovHhroyMUSoCeuY1wHvuuOD2Ntbo420d6QoXjcYZU7+P4MLrtWI4PXW56Nn6R+u+ijR9kAmHozQAgoErkkYLAD64XV9E49Vz4e2DA+lq644KUeHrkAMwY/h85nb7WGWD0M+fPKqh9QtMwO/3X0EIJAlwiN5YDW009EuPLlhKjWWXS9EBH/n8xWUkW5ON9btPxw+efUgzDKxMB12oxN54iddrjNDvvVyRtd+ZZj5b0b97Ox8tqf/b6/0f5mj+SjCXh9cAAAAASUVORK5CYII="
    m["quick_on"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABIFBMVEX9/fr7+vj6+vj5+vj6+fj6+ff5+fj5+ff4+ff5+Pf49/b39vX29vX29fT19fT09PPw8PDv7+/u7+/u7u/u7u7t7u7o6era3N/S1NnMztTAw8u7v8e7vsevtL6prrmdo7CYnqyLkqKHj5+CiZtye49ncolncYlncYdmcIhlcIdmcIZmb4Vlb4Zlb4Vlb4Rkb4VlboRkboVkboRkboNkbYRjbYNjbYJjbIJibIJibIFia4Fha4FfaoBeaH9daH9dZ39dZ35eZ3tcZ35cZn5bZn1bZX1cZXpaZXxcZHdaZHxZZHxZZHtZY3tVXW1PVWNJTlpCRk88PkQ2ODwyMzQvLzAvLy8uLy8uLi8uLi4sLCssKyorKykrKikqKikqKigqKSfvVvtbAAADu0lEQVR42u2Xa3eaWBiFwYnjaLzkIt4vQdAgVUwOQWhAa8WUeMNqNI0mlf//L4bbOYJ27If5MNOuPJ9Yex32Qt3v9gUT/iXYb2QAmhDOVTik3LiKhBAPDEBvPBxZDEeaBCxBGEBlrFqCIAKmBmlI+wY96gpCcgoQgCyTSKko5nmxoeiIR8ZvAHrFSDgcsgkHMlUZSM1swBVC4VBeEdqNx6ft29bm7W2tM5LHAPSoyBmRdCGw4vB6VMaQkExipMYzc2O5clm+vHy5FXcGzdFVKHkGuTzN9thhPrxTkqHSpCks1s8vkOfN1H2EHxlEbIOgxyDwbvBrGPx1NAd//sxAIwPExaXDBRHMadeTIp7aKVh5wrUWryiJq+Vm2vAYCBKXwaIRh9NgvNJnFZrAT10liqVouc3oxitkY8xbbd8wKdViFpKr9IE1HjmkFOiOOdD16Rwxuwf+cQbyqNtz6Gp9uw86GlKGiqW0GYatu9TAQaFcs5Br1lZ4HrWOe8nfIPj9RgLSeOiiTaznFcTbKuqfKrA+MOhO4JmxtmcAZK6cL+QtCvki3QNm/3yefYXMFPMrA32qgM5cyZL/CeQsFg4FbcI4QXXA7ecnw+2f7ZuxkO+ASsYDYedIKIwVesBjwA3MHKD6SeG5IV+dGZ5f3dBrQicT2ZXWRZzqgGNJFGpfv69Q7lbGrPoRpBPn6Mx5tDLgjs2CabDdMxDS8XeD/7vB8Rx8Nw14fw5IrwGnVkJJFLMUVvhREntZfJfEswTtTaJZKHkseBKwOcFTtMIDZWFsDYetMbdmkSJweOQEL6nAN0ySQpYgZctcbMr6DKKb64bZUTQ6UiI7ByvOwwQh2/0Dqoia+5iTsctEPWikNv/BXYg+cE5dgvb9R5c75zjLorWJ3TcQG2hnabcYu3/6HYD2p659qcnotgfFX6pS43G+QOh10byfzKQhWcqqD6WMhHSOVoC/1p+MNWRjTJm7T1Q8kog7JAIErbBaGYtDEljGV2lSTTeW354dvi1f58zNpIAT5xACL41ZJR33KFGqz/kMvMF9nddv/H+uf5TGTf5IlH9qEDANhHeDX8BguTNY2waeHYkI2QaeRkr6DcTG43q9cpO4Mhuwxg+vMBS7yzO8orIPOQwlMRkzlx7eO0yM/rJxWa/n93fm/3UhHotFLWKxRKkDgEJnolCJpkiV8/cB82WKaFmDJnWpCoTu2wMneRR1b0cSpBYDqbst0BmoAwt14DQDEPpIkbmDSmvvXslgj3AQ8I/K7/Xm+p8Z/A1Bb/fa+H5ihAAAAABJRU5ErkJggg=="
    m["quick_off"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABDlBMVEW5ubm0tLSysrKxsbGwsLCvr6+tra2srKyrq6uqqqqpqamoqKinp6empqalpaWkpKSjo6OioqKhoaGgoKCfn5+enp6cnJyampqZmZmUlJSTk5OSkpKQkJCOjo6NjY2KioqJiYmIiIiHh4eBgYGAgIB/f39+fn59fX17e3t5eXl4eHh3d3d2dnZ1dXV0dHRzc3NycnJxcXFvb29tbW1sbGxpaWlnZ2dmZmZhYWFgYGBdXV1cXFxbW1taWlpYWFhXV1dWVlZUVFRTU1NRUVFQUFBOTk5JSUlISEhGRkZFRUVERERDQ0NCQkJBQUFAQEA/Pz8+Pj49PT08PDw7Ozs6Ojo5OTk4ODg3Nzc2NjY1NTWJBtY8AAAD0UlEQVR42u2Xa3faOBCG2e2mLsaYIJO2pNmENg0kvUC2F0pDumXThi0eS7ZkG5z//0cqW0i+pQ013/bs+4kzZ/wg2TOvRjVnS9X+QwCwQUpGpGzYAACez4R85ogHqIpQKCChDPBm4w9C449AeALBFyryycUiSYkUAOANjYaUfjAngOGZriKNfvwAWUZKK7koAQBvZrQttFZHO2ML9lZTAQvVJwwgiFYZ4RyAjRuoLYWaR57NTow0YjVGvu2E2edXLuQAH1IAQkaPA/oZpKWfbw5AprUdwOjubgNA5sB9tfO0MgDtacMlHRzQqgBT+732OnQmPFIFgIzBsHavNgzIrwPiOkBm112+rv3BCTawkxzgrjqgH/UOr7jdVzQcxoRw4b+od5Cqzfq7GJCrRJJvJjjQmoZh7AwcQQjIF0s3pB48nvNdeVFGQaGZyL9nR71e7+nBhASC4P5zHEdiHfWvvXjBbqDEiu0MxE/alDqOLdfAVPMyseGMDUDZUBZ2Iu4/i/UaFlAwEIBbHEUCsLQfbkBYEEJbPVMwrdi1CgACb0/6QicvvriSQAI/FsXJp5qd9mXOGOM8AD/TpB816tYVkQT/JnnnYfz/F6bekC6lDbx8HVzoVvrV9WO2kPXAko8fUQD30OikHmVerQk/cCRYf4vQTggR49ndVjZnSuEHjtSOHQmcHCEB7JtZwOVdAJIlVABA4C9SQhWAf8PSNdzQCgD+t7bqzSoriHeu1hCXza8DsoS7AKU6SAB5ws/qwPvUQJZU50Gfn4TrEkxr0uvpHZXTbn11IdsLbr+uS9UfX7u8O8KkC2585Q+zTpqjjyjkm4lMRudCo3dzAfd431LKsCS4129UztQrjTjMVyI5/0g9CqcpajzIzkhSap6RLe8oj7Lt0thUK7uc+AnUVdOWp/zB+SaojEDRVINQKe507h+H3X2hbm+29qiAvH/0JI48n5PCS1ymp0YU8TLwZqZhSumda+mT+PR+i0e0P3FhyMqeOvzUAP9Uz55Mb1Rv0pcNbl5W8++sI90CKJ+N9noX9IxPT4VKvA1QPp3lmbU8NlChFzYBwLf3ONnFX7OHu+0qAOfRKeVr+G0Hmaga4Mn9lzQ43+Gt2K4G2G/pZ8sZus0PNgTwCfL4obkNgA+xuxuvIDcr8zqAxJFkzCoAHJIdf6LYkMaaKkTU1qfUps/T+R019+Yk30x0JdcQrZL5Bw/MplRrxLuDzA9VoLk3KTiSA9iVEmjsXU0vhaZfaZzh4s+XUnMKpVtb6c7lUan1iOSoACWwwbWvPBH97NL1/9V3C30HCcC8ZkWI/fcAAAAASUVORK5CYII="
    m["hist_on"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABIFBMVEX8/Pn7+vj5+ff39vXw8PDv7+/u7u7a3OCorbmio6ihoqednqKZn6yZnaycnaGXm6U/m5o8m5o6nJo6m5o3n5w5nps4nps5nZqMkp6Ki56biM6aiM6aiM2ZiM2Yh8uWhsmWhsiWhseVhseVhsaUhsaShMJ9eaZ8eaWAgYdegY9ClJZBlZZ1d5lrdohZeIlzdJtwc5RqcotacIdlb4VkboRkboNiboNeboVab4dlbYJkbYRkbYNjbYRjbYNibYLsR0XqSEbpSEfpSEbmSUjhSkrfS0vgSkvOT1OiW2aUX22SYG50aHtlbIJla4JibIJgbH9fa35gaYBeaH9dZ39cZ35XZ31bZn1ZY3lXV15WVl5VVV1UVFxUVFtTU1tRUVlLS1R3n443AAABrElEQVR42u3W/TfCUBzH8UmmB0LERp5SJJtarSa3tcSQZdmkB4n//7/wvd/lKKfjOMdv3Nfph3s67b3f7idO/yWOBViABf5agJQJfMqEnksUPRQLSIWj6qHfnqMvAVI6QxoU7j3wkN1BjqoX3Tblwk+rLWRXxgNEu79Dlkaapx6iOrIgAkF2VUeiJzFt69VCDimjAue937q5uAQXpmUfr1OxtYwjz/tmKV7qCOE0fT6y5CqpHZQaFTDQPLszzGtgGrf5k9hqFGwsPy1y/BzguUAn+PKGQnJ282AfJDePHs7HA3XzCpj123wmFv0I+Hg/4H2Bx1Dvud/v94YRORtP7IFEfHqgNi0wE3gM9oaDweD5NcwCLMACLPDfAz+5VBuGCUbX+goVXX5a4HjEBdrB189rPZkAya3DsQDRLNOog9oVDMuaJ+NIPOcDM36xuxRJU0LIUVLxbRDfzbUq49NmNeiyNWDa9NG0lcqutIAkV7dFgRILdlWRskBSWpWJcdVwW/OT4+p06bZ2XRjlNs5s29Z1+wFNjisUmoh8rDvuu/rNvFfYfyQWYAEW+OIdqQ1reNTV2ccAAAAASUVORK5CYII="
    m["hist_off"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABC1BMVEW7u7u6urq5ubm3t7e2traxsbGwsLCrq6uqqqqpqamoqKinp6empqajo6OioqKhoaGgoKCfn5+enp6dnZ2cnJyZmZmVlZV/f39+fn54eHh3d3d2dnZ0dHRzc3NycnJxcXFwcHBubm5tbW1sbGxra2tqamppaWloaGhnZ2dmZmZlZWVkZGRjY2NiYmJhYWFgYGBfX19eXl5dXV1cXFxbW1taWlpZWVlYWFhXV1dWVlZVVVVUVFRTU1NSUlJRUVFQUFBPT09OTk5NTU1MTExLS0tKSkpJSUlISEhHR0dGRkZFRUVERERDQ0NCQkJBQUFAQEA/Pz8+Pj49PT08PDw7Ozs6Ojo5OTk4ODg3NzfXOLNNAAACf0lEQVR42u3WWXfSQBQHcNraAkGhVauypoUubImghSh72ErILMmw1O//SZwZJko4VpvhzcM/L/Mw+Z07nHDvhOCeCR2AA/B/AgDsBwBCwD4A+JFPrW15AJD8q6NMMMEH2CR1dHa8JYBNfCv4e+UDMAtcZ4+FgOlORHgw3e3ylUs3Ir4TIz+A7MlkOp1MwTrDBWBPEHRmDzSNr2MH4G7TMIxmG0E0N4c0poW3AWQ/6J9p9C5YCeGb4Yw/KK9pYu87y2r6tlAo3GbuHOtevWK5maItAA+1Go9mQiHAllMOnydoLsK5RWo4n9E8pq1eLn9NU8gZDtgG9A2g97F3CntRjCXiNOeKSrKDESt8nJv1VA7k1ecA1BfC0tUjGyCqksxgPKIZZ/8NYP072ggrlIomJIB6sS2ENUkyITBQKbe8GrgQHND8QnCgWvUJFxKAT1AUCaBabkNPSJ/KANVSW3zVq8XH1EICqGhzJL5quw+zEoAOJrY4BZ6nZSogt58W4hSg3pcA3PJZmohToMehDBBTksSrgQtBAfoNecKaC4GBRMIvBAfifkEC4ILXaR9f0pF2ASqksFeDlZYA4ufhO7IUPUqzZAAls/R6NXA6zwF19n5d7+FaReNA1S1FLlhbfxvJuTp+EjXQts5SUJvbALK+aDpLbeq0SmWWkuEO3kUUmugbY1W4Eb16BRs5leV6hH2jzRryzOi4GQ1M0xwMIXTMYonmvuNC1Jj+mji9Tpc+E+wfrlsjc7Niw9VZLmiWrFaCoPhvrrHDgv9yRwL8YQubDXKbj3c2/alwepLEfx7vLwkVTkKX+9zS7KfkJcRgn2ues/N+YED8Ooe78gE4ALv5CXwYGuq6/2PcAAAAAElFTkSuQmCC"
    m["lock_closed"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABIFBMVEX////+/v79/f38/Pz7+/v6+vr5+fn4+Pj39/f29vb19fX09PTz8/Py8vLx8fHw8PDv7+/u7u7t7e3s7Ozr6+vq6uro6Ojm5ubl5eXk5OTj4+Pg4ODe3t7Y2NjV1dXMzMzDw8O7u7u3t7e0tLSwsLCvr6+urq6tra2srKylpaWjo6OioqKfn5+dnZ2ampqZmZmXl5eQkJCHh4eEhISDg4N9fX10dHRxcXFwcHBvb29tbW1oaGhkZGRgYGBeXl5dXV1bW1tVVVVTU1NRUVFPT09OTk5MTExJSUlISEhHR0dGRkZFRUVERERDQ0NCQkJBQUFAQEA/Pz8+Pj49PT08PDw7Ozs6Ojo5OTk4ODg3Nzc2NjY1NTU0NDQzMzMxMTEwMDDK/odPAAAC6ElEQVR42u3Xa1eiQBgHcGK8BsLM2Krdtsua3Vxz3XRLrbTMUmZUFEUw3e//LRbUU1KhQm/ac/qf4wsH+Z1nYHwGmMYHw3wBnx2gRDJCqEuASi1VHwx0VZaoG0Dq6I+FzFkqk6/qiuQYoFQvn2wFAcuCwMbhjd4gzgDS6v0KAw5iI4gHQlJuEycAbdH9FQFDUYTmB4vMbrVDnFSg7DFhaJwJeV40nTC7Q1p0aUDSTpg1UUQCWI3GeBBCprCvkmUB0isEjHNQEB4XKpXiWcRvfMMgq0nLAt1dLxZRYPvqqSfL3afbHUNAwe/LXgPSLXLG/PnorVYnlJJ6V9oOIhF7c32yFCANUiw2Ss481SYDde2PUQIGB7q0XAW9XR+C3NZj83mkvRNA8P05vAM0pe1ViD0/Xq6ZNEiyGIYid226BEDl+3UeYvbn4AXQMwCLonitOADAoT5TQZo1gRtHQHwWSLkADmaBs/8LaFUmgFan09T1CXD9zl+aedNHG0p1DCSGDXmaxnByF0pq802HfQWQtlarlmK8uZDo3f00d43keB0UHh76CpkHkG4lsRWLGR1EFMIb68/Z+CYYQ2J0fXO/1CP2AO2UN1c4owmZEfiZhMZDPM+BcNEqMK8aAbsGzTZoBs7keWTN953aVkCVG2H6U/tg/6Wlt80CRL0wW9kCAPy2tAUrcLkMcO4EwAhh6B6AosfnB9br4gSAIe4od3GKOOgW4LIjtTfK49kaHAAYHI1qhDz+TY/XsXMA+XLmHafKVchdBch/Ya5a2rkWRJdTOB0ZW0ttmHE5BVGAeZ0QtRTlocu7wIdySrsYWUVuF1KYSWr9jPmo4BLAIN3rnnuwe4BNj4ZZ8AHAc1wup70OgA/3g3xwMeDJ2gJUrkQW9jTEX1n2J8b6eJdi8PyEmbhK5mws8pEXeIBtjEN7kvWB0wrQppo/iScObJKIH+cUmc7b2ihRB5puG23Qp3TB7jx+SbEP+Xrt+4zAP5/GzEmwFjjrAAAAAElFTkSuQmCC"
    m["lock_open"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABIFBMVEX+/fr8+/n7+vj6+vj6+fj6+ff5+ff4+Pb39/b39vX29vX19fT09PPz8/Pz8/Lz8vLy8vLy8fHx8fHw8PDv7/Dv7+/u7+/u7u/u7u7t7u7t7e3s7O3p6uvn6Onn5+nm5+nm5+jj5Obd3uHW2NzLztTAw8u8v8e7v8e4vMWytsCvtL6rsLuprrmorbijqLSboa6ZnqyYnqyTmqiKkqGHj5+FjZ1/h5l7g5V5gZR4gZNzfJBveIxud4ttdottdopsdopqdIhncYZmcIZmb4Vlb4Vlb4RlboRkboRkboNkbYNjbYNibIJha4Jha4Fga4FgaoBfaYBeaX9eaH9dZ35cZ35cZn5bZn1bZX1aZXxaZH1aZHxZZHxZZHtZY3tYYnpWYHmqzeGyAAAC4ElEQVR42u3XaVPaQBgHcDAhRLnSbFbWAJX7lFI5FawFTNiUQzCI0CDm+3+LRtQq1EASZjq+8P8CZjLsL0/2DLbujrF9Ah8e6AhaRMkigIXe7XyxuJ8MBGwFEEb3rUrhJFeoNBVZMA1gPK9nIi6KIByucOpM6WJzAO6Pv/GkByIt0Odgs4OhaAbAfZyws0cQAI4DACJgjzdH2EwFo7iN15oiyDDaBwCBvVinjw0DgpKxBwA4ZEl3MMSQjB8Afi8xMQyIk4pLu6vfBTPVxkU1F9xHWjFEUREMAngcp5HWPlp7GF9fyw/1GO0H0BU12gd4XPVAwPmC9VkbYwm3x1dRrSLkLM0EQ4CwyBEIIKrw0Hq60J6VDjTAkVQEgxXEaT/nibR6f68MYwd+6Ir1jD1C7yrqhsiRmAqvNWUJxLHBxlAyAEiDy2OGQ0Ru8QrMC5Q2EOBMxsYBR1p5U0GeMAWEWT/vTL0FTswBAdrttSWsA81YNBaLZKcWgffWhjkASy/fL2krz8BoO6BthNeD9XTVp1E4n3ZFvBnoDGftHz8v19LoZpfzoNpqTm/ETUBHbqQiofDxWr6GA6zWHoSOI4nzW1EfwKN6xO5hfMx6fMv2gGG8JF8di/qAHN8LQO7fwGV7bYOEATr6S7cCLJ+xzz/VD6LLd6IOIN6VD7YD1Olc+I8AOoRoB4ADFL1PrvaLGYD74k2XShnohVYr8BbVya1aQSxnCUBUWm2LYkvNk8gSAOnS44hjucYAi0D5cd7jUY21BiBHVm1rx4pasPgIgIWVuSjenYcYa50IoI8tycNq0G15GHl79ve0YOctz0RE5SfjUyeyDhB5VS1SOwDOTL2e36GC95fz9w3A8t1oC+As6gLS4CL4dt28G+itrZxPK5uqMMvZ0BHaFN6WXH3dWztYhmknSTl0Q5Fk4qov6QNSb1LOJFO6SWZKNwO8+WycLJQNuZ9ivOV0FoWNET//9n1E4A90KbNOZcxS7AAAAABJRU5ErkJggg=="
    m["reload_g"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABIFBMVEX//P/++f39+fz8+fv9+Pz8+Pv7+Pr79/v79/r69/n69vn59vj49ff39fb39Pb29Pb29PX18/Tz8vPz8vLy8vLy8fLx8fHx8PHw8PDv8PDv8O/v7/Dv7+/u7+/u7+7u7u7t7+7t7u7t7u3s7u3s7ezp7Orl6Obj6OTd5N/U3tfN2dDE1Mi+0MK4zL2txLOjvqqauKKMr5R7pIVynn1ol3Rik25ZjmZVi2NRiV9KhFlFgFRAflA/fE4+fE4+fE09fE09e009e0w8e008e0w8ekw8eks7eks6eks6eUo5eUk5eEk4eEg3d0c2d0Y1dkU0dkU0dUQzdUQzdEMydEMydEIxdEIxc0Iwc0EwckEvc0AvckEvckAucj8ucT8tcT4qbzyAPLm3AAAEA0lEQVR42u2WXXeqRhSGE6stfkSUVkosYkElokFFMXKIA2OHk2j8DlVOi5j//y86Y9c5K1FSTXrT1ZW5YC0v9uO8e/be7z67+5fn7APwAfjPAyAAcDAgX+cdgAEYLjeb1WLhbjbuCMA3AiBcBFZXa6r1utrU9NuNi+BbAGC+umkq2WiUSiSoaJSuNrrLR8s5FYCQ31N/jGR4SSoKQlGS+Gw0U+/6Q3gaAI7nLZa6lHgOH56/JF+JT9DN4Qw8/5fXANbMvD7nJBwmSALLMDleEvAPkT+vGY9fCQ6YLlA4wJ6ZSrScx+F8KpIqyVfli0gyL2JEOS733L8JYPRk6DMUBkBjU4mXOS5fTKZqLd0wTUPX6llKwIJKadmY4zyA++BW+7X9hx0KmF9HcXyBper6JFhNx+OpG8y7apLBOqSEgoYA+UirnlXBMEwC8FvnOF5gWO1xhQBE+EAwWH7pVDJYRvm84S+nbSWSSzZ8KwQAZz2WJJ0p6E/Qfl7U255M4zsUkrpeo2ipFO94dhhgrVISl2dZPei/vFp/3atkeS6fqzAJscAzV+ZDyCv8trhhfsEvRmlP/f3X6W86aZzIfC5PkhFr/GmF1AEImhGJE5J197DmwN2TShUxgZSX+E3BS8C9reBrFlL6yt6PH23NlszuokmOvil4AYDLLo4XUrUJ2gt3hret3BlTEnblTRR8sUJ6AWy0mMhJkVYA9gEjU2souUicEUhdi9+3fRACsILmd9JOwWEKHrYBvNHUK1zerMTJn8YoBDBYqZTAsZIxRYc9aoH7xeZ3U2/VSokz1bPC2nmwrCcEnpHNMXplRsLxOpgYbbWzhv8AuHoNQJIBgTP1vbETOlAG7k5COVTCs34DthM+kXASYziJF7oL3+cLINAi5Bm1g2c8EQBdPV0glTwfvNOZhrdVXIp8truE7wOATQMnQaRUP0TDK87yAoCbgS7geZTsbA/aGU6W4LixkEoo4mar9Nb7A8U19K11FPD1Chm5t+0/uzLqe6aSam8ROuZMlt8kQ1Wk5U4wswHCFeMgC0y33WqK/6G1Pmj0fYAzHNbiJTKWLxq9tT9/wKNk5vlGk8kU80JMNUfoiDfCmSGnJeKJMU5t35h3d7e9dqMS5cgkZNM3c3jMXMFjT06UydjhqBhXVZRqgYrliFWW6HzXs4+7M3AN5VwgfloUuSydzv5cFIlVSrFq1wOn2DuYDxrJ1C4KK+HJGLwUJBonwAWnLRhw5Om1BPVTEe8XPI83DDEXp5TOcgJOXXGQvZp0VJmKUCmaTsWjVOW6/dkboDcsWbaz9j51WmpNUWrXzbbhevfWG9c8aI+9YDV2nAd340+h9Y5FE9kAft7NUgt9bOsfgP894C/gFPvpKaoQeQAAAABJRU5ErkJggg=="
    m["calib"] := "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAABIFBMVEX////+/v79/f38/Pz7+/v6+vr5+fn4+Pj39/f29vb19fX09PTz8/Py8vLx8fHw8PDv7+/u7u7t7e3s7Ozr6+vq6urn5+fl5eXk5OTh4eHe3t7b29vY2NjX19fW1tbV1dXU1NTNzc3Hx8fFxcXDw8PBwcG8vLy5ubm2trawsLCsrKyrq6unp6ekpKSgoKCcnJyXl5eUlJSPj4+KioqIiIiCgoJ9fX17e3t6enp5eXl1dXVwcHBra2tqampnZ2dkZGRfX19dXV1bW1tXV1dVVVVTU1NRUVFQUFBOTk5LS0tISEhGRkZFRUVERERDQ0NCQkJBQUFAQEA/Pz8+Pj49PT08PDw7Ozs6Ojo5OTk4ODg3Nzc2NjY1NTU0NDQzMzMxMTHtFyKbAAAEgklEQVR42u2XWVvqSBCGIZ0EQgjZOqhwcABFOa6oiIr7LtDdBCIJSVD+/7+YsISjAor4zNzM1AO56ryp7q76qipQ/6EF/mEARgj/BECsTsf+AYA8n+7uHjXJvADSqMQDQf72mcwLaD4uiop01Zof8LQYFcXr/zIA1R96gKsmInMAMNLNV9ID3HetxvR4nALA2Ozgi+KGGhNj+YOzqmsR/B0AatlX2794QMdEUWQoLrF5blqTNzIJQIh7vS5QEUVTZMX7aSoPuNULR8ezAXCzVYjRkuZ9OhICgPUcETSZ5bb0FpoFgFqVXFCEAgXX9i+Lv397j3yc4qEUzNxZ6GsAbj2lKFWh44U727Vs13Us13ncXwIyZBZv2ugrAGlWUgwU6fxDx8AI9wTF+zc7lS1WgOGF2xb+CtDKUVCIHDjG20MnqNE5lnnIpIlOPgUgtxBUxUip+/HOSO31TBYgteGgzwC4dR0TFXDQrY0fd/WlHJJk9rSNPwPY67RG5x00KWRqLzsUDGUMMh1AzKuoJMQfjIkxR3SUjKhs2cZTAaizTWlU4aU2WdaRewggvW6jqQAd/4qI8HbkAOnLOhn5o1cTfCz+8E6m3wKwdcErzNroC6Rhnu8VTg0DjzzcoiBz/O6IAoPkJdizmnMAILXfQf77KM8CwKw8+S5h+5iB1I5TxQPzAcS0zJ4Z3W1KiVxaww9iMx9QFEUNZBqjQnMPJWat+9xfbllDADZPsrlVz1ZyS1GZ2x8CsHXOKp4ciDBYGjqNrSNBEhZyK73VuUzRxAOAlQ1wob5FRSn8S/c3vAf6AAVsdnxAlpZFYbA2HEjqvgfZoMD3LSZKXHJ0YoUhgN5whwAzy8hibLA2yiT9LVjFZPovz5bTcUEO75rDLbRPGXWwhaIPaBd5Kaall3ur04nCcAv1ujlIMeRuAoW/8g+RGCsBqCgQpGrDFCTGoyaxOV9WzNE1Et/pfQqCA9e/RuMpQ9F0MHVj+vdil1kVbI/ueTyQzjj1TSpho1Ha3CjWzD+B5KUTXRoPpPeh+jgKVVJ3XNd9I8Y4FRG1O4NMTSZ3A2heKL5Lpj/SgpwTBjK59vRs9GKHk/mlSoNMKbaZ8McdfBQUc5WBYKtTmywoe0Dllj/VRC8fOVlmj1+rE953L6KiCo4+yNWYqG4FoSCfvdTI2Ps3ixEI1iz8qSoTXc8wkJfLL/o7XUb1l4vFMOQSlebnsu7p8p23UAjtIFdHnkyg/kN3mnvRCOSly7HSNFbakHWzwEAJJA+rrvPc9iTNsDv4JANEGJbOHTRDcW3fpikZRujE1sl9eXe3dF/eSTFhVQGJSwfNUt5RC2+wIRXygFGjwSCnsVREVTmwVmmj2RoMrDunGZaOQShJiiKJEIoMvXxkGWjWFodg2yivxxmK7elBiKK1XIk4mMzeI9Uxse2H452cLIqx7Hbpru3o6LttHjbsbq3X5t127Wf83TZv0BTUHweNZm2eRvP/bv3NyCP/YORpVLQACN3MPXR51fjQ61Qbc499nrVd9yeD589H339jev8bHflY9tT8loAAAAAASUVORK5CYII="
    return m
}
