# CONTEXTO Y DIFFS PARA AGENTE EXTERNO (Claude)

> Proyecto: `C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\`
> Script principal: `XPPEN AHK VERSION ESTABLE.ahk`
> Script de prueba: `XPPEN_NO_ADMIN.ahk`
> Libs: `lib/*.ahk`

---

## ESTADO: 2 de 3 problemas resueltos

| Problema | Estado | Dónde está el diff |
|----------|--------|--------------------|
| 1. Z sostenido lanza R automáticamente | ✅ HECHO | `XPPEN AHK VERSION ESTABLE.ahk` L55 + `lib/hotkeys_csp.ahk` |
| 2. Iconos Z/R no aparecen donde está el puntero | ✅ HECHO | `lib/companion.ahk` `LienzoHUD_Mostrar()` |
| 3. Space del keydial no funciona | ⚠️ PENDIENTE | `lib/hotkeys_csp.ahk` `~Space::` |

---

## DIFFS YA APLICADOS (para que el agente no los repita)

### 1. `XPPEN AHK VERSION ESTABLE.ahk` — línea 55
```diff
- Z := {last:0,timerRunning:0}
+ Z := {last:0,timerRunning:0,estaAbajo:false}
```

### 2. `lib/hotkeys_csp.ahk` — bloque `$z::` (líneas 480-506 aprox)
```diff
 $z:: {
     _FlushPendentes()
     now := A_TickCount
+    if (Z.estaAbajo) {
+        Z.last := now
+        return
+    }
+    Z.estaAbajo := true
     if (now - Z.last < 300) {
         Z.last := 0
         Z.timerRunning := 0
         SendInput("{z up}")
         SendInput("r")
         if !(IsSet(LienzoHUD_Mostrar) && LienzoHUD_Mostrar("r", "", 800))
             MostrarToolTipZ("✋ R",800)
         return
     }
     Z.last := now
     Z.timerRunning := 1
     SendInput("{Blind}z")
     if !(IsSet(LienzoHUD_Mostrar) && LienzoHUD_Mostrar("z", "z", 450))
         MostrarToolTipZ("🔍 Z",800)
 }

+$z up:: {
+    Z.estaAbajo := false
+}
```

### 3. `lib/hotkeys_csp.ahk` — `~Space::` (línea 1338-1340 aprox)
```diff
 ~Space:: {
     spc.downTick := A_TickCount
-    SetTimer(LienzoHUD_ChequeoSpace, -150)
+    LienzoHUD_ChequeoSpace()
 }
```

### 4. `lib/companion.ahk` — `LienzoHUD_Mostrar()` (líneas 2440-2449 aprox)
```diff
     if (e.vis && e.modo = modo && e.paso = 0) {      ; auto-repeat: solo extiende, sin repintar
+        pt := Buffer(8)
+        DllCall("GetCursorPos", "Ptr", pt)
+        e.ultimoX := NumGet(pt, 0, "int")
+        e.ultimoY := NumGet(pt, 4, "int")
+        _LHAsegurarGui()
+        e.gui.Show("x" e.ultimoX " y" e.ultimoY " NA")
         e.tecla := tecla
         e.hasta := Max(e.hasta, A_TickCount + minMs)
         return true
     }
```

---

## PENDIENTE: Space del keydial

### Qué se necesita
El hotkey `~Space::` solo captura la tecla Space estándar del teclado. El keydial envía un **VK y/o SC diferente**. Para agregarlo, necesito esos dos valores.

### Template del diff a aplicar (una vez se tenga VK y SC)

En `lib/hotkeys_csp.ahk`, después del bloque `~Space::` existente, agregar:

```diff
+~vkXXscYY:: {
+    spc.downTick := A_TickCount
+    LienzoHUD_ChequeoSpace()
+}
```

Donde:
- `XX` = VK en hex (ej: `20`, `5B`, etc.)
- `YY` = SC en hex (ej: `20`, `E020`, etc.)

### Cómo obtener VK y SC del keydial (rápido)

**Opción A — Key History de AutoHotkey:**
1. Ejecutar `XPPEN_NO_ADMIN.ahk` (sin admin)
2. Clic derecho en el icono verde de AHK en bandeja → **Key History**
3. Presionar el botón Space del keydial
4. Anotar el VK y SC que aparecen en la última fila

**Opción B — PowerToys Keyboard Manager:**
1. Abrir PowerToys Settings → Keyboard Manager
2. Presionar el botón del keydial, ver qué tecla detecta

---

## CONTEXTO MÍNIMO PARA EL AGENTE

### Funciones usadas (ya existen, no crear)
| Función | Archivo | Propósito |
|---------|---------|-----------|
| `LienzoHUD_ChequeoSpace()` | `lib/companion.ahk` | Muestra el icono de palma verde (Space) |
| `LienzoHUD_Mostrar(modo, tecla, minMs)` | `lib/companion.ahk` | Muestra/actualiza iconos Z, R, Space en el lienzo |
| `_LHAsegurarGui()` | `lib/companion.ahk` | Asegura que el GUI del HUD exista |
| `GetCursorPos` | WinAPI | Obtiene posición actual del cursor |
| `spc` | Objeto global en `XPPEN AHK VERSION ESTABLE.ahk` L78 | Estado del Space |

### Variables globales relevantes
- `spc := {last:0,downTick:0,selectArmed:false,rotOn:false}` — estado Space
- `Z := {last:0,timerRunning:0,estaAbajo:false}` — estado Z (ya modificado)
- `stylus := {comboUsado:false,...}` — estado del stylus

### Regla obligatoria del proyecto
- Cada combinación con stylus (`~RButton & tecla`) debe marcar `stylus.comboUsado := true`.
- Aislar por `#HotIf`: CSP (`ahk_exe CLIPStudioPaint.exe`) y PureRef (`ahk_exe PureRef.exe`) no deben cruzar pulsaciones.
- Solo diffs atómicos, nunca reescribir archivos completos.
- Backup `.bak` antes de modificar.

---

## INSTRUCCIONES PARA CLAUDE

1. Lee `lib/hotkeys_csp.ahk` completo para ver la estructura de hotkeys existentes.
2. Localiza el bloque `~Space::` (línea ~1338).
3. Pregunta al usuario: "¿Cuál es el VK y SC de tu keydial para el botón Space?"
4. Una vez tenga los valores, aplica el diff del template arriba.
5. Valida con `/validate` en `XPPEN_NO_ADMIN.ahk` primero.
6. Si funciona, replica en `XPPEN AHK VERSION ESTABLE.ahk`.

---

## ARCHIVOS BACKUP YA CREADOS
- `XPPEN_NO_ADMIN.ahk.bak`
- `XPPEN AHK VERSION ESTABLE.ahk.bak`
- `lib/hotkeys_csp.ahk.bak`
- `lib/companion.ahk.bak`
