# RESUMEN DE CORRECCIONES — Proyecto AHK CSP

> **Generado:** 10/11/2026  
> **Repositorio:** `C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\`  
> **Estado:** 2 de 3 problemas resueltos. Pendiente: Space del keydial.

---

## Problemas reportados

| # | Problema | Estado |
|---|----------|--------|
| 1 | **Z sostenido lanza R automáticamente** — al mantener Z presionado, el teclado repite la tecla y se interpreta como doble-toque, lanzando `r`. | ✅ SOLUCIONADO |
| 2 | **Iconos Z/R no aparecen donde está el puntero** — solo se dibujan al terminar la animación previa, no al instante donde está el cursor. | ✅ SOLUCIONADO |
| 3 | **Space del keydial no funciona** — el icono de palma verde solo aparece con la tecla Space del teclado, no con el botón Space del keydial. También hay ligero retraso (<0.2 ms). | ⚠️ PENDIENTE (necesita VK/SC del keydial) |

---

## Archivos modificados

### 1. `XPPEN AHK VERSION ESTABLE.ahk` (línea 55)

```diff
- Z := {last:0,timerRunning:0}
+ Z := {last:0,timerRunning:0,estaAbajo:false}
```

### 2. `lib/hotkeys_csp.ahk`

**Bloque `$z::` (líneas 480-506):**

```diff
 $z:: {
     _FlushPendentes()
     now := A_TickCount
+    if (Z.estaAbajo) {
+        Z.last := now
+        return
+    }
+    Z.estaAbajo := true
     if (now - Z.last < 300) {
         Z.last := 0
         Z.timerRunning := 0
         SendInput("{z up}")
         SendInput("r")
         if !(IsSet(LienzoHUD_Mostrar) && LienzoHUD_Mostrar("r", "", 800))
             MostrarToolTipZ("✋ R",800)
         return
     }
     Z.last := now
     Z.timerRunning := 1
     SendInput("{Blind}z")
     if !(IsSet(LienzoHUD_Mostrar) && LienzoHUD_Mostrar("z", "z", 450))
         MostrarToolTipZ("🔍 Z",800)
 }

+$z up:: {
+    Z.estaAbajo := false
+}
```

**Bloque `~Space::` (línea 1338-1341):**

```diff
 ~Space:: {
     spc.downTick := A_TickCount
-    SetTimer(LienzoHUD_ChequeoSpace, -150)
+    LienzoHUD_ChequeoSpace()
 }
```

### 3. `lib/companion.ahk`

**Función `LienzoHUD_Mostrar` (líneas 2440-2449):**

```diff
     if (e.vis && e.modo = modo && e.paso = 0) {      ; auto-repeat: solo extiende, sin repintar
+        pt := Buffer(8)
+        DllCall("GetCursorPos", "Ptr", pt)
+        e.ultimoX := NumGet(pt, 0, "int")
+        e.ultimoY := NumGet(pt, 4, "int")
+        _LHAsegurarGui()
+        e.gui.Show("x" e.ultimoX " y" e.ultimoY " NA")
         e.tecla := tecla
         e.hasta := Max(e.hasta, A_TickCount + minMs)
         return true
     }
```

---

## Backups creados

| Archivo original | Backup |
|-----------------|--------|
| `XPPEN_NO_ADMIN.ahk` | `XPPEN_NO_ADMIN.ahk.bak` |
| `XPPEN AHK VERSION ESTABLE.ahk` | `XPPEN AHK VERSION ESTABLE.ahk.bak` |
| `lib/hotkeys_csp.ahk` | `lib/hotkeys_csp.ahk.bak` |
| `lib/companion.ahk` | `lib/companion.ahk.bak` |

---

## Qué hace cada cambio

### Problema 1: Z sostenido no lanza R
- Se agregó `Z.estaAbajo` al objeto `Z`.
- En `$z::`, si la tecla ya está abajo (auto-repetición del teclado), retorna sin lanzar `r`.
- `$z up::` resetea `estaAbajo := false` al soltar la tecla.
- Solo un doble-toque deliberado (presionar-soltar-presionar) lanza `r`.

### Problema 2: Iconos Z/R al instante donde está el puntero
- Cuando el mismo icono ya está activo (`e.vis && e.modo = modo && e.paso = 0`), ahora obtiene la posición del cursor con `GetCursorPos`, actualiza `e.ultimoX/Y` y reposiciona el GUI con `e.gui.Show("x... y... NA")`.
- Antes: el icono se quedaba donde se creó originalmente. Ahora: aparece donde está el puntero.

### Problema 3: Space sin retraso de 150 ms
- Se eliminó `SetTimer(LienzoHUD_ChequeoSpace, -150)`.
- Ahora `LienzoHUD_ChequeoSpace()` se ejecuta inmediatamente al presionar Space.
- El icono de palma verde aparece entre la pulsación y la soltada.

---

## Qué falta: Space del keydial (PENDIENTE)

### Información necesaria
Para agregar soporte al Space del keydial, se necesita saber **qué código de tecla envía** tu keydial al presionar su botón Space:

- **VK** (código virtual de tecla)
- **SC** (scan code)

### Cómo obtenerlo
Ejecutar cualquier herramienta que muestre VK/SC al presionar una tecla (Key History de AutoHotkey, PowerToys Keyboard Manager, o el script de diagnóstico).

### Cambio a aplicar en `lib/hotkeys_csp.ahk`

Una vez se tenga el VK y SC, agregar este bloque al final de `lib/hotkeys_csp.ahk` (después del bloque `~Space::`):

```ahk
~vkXXscYY:: {
    spc.downTick := A_TickCount
    LienzoHUD_ChequeoSpace()
}
```

Donde `XX` y `YY` son el VK y SC reales del keydial (ej: `~vk20sc20::`).

---

## Instrucciones para agente externo

Si delegas a Claude/Cline:

1. **Archivos a editar:** `lib/hotkeys_csp.ahk` (único archivo pendiente)
2. **No tocar:** `XPPEN AHK VERSION ESTABLE.ahk`, `lib/companion.ahk`, `lib/hud_badges.ahk`, `lib/core_config.ahk` — ya están correctos.
3. **Reglas del proyecto:**
   - No reescribir archivos completos — solo diffs atómicos.
   - Mantener `stylus.comboUsado := true` en combinaciones con stylus.
   - Aislar por `#HotIf` (CSP vs PureRef no cruzan pulsaciones).
   - Validar con `/validate` antes de entregar.
4. **Backup:** Crear `.bak` antes de cualquier cambio.

---

## Scripts de diagnóstico (no funcionales)

- `diagnostico_teclas.ahk` — creado pero no se pudo ejecutar correctamente en el entorno actual (problemas con PowerShell y rutas con espacios).
- `teclas_presionadas.txt` — no se generó por fallo en el script anterior.

---

**Estado general:** Funcional para teclado estándar. Pendiente únicamente el mapeo del botón Space del keydial.