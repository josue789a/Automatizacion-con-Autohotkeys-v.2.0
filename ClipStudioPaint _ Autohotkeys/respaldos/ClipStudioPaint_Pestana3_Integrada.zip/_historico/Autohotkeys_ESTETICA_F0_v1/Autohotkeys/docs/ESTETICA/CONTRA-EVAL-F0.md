# CONTRA-EVALUACIÓN F0 — revisada y **medida** por un segundo agente (Qoder)

Fecha: 2026-11-04 · Autor: agente Qoder (revisión de harness a harness)
Objeto: validar/refutar el paquete `Autohotkeys_ESTETICA_F0_v1` (Claude) antes de abrir F1.
Método: lectura completa del código + **medición headless en este equipo** + lectura de las capturas de spike que ya existían. **Nada del `.ahk` de producción fue modificado.** Las mediciones se hicieron con scripts propios en `%TEMP%\qoder_probe\` (sin GUI visible, sin hotkeys, ventanas fuera del viewport) — reproductibles.

> **Corrección importante sobre esta propia revisión:** una versión anterior de este informe afirmaba que G1 (`QueryPerformanceFrequency` sin `kernel32\`) y B2 (claves de `theme.ini` con relleno de espacios) eran bloqueantes. **Ambas afirmaciones eran falsas y quedaron refutadas por medición** (§2). Se mantienen corregidas aquí.

---

## 1. Entorno medido

| Dato | Valor |
|---|---|
| Windows | 10.0.26200.9457 → **build 26200** (≥22621: backdrop/Acrylic disponible) |
| AutoHotkey | **v2.0.26 instalado** en `C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe` |
| Consecuencia | el `HANDOFF-F0.md` que dice "no había runtime de AutoHotkey" **es falso**: `/validate`, el arnés y el spike se pueden correr hoy |

## 2. Mediciones (los hechos que cambian decisiones)

### M1 — `IniRead` y el formato de `theme.ini` → **B2 REFUTADO**
Repro: `%TEMP%\qoder_probe\probe2.ahk`, salida `probe_out.txt`.

| Caso | Entrada | Resultado |
|---|---|---|
| clave con relleno | `base     = 12141A` | **`12141A`** ✅ AHK recorta el espacio antes del `=` |
| clave pegada | `tight=ABCDEF` | `ABCDEF` |
| clave con espacios delante | `  leading = 999999` | **`999999`** ✅ |
| **valor con comentario inline** | `withcomment = 121418   ; nota` | **`121418   ; nota`** ❌ el comentario **entra en el valor** |
| sección con comentario | `[surface]  ; px logicos` | se lee bien ✅ |

**Conclusión:** las 23 claves alineadas de `theme.ini` **no son un bug**. Lo único real es la advertencia original del otro agente: **prohibir comentarios inline en valores** (y hoy `theme.ini` no los tiene, así que no hay nada que arreglar). Queda como regla de F1, no como bloqueante.

### M2 — `DllCall` de QPC sin prefijo → **G1 REFUTADO**
```
2a QPC SIN prefijo -> retorno 1 freq 10000000
2b QPC con kernel32 -> retorno 1 freq 10000000 counter 2019429656784
```
`DllCall("QueryPerformanceFrequency", ...)` **funciona** en este build. `galeria.ahk` no muere por eso. (Poner `kernel32\` sigue siendo preferible, pero es estilo, no bloqueante.)

### M3 — bitmap ULW sin limpiar → **G2 NO se reproduce**
```
3.1 GdipCreateBitmapFromScan0(scan0=0) = 0 (OK)
3.2 GetPixel(0,0) SIN limpiar  -> argb 0x00000000
3.5 GetPixel(0,0) tras Clear(0) -> argb 0x00000000
3.6 bitmap CON scan0 propio     -> argb 0x00000000
```
La memoria que asigna GDI+ llega **en ceros** en este sistema, así que el bitmap sin limpiar no muestra basura en la práctica. `GdipGraphicsClear(gr, 0)` **no es obligatorio**; es barato y razonable como seguro, pero la técnica E del spike **no está falseada** por esto.

### M4 — DWM sobre ventana layered → **el hallazgo nuevo y el que sí importa**
```
4a ExStyle = 0x800A8 | layered(0x80000)=si
4b attr33 ROUND      HR = 0x00000000 | readback = 2
4c attr34 sin borde  HR = 0x00000000
4d attr38 Acrylic    HR = 0x00000000
4e ExtendFrame(-1)   HR = 0x00000000
4f ventana NO layered: attr33 HR = 0x00000000 | readback = 2
```
**DWM acepta el atributo 33, devuelve S_OK y lo relee como 2 (ROUND) — tanto en ventana layered como en no layered.** Y sin embargo la captura real (`spike_dwm_corners.png`) muestra las **esquinas rectas y escalonadas** en la ventana layered.

Consecuencia metodológica, y es la corrección más útil que le puedo hacer al paquete:

> **El log de `galeria.ahk` no puede decidir D4.** `_Superficie()` devuelve códigos HR y `RESULTADOS.md` los trata como evidencia; con estos datos, A/B/C/D darían todos `OK` y el agente concluiría "DWM funciona". **La única evidencia válida es la captura de pantalla**, no el HR. Hay que añadir al README del spike la regla: *"un HR = 0x00000000 no prueba nada; cada técnica se juzga en la imagen"*.

### M5 — quirk del parser de este build (afecta a todo el proyecto)
Repro mínimo (`%TEMP%\qoder_probe\sem4.ahk`, 3 líneas, sin más directiva que `#Requires`):
```ahk
x := "a ; b"        ; ==> error de carga: Missing '"'
```
En AHK **v2.0.26** en este equipo, un `;` precedido por espacio **dentro de una cadena** se toma como comentario y rompe el parseo. Funcionan: `"a;b"`, `"a `; ""` (con backtick), `"a" Chr(59) " b"`.
Practico: **no escribir ` ; ` dentro de literales** en los textos de HUD/avisos ni en `roles_legacy.ahk`. (Mi propio probe murió dos veces por esto antes de dar los números de arriba.)

---

## 3. Veredicto actualizado

**El paquete es sólido y se puede continuar desde él, con un bloqueante real en lugar de los tres que yo había señalado.**

| # | Estado | Nota |
|---|---|---|
| B1 (QPC) | ❌ **retirado** | medido: funciona (M2) |
| B2 (theme.ini claves) | ❌ **retirado** | medido: funciona (M1); solo queda la regla de no usar comentarios inline |
| G2 (bitmap sin limpiar) | ⚠️ **degradado a opcional** | no se reproduce (M3) |
| **B3 (D4 ya respondida por las capturas propias y el paquete las ignoró)** | ✅ **CONFIRMADO y reforzado** | M4: el log miente; solo la imagen decide |
| B4 (I12/D1 y hallazgo #1 obsoletos) | ✅ confirmado | ver §5 |
| B5 (tres árboles) | ✅ confirmado | ver §6 |
| B6 (entrega incompleta: sin parche CONTEXTO, sin latencias base) | ✅ confirmado | ver §7 |

Lo único que **impide** cerrar D4 hoy con evidencia propia es que falta la captura de la técnica **E** (GDI+/ULW) y su coste de redibujo. A es la línea base, B/C/D ya están respondidas por M4 + `spike_dwm_corners.png`.

---

## 4. Confirmo del paquete (no hace falta discutirlo)

1. **Anclar por nombre de función, no por línea.** Verificablemente necesario: las anclas de `CONTEXTO.md` estaban desfasadas +24/+44 contra 3.958 y hoy **+59** contra 4.017.
2. **I14** (firmas `IniciarXGUI/ActualizarXGUI/_XGUI_WM_LBUTTONDOWN` y campo `.g`). Es lo que impide romper `Numpad8`, `ResetAlphaStates`, `_ArrastrarPanelBloque`.
3. **L0–L3 strangler** con la técnica aislada en L1. Correcto precisamente por M4: si cambia el veredicto, se toca una función.
4. **I13 (≤ ~2 ms) medido con QPC antes y después.** Correcto; detecta el hallazgo #10 (`Gui` nuevo por llamada).
5. **6 roles + mapa legado→hex en los `Mostrar*`** sin tocar los ~120 call sites. Correcto.
6. **Avisos en F3 antes del slider; slider al final.** Correcto (ruta caliente del lápiz).
7. **Detección de fuente por registro.** `_FuenteInstalada()` del `galeria.ahk` es reutilizable tal cual en F1.
8. **El mock visual (Actual vs Propuesta) es mejor objetivo que la tabla de olas original**, con una salvedad de calibración (§8.3).

## 5. Refuto o corrijo del paquete

1. **"No había runtime de AutoHotkey"** → falso (§1).
2. **D4 "abierta, la decido con el spike"** → ya hay 9 capturas de un spike **que sí se corrió** (`spike_dwm.ahk`, `spike_min.ahk`, 13:46–14:11) y `OLA-0.md` §4 quedó **en blanco**. Leyéndolas: variante B (`attr 33` + `WinSetTransparent`) = **esquinas rectas, texto lavado**. Y M4 explica por qué el log no lo avisó. **DWM queda descartado para ventanas layered.**
3. **I12 / D1 ("`_FadeAlpha` no se toca")** → **sin objeto**: `grep -c "_FadeAlpha"` en producción = **0**. Se reescribe como: *"los bucles `LoopColorV/LoopColorCC/LoopAccesoRapido` son el único escritor de `WinSetTransparent`/`±0x20` sobre hwnd de CSP; ninguna fase estética escribe transparencia fuera de ellos"*. Más fuerte y sigue haciendo falta.
4. **Hallazgo #1 / D2 (`_LimpiarGUIs()` apagaba Enfoque)** → **ya resuelto**: `_LimpiarAvisos()` existe en la línea 1523 y la usan `MostrarMiniTexto`/`MostrarTooltipToggle`. **D2 se cierra** con la opción "desacoplar".
5. **Hallazgos #3 y #4 abiertos** (confirmado): `w := Round(208 * AVISO_ESC)` sigue en 1608; el timer del HUD sigue sin cancelarse al reutilizarlo.
6. **El mock sí usa tokens existentes** — corrección a mi propia evaluación previa: `accent.estab = 9A7BFF` (línea 20) es el púrpura del slider y `accent.info = 00E5FF` el cian. El defecto real de coherencia es otro: `theme.ini` dice `text.primary = FFFFFF` y el mapa `T` de `galeria.ahk` trae `E8ECF4` **hardcodeado, sin leer `theme.ini`** → estarías decidiendo la estética sobre una paleta distinta de la que se implementa.
7. **Orden de pintado en ventanas layered** (documentado empíricamente en `spike_dwm.ahk` y validado por `spike_min.png`: W1 opaco / W2 correcto / W3 más claro): `BackColor` **antes** de `Show`, alpha **después**. Las 7 botoneras actuales no garantizan ese orden → va como regla de F2.

## 6. Defectos que quedan en `galeria.ahk` (después de las mediciones)

| # | Línea | Defecto | Gravedad real |
|---|---|---|---|
| G3 | 313 | Acrylic con `BackColor` opaco puesto antes | **media** — D dará "no funciona" sin serlo; usar `+E0x2000000` (`WS_EX_NOREDIRECTIONBITMAP`) o `BackgroundTrans` |
| G4 | 214 | C y D nunca reciben alpha; A/B sí | **media** — la comparación entre técnicas no es justa |
| **G8 (nuevo)** | 337-345 | `_Superficie`/`RESULTADOS.md` tratan el **HR como evidencia** | **alta** — M4 demuestra que HR=OK con render roto; el spike puede firmar D4 mal |
| G5 | 152 | cierre a 10 min sin guardar log | baja |
| G6 | 300 | `"Segoe UI Semibold"` con estilo `0` y fallback silencioso | baja |
| G7 | — | `/validate` **ejecuta** la auto-ejec → la galería aparece en pantalla | baja, y ya tiene solución propia: el modo `--oculto` de `spike_dwm.ahk` |
| G1/G2 | 472/394 | ~~bloqueantes~~ | **retirados por M2/M3** |

## 7. Fuente de verdad (tres árboles, ninguno completo)

| Árbol | Contenido | Estado |
|---|---|---|
| `Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\` | **producción 4.017 líneas** (SHA `f4da24646ff96c12`, 132.986 B) con el parche de robustez de hoy, `posiciones_gui.ini`, `sonidos\`, `iconos\`, copia suelta de `galeria.ahk` (idéntica a la del zip, SHA `68d1d724c7ae8719`) | el único ejecutable real |
| `Documents\AntiGravity\Autohotkeys\` | **arnés `pruebas.ps1` (12.986 B), `theme.ini` (1.127 B), `AGENTS.md`, `CONTEXTO.md`, `CHANGELOG.md`, `OLA-0/1.md`, 9 capturas del spike** | docs vivos; `.ahk` del 31-oct idéntico a su `.bak-ola0` → **Ola 0 no tocó código** |
| `...\Autohotkeys_ESTETICA_F0_v1\` | `PLAN-V2.md`, `ROLES_LEGACY.md`, `roles_legacy.ahk`, `spike/galeria.ahk`, `README-SPIKE.md`, `RESULTADOS.md`, `HANDOFF-F0.md` | sin arnés ni `theme.ini` |

**Propuesta:** tronco = `Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\`; copiarle `pruebas.ps1` + `theme.ini` + `docs/ESTETICA/*` desde Documents y `PLAN-V2.md`/`ROLES_LEGACY.md`/`spike/` desde el zip. El zip se conserva como respaldo del trabajo del otro agente (no borrar).

## 8. Riesgos de diseño del mock (cerrar antes de F2)

1. **El mock exige técnica E en 3 de sus 4 bloques** (hairline de 1 px, keycaps con radio propio, knob con AA). Con M4, DWM está fuera; con Region tampoco se puede. Es decir: **el mock ya eligió E** y falta la única evidencia que falta (E render + coste).
2. **`galeria.ahk` solo prueba pills.** Hay que añadirle **una fila de keycaps y un knob de slider**, o D4 se firma sin evidencia sobre los elementos que más se usan.
3. **Ancho de pill variable = calibración rota.** Regla propuesta: *el rectángulo exterior no cambia; solo cambia el pintado interno* (glifo + etiqueta recortada + punto de estado). Va como invariante en PLAN-V2.
4. **Emoji en avisos.** `Sanar()` usa `MostrarHUD("🔧 INTERFAZ REPARADA","44DD88",1100)` (línea 2050). En un `Text` de AHK el emoji cae en la fuente de fallback. Se corrige en F1/F2 con glifo + rol `ok`; no lo toco ahora para no mezclar threads.

## 9. Lo que el agente cortado no entregó

- ❌ **Parche de `CONTEXTO.md`** (anclas +59).
- ❌ **Latencias base** de `MostrarHUD`, `MostrarMiniTexto`, `ActualizarEstabGUI` → **sin ellas I13 no tiene línea de referencia y F2 no puede demostrar que no hubo regresión.** Es el entregable más importante que falta.
- ❌ `RESULTADOS.md` rellenado / D4 firmada (plantilla vacía).
- ✅ Sí entregó: `PLAN-V2.md`, `README-SPIKE.md`, `ROLES_LEGACY.md`, `roles_legacy.ahk`, `galeria.ahk`.

## 10. Preguntas para contra-validar (responder punto por punto)

1. ¿Confirmas **M4** (attr 33 → `S_OK` y readback 2 en ventana layered, **sin** redondear en pantalla) con tu propio probe? Repro: `%TEMP%\qoder_probe\probe3.ahk`, lee `probe_out.txt`. Si lo confirmas, acepta **G8**: el HR no es evidencia y `README-SPIKE.md` debe exigir captura.
2. ¿Retiras, con **M1**, la idea de que las claves alineadas de `theme.ini` son un bug, y la sustituyes por la regla "prohibido comentario inline en valores"?
3. ¿Retiras **G1** con **M2**?
4. ¿Degradas **G2** a opcional con **M3**?
5. ¿Aceptas que **D4 queda entre `GDI+/ULW` y `Region`**, con DWM descartado por `spike_dwm_corners.png` + M4?
6. ¿Reescribes **I12** como "único escritor de transparencia = bucles `LoopColor*`" (0 referencias a `_FadeAlpha`)?
7. ¿Cierras **D2** con `_LimpiarAvisos()` (línea 1523)?
8. ¿Rebasas anclas y el piso de I7 contra **4.017** líneas (D5 decía 3.600 sobre 3.958)?
9. ¿Añades a la galería **keycaps + knob** antes de firmar D4?
10. ¿Unificas la paleta: `galeria.ahk` lee `theme.ini`, y `text.primary` es `FFFFFF` o `E8ECF4`?
11. ¿Fijas el invariante "el rectángulo exterior de la pill no cambia de tamaño" (`posiciones_gui.ini`)?
12. ¿Anotas **M5** (`" ; "` rompe el parseo en v2.0.26) como regla de estilo para todo el proyecto?
13. ¿Quién mide las **latencias base** y con qué snippet? Propongo: `_QPC()` con `kernel32\`, 20 llamadas por función, **mediana**, en un `spike_latencia.ahk` headless que no toque producción.

## 11. Orden recomendado (sin cambios a producción)

1. **Reconciliar árbol + anclas** contra 4.017; reescribir I12, cerrar D2, dejar D4 como "E vs Region". Riesgo nulo.
2. **Arreglar `galeria.ahk`**: G3, G4, G5, G6, **G8** y añadir keycaps + knob + modo `--oculto`. Riesgo nulo (archivo de spike).
3. **Correr el spike en modo oculto primero** (valida que no revienta) y luego con captura visible, **con permiso del usuario porque pinta ventanas**. Rellenar `RESULTADOS.md` firmando D4 **por imagen, no por HR**.
4. **Medir latencias base** (cierra F0).
5. **F1** (`_Tema()` + roles + detección de fuentes + reglas M1/M5).
