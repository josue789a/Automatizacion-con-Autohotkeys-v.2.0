#Requires AutoHotkey v2.0
#SingleInstance Force
; =====================================================================
; galeria.ahk  -  FASE 0 (spike estetico)
; Script AUTONOMO. No toca ni incluye el .ahk real.
;   - SIN elevacion (no pedir admin), SIN hotkeys, SIN SendInput/BlockInput.
;   - Se cierra solo a los 10 min o con el boton "Cerrar".
;   - Resultados: panel de log + spike_resultados.txt (boton "Guardar log").
;
; Compara la MISMA pill (112x28 logicos) con 5 tecnicas de render:
;   A  Region          SetWindowRgn (lo que hay hoy: sin antialias)
;   B  DWM + alfa      esquinas DWM + WinSetTransparent(235)
;   C  DWM             esquinas DWM sin transparencia
;   D  Acrylic         DWM backdrop (necesita Win11 22H2+, build 22621)
;   E  GDI+ + ULW      alfa por pixel, esquinas AA, texto nitido
; Fila superior = estado ON, fila inferior = OFF. Clic en una pill = alterna
; el estado y mide el tiempo de redibujo (ms) en el log.
; =====================================================================
DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
SetWorkingDir(A_ScriptDir)

S := {esc: 1.0, mon: MonitorGetPrimary(), log: "", ed: 0, ctl: 0, stage: 0, wins: [], porHwnd: Map(), gdip: 0, fondoI: 1, ct: 0, na: 0, dpi: A_ScreenDPI / 96, build: 0, fIcon: "", fMono: ""}
T := Map("base", "12141A", "raised", "1B1E26", "overlay", "20242E", "primary", "E8ECF4", "muted", "8E97A8", "dim", "5A6273", "info", "00E5FF")
FONDOS := [["Oscuro", "1B1B1B", "C8C8C8"], ["Medio", "808080", "101010"], ["Claro", "E8E8E8", "202020"], ["Color", "C8553D", "FFFFFF"]]

try S.build := Integer(StrSplit(A_OSVersion, ".")[3])
S.fIcon := _FuenteInstalada("Segoe Fluent Icons") ? "Segoe Fluent Icons" : (_FuenteInstalada("Segoe MDL2 Assets") ? "Segoe MDL2 Assets" : "Segoe UI Symbol")
S.fMono := _FuenteInstalada("Cascadia Mono") ? "Cascadia Mono" : "Consolas"

_GdipIniciar()
OnExit(_AlSalir)
OnMessage(0x0201, _Click)
_CrearControl()
_LogInicial()
_Reconstruir()
SetTimer(ExitApp, -600000)
return

; ---------------------------------------------------------------------
; UI de control
; ---------------------------------------------------------------------
_CrearControl() {
    g := Gui("+AlwaysOnTop", "Galeria F0 - spike estetico")
    g.SetFont("s9", "Segoe UI")
    g.Add("Text", "xm y+6", "Escala %")
    dEsc := g.Add("DropDownList", "x+6 yp-3 w60 Choose2", ["75", "100", "125", "150"])
    g.Add("Text", "x+14 yp+3", "Monitor")
    mons := []
    Loop MonitorGetCount()
        mons.Push(String(A_Index))
    dMon := g.Add("DropDownList", "x+6 yp-3 w50 Choose" S.mon, mons)
    g.Add("Text", "x+14 yp+3", "Fondo")
    nombres := []
    for f in FONDOS
        nombres.Push(f[1])
    dFon := g.Add("DropDownList", "x+6 yp-3 w80 Choose1", nombres)
    S.ct := g.Add("Checkbox", "xm y+10", "Click-through (+E0x20)")
    S.na := g.Add("Checkbox", "x+14 yp", "NoActivate (+E0x08000000)")
    bRec := g.Add("Button", "xm y+10 w110", "Reconstruir")
    bGli := g.Add("Button", "x+6 yp w110", "Rejilla de glifos")
    bGua := g.Add("Button", "x+6 yp w110", "Guardar log")
    bCer := g.Add("Button", "x+6 yp w90", "Cerrar")
    S.ed := g.Add("Edit", "xm y+10 w560 r16 ReadOnly")
    dEsc.OnEvent("Change", _CambiarEsc)
    dMon.OnEvent("Change", _CambiarMon)
    dFon.OnEvent("Change", _CambiarFondo)
    S.ct.OnEvent("Click", _AplicarEx)
    S.na.OnEvent("Click", _AplicarEx)
    bRec.OnEvent("Click", _Reconstruir)
    bGli.OnEvent("Click", _Glifos)
    bGua.OnEvent("Click", _GuardarLog)
    bCer.OnEvent("Click", (*) => ExitApp())
    g.OnEvent("Close", (*) => ExitApp())
    MonitorGetWorkArea(S.mon, &l, &t, &r, &b)
    g.Show("x" (l + 10) " y" (t + 10))
    S.ctl := g
}

_CambiarEsc(ctrl, *) {
    S.esc := Integer(ctrl.Text) / 100
    _Reconstruir()
}

_CambiarMon(ctrl, *) {
    S.mon := ctrl.Value
    MonitorGetWorkArea(S.mon, &l, &t, &r, &b)
    S.ctl.Move(l + 10, t + 10)
    _Reconstruir()
}

_CambiarFondo(ctrl, *) {
    S.fondoI := ctrl.Value
    _Reconstruir()
}

_Log(txt) {
    S.log .= txt "`r`n"
    if IsObject(S.ed) {
        S.ed.Value := S.log
        SendMessage(0x115, 7, 0, S.ed)
    }
}

_LogInicial() {
    _Log("=== GALERIA F0 · " FormatTime(, "yyyy-MM-dd HH:mm:ss") " ===")
    _Log("Windows " A_OSVersion " (build " S.build ") · Win11=" (S.build >= 22000 ? "si" : "no") " · Acrylic/backdrop=" (S.build >= 22621 ? "si" : "no"))
    _Log("DPI sistema " A_ScreenDPI " (factor " Round(S.dpi, 2) ") · monitores " MonitorGetCount() " · AHK " A_AhkVersion " · admin=" (A_IsAdmin ? "SI (no deberia)" : "no"))
    _Log("GDI+ " (S.gdip ? "ok" : "FALLO"))
    for n in ["Segoe Fluent Icons", "Segoe MDL2 Assets", "Segoe UI Variable", "Segoe UI Semibold", "Cascadia Mono", "Consolas"]
        _Log("Fuente " n ": " (_FuenteInstalada(n) ? "instalada" : "NO"))
    _Log("-> iconos: " S.fIcon " · mono: " S.fMono)
    _Log("")
}

_GuardarLog(*) {
    ruta := A_ScriptDir "\spike_resultados.txt"
    try FileDelete(ruta)
    FileAppend(S.log, ruta, "UTF-8")
    _Log("Guardado: " ruta)
}

; ---------------------------------------------------------------------
; Construccion de la galeria
; ---------------------------------------------------------------------
_DestruirTodo() {
    for o in S.wins {
        try o.g.Destroy()
    }
    S.wins := []
    S.porHwnd := Map()
    if IsObject(S.stage) {
        try S.stage.Destroy()
    }
    S.stage := 0
}

_Reconstruir(*) {
    fg0 := WinExist("A")
    _DestruirTodo()
    k := S.esc * S.dpi
    pw := Round(112 * k)
    ph := Round(28 * k)
    gap := Round(16 * k)
    hdr := Round(24 * k)
    MonitorGetWorkArea(S.mon, &l, &t, &r, &b)
    sw := 5 * (pw + gap) + gap
    sh := hdr + 2 * ph + 3 * gap
    sx := l + 10
    sy := t + 10
    if IsObject(S.ctl) {
        try {
            WinGetPos(&cx, &cy, &cw, &ch, "ahk_id " S.ctl.Hwnd)
            sy := cy + ch + 10
        }
    }
    fon := FONDOS[S.fondoI]
    st := Gui("-Caption +ToolWindow -DPIScale")
    st.BackColor := fon[2]
    st.MarginX := 0
    st.MarginY := 0
    st.SetFont("s9", "Segoe UI")
    cab := ["A Region", "B DWM + alfa", "C DWM", "D Acrylic", "E GDI+ ULW"]
    for i, n in cab
        st.Add("Text", "x" (gap + (i - 1) * (pw + gap)) " y" Round(4 * k) " w" pw " Center c" fon[3], n)
    st.Show("x" sx " y" sy " w" sw " h" sh " NoActivate")
    S.stage := st
    _Log("--- Reconstruccion: escala " Round(S.esc * 100) "% · monitor " S.mon " · fondo " fon[1] " · pill " pw "x" ph " px ---")
    tipos := ["A", "B", "C", "D", "E"]
    for i, tp in tipos {
        px := sx + gap + (i - 1) * (pw + gap)
        for j, estadoOn in [true, false] {
            py := sy + hdr + gap + (j - 1) * (ph + gap)
            t0 := _QPC()
            o := _CrearPill(tp, px, py, pw, ph, estadoOn)
            if (j = 1)
                _Log(tp ": creada en " Round(_QPC() - t0, 1) " ms · " o.info)
        }
    }
    fg1 := WinExist("A")
    _Log("Foco tras Show NoActivate: " (fg0 = fg1 ? "conservado" : "CAMBIO (alguna ventana robo el foco)"))
    _AplicarEx()
}

_CrearPill(tipo, x, y, w, h, encendido) {
    k := S.esc * S.dpi
    o := {tipo: tipo, x: x, y: y, w: w, h: h, on: encendido, g: 0, hwnd: 0, ico: 0, lbl: 0, dot: 0, info: "", label: "Slider"}
    opts := "-Caption +AlwaysOnTop +ToolWindow -DPIScale"
    if (tipo = "E")
        opts .= " +E0x80000"
    g := Gui(opts)
    g.MarginX := 0
    g.MarginY := 0
    o.g := g
    if (tipo != "E") {
        g.BackColor := (tipo = "D") ? "000000" : (encendido ? T["overlay"] : T["raised"])
        col := encendido ? T["primary"] : T["muted"]
        icoC := encendido ? T["info"] : T["dim"]
        o.ico := g.Add("Text", "x" Round(8 * k) " y0 w" Round(20 * k) " h" h " +0x200 Center BackgroundTrans c" icoC, Chr(0xE9E9))
        o.ico.SetFont("s" Max(8, Round(11 * S.esc)), S.fIcon)
        o.lbl := g.Add("Text", "x" Round(32 * k) " y0 w" Round(56 * k) " h" h " +0x200 BackgroundTrans c" col, o.label)
        o.lbl.SetFont("s" Max(7, Round(10 * S.esc)) " w600", "Segoe UI")
        o.dot := g.Add("Text", "x" (w - Round(22 * k)) " y0 w" Round(14 * k) " h" h " +0x200 Center BackgroundTrans c" icoC, encendido ? Chr(0x25CF) : Chr(0x25CB))
        o.dot.SetFont("s" Max(6, Round(8 * S.esc)), "Segoe UI Symbol")
    }
    g.Show("x" x " y" y " w" w " h" h " NoActivate")
    o.hwnd := g.Hwnd
    S.porHwnd[o.hwnd] := o
    S.wins.Push(o)
    rad := Round(10 * k)
    switch tipo {
        case "A":
            WinSetTransparent(235, "ahk_id " o.hwnd)
            o.info := _Superficie(o.hwnd, w, h, rad, "region")
        case "B":
            WinSetTransparent(235, "ahk_id " o.hwnd)
            o.info := _Superficie(o.hwnd, w, h, rad, "dwm")
        case "C":
            o.info := _Superficie(o.hwnd, w, h, rad, "dwm")
        case "D":
            o.info := _Superficie(o.hwnd, w, h, rad, "acrylic")
        case "E":
            o.info := "UpdateLayeredWindow=" _PillULW(o)
    }
    return o
}

_Click(wParam, lParam, msg, hwnd) {
    if !S.porHwnd.Has(hwnd) {
        p := DllCall("user32\GetParent", "ptr", hwnd, "ptr")
        if !S.porHwnd.Has(p)
            return
        hwnd := p
    }
    o := S.porHwnd[hwnd]
    o.on := !o.on
    _Redibujar(o)
}

_Redibujar(o) {
    t0 := _QPC()
    if (o.tipo = "E") {
        _PillULW(o)
    } else {
        col := o.on ? T["primary"] : T["muted"]
        icoC := o.on ? T["info"] : T["dim"]
        if (o.tipo != "D")
            o.g.BackColor := o.on ? T["overlay"] : T["raised"]
        o.ico.SetFont("c" icoC)
        o.lbl.SetFont("c" col)
        o.dot.SetFont("c" icoC)
        o.dot.Value := o.on ? Chr(0x25CF) : Chr(0x25CB)
    }
    _Log(o.tipo " redibujo (" (o.on ? "ON" : "OFF") "): " Round(_QPC() - t0, 2) " ms")
}

_AplicarEx(*) {
    vistos := Map()
    for o in S.wins {
        try {
            WinSetExStyle((S.ct.Value ? "+" : "-") "0x20", "ahk_id " o.hwnd)
            WinSetExStyle((S.na.Value ? "+" : "-") "0x08000000", "ahk_id " o.hwnd)
        }
        if !vistos.Has(o.tipo) {
            vistos[o.tipo] := 1
            ex := 0
            try ex := WinGetExStyle("ahk_id " o.hwnd)
            _Log(o.tipo " ExStyle=0x" Format("{:X}", ex) " · layered=" ((ex & 0x80000) ? "si" : "no") " · transparent(click-through)=" ((ex & 0x20) ? "si" : "no") " · noactivate=" ((ex & 0x08000000) ? "si" : "no"))
        }
    }
}

; ---------------------------------------------------------------------
; Capa L1 de ejemplo: _Superficie(hwnd, w, h, radio, modo)
; ---------------------------------------------------------------------
_Superficie(hwnd, w, h, r, modo) {
    switch modo {
        case "region":
            rgn := DllCall("gdi32\CreateRoundRectRgn", "int", 0, "int", 0, "int", w + 1, "int", h + 1, "int", r * 2, "int", r * 2, "ptr")
            DllCall("user32\SetWindowRgn", "ptr", hwnd, "ptr", rgn, "int", 1)
            return "region aplicada (sin AA)"
        case "dwm":
            a := _Dwm(hwnd, 33, 2)
            b := _Dwm(hwnd, 34, 0xFFFFFFFE)
            return "corner(33)=" _Hr(a) " borde(34)=" _Hr(b)
        case "acrylic":
            c := _Dwm(hwnd, 20, 1)
            d := _Dwm(hwnd, 38, 3)
            m := Buffer(16, 255)
            e := "ERR"
            try e := DllCall("dwmapi\DwmExtendFrameIntoClientArea", "ptr", hwnd, "ptr", m, "int")
            return "dark(20)=" _Hr(c) " backdrop(38)=" _Hr(d) " extend=" _Hr(e)
    }
    return ""
}

_Dwm(hwnd, attr, val) {
    b := Buffer(4, 0)
    NumPut("UInt", val, b)
    try {
        return DllCall("dwmapi\DwmSetWindowAttribute", "ptr", hwnd, "uint", attr, "ptr", b, "uint", 4, "int")
    } catch {
        return "ERR"
    }
}

_Hr(v) {
    if (v = "ERR")
        return "ERR"
    return (v = 0) ? "OK" : Format("0x{:08X}", v & 0xFFFFFFFF)
}

; ---------------------------------------------------------------------
; GDI+ + UpdateLayeredWindow (tecnica E)
; ---------------------------------------------------------------------
_GdipIniciar() {
    if !DllCall("LoadLibrary", "str", "gdiplus", "ptr")
        return false
    si := Buffer(A_PtrSize = 8 ? 24 : 16, 0)
    NumPut("UInt", 1, si, 0)
    tok := 0
    r := DllCall("gdiplus\GdiplusStartup", "ptr*", &tok, "ptr", si, "ptr", 0, "int")
    if (r = 0)
        S.gdip := tok
    return (r = 0)
}

_AlSalir(*) {
    if S.gdip {
        try DllCall("gdiplus\GdiplusShutdown", "ptr", S.gdip)
    }
    return 0
}

_Argb(hex, a) => (a << 24) | Integer("0x" hex)

_GdipRoundPath(x, y, w, h, r) {
    path := 0
    DllCall("gdiplus\GdipCreatePath", "int", 0, "ptr*", &path)
    d := r * 2
    DllCall("gdiplus\GdipAddPathArc", "ptr", path, "float", x, "float", y, "float", d, "float", d, "float", 180, "float", 90)
    DllCall("gdiplus\GdipAddPathArc", "ptr", path, "float", x + w - d, "float", y, "float", d, "float", d, "float", 270, "float", 90)
    DllCall("gdiplus\GdipAddPathArc", "ptr", path, "float", x + w - d, "float", y + h - d, "float", d, "float", d, "float", 0, "float", 90)
    DllCall("gdiplus\GdipAddPathArc", "ptr", path, "float", x, "float", y + h - d, "float", d, "float", d, "float", 90, "float", 90)
    DllCall("gdiplus\GdipClosePathFigure", "ptr", path)
    return path
}

_GdipRelleno(gr, path, argb) {
    br := 0
    DllCall("gdiplus\GdipCreateSolidFill", "uint", argb, "ptr*", &br)
    DllCall("gdiplus\GdipFillPath", "ptr", gr, "ptr", br, "ptr", path)
    DllCall("gdiplus\GdipDeleteBrush", "ptr", br)
}

_GdipTrazo(gr, path, argb, ancho) {
    pen := 0
    DllCall("gdiplus\GdipCreatePen1", "uint", argb, "float", ancho, "int", 2, "ptr*", &pen)
    DllCall("gdiplus\GdipDrawPath", "ptr", gr, "ptr", pen, "ptr", path)
    DllCall("gdiplus\GdipDeletePen", "ptr", pen)
}

_GdipTexto(gr, txt, fam, px, argb, x, y, w, h, centrar := 0) {
    ff := 0
    font := 0
    sf := 0
    br := 0
    st := DllCall("gdiplus\GdipCreateFontFamilyFromName", "str", fam, "ptr", 0, "ptr*", &ff, "int")
    if (st != 0 || !ff) {
        ff := 0
        st := DllCall("gdiplus\GdipCreateFontFamilyFromName", "str", "Segoe UI", "ptr", 0, "ptr*", &ff, "int")
        if (st != 0 || !ff)
            return
    }
    DllCall("gdiplus\GdipCreateFont", "ptr", ff, "float", px, "int", 0, "int", 2, "ptr*", &font)
    DllCall("gdiplus\GdipCreateStringFormat", "int", 0x1000, "int", 0, "ptr*", &sf)
    DllCall("gdiplus\GdipSetStringFormatLineAlign", "ptr", sf, "int", 1)
    DllCall("gdiplus\GdipSetStringFormatAlign", "ptr", sf, "int", centrar ? 1 : 0)
    DllCall("gdiplus\GdipCreateSolidFill", "uint", argb, "ptr*", &br)
    rc := Buffer(16, 0)
    NumPut("float", x, "float", y, "float", w, "float", h, rc)
    DllCall("gdiplus\GdipDrawString", "ptr", gr, "str", txt, "int", -1, "ptr", font, "ptr", rc, "ptr", sf, "ptr", br)
    DllCall("gdiplus\GdipDeleteBrush", "ptr", br)
    DllCall("gdiplus\GdipDeleteStringFormat", "ptr", sf)
    DllCall("gdiplus\GdipDeleteFont", "ptr", font)
    DllCall("gdiplus\GdipDeleteFontFamily", "ptr", ff)
}

_PillULW(o) {
    w := o.w
    h := o.h
    k := S.esc * S.dpi
    bmp := 0
    gr := 0
    if DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", w, "int", h, "int", 0, "int", 0x26200A, "ptr", 0, "ptr*", &bmp, "int")
        return 0
    DllCall("gdiplus\GdipGetImageGraphicsContext", "ptr", bmp, "ptr*", &gr)
    DllCall("gdiplus\GdipSetSmoothingMode", "ptr", gr, "int", 4)
    DllCall("gdiplus\GdipSetTextRenderingHint", "ptr", gr, "int", 4)
    fondo := o.on ? T["overlay"] : T["raised"]
    path := _GdipRoundPath(0.5, 0.5, w - 1, h - 1, 10 * k)
    _GdipRelleno(gr, path, _Argb(fondo, 235))
    _GdipTrazo(gr, path, o.on ? _Argb(T["info"], 90) : _Argb("FFFFFF", 20), 1)
    DllCall("gdiplus\GdipDeletePath", "ptr", path)
    col := o.on ? T["primary"] : T["muted"]
    icoC := o.on ? T["info"] : T["dim"]
    _GdipTexto(gr, Chr(0xE9E9), S.fIcon, 14 * k, _Argb(icoC, 255), 8 * k, 0, 22 * k, h, 1)
    _GdipTexto(gr, o.label, "Segoe UI Semibold", 13 * k, _Argb(col, 255), 34 * k, 0, 56 * k, h, 0)
    dd := 7 * k
    dx := w - 20 * k
    dy := (h - dd) / 2
    if o.on {
        br := 0
        DllCall("gdiplus\GdipCreateSolidFill", "uint", _Argb(T["info"], 255), "ptr*", &br)
        DllCall("gdiplus\GdipFillEllipse", "ptr", gr, "ptr", br, "float", dx, "float", dy, "float", dd, "float", dd)
        DllCall("gdiplus\GdipDeleteBrush", "ptr", br)
    } else {
        pen := 0
        DllCall("gdiplus\GdipCreatePen1", "uint", _Argb(T["dim"], 255), "float", 1.5 * k, "int", 2, "ptr*", &pen)
        DllCall("gdiplus\GdipDrawEllipse", "ptr", gr, "ptr", pen, "float", dx, "float", dy, "float", dd, "float", dd)
        DllCall("gdiplus\GdipDeletePen", "ptr", pen)
    }
    hbm := 0
    DllCall("gdiplus\GdipCreateHBITMAPFromBitmap", "ptr", bmp, "ptr*", &hbm, "uint", 0)
    hdc := DllCall("gdi32\CreateCompatibleDC", "ptr", 0, "ptr")
    old := DllCall("gdi32\SelectObject", "ptr", hdc, "ptr", hbm, "ptr")
    pt := Buffer(8, 0)
    sz := Buffer(8, 0)
    src := Buffer(8, 0)
    bl := Buffer(4, 0)
    NumPut("int", o.x, "int", o.y, pt)
    NumPut("int", w, "int", h, sz)
    NumPut("UChar", 0, "UChar", 0, "UChar", 255, "UChar", 1, bl)
    ok := DllCall("user32\UpdateLayeredWindow", "ptr", o.hwnd, "ptr", 0, "ptr", pt, "ptr", sz, "ptr", hdc, "ptr", src, "uint", 0, "ptr", bl, "uint", 2, "int")
    DllCall("gdi32\SelectObject", "ptr", hdc, "ptr", old)
    DllCall("gdi32\DeleteObject", "ptr", hbm)
    DllCall("gdi32\DeleteDC", "ptr", hdc)
    DllCall("gdiplus\GdipDeleteGraphics", "ptr", gr)
    DllCall("gdiplus\GdipDisposeImage", "ptr", bmp)
    return ok
}

; ---------------------------------------------------------------------
; Rejilla de glifos (decision de iconos para la fase 2)
; ---------------------------------------------------------------------
_Glifos(*) {
    static gg := 0
    try gg.Destroy()
    gg := Gui("+AlwaysOnTop", "Rejilla de glifos - " S.fIcon)
    gg.SetFont("s8", "Segoe UI")
    gg.MarginX := 10
    gg.MarginY := 10
    cand := [[0xE713, "settings"], [0xE9E9, "slider?"], [0xE790, "color"], [0xE81C, "history"], [0xE72E, "lock"], [0xE785, "unlock"], [0xE718, "pin"], [0xE77A, "unpin"], [0xE71D, "quick?"], [0xE8AB, "switch"], [0xE71E, "zoom"], [0xE72C, "refresh"], [0xE895, "sync"], [0xE7C9, "?"], [0xE8B9, "?"], [0xE7B3, "?"]]
    for i, c in cand {
        x := 10 + Mod(i - 1, 8) * 84
        y := 10 + ((i - 1) // 8) * 150
        a := gg.Add("Text", "x" x " y" y " w76 h44 Center +0x200 Background" T["overlay"] " c" T["info"], Chr(c[1]))
        a.SetFont("s22", S.fIcon)
        b := gg.Add("Text", "x" x " y+2 w76 h44 Center +0x200 Background" T["raised"] " c" T["dim"], Chr(c[1]))
        b.SetFont("s22", S.fIcon)
        gg.Add("Text", "x" x " y+2 w76 Center", Format("{:04X} {}", c[1], c[2]))
    }
    gg.Show()
    _Log("Rejilla de glifos abierta con fuente: " S.fIcon " (anota los codigos elegidos)")
}

; ---------------------------------------------------------------------
; Utilidades
; ---------------------------------------------------------------------
_QPC() {
    static f := 0
    if !f
        DllCall("QueryPerformanceFrequency", "int64*", &f)
    c := 0
    DllCall("QueryPerformanceCounter", "int64*", &c)
    return c * 1000 / f
}

_FuenteInstalada(nombre) {
    for raiz in ["HKLM", "HKCU"] {
        try {
            Loop Reg(raiz "\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts", "V") {
                if InStr(A_LoopRegName, nombre)
                    return true
            }
        }
    }
    return false
}
