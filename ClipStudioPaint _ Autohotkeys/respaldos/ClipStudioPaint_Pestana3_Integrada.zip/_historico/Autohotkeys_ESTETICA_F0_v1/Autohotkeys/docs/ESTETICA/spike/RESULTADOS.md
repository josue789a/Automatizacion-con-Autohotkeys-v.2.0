# RESULTADOS - Fase 0

Fecha: ____  Windows (build): ____  Monitores / DPI: ____

## Log pegado de spike_resultados.txt

```text

```

## Tabla de observaciones

| Criterio | A Region | B DWM+alfa | C DWM | D Acrylic | E GDI+ ULW |
|---|---|---|---|---|---|
| Esquinas AA (75 / 100 / 150 %) | | | | | |
| Borde de 1 px no deseado | | | | | |
| Texto nitido | | | | | |
| Foco conservado | | | | | |
| Click-through OK | | | | | |
| Redibujo (ms) | | | | | |
| 2.o monitor / DPI | | | | | |

## Glifos aprobados (codigo -> uso)

| Uso | Codigo | Fuente |
|---|---|---|
| slider |  |  |
| circle |  |  |
| quick |  |  |
| history |  |  |
| lock / unlock |  |  |
| pin / unpin |  |  |
| calib |  |  |
| reload |  |  |

## Decision D4 (tecnica de render)

[ ] GDI+ ULW   [ ] DWM   [ ] Region   [ ] Mixta: ____
Motivo:
