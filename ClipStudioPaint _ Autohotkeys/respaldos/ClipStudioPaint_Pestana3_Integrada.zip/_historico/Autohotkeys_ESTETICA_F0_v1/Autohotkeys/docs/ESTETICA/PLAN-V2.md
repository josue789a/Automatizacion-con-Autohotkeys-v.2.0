# PLAN-V2 - Refactor estetico (sustituye la tabla de olas de CONTEXTO.md sec. 6)

Fecha: 2026-11-04. Aprobado por el usuario ("sigue tal cual tu plan"). Los invariantes I1-I11 de `CONTEXTO.md` **no cambian**; se anaden I12-I14.

## 1. Revision tecnica (hechos medidos en la copia de 3.958 lineas)

| # | Hallazgo | Tipo | Fase |
|---|---|---|---|
| 1 | `_LimpiarGUIs()` (llamado desde `MostrarMiniTexto` y `MostrarTooltipToggle`, ademas de `Numpad8`) destruye el HUD y fija `enfoque.activo := false` + oculta el marco de enfoque | logica | F3 (decision D2) |
| 2 | HUD y badge en `(-2247, 30)` fijo; MiniTexto/toggle/icono en `PUNTOS[30]` (etiquetado "Avisos (HUD)") | consistencia | F3 (D3) |
| 3 | HUD con ancho fijo `208 * AVISO_ESC`: textos largos recortados (6 literales >= 24 car. + mensajes de `ElegirPerfil`) | visual | F3 |
| 4 | Timer de ocultar del HUD no se cancela al reutilizarlo: oculta antes de tiempo | visual | F3 |
| 5 | 9 `Picture` vacios (`iconos\` no existe, `_IconosB64()` = `Map()`): hueco de 20 px | visual | F2 |
| 6 | ON/OFF casi iguales (`636D83` vs `424242`) | visual | F2 |
| 7 | `ESTAB_ALPHA_H 128` lava el numero; solo alfa por pixel lo resuelve | visual | F5 |
| 8 | 58 hex distintos; 33 pasados a avisos; verdes (6) y naranjas (2) inconsistentes | sistema | F1 |
| 9 | 7 botoneras clonadas + 10 handlers `WM_LBUTTONDOWN` + `if/else` hwnd->accion duplicado | estructura | F2 / F6 |
| 10 | `MostrarBadgeCombo` / `MostrarMiniTexto` crean un `Gui` por llamada | rendimiento | F3 |
| 11 | `MostrarMiniGUI`: codigo muerto (0 usos) | limpieza | F3 |
| 12 | Anclas de `CONTEXTO.md` desfasadas (+24..+44) y 3.958 frente a 3.917 | proceso | F0 |

## 2. Diseno objetivo (resumen)

1. **Periferico primero**: estado legible de un vistazo; forma (punto lleno/hueco) ademas de color.
2. **6 roles de color**: `info ok warn danger estab neutral` (ver `ROLES_LEGACY.md`). Mapa hex-legado->rol dentro de `Mostrar*`: los ~120 call sites no cambian.
3. **2 motores de aviso** (linea simple de ancho automatico; combo con keycaps), ventanas persistentes reutilizadas, **una sola ancla** de posicion.
4. **Forma**: radio 10 px, borde de 1 px (blanco ~8 %) en vez de sombra.
5. **Tipografia**: 3 niveles; numeros en mono (`Cascadia Mono` -> `Consolas`), con deteccion de fuente.
6. **Movimiento**: solo opacidad, 120-180 ms, out-cubic; nada en la ruta del lapiz.
7. **Iconos**: glifos (`Segoe Fluent Icons` -> `Segoe MDL2 Assets`), con deteccion.

## 3. Arquitectura (strangler: envolver, no reescribir)

```text
L3  Adaptadores   IniciarXGUI / ActualizarXGUI / MostrarHUD(texto, hexLegado, ms)   <- firmas intactas, campo .g intacto
L2  Componentes   Pill - Toast - ToastCombo - SliderSkin
L1  Superficie    _Superficie(hwnd, w, h, radio, modo)     <- Region | DWM | ULW segun D4
L0  Tema          _Tema() + roles + deteccion de fuentes
```

## 4. Fases

| Fase | Que hace | Toca (por nombre de funcion) | Riesgo |
|---|---|---|---|
| **F0** | Reconciliar 3.958/3.917 + SHA; medir latencias base; `galeria.ahk`; decidir D4 | **nada del `.ahk`** | nulo |
| **F1** | `_Tema()` con validacion hex, roles, deteccion de fuentes. Cero cambio visual | bloque nuevo (`roles_legacy.ahk`) | bajo |
| **F2** | Botoneras: glifo, punto de estado, radio, hairline; cuerpos de `Iniciar/Actualizar` -> `PillCrear/PillEstado` | 7 botoneras, `IniciarReloadGUI`, `IniciarPuntosGUI`, `_SetIcono` | medio |
| **F3** | Avisos: 2 motores, ancho automatico, ancla unica, timer unico; retirar `MostrarMiniGUI` | `MostrarHUD`, `MostrarMiniTexto`, `MostrarBadgeCombo`, `MostrarTooltipToggle`, `MostrarIconoHerramienta` | bajo-medio |
| **F4** | Animacion de opacidad solo en GUIs propias | `_Animar` nuevo | bajo |
| **F5** | Slider: pintado/controles; sin tocar hotkeys, `_EstabEmitir` ni `_EstabEnviarDelta` | creacion de controles en `IniciarEstabGUI`, `ActualizarEstabGUI`, `_EstabRegion`, `_EstabKnobRegion` | medio |
| **F6** (opc.) | Panel de calibracion oscuro, tabla hwnd->accion, marcos de enfoque 8 -> menos ventanas | `AbrirPanelPuntos`, `_ArrastrarPanelBloque`, `MostrarGUIEnfoque` | bajo-medio |

### Puerta de cada fase (DoD)

1. `.bak-faseN-<fecha>` antes de la primera edicion (I2).
2. Ediciones con anclas unicas por **nombre de funcion** (I1); nunca `write` ni `replaceAll` sobre el `.ahk`.
3. `pruebas.ps1 -Modo parse` y `-Modo esteril` en PASS (I3, I4).
4. Captura de `galeria.ahk`/GUIs frente a la fase anterior.
5. **Latencia**: ninguna funcion estetica nueva suma > ~2 ms en ruta caliente (medido con QPC; linea base de F0).
6. Lineas antes -> despues dentro de I7 (ver D5).
7. 5 lineas en `CHANGELOG.md` + lista corta de pruebas manuales con el lapiz.
8. Rollback: `Copy-Item <bak> <archivo> -Force`.

## 5. Invariantes nuevos

| # | Regla |
|---|---|
| I12 | **`_FadeAlpha` no se toca** (actua sobre ventanas de CSP: zona I5). El animador nuevo solo opera sobre GUIs propias. |
| I13 | **Presupuesto de latencia**: funcion estetica nueva <= ~2 ms en ruta caliente; se mide antes y despues. |
| I14 | **Compatibilidad de adaptadores**: se conservan firmas `IniciarXGUI/ActualizarXGUI/_XGUI_WM_LBUTTONDOWN` y el campo `.g` (los usan `Numpad8`, `ResetAlphaStates`, `_MostrarPaneles`, `_TraerPanelesAlFrente`, `_ArrastrarPanelBloque`). |

## 6. Decisiones

| ID | Decision | Estado |
|---|---|---|
| D1 | `_FadeAlpha` fuera del alcance | **cerrada** (I12) |
| D2 | `_LimpiarGUIs()` y `enfoque.activo`: conservar o desacoplar | **abierta** (F3) - cambia comportamiento |
| D3 | Ancla de avisos: `PUNTOS[30]` o `(-2247, 30)` | **abierta** (F3) - confirmar si coinciden en tu equipo |
| D4 | Tecnica de render (Region / DWM / GDI+ ULW) | **abierta** - la fija F0 (`spike/RESULTADOS.md`) |
| D5 | Piso de I7 en F2 | **provisional**: 3.600 lineas (consolidar clones reduce lineas por diseno); confirmar al cerrar F2 |

## 7. Salida de F0 (criterio)

`spike/RESULTADOS.md` completo + D4 marcada + latencias base anotadas + SHA/lineas del `.ahk` de produccion reconciliados. Con eso F1 puede empezar.
