# HANDOFF - tras Fase 0 (paquete v1)

Un chat nuevo lee **solo**: `CONTEXTO.md` -> `PLAN-V2.md` -> `spike/RESULTADOS.md` (si existe).

## Estado

- F0 preparada: `spike/galeria.ahk`, `spike/README-SPIKE.md`, `spike/RESULTADOS.md` (plantilla), `ROLES_LEGACY.md`, `roles_legacy.ahk`.
- El `.ahk` de produccion **no se ha tocado**. `theme.ini` tampoco.
- `galeria.ahk` se escribio sin poder ejecutarlo (no habia runtime de AutoHotkey): el primer paso es `/validate` (ver README-SPIKE).

## Pendiente del usuario

1. `/validate` + ejecutar `galeria.ahk` y rellenar `RESULTADOS.md`.
2. Confirmar si el `.ahk` de disco tiene 3.917 o 3.958 lineas (SHA) y cual es la fuente de verdad.
3. Anotar latencias base (`MostrarHUD`, `MostrarMiniTexto`, `ActualizarEstabGUI`) - o pedir el snippet de medicion.

## Siguiente entregable (F1)

`theme.ini` con bloque `[rol]` + `_Tema()` validado + deteccion de fuentes + `roles_legacy.ahk` integrado como bloque nuevo. Sin cambio visual.
