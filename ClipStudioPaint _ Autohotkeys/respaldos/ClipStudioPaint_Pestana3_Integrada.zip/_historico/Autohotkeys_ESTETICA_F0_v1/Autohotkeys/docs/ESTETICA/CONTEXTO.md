# CONTEXTO — Refactor estético (traspaso entre chats)

> **Documento de arranque.** Un chat nuevo debe leer **solo este archivo** más el
> `OLA-N.md` de turno. Todo lo demás es opcional.
>
> Regla de oro: **si no está escrito aquí, no existe.** Las decisiones que no se
> registran se re-discuten y se implementan distinto en cada ola.

- Última actualización: 2026-11-04 (revisión técnica + **PLAN-V2.md**; ver §10)
- Proyecto: `C:\Users\jbard\Documents\AntiGravity\Autohotkeys\`
- Archivo objetivo: `XxxPPEN_a16pg2_displayAS_secondary.ahk` (**3.917 líneas**)
- Fase: estética AHK, sin segundo proceso. C#/overlays quedan para después.
- Convive con `AGENTS.md` (reglas generales del proyecto). Este documento **no lo
  sustituye**: añade el detalle de la fase estética.

---

## 0. Punto de partida verificado (2026-11-04, no re-verificar)

| Comprobación | Resultado |
|---|---|
| Líneas del `.ahk` | **3.917** en disco · la copia del proyecto Claude tiene **3.958** (anclas §2 desfasadas +24…+44): **reconciliar en F0**, anclar por nombre de función |
| `/validate` | **exit 0** |
| Prueba de carga | **exit 0**, stderr 0 bytes |
| `theme.ini` | **creado** en la raíz (inerte hasta la ola 1) |
| Carpeta `iconos\` | **no existe** |
| `_IconosB64()` | vacío (`return Map()`) |
| Import keys del `.ini` con puntos (`surface.off`) | **leídas correctamente** por `IniRead` |
| Dial | muerto: `IniciarDialGUI() => 0` (2188) |
| Arnés `pruebas.ps1` | **probado**: `parse` PASS (0.1 s) · `esteril` PASS (1 s) |
| Procesos AHK elevados | 3 del 2-nov + 1 del 4-nov vivos (ver §9.1) |

Cualquier desviación de esta tabla en un chat nuevo = el archivo cambió desde
entonces: **parar y avisar** antes de editar.

---

## 1. Invariantes (no negociables)

| # | Regla |
|---|---|
| I1 | **Zero-rewrite.** Solo se tocan las líneas exactas del bloque indicado. Prohibido reescribir el archivo con `write`; usar `edit` con anclas únicas. |
| I2 | **Respaldo antes de guardar**, una vez por ola: `<archivo>.bak-olaN-YYYYMMDD-HHmmss`. Nunca sobrescribir un `.bak` anterior. |
| I3 | **Validar siempre**: `& "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" /validate "<archivo>.ahk"` → **exit 0**. Sin excepciones. |
| I4 | **Prueba de carga** además del validate (ver §5): exit 0 y sin salida en stderr. |
| I5 | **No tocar** (nunca, en ninguna ola): detección de HWND de paneles de CSP, zonas de hover, `LoopColorV` / `LoopColorCC` / `ChequearZona*`, `WS_EX_TRANSPARENT` (`+0x20`), `WS_EX_NOACTIVATE` (`+E0x08000000`), click-through, `BlockInput`, `_EstabEmitir` (2865) y sus constantes de timing. |
| I6 | **No tocar los `#HotIf`** ni reordenar hotkeys. |
| I7 | **Presupuesto de tamaño**: si una ola deja el archivo por debajo de **3.850** o por encima de **4.050** líneas, detenerse y justificarlo. Es la red de seguridad contra un reescrito accidental. |
| I8 | **No arreglar bugs colaterales** que la ola no pida (ver §7). Se anotan, no se corrigen. |
| I9 | Si un cambio estético obliga a tocar §I5, **el cambio está mal planteado**. Parar y consultar. |
| I10 | `posiciones_gui.ini` está en **UTF-16**. Ninguna ola estética debe escribirlo. |
| I11 | **La elevación de las líneas 3-6 es intencional y NO se toca.** El driver de la XP-Pen y el cambio de perfiles (CSP ↔ otras apps) la necesitan para funcionar sin errores. El arnés de pruebas la anula **solo en la copia desechable**, nunca en producción. Tampoco quitar `#SingleInstance Force` (línea 2). |
| I12 | **`_FadeAlpha` no se toca**: actúa sobre ventanas de CSP (zona I5). El animador nuevo solo opera sobre GUIs propias. |
| I13 | **Presupuesto de latencia**: ninguna función estética nueva suma > ~2 ms en ruta caliente (QPC antes/después). |
| I14 | **Compatibilidad de adaptadores**: conservar firmas `IniciarXGUI/ActualizarXGUI/_XGUI_WM_LBUTTONDOWN` y el campo `.g` (los usan `Numpad8`, `ResetAlphaStates`, `_MostrarPaneles`, `_TraerPanelesAlFrente`, `_ArrastrarPanelBloque`). |

---

## 2. Mapa del código relevante (verificado, 2026-11-04)

```
1-6      #Requires + #SingleInstance Force + ELEVACIÓN (intencional, ver §I11)
29-32    ESTAB_COLOR "9A7BFF" / ESTAB_ALPHA_H 128 / ACT 235 / F 150
78       AVISO_ESC := 1.0        (escala de avisos, vía CargarEscalaAvisos)
84       ESC := 1.0              (escala general, vía CargarEscala)
539      _FadeAlpha(hwnd,hasta,pasos:=6,delayMs:=10)   ← 6 pasos, Sleep bloqueante
1528     MostrarBadgeCombo                                ← Show/Hide seco
1574     MostrarHUD                                      ← Show/Hide seco
1627     MostrarIconoHerramienta                         ← SetWindowRgn + emoji
1675     MostrarMiniTexto
1722     MostrarTooltipToggle
2019     _PosGuiIniPath() => A_ScriptDir "\posiciones_gui.ini"
2046     _AnclaBloquePaneles()
2205     IniciarDsGUI          / 2222 ActualizarDsGUI        ┐
2239     IniciarCcGUI          / 2256 ActualizarCcGUI        │
2286     IniciarArGUI          / 2306 ActualizarArGUI        │ 7 botoneras
2333     IniciarHCGUI          / 2353 ActualizarHCGUI        │ clonadas
2380     IniciarLockGUI        / 2400 ActualizarLockGUI      │
2427     IniciarFrenteGUI      / 2447 ActualizarFrenteGUI    │
2482     IniciarEstabBtnGUI    / 2512 ActualizarEstabBtnGUI  ┘
2544     IniciarEstabGUI                                 ← slider
2635     _EstabCalcular      2661 _EstabLayout
2680     _EstabKnobRegion    2689 _EstabRegion
2698     ActualizarEstabGUI
2865     _EstabEmitir         ← PROHIBIDO TOCAR
3139     IniciarReloadGUI     ← misma familia visual (Picture 20x20 + label + barra)
3251     _E(n)  => Max(1,Round(n * ESC))
3252     _FS(n) => Max(6,Round(n * ESC))
3334     IniciarPuntosGUI     ← misma familia visual (icono "calib")
3868     _SetIcono(ctrl,nombre)  ← lee PNG, return silencioso si falta
3874     _RutaIcono(nombre)      ← iconos\csp2_<nombre>.png  →  <dir>\csp2_<nombre>.png  →  base64  →  %TEMP%
3911     _IconosB64()            ← return Map() VACÍO
```

**Colores hoy hardcodeados** (sustituir por tokens en la ola que corresponda):
`00E5FF` `FF4444` `44DD88` `FF6B00` `12141A` `1a1a1a` `181818` `222222` `EEEEEE`
`1F4D3A` `1A5276` `1E8449` `D92B2B` `B4C0DE` `636D83` `424242` `3A4260` `3A3A45`
`2B2B2B` `FFFFFF` `8E9AA0` `6A6A6A` `B2B2B2`

**Iconos referenciados (14):** `slider_on/off` `circle_on/off` `quick_on/off`
`hist_on/off` `lock_closed/open` `pin_on/off` `calib` `reload_g`.
Carpeta `iconos\` **no existe** y `_IconosB64()` está vacío → hoy los `Picture` se
pintan en blanco.

---

## 3. Limitaciones técnicas aceptadas (por qué se ve "a Windows")

1. `WinSetTransparent` = alpha **uniforme** de toda la ventana → el texto se lava
   junto con el fondo (`ESTAB_ALPHA_H 128` deja el número casi ilegible).
2. `SetWindowRgn` = esquinas **sin antialias** (2680, 2689, 1646). Escalonadas a 1,5×/2×.
3. Los controles `Progress` / `Text` no saben redondear. El knob es un `Text`
   blanco recortado con elipse (2594 + 2680).
4. No hay transiciones: `Show()` / `Hide()` secos en HUD, badge, tooltips.
5. Todo es `Segoe UI bold 9`. Sin jerarquía tipográfica.
6. Emoji como iconos (`🔍 ↻ ⚙ 🎯 🎚 ◢`) → tamaño/baseline inconsistentes, no se tiñen.

---

## 4. Decisiones cerradas (no re-discutir)

### 4.1 Formato de tema: **INI**, no JSON
`theme.ini` junto al script. Motivo: AHK v2 tiene `IniRead` nativo y **no** tiene
parser JSON. Cero dependencias, editable a mano, apto para el futuro Centro de Control.

- Ruta: `A_ScriptDir "\theme.ini"`.
- Si el archivo falta o la clave no existe → **valor por defecto hardcodeado**.
  Un tema roto jamás debe dejar la UI sin color. (Invariante de robustez.)
- Colores en formato `RRGGBB` **sin** `#`.
- API: `_Tema(seccion, clave, defecto)` con caché en un `Map` para no leer disco
  en cada repintado.

### 4.2 Capturar primero, afinar después
La ola 1 mapea **1:1 los hex actuales** a tokens. El reajuste de paleta (sustituir
`FFFFFF` por `E8ECF4`, unificar los tres negros) ocurre en la ola 2 **con prueba
visual**. Nunca cambiar valor y mecanismo en el mismo paso.

### 4.3 Tokens (nombres definitivos)

```ini
[color]
surface.base     = 12141A
surface.raised   = 1B1E26
surface.overlay  = 20242E
surface.off      = 424242
surface.on       = 636D83
text.primary     = FFFFFF
text.idle        = B2B2B2      ; captura 1:1 del label OFF
text.muted       = 8E97A8
text.disabled    = 5A6273
accent.info      = 00E5FF
accent.success   = 44DD88
accent.warn      = FF6B00
accent.danger    = FF4444
accent.estab     = 9A7BFF
accent.estabSoft = B4C0DE      ; captura 1:1 de la barra ON
track.off        = 3A3A45
track.pillOff    = 6A6A6A      ; captura 1:1 de la barra OFF

[alpha]
pill = 235
badge = 230
hud = 215
mini = 200
icono = 185

[radius]        ; px lógicos, escalar con _E()
sm = 6
md = 10
lg = 14

[type]
family       = Segoe UI
family.value = Cascadia Mono   ; fallback: Consolas
size.caption = 9
size.body    = 11
size.value   = 13

[motion]        ; ms
fast = 120
base = 180
slow = 240
```

Easing único: **out-cubic** → `t' = 1 - (1-t)^3`.

### 4.4 Iconos: fuente de iconos, no PNG
Sustituir `Picture` + PNG por un control `Text` con fuente de glifos:
`Segoe Fluent Icons` (Win11) con fallback a `Segoe MDL2 Assets` (Win10).
Monocromo, se tiñe con el color del texto, escala sin assets, elimina el bug de
los cuadros blancos y hace innecesario `_IconosB64()`.

- **El mapa de glifos se elige visualmente en la ola 2**, renderizando una rejilla
  de candidatos. No fijar códigos a ciegas aquí.
- Candidatos de partida (verificar): `E713` settings · `E9E9` slider · `E790` color ·
  `E81C` history · `E72E` lock · `E785` unlock · `E718` pin · `E77A` unpin ·
  `E71D` quick access · `E8AB` switch.

### 4.5 Nombres nuevos reservados
`_Tema()` · `_RepintarPill()` · `PillDef()` · `PillCrear()` · `PillEstado()` ·
`_Animar()` · `_AnimTick()` · `_Glifo()` · `_DwmRedondear()` · `_DwmFondo()`
No usar estos nombres para otra cosa.

---

## 5. Protocolo de cierre de ola (Definition of Done)

1. `.bak` creado **antes** de la primera edición: `XxxPPEN_...ahk.bak-olaN-<fecha>`.
2. Ediciones con `edit` (anclas únicas). Nunca `write` sobre el `.ahk`.
3. **Validar y probar con el arnés, nunca a mano:**
   ```powershell
   cd docs\ESTETICA
   .\pruebas.ps1 -Modo parse       # /validate sobre el real: 0 ventanas, 0 UAC, 0.1 s
   .\pruebas.ps1 -Modo esteril     # copia desechable: sin UAC, hotkeys suspendidos,
                                   # GUIs ocultas, errores a stderr, watchdog, ~1 s
   ```
   Requisito: `RESULTADO: PASS` en ambos. El arnés ya comprueba exit code, stderr,
   huérfanos y que el archivo real quede intacto (hash).

   **Nunca** lanzar el `.ahk` real para "probar que arranca": pide UAC por diseño
   (§I11), registra hotkeys y puede dejar procesos elevados huérfanos imposibles de
   cerrar sin admin. El arnés existe exactamente para evitar eso.

   **Modo `carga`** (GUIs visibles, sin UAC): solo si estás dispuesto a que
   parpadeen ~1 s. Para pruebas de input real con el lápiz: `-Modo carga` **no** basta,
   hay que ejecutar el script real y eso es una prueba manual deliberada, nunca
   durante el flujo de dibujo.
4. Conteo de líneas dentro de §I7. Reportar `antes → después`.
5. 5 líneas en `CHANGELOG.md` (qué cambió, qué probar, cómo revertir).
6. Marcar la ola como `hecho` en la tabla de §6.

**Revertir:** `Copy-Item "<archivo>.bak-olaN-<fecha>" "<archivo>" -Force`
(una ola = un `.bak`, así se puede volver a la ola anterior sin perder las demás).

---

## 6. Índice de olas

> **Sustituido por `PLAN-V2.md` (fases F0–F6).** Esta tabla se conserva como histórico; no usarla para planificar.

| Ola | Objetivo | Toca | Riesgo | Estado |
|---|---|---|---|---|
| **0** | Spike DWM: ¿esquinas AA / backdrop funcionan en este Windows? | nada del script | nulo | `pendiente` |
| **1** | `theme.ini` + cargador `_Tema()` + tokens **solo** en las 7 botoneras (colores, sin estructura) | 2205-2530 | bajo | `pendiente` |
| **2** | Componente `Pill*` único + fuente de iconos + reajuste de paleta | 2205-2530 + 3139/3334 | medio | `pendiente` |
| **3** | Animador no bloqueante + entrada/salida de HUD/badge + `_FadeAlpha` sin `Sleep` | 539, 1528-1755 | bajo-medio | `pendiente` |
| **4** | Slider: knob AA, track redondeado, dígitos tabulares, interpolación de valor | 2544-2727 | medio | `pendiente` |
| **5** | HUD/badge unificados + posición calculada (mata `x := -2247`) | 1528-1755 | bajo | `pendiente` |

Dependencias: **0 → 1 → 2** en serie. 3 puede ir en paralelo a 2 (bloques
distintos) pero **no** en el mismo chat. 4 depende de 0 (para el redondeo) y de 3
(para el animador). 5 depende de 3.

**Paralelismo:** solo artefactos independientes (`theme.ini`, mapa de glifos,
documentación). Nunca dos chats editando el `.ahk` a la vez.

---

## 7. Deuda conocida — NO tocar salvo que la ola lo pida

| Bug | Línea | Ola que lo cubre |
|---|---|---|
| `x := -2247, y := 30` hardcodeado en HUD/badge → fuera de pantalla en otro monitor | 1540-1541, 1582-1583 | 5 |
| `MostrarBadgeCombo` no limpia `floatGui.badge` al ocultar (fuga) | 1568-1573 | 5 |
| Carrera de timers en `_OcultarHUDSi` (no revalida `A_TickCount`) | 1611-1614 | 5 |
| `_FadeAlpha` con `Sleep` en rutas de input (posible micro-tirón) | 539-555 | 3 |
| `_IconosB64()` vacío y `iconos\` inexistente → `Picture` en blanco | 3911, 3874 | 2 |
| Falta `global PUNTOS` en `_PtsDefecto` | ~3693 | — (fuera de alcance) |
| Falta `global HIST_ALTO` en `_PtsAltoChange` | ~3649 | — (fuera de alcance) |
| `Ctrl+G` con ruta `C:\Users\JOSUE\...` hardcodeada | ~119 | — (fuera de alcance) |
| Dial muerto: `IniciarDialGUI() => 0` | 2188 | — |

---

## 8. Reglas de edición (para el chat ejecutor)

- Antes de editar: `grep` del bloque y `read` con `offset`/`limit`. **No leer las
  3.917 líneas completas** salvo en la ola 2.
- Un `edit` por unidad lógica (una botonera, una función). Validar al terminar el
  bloque, no al terminar la ola, si la ola tiene más de 5 ediciones.
- Si un `edit` falla por ancla ambigua: **ampliar el ancla**, nunca usar
  `replaceAll` en este archivo (los bloques clonados lo hacen catastrófico).
- Prohibido `Set-Content` / `Out-File` sobre el `.ahk` (rompe el encoding).
- Al reportar: `líneas antes → después`, `validate: exit 0`, y qué probar a mano.

---

## 9. Arnés de pruebas (no invasivo)

`docs/ESTETICA/pruebas.ps1` — **única forma autorizada de ejecutar el script**.
Existe porque el script pide elevación en las líneas 3-6 y crea ~10 GUIs en el
auto-ejecutable: lanzarlo "para ver si arranca" interrumpe el dibujo.

| Modo | Qué hace | UAC | Ventanas | Duración |
|---|---|---|---|---|
| `parse` | `/validate` sobre el **real** | no | 0 | ~0.1 s |
| `esteril` | copia en `%TEMP%` con elevación anulada, `Suspend(1)`, todas las GUIs ocultas, errores a stderr | **no** | 0 | ~1 s |
| `carga` | igual, pero con GUIs visibles (parpadean) | no | ~10 | ~1 s |
| `info` | diagnóstico de procesos AutoHotkey vivos / huérfanos / elevados | no | 0 | instantáneo |

Garantías del arnés:
- **Nunca** modifica el `.ahk` real (verifica el SHA-256 antes y después).
- **Verifica la huella estructural** del script (`.Show()`: 31 string + 2 vacías +
  3 posicionales). Si cambia, **se niega a ejecutar** en vez de corromper la copia.
- **Watchdog**: mata el proceso si excede `-TimeoutSeg` (default 30).
- **Detección de huérfanos**: compara PIDs antes/después y avisa con el comando
  `Stop-Process` exacto.
- Encoding preservado: lee y escribe UTF-8 **sin BOM** vía .NET
  (`Get-Content` de PowerShell 5.1 corrompe los emojis).

### 9.1 Elevación: intencional en producción, anulada en pruebas

Las líneas 3-6 (`Run('*RunAs ...')` + `ExitApp()`) **existen por una razón**:
el driver XP-Pen necesita privilegios para cambiar de perfil entre CSP y otras
apps sin fallar. **No es un bug y no se elimina.** Ver §I11.

El coste de esa decisión es que el script de producción corre elevado, y eso tiene
tres consecuencias operativas:

1. **No se puede ejecutar "para probar".** Cada arranque pide UAC e interrumpe el
   dibujo. Para eso está el arnés: la copia desechable corre **sin elevación**
   (basta para validar sintaxis, construcción de GUIs, lectura de config y DllCalls
   de pintado; lo único que no cubre es `BlockInput`, que solo actúa en hotkeys).
2. **Los procesos elevados no se pueden inspeccionar ni cerrar sin admin.** El
   2026-11-04 había 3 procesos elevados del 2-nov vivos, uno con 2,5 h de CPU.
   `-Modo info` los marca como "línea de comandos ilegible".
3. **No hay conflicto entre producción y prueba**, aunque ambas sean elevadas:
   `#SingleInstance Force` empareja por **nombre de archivo**, y la copia se llama
   `prueba_esteril.ahk`. Verificado empíricamente: el PID de producción sobrevivió
   a varias corridas del arnés.

**Nunca matar procesos AHK a ciegas.** `Stop-Process -Name AutoHotkey64` cerraría
también la producción. Confirmar PID por PID con el usuario.

**Nota para la fase de producto:** un shell C# sin elevar no puede hablar por named
pipe con un motor elevado (UIPI / integridad). Ese día habrá que decidir entre
elevar también el shell o partir el motor en dos procesos. No es problema ahora.

### 9.3 Qué necesita elevación y qué no

**Las pruebas NO necesitan admin.** Verificado empíricamente: `-Modo esteril` y
`-Modo parse` pasan con shell estándar (`JOSUE\jbard`, sin elevar), stderr vacío.

| Tarea | ¿Admin? |
|---|---|
| `/validate` (parse) | **no** |
| Copia estéril: construir GUIs, `DllCall` de pintado (`SetWindowRgn`, `SetWindowPos`, `UpdateLayeredWindow`, `DwmSetWindowAttribute`), leer/escribir INI, enumerar monitores | **no** |
| Leer `theme.ini` / `posiciones_gui.ini` | **no** |
| `BlockInput` (solo dentro de acciones de hotkey) | sí — **nunca se ejercita en pruebas** |
| Inyectar teclas en un CSP elevado (UIPI) | sí — **no se prueba nunca; es manual** |
| Ejecutar el script real para dibujar (olas 3-4) | sí — **lo hace el usuario**, ya es su flujo normal |
| Inspeccionar o cerrar procesos AHK elevados huérfanos | sí — limpieza opcional del usuario |

**Regla:** el agente nunca debe pedir ni recibir un shell elevado. Trabaja sobre
archivos del proyecto (permisos normales) y valida con el arnés sin privilegios.
Elevar el shell del agente solo añadiría riesgo (archivos con dueño equivocado,
ediciones sin control de UAC) sin desbloquear nada del camino crítico.

### 9.2 Lo que el arnés NO puede probar

Nada que requiera el lápiz o CSP real: hover, fade de paneles, inyección de
teclas, timing del estabilizador, `BlockInput`. Eso sigue siendo prueba manual
deliberada, con el usuario mirando, nunca en medio del flujo de dibujo.

**Máquina virtual: no hace falta para esta fase.** El arnés cubre el 80 % de lo que
interrumpe (UAC, ventanas, hotkeys, huérfanos, MsgBox de error). Una VM no tendría
ni CSP ni drivers de la XP-Pen, así que no aportaría nada para lo estético; se
justifica más adelante para instalar/desinstalar/antivirus en fase de producto.

---

## 10. Revisión técnica y plan v2 (2026-11-04)

Documentos nuevos en `docs/ESTETICA/`: `PLAN-V2.md` (plan vigente), `ROLES_LEGACY.md` + `roles_legacy.ahk` (mapa hex→rol), `spike/` (F0: `galeria.ahk`, `README-SPIKE.md`, `RESULTADOS.md`), `HANDOFF-F0.md`.

Correcciones a este documento:
- **Colores (§2):** hay **58** hex distintos en el archivo; **33** se pasan a funciones de aviso (31 de mensaje + `FFFFFF`/`000000` de texto). La lista de §2 era incompleta.
- **Anclas (§2):** válidas solo para el archivo de 3.917 líneas; en la copia de 3.958 van desfasadas. Anclar por nombre de función.
- **`theme.ini`:** `IniRead` no quita comentarios en la misma línea ni texto tras `]`. Los ejemplos de §4.3 con `; comentario` al lado del valor son **ilustrativos**: en el archivo real, comentarios en línea propia y validar `^[0-9A-Fa-f]{6}$` con caída al defecto.
- **§4.3 radius:** los tokens `sm/md/lg` (6/10/14) solo se respetan con Region o GDI+; DWM fija ~8 px. Depende de D4.

Decisiones abiertas: D2 (`_LimpiarGUIs` ↔ `enfoque.activo`), D3 (ancla de avisos), D4 (técnica de render, la fija F0), D5 (piso de I7 provisional 3.600 en F2). Ver `PLAN-V2.md` §6.
