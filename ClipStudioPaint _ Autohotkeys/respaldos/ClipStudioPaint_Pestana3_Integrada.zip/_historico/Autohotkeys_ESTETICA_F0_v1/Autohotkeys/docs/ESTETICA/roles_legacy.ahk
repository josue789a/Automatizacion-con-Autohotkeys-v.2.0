; roles_legacy.ahk - FASE 1 (se pega como BLOQUE NUEVO, sin editar call sites)
; Mapa hex legado -> rol. SOLO para colores pasados a Mostrar* / ToolTipE / ToolTipCS.
; No aplica a BorderFrame, marcos de enfoque, overlays de calibracion (no son avisos).
; Un hex que no este aqui devuelve "" y el llamador conserva el hex original.
ROL_LEGADO := Map(
    "00E5FF","info", "1C6EA4","info", "1A5276","info", "1A2E5C","info",
    "44DD88","ok", "1E8449","ok", "27AE60","ok", "51D67B","ok",
    "1A5C2A","ok", "32CD32","ok", "2ECC71","ok", "FF6B00","warn",
    "FF8C42","warn", "AA8844","warn", "FFAA33","warn", "FF6F61","warn",
    "FF4444","danger", "C0392B","danger", "E74C3C","danger", "922B21","danger",
    "9A7BFF","estab", "AA44FF","estab", "6C3483","estab", "1A1A2E","neutral",
    "888888","neutral", "555555","neutral", "9AA7C7","neutral", "2B3B32","neutral",
    "222222","neutral", "EEEEEE","neutral", "424949","neutral"
)
_RolDeHex(hex) => ROL_LEGADO.Has(StrUpper(hex)) ? ROL_LEGADO[StrUpper(hex)] : ""
; MostrarTooltipToggle usa "verde"/"rojo" (no hex): verde -> ok, rojo -> danger
