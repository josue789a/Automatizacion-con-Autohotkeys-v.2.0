# ROLES_LEGACY - mapa de colores de avisos a roles semanticos (F1)

Fecha: 2026-11-04. Fuente: `XPPEN_a16pg2_displayAS_secondary.ahk` (copia del proyecto, 3.958 lineas).

## Cifras corregidas

- **58** hex distintos en todo el archivo (botoneras, avisos, BorderFrame, marcos de enfoque, calibracion, slider).
- **33** se pasan a funciones de aviso (`MostrarHUD`, `MostrarMiniTexto`, `MostrarBadgeCombo`, `ToolTipE/CS`). De esos, 31 son colores de mensaje (mapeados abajo) y 2 son estructura (`FFFFFF` texto por defecto, `000000` texto oscuro).
- Cifras anteriores del chat ("~41") y la lista de 23 de `CONTEXTO.md` §2 eran incompletas.

## Roles (6)

| Rol | Semantica en el script | Hex de referencia |
|---|---|---|
| `info` | accion primaria / modo (1) / informacion | `00E5FF` |
| `ok` | confirmacion, restaurar, activo | `44DD88` |
| `warn` | modo alterno (2), lazo, smudge, atencion | `FF6B00` |
| `danger` | borrar, deseleccionar, error | `FF4444` |
| `estab` | estabilizacion, referencia, smear, capas de correccion | `9A7BFF` |
| `neutral` | informacion sin carga semantica | `8E97A8` |

## Mapa (31 entradas)

| Hex | Usos | Rol |
|---|---|---|
| `00E5FF` | 20 | info |
| `1C6EA4` | 3 | info |
| `1A5276` | 2 | info |
| `1A2E5C` | 2 | info |
| `44DD88` | 10 | ok |
| `1E8449` | 4 | ok |
| `27AE60` | 2 | ok |
| `51D67B` | 2 | ok |
| `1A5C2A` | 2 | ok |
| `32CD32` | 1 | ok |
| `2ECC71` | 1 | ok |
| `FF6B00` | 17 | warn |
| `FF8C42` | 3 | warn |
| `AA8844` | 3 | warn |
| `FFAA33` | 1 | warn |
| `FF6F61` | 1 | warn |
| `FF4444` | 10 | danger |
| `C0392B` | 3 | danger |
| `E74C3C` | 1 | danger |
| `922B21` | 1 | danger |
| `9A7BFF` | 6 | estab |
| `AA44FF` | 3 | estab |
| `6C3483` | 1 | estab |
| `1A1A2E` | 5 | neutral |
| `888888` | 3 | neutral |
| `555555` | 3 | neutral |
| `9AA7C7` | 2 | neutral |
| `2B3B32` | 2 | neutral |
| `222222` | 2 | neutral |
| `EEEEEE` | 1 | neutral |
| `424949` | 1 | neutral |

## Notas de criterio

- `FF6B00` aparece en mensajes de naturaleza distinta (SMUDGE, LASSO, ALL LAYERS (2), HISTORY LOCKED). Se unifica como `warn` = "modo alterno / atencion". Si se quiere distinguir, hace falta un 7.o rol: decision de F3.
- `AA44FF`, `9B59B6`, `6C3483` (violetas distintos) se funden en `estab`. Perdemos la distincion entre estabilizacion y referencia/smear. Aceptado salvo objecion.
- `1A5276` y `1A2E5C` (azules oscuros usados como *fondo* de mini-texto) pasan a `info`; en el diseno nuevo el color es el acento del glifo, no el fondo.
- `EEEEEE` / `000000` (variante `MostrarMiniTextoOscuro`) desaparecen como variante: el toast nuevo es siempre superficie oscura.
- El mapa se aplica **dentro** de `Mostrar*`; los ~120 call sites no cambian. Los colores de `BorderFrame` (`44AA66`, `AA6622`, `AA8844`), marcos de enfoque (`0077B6`, `00B4D8`) y overlays de calibracion **no** pasan por el mapa.

## Bloque `[rol]` propuesto para `theme.ini` (F1)

```ini
[rol]
info    = 00E5FF
ok      = 44DD88
warn    = FF6B00
danger  = FF4444
estab   = 9A7BFF
neutral = 8E97A8
```

Recordatorio: **sin comentarios en la misma linea** que un valor (`IniRead` no los quita) y sin texto tras el `]` de una seccion.
