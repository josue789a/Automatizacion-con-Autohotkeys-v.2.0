# README-SPIKE - Fase 0 (galeria.ahk)

**No toca el `.ahk` real, no pide UAC, no registra hotkeys.** Duracion: ~10 min.

## Como correrlo

1. Validar sintaxis (sin ejecutar):
   ```powershell
   & "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" /validate "docs\ESTETICA\spike\galeria.ahk"
   ```
   Debe dar exit 0. Si falla, copiar el mensaje a `RESULTADOS.md` y traerlo al chat (el archivo no se pudo ejecutar donde se escribio).
2. Ejecutarlo con doble clic (o `AutoHotkey64.exe galeria.ahk`). **Sin elevar.**
3. En la ventana de control: probar escala 75 / 100 / 150, **fondo** (oscuro / medio / claro / color) y el **monitor secundario** (el de x negativo).
4. Hacer clic en cada pill: alterna ON/OFF y mide el redibujo en el log.
5. Marcar *Click-through* y *NoActivate* y leer el `ExStyle` en el log.
6. *Rejilla de glifos*: anotar que codigos se ven bien y cuales no (cuadrito = no existe en tu fuente).
7. *Guardar log* -> `spike_resultados.txt`. Pegar su contenido y tus notas en `RESULTADOS.md`.

## Que mirar (por tecnica A-E)

| Criterio | Como se ve / donde se lee |
|---|---|
| Esquinas con antialias | A ojo a 150 % y sobre fondo claro y oscuro (escalones = no AA) |
| Borde de 1 px no deseado | Linea clara/oscura alrededor (tipica de DWM) |
| Texto nitido sobre fondo translucido | Comparar B (texto lavado) frente a E (texto opaco) |
| Efecto backdrop (D) | Solo si `backdrop(38)=OK` y build >= 22621; fijarse en fringes negros del texto |
| Foco | Linea `Foco tras Show NoActivate` en el log |
| Click-through y NoActivate | Lineas `ExStyle=` tras marcar las casillas; con click-through activo la pill ya no responde al clic |
| Costo de redibujo | `redibujo (ON/OFF): X ms`. Meta para E: **< 2 ms** |
| Coherencia en 2.o monitor / DPI | Misma pill, mismo radio visual |

## Regla de decision (se rellena en `RESULTADOS.md`)

| Si... | Entonces |
|---|---|
| E: AA correcto, redibujo < 2 ms, foco conservado, click-through OK | **Tecnica = GDI+ ULW** para pills, avisos y (si procede) slider |
| E falla o > 2 ms, B/C dan AA y `ExStyle` correcto en Win11 | **DWM** (radio fijo ~8 px: aceptar o abandonar los tokens `radius`) |
| Ninguna da AA fiable | **Region** (estado actual) + mejoras de color/tipografia/glifos solamente |
| D funciona sin fringes y sin robar foco | Opcional: acrylic en avisos (no en pills) |

La decision se registra en `PLAN-V2.md` (D4) y desbloquea F2.

## Limites del spike

- Pills sin fuente `Segoe UI Variable` (se usa `Segoe UI` en las 5 tecnicas para comparar igual).
- Las pills A-D usan controles de AHK (como hoy); E dibuja todo con GDI+, sin controles hijos. En F2 esa diferencia importa: con ULW el hit-test y el arrastre se resuelven en el propio hwnd (ya es lo que hace `_ArrastrarPanelBloque`).
- No prueba hover de paneles CSP, `BlockInput` ni inyeccion de teclas (manual, fuera del spike).
