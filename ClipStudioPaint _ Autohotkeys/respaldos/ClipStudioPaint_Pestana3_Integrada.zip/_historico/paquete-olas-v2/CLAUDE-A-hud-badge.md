# CLAUDE A — ola B: HUD y badge (posición real, fugas de HWND, carrera de timers)

Adjunto: `PROTOCOLO.md`. Eres el único con esta zona. **No toques** `_FadeAlpha`, `_Estab*`,
`_IconosB64`, `PillRegion`, `IniciarDialGUI` ni `theme.ini`: son de los otros paquetes.

> **No tienes acceso a mi PC.** No puedes leer ni editar el archivo, ni ejecutar AutoHotkey, ni ver la
> pantalla. Todo lo que necesitas está en este mensaje: tú devuelves texto y ya. Los `l.NNN` son mi
> referencia para aplicar el parche; **la fuente de verdad es el bloque `ANTES`**. No pidas el archivo.

Reglas duras (resumen de `PROTOCOLO.md`; si no lo has leído, pídelo): no cambiar el número de `.Show(`; no
añadir asignaciones globales de nivel superior; usar solo funciones que ya existen o definirlas en el mismo
parche; nada de `Sleep` en rutas de repintado; CRLF; cero refactors y no tocar `posiciones_gui.ini`.

## Diagnóstico (medido por mí en el archivo de 4.329 líneas; dalo por bueno, no lo compruebes)
1. **Posición literal.** `MostrarBadgeCombo` (l.1564-1605) y `MostrarHUD` (l.1610-1646) ponen la ventana
   en `x := -2247` / `y := 30`, a pelo. Ese punto solo existe en el escritorio virtual de hoy: con otro
   perfil, otro monitor o si se desconecta el monitor izquierdo, el aviso **nace fuera de pantalla** y no
   se ve. Es el bug que el usuario reporta como "el HUD no sale".
2. **Fuga.** Cada `MostrarBadgeCombo` crea una `Gui` nueva y la asigna a `floatGui.badge` **sin destruir la
   anterior**; `_OcultarBadgeSi` solo hace `.Hide()`. Cada combo deja vivos 1 HWND + 5 controles para
   siempre. Con uso normal son decenas de HWND huérfanos por sesión.
3. **Carrera.** `_OcultarHUDSi(hwnd)` compara **HWND**, pero el HUD **reutiliza** el mismo HWND (se crea una
   vez, l.1622). Cualquier timer viejo de hace 2 s apaga el HUD recién mostrado: el aviso parpadea o no se
   llega a leer. El badge ya resuelve esto con un ID por llamada (`badgeID`); el HUD no lo tiene.
4. **Convivencia.** `MostrarBadgeCombo` oculta el HUD pero **no invalida su timer** (lo apagará en cuanto
   toque, encima del badge) y `MostrarHUD` **no oculta el badge**: un badge puede quedar vivo encima del
   HUD o sobre el lienzo cuando ya no viene a cuento.

## CAMBIO 1 — contador de generación del HUD
Ancla literal (l.56, aparece una sola vez):
```ahk
floatGui := {miniTip:0,miniGUI:0,tooltipToggle:0,enfoque:0,miniTipTick:0,miniTipID:0,hud:0,hudLabel:0,hudBar:0,hudHwnd:0,overlayIcon:0,overlayIconID:0,badge:0,badgeHwnd:0,badgeSub:0,badgeMain:0,badgeSubBar:0,badgeBar:0,badgeID:0}
```
Añade `hudID:0` en la misma línea, junto a `hudHwnd`. Sin líneas nuevas. `hudID` es la generación: sube en
cada `MostrarHUD` y el timer solo apaga si sigue siendo la suya.

## CAMBIO 2 — posición calculada (función nueva)
Inserta esta función **inmediatamente antes** de `MostrarBadgeCombo`, con una línea en blanco de
separación. Justificación: el aviso vivía en la esquina superior izquierda del monitor más a la izquierda
del escritorio virtual; eso se conserva, pero ahora se calcula y se recorta.

```ahk
_PosicionAviso(w,h) {
    ; El HUD/badge vivian en -2247,30 fijos: una esquina del escritorio virtual de hoy.
    ; Se conserva esa esquina (la del monitor mas a la izquierda/arriba) pero calculada y
    ; recortada con _RectaFijaEnPantalla, que ya existe y garantiza que el rectangulo
    ; entero cabe en un monitor. Coste: MonitorGetCount + MonitorGet, solo al mostrar aviso.
    xIzq := 0, ySup := 0
    n := MonitorGetCount()
    Loop n {
        MonitorGet(A_Index,&l,&t,&r,&b)
        if (A_Index = 1 || l < xIzq)
            xIzq := l
        if (A_Index = 1 || t < ySup)
            ySup := t
    }
    return _RectaFijaEnPantalla(xIzq + 8,ySup + 8,w,h)
}
```

## CAMBIO 3 — `MostrarBadgeCombo` + `_OcultarBadgeSi`
Ancla literal (l.1564-1609, aparece una sola vez):
```ahk
MostrarBadgeCombo(comboText,toolText,colorAcento := "00E5FF",duracion := 2200) {
    global AVISO_ESC
    if IsObject(floatGui.miniTip)
        _DestruirGui(floatGui.miniTip)
    if IsObject(floatGui.miniGUI)
        _DestruirGui(floatGui.miniGUI)
    if IsObject(floatGui.tooltipToggle)
        _DestruirGui(floatGui.tooltipToggle)
    if IsObject(floatGui.hud)
        floatGui.hud.Hide()
    thisID := A_TickCount
    floatGui.badgeID := thisID
    x := -2247
    y := 30
    w := Round(240 * AVISO_ESC)
    h := Round(62 * AVISO_ESC)
    g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
    g.BackColor := "12141A"
    g.MarginX := 0
    g.MarginY := 0
    WinSetTransparent(230,g)
    bLeft := g.Add("Progress","x0 y0 w" Round(5 * AVISO_ESC) " h" h)
    bLeft.Opt("c" colorAcento)
    bLeft.Value := 100
    lblSub := g.Add("Text","x" Round(12 * AVISO_ESC) " y" Round(6 * AVISO_ESC) " w" (w - Round(16 * AVISO_ESC)) " c8E9AA0",comboText)
    lblSub.SetFont("s" Max(6,Round(9 * AVISO_ESC)) " bold","Segoe UI")
    lblMain := g.Add("Text","x" Round(12 * AVISO_ESC) " y" Round(24 * AVISO_ESC) " w" (w - Round(16 * AVISO_ESC)) " cWhite",toolText)
    lblMain.SetFont("s" Max(7,Round(13 * AVISO_ESC)) " bold","Segoe UI")
    bSub := g.Add("Progress","x0 y" Round(58 * AVISO_ESC) " w" w " h" Round(4 * AVISO_ESC))
    bSub.Opt("c" colorAcento)
    bSub.Value := 100
    g.Show("w" w " h" h " NoActivate Hide")
    floatGui.badge := g
    floatGui.badgeHwnd := g.Hwnd
    floatGui.badgeSub := lblSub
    floatGui.badgeMain := lblMain
    floatGui.badgeSubBar := bLeft
    floatGui.badgeBar := bSub
    DllCall("SetWindowPos","Ptr",floatGui.badgeHwnd,"Ptr",-1,"int",x,"int",y,"int",0,"int",0,"uint",0x0040 | 0x0010 | 0x0001)
    floatGui.badge.Show("NoActivate")
    SetTimer(() => _OcultarBadgeSi(thisID),-duracion)
}
_OcultarBadgeSi(targetID) {
    if (IsObject(floatGui.badge) && floatGui.badgeID = targetID)
        floatGui.badge.Hide()
}
```

Requisitos del DESPUÉS:
- `thisID` **no** puede ser `A_TickCount` (dos combos en el mismo milisegundo comparten ID y el timer viejo
  puede ocultar el nuevo). Usa un contador que solo suba: `floatGui.badgeID += 1` y `thisID := floatGui.badgeID`.
  Ojo: `badgeID` arranca en 0, así que **no** lo uses como "hay badge" en ningún sitio.
- **Destruye** el badge anterior (`_DestruirGui(floatGui.badge)` + poner a 0 `badge`, `badgeHwnd`,
  `badgeSub`, `badgeMain`, `badgeSubBar`, `badgeBar`) antes de crear el nuevo. Ese es el arreglo de la fuga.
- **Invalida el timer del HUD**: `floatGui.hudID += 1` (CAMBIO 1) y luego oculta el HUD. Así el timer
  pendiente del HUD ya no puede apagar nada.
- Posición: `p := _PosicionAviso(w,h)` y `SetWindowPos` con `p.x`,`p.y`. **Nada de -2247.**
- `_OcultarBadgeSi(targetID)`: si `floatGui.badgeID != targetID`, salir sin tocar nada (no ocultar ni
  destruir el badge de otra llamada). Si coincide: **destruir** la GUI y dejar los 6 campos a 0. Deja el
  patrón listo para que otra llamada pueda crear una nueva.
- `_DestruirGui(obj)` ya existe (l.1537) y hace `try obj.Destroy()`.
- Mantén **exactamente 2** ocurrencias de `.Show(` en este bloque (las dos que ya hay), y `WinSetTransparent(230,g)`
  puedes dejarlo tal cual.
- No cambies textos, tamaños, colores ni el orden de los controles.

## CAMBIO 4 — `MostrarHUD` + `_OcultarHUDSi`
Ancla literal (l.1610-1650, aparece una sola vez):
```ahk
MostrarHUD(texto,colorBarra := "00E5FF",duracion := 1200) {
    global AVISO_ESC
    if IsObject(floatGui.miniTip)
        _DestruirGui(floatGui.miniTip)
    if IsObject(floatGui.miniGUI)
        _DestruirGui(floatGui.miniGUI)
    if IsObject(floatGui.tooltipToggle)
        _DestruirGui(floatGui.tooltipToggle)
    x := -2247
    y := 30
    w := Round(208 * AVISO_ESC)
    h := Round(40 * AVISO_ESC)
    if (!IsObject(floatGui.hud) || !floatGui.hudHwnd || !DllCall("IsWindow","Ptr",floatGui.hudHwnd)) {
        g := Gui("-Caption +AlwaysOnTop +ToolWindow +E0x20")
        g.BackColor := "1a1a1a"
        g.MarginX := 0
        g.MarginY := 0
        WinSetTransparent(215,g)
        lbl := g.Add("Text","x0 y" Round(7 * AVISO_ESC) " w" w " h" Round(26 * AVISO_ESC) " cWhite +0x200 Center",texto)
        lbl.SetFont("s" Max(6,Round(12 * AVISO_ESC)) " bold","Segoe UI")
        bar := g.Add("Progress","x0 y" Round(35 * AVISO_ESC) " w" w " h" Round(5 * AVISO_ESC))
        bar.Opt("c" colorBarra)
        bar.Value := 100
        g.Show("w" w " h" h " NoActivate Hide")
        floatGui.hud := g
        floatGui.hudLabel := lbl
        floatGui.hudBar := bar
        floatGui.hudHwnd := g.Hwnd
    } else {
        floatGui.hudLabel.Value := texto
        floatGui.hudBar.Opt("c" colorBarra)
        floatGui.hudBar.Value := 100
    }
    DllCall("SetWindowPos","Ptr",floatGui.hudHwnd,"Ptr",-1,"int",x,"int",y,"int",0,"int",0,"uint",0x0040 | 0x0010 | 0x0001)
    hwnd := floatGui.hudHwnd
    SetTimer(() => _OcultarHUDSi(hwnd),-duracion)
}
_OcultarHUDSi(hwnd) {
    if (IsObject(floatGui.hud) && floatGui.hudHwnd = hwnd)
        floatGui.hud.Hide()
}
```

Requisitos del DESPUÉS:
- Generación: `floatGui.hudID += 1` + `thisID := floatGui.hudID`; `SetTimer(() => _OcultarHUDSi(thisID),-duracion)`.
- `_OcultarHUDSi(targetID)`: si `floatGui.hudID != targetID`, salir. Si coincide, `.Hide()` (el HUD **se
  reutiliza**, no se destruye: es el patrón actual y evita parpadeo).
- **Oculta el badge** al mostrar el HUD, invalidando su timer: `floatGui.badgeID += 1`, `_DestruirGui(floatGui.badge)`
  y los 6 campos del badge a 0. Si nunca hubo badge, todo esto es no-op (los campos valen 0 y `_DestruirGui`
  comprueba `IsObject`).
- Posición: `p := _PosicionAviso(w,h)` para `SetWindowPos`. **Nada de -2247.**
- Mantén **exactamente 1** ocurrencia de `.Show(` en este bloque.
- No cambies el tamaño (208×40), ni la fuente, ni el color de fondo, ni el alto de la barra.

## Verificación antes de responder (sobre tu propio texto, no ejecutando nada)
- [ ] Cuenta `.Show(` en tus bloques: **2** en el del badge y **1** en el del HUD (3 en total). Ni una más,
      ni una menos, ni siquiera dentro de un comentario.
- [ ] `hudID` y `badgeID` se incrementan (`+= 1`) y nunca se leen como booleano de "existe".
- [ ] Ni un `-2247` sobrevive en tu texto.
- [ ] `_PosicionAviso` aparece definida **antes** de su primer uso y solo llama a funciones que ya existen en
      el archivo (`MonitorGet`, `MonitorGetCount`, `_RectaFijaEnPantalla`): no las redefinas.
- [ ] `_DestruirGui` no la defines tú: ya existe, llámala por su nombre.
- [ ] Delta total ≤ +35 líneas.
- [ ] No has pedido el archivo ni has inventado el contenido de ninguna zona que no esté aquí.
