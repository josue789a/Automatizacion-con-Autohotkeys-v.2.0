# PROTOCOLO COMUN — agentes en paralelo por anclas

Lee esto antes de tu paquete. Es idéntico para los 3.

## ENTORNO — no tienes acceso a mi PC (esto condiciona todo lo demás)

No puedes **abrir, leer, buscar ni editar** ningún archivo. No puedes **ejecutar** AutoHotkey ni ningún
comando. No puedes **ver mi pantalla** ni **medir** tiempos. No recuerdas conversaciones anteriores.
**Todo lo que necesitas está en este mensaje y en tu paquete.** Tú devuelves **texto**; los archivos los
cambio yo.

Cómo se traduce eso en la práctica:

- **La fuente de verdad es el bloque `ANTES` de tu paquete**, no los números de línea. Los `l.NNN` son
  referencia mía para aplicar el parche; **no los uses para deducir nada** ni intentes "ir a ver" esa zona.
- Todo lo que el paquete afirma del archivo (que tal función existe, quién la llama, qué devuelve, qué
  mide) es **dato mío ya medido**: no lo verifiques, no lo cuestiones, úsalo.
- Si de verdad te falta un dato, **no lo inventes y no supongas el contenido del archivo**: aplica la opción
  más conservadora, escribe una línea `SUPUESTO: ...` y entrega igualmente el resto de los cambios.
- Ninguna comprobación puede ser un comando. Autoverifícate **sobre tu propio texto de salida**: contar
  apariciones de una cadena, buscar una palabra en tu `DESPUÉS`, comprobar que una función que llamas está
  definida en el mismo mensaje.

## El objetivo
Devolver un parche **aplicable sin discusión y sin iteración**. Yo (OpenCode) aplico los parches en serie
sobre el archivo real y valido **una sola vez al final**. Si tu parche no encaja literalmente en el ancla,
se descarta sin aviso.

## El archivo (dónde vive, para que tengas el contexto; **tú no puedes abrirlo**)
- Ruta: `C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk`
- Estado de referencia (dato mío, no comprobable por ti): **4329 líneas**, sha256 `0819B4D030159A719E3E741B86349AF3539CC26D00BB428776B85A8BBBC6EE3D`
- AutoHotkey **v2.0.26**, un solo archivo, **CRLF**, UTF-8 **sin BOM**, pide elevación en l.3-6 (intencional).
- Es el companion GUI de ClipStudioPaint: ventanas sin caption (`+ToolWindow`), pills de 104×25 px.
- **No tienes el archivo, solo los extractos de tu paquete.** No pidas que te lo pegue: si el `ANTES` está
  completo, tienes todo lo necesario para ese cambio.
- Las funciones que tu paquete dice "ya existe" **existen**: úsalas por su nombre y firma tal cual, sin
  redefinirlas.

## Formato de respuesta OBLIGATORIO
Por cada cambio, exactamente este bloque:

```
### CAMBIO n — <nombre corto>
ANTES (texto literal del archivo, sin tocar un espacio):
<...>
DESPUES:
<...>
DELTA LINEAS: +N / -N
ANCLA UNICA: si
COSTE: <a ojo, nº de operaciones por llamada (p. ej. "1 WinSetTransparent"); NO midas nada>
```

Si tu paquete toca **dos archivos** (p. ej. el `.ahk` y `theme.ini`), el segundo va con el mismo formato:
bloque `ANTES` literal del `.ini` + `DESPUES`. Tú no editas ese archivo: me lo entregas como texto.

Nada de: reescribir el archivo, proponer refactors, añadir tests, sugerir arquitectura, ni "habría que
decidir". Si necesitas una decisión, **toma la opción más conservadora y dila en una línea**.

## Reglas duras (violarlas = parche rechazado)
1. **No cambiar el número de ocurrencias de `.Show(`** en tu zona: ni una más, ni una menos, ni dentro de
   un comentario. Hay un arnés que cuenta ese patrón con regex sobre el texto crudo. Para recolocar
   ventanas se usa `DllCall("SetWindowPos", ...)`, nunca `.Show("x.. y..")`.
2. **No tocar**: la inyección de teclas a CSP (`_EstabEmitir`, `SendInput`), las líneas 3-6 de elevación,
   `#SingleInstance Force`, `BlockInput`, `WS_EX_TRANSPARENT`/`WS_EX_NOACTIVATE`, ni la detección del HWND
   de CSP. Tampoco `posiciones_gui.ini` (es UTF-16 y solo lo escribe el propio script).
3. **No añadir asignaciones globales nuevas al final del archivo.** En AHK v2 nada de lo que va después del
   primer `#HotIf` ejecuta asignaciones de nivel superior: un `X := Map()` tardío no se ejecuta nunca.
   Si necesitas estado nuevo, cuélgalo de un objeto global que ya exista (`floatGui.xxx`) o usa `static`.
4. **Rendimiento**: cualquier función llamada en bucle o en repintado debe costar **≤ 35 ms**. Nada de
   `Sleep`, `WinGet`/`WinGetPos` masivos ni bucles por ventana dentro de esas rutas.
5. **Solo funciones que existen.** Si llamas algo nuevo, incluye su definición completa en el mismo parche.
   Trampas reales de v2 ya pisadas aquí: `map` es nombre reservado (clase `Map`); es `WinGetPID`, no
   `WinGetProcessID`; es `WinGetClass`, no `WinGetClassName`; no existe `FileClose`; no existe
   `SysGetWorkArea` (usar `MonitorWorkArea`); los out-params se escriben `&var`; el backtick dentro de
   cadena va doblado. Leer una global no requiere `global` (solo escribir).
6. **Presupuesto de líneas**: el archivo no debe crecer más de **+60 líneas** entre los 3 paquetes.
   Si tu parche crece más de +35, recórtalo.
7. CRLF. No cambiar la codificación. No reordenar código ajeno. No "aprovechar" para limpiar tu zona.

## Runtime
Repetido porque es lo que más se falla: **no puedes ejecutar AutoHotkey, ni leer el archivo, ni ver la
pantalla**. **No adivines píxeles ni medidas**: usa solo los números que van en tu paquete. Si un número no
está, es que no hace falta.
