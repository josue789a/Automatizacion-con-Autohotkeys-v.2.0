# CLAUDE C — olas E+F: 2 bugs mudos + limpieza de código muerto (4 anclas lejanas)

Adjunto: `PROTOCOLO.md`. Eres el único con esta zona. **No toques** `MostrarHUD`, `MostrarBadgeCombo`,
`_FadeAlpha` (CLAUDE A y B), ni nada de `_Estab*`, ni `theme.ini`.

> **No tienes acceso a mi PC.** No puedes leer ni editar el archivo, ni ejecutar AutoHotkey, ni ver la
> pantalla. Todo lo que necesitas está en este mensaje: tú devuelves texto y ya. Los `l.NNN` son mi
> referencia para aplicar el parche; **la fuente de verdad es el bloque `ANTES`**. No pidas el archivo.

Reglas duras (resumen de `PROTOCOLO.md`; si no lo has leído, pídelo): no cambiar el número de `.Show(`; no
añadir asignaciones globales de nivel superior; usar solo funciones que ya existen o definirlas en el mismo
parche; nada de `Sleep` en rutas de repintado; CRLF; cero refactors y no tocar `posiciones_gui.ini`.

Contexto: el archivo arrastra dos bugs mudos (una asignación sin `global` que se queda en local, así que el
botón "por defecto" del calibrador y el campo `HistAlto` no hacen nada) y dos cadáveres de refactors
anteriores. Los cuatro son **cero riesgo**: nadie depende de que sigan así.

## CAMBIO 1 — `global` que falta: el calibrador "Restaurar por defecto" y `HistAlto` no hacen nada
Hecho verificado con AutoHotkey v2.0.26 (prueba aislada): asignar a una variable de nivel superior dentro de
una función **sin** declararla `global` crea una local y deja la global intacta. Resultado: `PUNTOS` se
queda como estaba y el usuario ve que el botón no responde.

Ancla literal A (l.3771-3777, aparece una sola vez):
```ahk
_PtsAltoChange(*) {
    v := Trim(ptsEd.hAlto.Value)
    if (!IsInteger(v) || Integer(v) = HIST_ALTO)
        return
    HIST_ALTO := Integer(v)
    RecalcularZonas()
}
```
DESPUÉS: la misma función con `global HIST_ALTO` como primera línea del cuerpo (encima de `v := Trim(...)`).

Ancla literal B (l.3817-3820, aparece una sola vez):
```ahk
_PtsDefecto(*) {
    global HIST_ALTO
    PUNTOS := PuntosPorDefecto()
    HIST_ALTO := 104
```
DESPUÉS: `global HIST_ALTO,PUNTOS` en esa misma línea (una sola línea de declaración, sin añadir líneas).

No toques `RecalcularZonas`, `_PtsRefrescar` ni el resto del cuerpo.

## CAMBIO 2 — ruta hardcodeada de otro usuario
Ancla literal (l.124, aparece una sola vez):
```ahk
    repoPath := "C:\Users\JOSUE\Desktop\AHK-global-main"
```
DESPUÉS: derivarla del propio script, que vive en `<repo>\ClipStudioPaint _ Autohotkeys\`:
```ahk
    repoPath := RegExReplace(A_ScriptDir,"\\[^\\]+$")
```
Añade encima una línea de comentario: `; El script vive en <repo>\ClipStudioPaint _ Autohotkeys\: el repo es el padre.`
Motivo: con `JOSUE`, el atajo `Ctrl+G` (commit+push) apunta a una carpeta que no existe en este PC.
No toques el resto del hotkey (`cmd`, `Run`, `_CheckGitDone`).

## CAMBIO 3 — maquinaria de iconos en base64 que nunca puede funcionar
Hechos: `_IconosB64()` devuelve un `Map()` **vacío** por diseño (los PNG se perdieron al compactar), así que
`_IconoExtraer()` siempre devuelve `false`, y las dos llamadas de `_RutaIcono` son código muerto. Los glifos
ya se dibujan con `_Glifo()`/`_Glifizar()` (fuente Segoe Fluent Icons) y el respaldo real que sí puede
funcionar es **tener los PNG en disco** (`iconos\csp2_<nombre>.png`), que es lo que hay que conservar.

Ancla literal (l.4031-4074, aparece una sola vez):
```ahk
_RutaIcono(nombre) {
    arch := "csp2_" nombre ".png"
    ruta := A_ScriptDir "\iconos\" arch
    if FileExist(ruta)
        return ruta
    suelto := A_ScriptDir "\" arch
    if FileExist(suelto)
        return suelto
    if _IconoExtraer(nombre,ruta)
        return ruta
    tmp := A_Temp "\csp_iconos\" arch
    if FileExist(tmp)
        return tmp
    if _IconoExtraer(nombre,tmp)
        return tmp
    return ""
}
_IconoExtraer(nombre,ruta) {
    mapa := _IconosB64()
    if !mapa.Has(nombre)
        return false
    b64 := mapa[nombre]
    try {
        DirCreate(RegExReplace(ruta,"\\[^\\]+$"))
        n := 0
        if !DllCall("Crypt32\CryptStringToBinaryW","Str",b64,"UInt",0,"UInt",1,"Ptr",0,"UInt*",&n,"Ptr",0,"Ptr",0)
            return false
        buf := Buffer(n)
        if !DllCall("Crypt32\CryptStringToBinaryW","Str",b64,"UInt",0,"UInt",1,"Ptr",buf,"UInt*",&n,"Ptr",0,"Ptr",0)
            return false
        f := FileOpen(ruta,"w")
        f.RawWrite(buf,n)
        f.Close()
        return true
    }
    return false
}
_IconosB64() {
    ; Los iconos originales se perdieron en la compactación. Copia la
    ; función _IconosB64() completa desde tu archivo de respaldo v52.
    ; Mientras tanto, esta versión vacía hace que los botones se muestren
    ; como "SLIDER ON/OFF", "CIRCLE ON/OFF", etc. sin dibujito.
    return Map()
}
```
DESPUÉS: solo `_RutaIcono` con la sonda de disco intacta y una nota. Debe quedar exactamente así:
```ahk
_RutaIcono(nombre) {
    ; Respaldo real de iconos: PNG sueltos en disco. Si algun dia aparecen,
    ; se usan sin tocar codigo. La maquinaria base64 que habia aqui era un
    ; placeholder vacio que siempre devolvia false (se retiro en la ola 7;
    ; sigue en el .bak de esa ola si hiciera falta).
    arch := "csp2_" nombre ".png"
    ruta := A_ScriptDir "\iconos\" arch
    if FileExist(ruta)
        return ruta
    suelto := A_ScriptDir "\" arch
    if FileExist(suelto)
        return suelto
    return ""
}
```
Sin `_IconoExtraer` ni `_IconosB64`: si dejas alguna referencia a esas funciones, el script no carga.

## CAMBIO 4 — `PillRegion()` sin ningún consumidor
Hechos: `PillRegion(ctrl,clave)` está implementada en l.4169 y **no la llama nadie** (0 referencias en 4.329
líneas). Nació en la ola 2 para el "chip interior" (deuda D7) y el spike de la ola 0 ya demostró que el
arco/redondeo en **controles hijos** no aplica de forma fiable (ERROR_INVALID_HANDLE); la decisión de la ola 6
fue redondear **ventanas** con `_DwmRedondear`. D7 se cierra como **descartado**, y esta función se va.

Ancla literal (l.4169-4180, aparece una sola vez):
```ahk
PillRegion(ctrl, clave := "sm") {
    r0 := _Tema("radius", clave, "8")
    r := _E(IsInteger(r0) ? Integer(r0) : 8)
    rc := Buffer(16, 0)
    DllCall("GetWindowRect", "Ptr", ctrl.Hwnd, "Ptr", rc)
    w := NumGet(rc, 8, "int") - NumGet(rc, 0, "int")
    h := NumGet(rc, 12, "int") - NumGet(rc, 4, "int")
    r := Min(r, h // 2, w // 2)
    rgn := DllCall("Gdi32\CreateRoundRectRgn", "int", 0, "int", 0, "int", w + 1, "int", h + 1, "int", 2 * r, "int", 2 * r, "Ptr")
    if !DllCall("SetWindowRgn", "Ptr", ctrl.Hwnd, "Ptr", rgn, "int", 1)
        DllCall("Gdi32\DeleteObject", "Ptr", rgn)
}
```
DESPUÉS: el bloque entero desaparece y en su lugar queda **una sola línea** de comentario:
```ahk
; D7 (chip interior) cerrado en la ola 7: el redondeo se hace con _DwmRedondear sobre
; la ventana, no con regiones en controles hijos. PillRegion() se retiro por no tener
; ningun consumidor (0 referencias) y no ser fiable en hijos (spike ola 0).
```
Cuidado: ese comentario va **entre** `_DwmRedondear` y `; === F2-END ===`, en el mismo sitio. No muevas nada más.

## Verificación antes de responder (sobre tu propio texto, no ejecutando nada)
- [ ] En tu `DESPUES` de `_PtsAltoChange` la primera línea del cuerpo es `global HIST_ALTO`, y el de
      `_PtsDefecto` declara `global HIST_ALTO,PUNTOS` en **una sola** línea de declaración.
- [ ] En tus `DESPUES` **no queda ni una** de estas cadenas en código: `PillRegion`, `_IconoExtraer`,
      `_IconosB64`, `Users\JOSUE`. Las únicas menciones permitidas son **texto de comentario** (el de
      `_RutaIcono` y el bloque de D7), que dicen el nombre sin llamarlo. Búscalas en tu propio texto.
- [ ] `_RutaIcono` conserva la firma y las dos sondas de disco (`A_ScriptDir "\iconos\"` y `A_ScriptDir "\"`).
- [ ] Ninguna ocurrencia de `.Show(` añadida ni eliminada.
- [ ] Delta total ≤ −25 líneas (este paquete debe **adelgazar** el archivo).
- [ ] No has pedido el archivo ni has inventado el contenido de ninguna zona que no esté aquí.
