# PROTOCOLO COMUN — agentes en paralelo por anclas

Lee esto antes de tu paquete. Es idéntico para los 3.

## ENTORNO — no tienes acceso a mi PC (esto condiciona todo lo demás)

No puedes **abrir, leer, buscar ni editar** ningún archivo. No puedes **ejecutar** AutoHotkey ni ningún
comando. No puedes **ver mi pantalla** ni **medir** tiempos. No recuerdas conversaciones anteriores.
**Todo lo que necesitas está en este mensaje y en tu paquete.** Tú devuelves **texto**; los archivos los
cambio yo.

Cómo se traduce eso en la práctica:

- **La fuente de verdad es el bloque `ANTES` de tu paquete**, no los números de línea. Los `l.NNN` son
  referencia mía para aplicar el parche; **no los uses para deducir nada** ni intentes "ir a ver" esa zona.
- Todo lo que el paquete afirma del archivo (que tal función existe, quién la llama, qué devuelve, qué
  mide) es **dato mío ya medido**: no lo verifiques, no lo cuestiones, úsalo.
- Si de verdad te falta un dato, **no lo inventes y no supongas el contenido del archivo**: aplica la opción
  más conservadora, escribe una línea `SUPUESTO: ...` y entrega igualmente el resto de los cambios.
- Ninguna comprobación puede ser un comando. Autoverifícate **sobre tu propio texto de salida**: contar
  apariciones de una cadena, buscar una palabra en tu `DESPUÉS`, comprobar que una función que llamas está
  definida en el mismo mensaje.

## El objetivo
Devolver un parche **aplicable sin discusión y sin iteración**. Yo (OpenCode) aplico los parches en serie
sobre el archivo real y valido **una sola vez al final**. Si tu parche no encaja literalmente en el ancla,
se descarta sin aviso.

## El archivo (dónde vive, para que tengas el contexto; **tú no puedes abrirlo**)
- Ruta: `C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk`
- Estado de referencia (dato mío, no comprobable por ti): **4329 líneas**, sha256 `0819B4D030159A719E3E741B86349AF3539CC26D00BB428776B85A8BBBC6EE3D`
- AutoHotkey **v2.0.26**, un solo archivo, **CRLF**, UTF-8 **sin BOM**, pide elevación en l.3-6 (intencional).
- Es el companion GUI de ClipStudioPaint: ventanas sin caption (`+ToolWindow`), pills de 104×25 px.
- **No tienes el archivo, solo los extractos de tu paquete.** No pidas que te lo pegue: si el `ANTES` está
  completo, tienes todo lo necesario para ese cambio.
- Las funciones que tu paquete dice "ya existe" **existen**: úsalas por su nombre y firma tal cual, sin
  redefinirlas.

## Formato de respuesta OBLIGATORIO
Por cada cambio, exactamente este bloque:

```
### CAMBIO n — <nombre corto>
ANTES (texto literal del archivo, sin tocar un espacio):
<...>
DESPUES:
<...>
DELTA LINEAS: +N / -N
ANCLA UNICA: si
COSTE: <a ojo, nº de operaciones por llamada (p. ej. "1 WinSetTransparent"); NO midas nada>
```

Si tu paquete toca **dos archivos** (p. ej. el `.ahk` y `theme.ini`), el segundo va con el mismo formato:
bloque `ANTES` literal del `.ini` + `DESPUES`. Tú no editas ese archivo: me lo entregas como texto.

Nada de: reescribir el archivo, proponer refactors, añadir tests, sugerir arquitectura, ni "habría que
decidir". Si necesitas una decisión, **toma la opción más conservadora y dila en una línea**.

## Reglas duras (violarlas = parche rechazado)
1. **No cambiar el número de ocurrencias de `.Show(`** en tu zona: ni una más, ni una menos, ni dentro de
   un comentario. Hay un arnés que cuenta ese patrón con regex sobre el texto crudo. Para recolocar
   ventanas se usa `DllCall("SetWindowPos", ...)`, nunca `.Show("x.. y..")`.
2. **No tocar**: la inyección de teclas a CSP (`_EstabEmitir`, `SendInput`), las líneas 3-6 de elevación,
   `#SingleInstance Force`, `BlockInput`, `WS_EX_TRANSPARENT`/`WS_EX_NOACTIVATE`, ni la detección del HWND
   de CSP. Tampoco `posiciones_gui.ini` (es UTF-16 y solo lo escribe el propio script).
3. **No añadir asignaciones globales nuevas al final del archivo.** En AHK v2 nada de lo que va después del
   primer `#HotIf` ejecuta asignaciones de nivel superior: un `X := Map()` tardío no se ejecuta nunca.
   Si necesitas estado nuevo, cuélgalo de un objeto global que ya exista (`floatGui.xxx`) o usa `static`.
4. **Rendimiento**: cualquier función llamada en bucle o en repintado debe costar **≤ 35 ms**. Nada de
   `Sleep`, `WinGet`/`WinGetPos` masivos ni bucles por ventana dentro de esas rutas.
5. **Solo funciones que existen.** Si llamas algo nuevo, incluye su definición completa en el mismo parche.
   Trampas reales de v2 ya pisadas aquí: `map` es nombre reservado (clase `Map`); es `WinGetPID`, no
   `WinGetProcessID`; es `WinGetClass`, no `WinGetClassName`; no existe `FileClose`; no existe
   `SysGetWorkArea` (usar `MonitorWorkArea`); los out-params se escriben `&var`; el backtick dentro de
   cadena va doblado. Leer una global no requiere `global` (solo escribir).
6. **Presupuesto de líneas**: el archivo no debe crecer más de **+60 líneas** entre los 3 paquetes.
   Si tu parche crece más de +35, recórtalo.
7. CRLF. No cambiar la codificación. No reordenar código ajeno. No "aprovechar" para limpiar tu zona.

## Runtime
Repetido porque es lo que más se falla: **no puedes ejecutar AutoHotkey, ni leer el archivo, ni ver la
pantalla**. **No adivines píxeles ni medidas**: usa solo los números que van en tu paquete. Si un número no
está, es que no hace falta.

---

# ===== TU PAQUETE =====

# CLAUDE B — ola C: fundido sin `Sleep` + tokens `[motion]` vivos

Adjunto: `PROTOCOLO.md`. Eres el único con esta zona: `_FadeAlpha` (l.566-582) y la sección `[motion]` de
`theme.ini`. **No toques** `_SetColorV`/`_SetColorCC`/`_SetAR` (no hace falta: ver más abajo), ni
`MostrarHUD`/`MostrarBadgeCombo` (son de CLAUDE A), ni nada de `_Estab*`.

> **No tienes acceso a mi PC.** No puedes leer ni editar el archivo, ni ejecutar AutoHotkey, ni ver la
> pantalla. Todo lo que necesitas está en este mensaje: tú devuelves texto y ya. Los `l.NNN` son mi
> referencia para aplicar el parche; **la fuente de verdad es el bloque `ANTES`**. No pidas el archivo.
> El `theme.ini` tampoco puedes tocarlo: me entregas su `ANTES`/`DESPUES` como texto y lo edito yo.

Reglas duras (resumen de `PROTOCOLO.md`; si no lo has leído, pídelo): no cambiar el número de `.Show(`; no
añadir asignaciones globales de nivel superior; usar solo funciones que ya existen o definirlas en el mismo
parche; nada de `Sleep` en rutas de repintado; CRLF; cero refactors y no tocar `posiciones_gui.ini`.

## Diagnóstico (medido por mí; dalo por bueno, no lo compruebes)
1. `_FadeAlpha` hace `Loop pasos { ... Sleep(delayMs) }`: **60 ms de bloqueo del hilo** (6 × 10 ms) cada vez
   que el usuario pasa el ratón por el borde del panel de CSP o lo abandona. Se llama desde `_SetColorV`
   (l.591, 597), `_SetColorCC` (l.611, 617) y `_SetAR` (l.629, 635): o sea, **en la ruta de entrada**, y con
   el lápiz en marcha. Cualquier `Sleep` ahí se nota como tirón.
2. La sección `[motion]` de `theme.ini` (l.52-56) **no la lee nadie**: `fast`, `base`, `slow` y `easing` son
   tokens muertos. El contrato de la ola 1 era "si el archivo falta, el código usa valores por defecto
   idénticos"; hoy es al revés, no hay consumidor.

## El contrato que NO puedes romper
Los tres llamadores hacen, en este orden (ilustrativo, **no es un ancla ni lo copies**):
```text
SetTimer(LoopColorV,0)      ; 1. paran el bucle que fija la transparencia
_FadeAlpha(colorV.dsID,5)   ; 2. funden
SetTimer(LoopColorV,80)     ; 3. rearman el bucle a 80 ms
```
Si el fundido dura **más de ~72 ms**, el bucle se rearma antes de que acabe y pisa la animación a mitad
(parpadeo). Por eso el fundido se reparte en pasos de **≤ 12 ms** (contrato explícito en el código). No
cambies los llamadores.

## CAMBIO 1 — `_FadeAlpha` no bloqueante + `_FadePaso`
Ancla literal (l.566-582, aparece una sola vez):
```ahk
_FadeAlpha(hwnd,hasta,pasos := 6,delayMs := 10) {
    try actual := WinGetTransparent("ahk_id " hwnd)
    if (actual = "" || !IsNumber(actual))
        actual := hasta
    if (actual = hasta)
        return
    paso := (hasta - actual) / pasos
    valor := actual
    Loop pasos {
        valor += paso
        v := Round(valor)
        v := (v < 0) ? 0 : (v > 255 ? 255 : v)
        try WinSetTransparent(v,"ahk_id " hwnd)
        Sleep(delayMs)
    }
    try WinSetTransparent(hasta,"ahk_id " hwnd)
}
```

Requisitos del DESPUÉS:
- **Cero `Sleep`.** El fundido se hace con un timer por ventana que se rearma solo, una vez por paso.
- Estado en `floatGui.fade` (Map por HWND). **No** declares una global nueva al final del archivo (regla 3 del
  protocolo): `floatGui` ya es global, y añadirle una propiedad en tiempo de ejecución es válido.
  Patrón: `if !HasProp(floatGui,"fade")` → `floatGui.fade := Map()`.
- Firma nueva: `_FadeAlpha(hwnd,hasta,pasos := 6,delayMs := 0)`. Con `delayMs <= 0` se calcula desde el tema:
  `tot := _Tema("motion","fast","60")`, validado con `IsInteger(tot) && Integer(tot) > 0`, y
  `ms := Max(1,Min(12,Round(tot / pasos)))`. El `Min(12, …)` es el contrato de arriba: **no lo quites**, y
  déjalo comentado.
- Curva: `ez := _Tema("motion","easing","out-cubic")`; si vale `linear`, `f := t`; si no,
  `f := 1 - (1 - t) ** 3`. `t := i / total` (i de 1 a total).
- Valor por paso: `v := Round(desde + (hasta - desde) * f)`, recortado a 0..255, aplicado con
  `try WinSetTransparent(v,"ahk_id " key)`.
- Al terminar (`i >= total`): `try WinSetTransparent(hasta,"ahk_id " key)`, borrar la entrada del Map y salir.
- Si al entrar ya se está en `hasta`, **borra la entrada pendiente** de ese HWND (una animación vieja no
  puede seguir pisando) y sal sin programar nada.
- El callback del timer se llama `_FadePaso(key)` y va **inmediatamente después** de `_FadeAlpha`.
  Se programa con `SetTimer(_FadePaso.Bind(key),-ms)` (una sola vez por paso).
- `key := "" hwnd` (cadena), para que el Map no mezcle números y cadenas.
- Coste por paso: 1 `WinSetTransparent` (~1 ms). Nada más.

## CAMBIO 2 — `theme.ini`, sección `[motion]`
Archivo: `C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\theme.ini`
Ancla literal (l.52-56, aparece una sola vez):
```ini
[motion]
fast = 120
base = 180
slow = 240
easing = out-cubic
```
DESPUÉS: mismos tokens, `fast = 60` y tres líneas de comentario que digan la verdad:
- `fast` = milisegundos **totales** del fundido de los paneles de CSP (el script lo reparte en pasos de ≤12 ms).
- `easing` = `linear` | `out-cubic`.
- `base` y `slow` = **reservados**: hoy ningún consumidor los lee (las duraciones del HUD y del badge van por
  llamada, no por token).

No toques ninguna otra sección del `theme.ini` (los colores y `[fx]` son de otras olas).

## Verificación antes de responder (sobre tu propio texto, no ejecutando nada)
- [ ] En tus bloques `DESPUES` la palabra `Sleep` aparece **0 veces** (cuéntrala en tu texto).
- [ ] El número de `.Show(` en tus bloques no cambia (tu zona no tiene ninguna): 0 añadidas, 0 quitadas.
- [ ] `_FadePaso` está definida en tu mensaje **antes** de la primera vez que se usa, y no hay ninguna
      asignación de nivel superior nueva (`X := ...` fuera de función): todo el estado va en `floatGui.fade`.
- [ ] Delta total de líneas ≤ +20.
- [ ] `fast = 60` (no 120) y los comentarios están dentro de `[motion]`.
- [ ] No has pedido el archivo ni has inventado el contenido de ninguna zona que no esté aquí.
