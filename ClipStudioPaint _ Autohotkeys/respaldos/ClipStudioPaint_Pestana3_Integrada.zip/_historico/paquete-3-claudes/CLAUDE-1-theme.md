# CLAUDE 1 — acabado en `theme.ini` (cero codigo)

Adjunto: `PROTOCOLO.md` (aplica, aunque tu paquete no toca el `.ahk`).

## Alcance
**Unicamente** `C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\theme.ini`.
No propongas cambios de `.ahk`: hay otros dos agentes con ese archivo y se pisan. Si algo requiere codigo,
lo listas al final como `REQUERIMIENTO-PARA-CLAUDE-2/3` con una frase.

## Estado actual del archivo (literal)
```ini
[color]
surface.base     = 12141A
surface.raised   = 1B1E26
surface.overlay  = 20242E
surface.off      = 424242
surface.on       = 636D83
text.primary     = F0F3FA
text.idle        = B2B2B2
text.muted       = 8E97A8
text.disabled    = 5A6273
accent.info      = 00E5FF
accent.success   = 44DD88
accent.warn      = FF6B00
accent.danger    = FF4444
accent.estab     = 9A7BFF
accent.estabSoft = B4C0DE
track.off        = 3A3A45
track.pillOff    = 6A6A6A
surface.estabLocked = 2B2B2B
surface.estabOpen   = 3A4260
surface.reload = 3B7A4B

[alpha]
pill  = 235
badge = 230
hud   = 215
mini  = 200
icono = 185

[radius]
sm = 8
md = 12

[type]
family       = Segoe UI
family.value = Cascadia Mono
size.caption = 9
size.body    = 11
size.value   = 13

[motion]
fast = 120
base = 180
slow = 240
easing = out-cubic

[fx]
corners  = 3
backdrop = 0
```

## Datos medidos en la pantalla real (no los vuelvas a estimar)
- **Geometria del panel de estabilizacion** (perfil 2, monitor secundario): ventana 60x626, cliente
  **~47 px de ancho**; la pista mide **~10 px de ancho**; el knob **~22 px de diametro**; el numero
  (`valorTxt`) es un `Text` separado en un extremo.
- Colores del chrome de ClipStudioPaint detras del panel, muestreados: **(58,58,58)**, **(66,66,66)**,
  **(81,81,81)**. Es decir: `surface.estabOpen = 3A4260` (58,66,96) es **practicamente el mismo gris** que
  el fondo de CSP, solo difiere en el azul. Eso es lo que hace que el panel "no exista" visualmente.
- `surface.estabLocked = 2B2B2B` (43,43,43) tampoco contrasta con (58,58,58).
- Contraste del glifo OFF actual: `text.disabled 5A6273` (90,98,115) sobre `surface.off 424242` (66,66,66)
  = **1,6:1** → el icono no se ve. El ON usa `FFFFFF` y si se ve.
- DWM: con `corners = 3` (DEFAULT) Windows aplica ~11-13 px; `1` = ROUND (~11-13 forzado), `2` =
  ROUNDSMALL (~7-8 px). **No existe un cuarto radio**: el sistema solo da recto / ~7-8 / ~11-13.
  `[radius] sm/md` **hoy no se lee** (el helper que lo consume esta sin conectar).
- `[motion]` **hoy no se lee** en ninguna parte del script.

## Lo que tienes que entregar (4 cambios, en este orden)
1. **`icon.off`** nuevo en `[color]`, con el valor que suba el contraste del glifo OFF por encima de ~4,5:1
   sobre `424242`, y que siga siendo claramente mas tenue que el ON (`FFFFFF`). Justifica el numero con la
   ratio calculada.
2. **`corners`**: elige 1 o 2 y di por que, asumiendo pills de 25-31 px de alto (un radio de 13 px en una
   pill de 25 px de alto come la mitad).
3. **`surface.estabOpen` / `surface.estabLocked`**: dos valores que (a) se distingan entre si de verdad,
   (b) contrasten con el chrome de CSP medido arriba, y (c) no choquen con el acento `9A7BFF`. Entrega
   tambien `track.off` y `track.pillOff` coherentes.
4. **`[alpha] pill`**: 235 actual = 92 % opaco. Recomienda un valor y di que se pierde.

Formato por cambio: `ANTES` / `DESPUES` sobre lineas literales del ini, `DELTA LINEAS`, y una linea de
justificacion con el numero (ratio de contraste, px de radio, etc.). Nada de prosa de diseno.
