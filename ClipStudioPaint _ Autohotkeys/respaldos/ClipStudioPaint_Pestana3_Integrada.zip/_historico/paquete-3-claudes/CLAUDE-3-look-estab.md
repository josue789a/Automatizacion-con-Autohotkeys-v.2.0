# CLAUDE 3 — pasada de look del panel de estabilizacion

Adjunto: `PROTOCOLO.md`. Eres el unico con esta zona; CLAUDE 2 tiene `_ColorIcono` y `_MostrarPaneles`,
CLAUDE 1 tiene `theme.ini`. **No toques esas tres funciones.**

## Que se ve hoy, medido en pantalla real (no es opinion)
Panel vertical, cliente **~47 px de ancho x ~650 de alto**. En su interior:
- pista (`track`) de **~10 px de ancho** (x=28..37), color `track.off 3A3A45` en el tramo sin usar y
  `accent.estab 9A7BFF` en el relleno.
- knob: **disco blanco de 22 px de diametro** con anillo del color de acento de ~1,7 px. Se leio como
  "un ligero borde blanco" — o sea, el usuario apenas lo registra.
- el numero ("91", "0") es un control `Text` **apart** pegado a un extremo del panel, en color de acento.
- fondo del panel = `surface.estabOpen 3A4260` (o `2B2B2B` si esta fijado), que contra el chrome de CSP
  **(58,58,58)/(66,66,66)/(81,81,81)** es casi invisible. El panel no parece un objeto, parece un agujero.

## Lo que el pidio explicitamente (nota del 2026-11-06)
> "para que se parezca al slider del stab, seria bueno que se dibuje ese circulo con el numero y el porcentaje"

O sea: **el numero dentro del circulo**, como el deslizador de estabilizacion de Clip Studio.

## Restriccion fisica que tienes que resolver primero (aritmetica, no gusto)
Un circulo de 22 px **no admite** "91 %" en ningun tamano legible. Para meter numero+simbolo dentro del knob
hace falta diametro >= ~34 px, y el knob sale de `knobSize := Max(14, Round(w * 0.58))` con `w` = ancho del
cliente (~47). Tienes tres salidas y **tienes que elegir una y justificarla con numeros**:
(a) exigir un ancho minimo de panel (cambia la formula de layout y el minimo), con el coste de tapar mas lienzo;
(b) knob grande y numero **al lado** del knob, dentro de la franja del panel;
(c) knob pequeno y numero+`%` en el **centro del tramo rellen**o, rotado 90 grados (panel vertical).
No propongas "reducir el tamano de fuente" sin calcular: a 9 px una cifra de 2 digitos ya no se lee sobre 22 px.

## Anclas literales (unicas en el archivo)

Dibujo actual, l.4208-4247:
```ahk
_EstabPanelPintar(gfx) {
    global estabGui, panelBlk, ESTAB_COLOR
    val := estabGui.dibV
    if (val < 0)
        val := estabGui.valor
    val := Min(100,Max(0,Integer(val)))
    tx := Float(estabGui.trackX)
    ty := Float(estabGui.trackY)
    tw := Float(estabGui.trackW)
    th := Float(estabGui.trackH)
    bo := Float(estabGui.knobSize)
    plano := estabGui.horiz ? th : tw
    radio := plano / 2.0
    acento := _Tema("color","accent.estab",ESTAB_COLOR)
    surf := panelBlk.locked ? _Tema("color","surface.estabLocked","2B2B2B") : _Tema("color","surface.estabOpen","3A4260")
    DllCall("gdiplus\GdipGraphicsClear","ptr",gfx,"uint",_ArgbDeHex(surf,255),"int")
    ruta := _EstabPildora(tx,ty,tw,th,radio)
    _EstabRellenar(gfx,ruta,_Tema("color","track.off","3A3A45"))
    _EstabTrazar(gfx,ruta,_Tema("color","track.pillOff","6A6A6A"),1.0)
    DllCall("gdiplus\GdipDeletePath","ptr",ruta,"int")
    largo := Round((estabGui.horiz ? tw : th) * val / 100.0)
    if (largo >= 2) {
        rr := Min(largo / 2.0,radio)
        ruta := estabGui.horiz ? _EstabPildora(tx,ty,largo,th,rr) : _EstabPildora(tx,ty + th - largo,tw,largo,rr)
        _EstabRellenar(gfx,ruta,acento)
        DllCall("gdiplus\GdipDeletePath","ptr",ruta,"int")
    }
    kx := estabGui.horiz ? (tx + tw * val / 100.0) : (tx + tw / 2.0)
    ky := estabGui.horiz ? (ty + th / 2.0) : (ty + th - th * val / 100.0)
    gp := Max(1.0,Min(2.5,bo * 0.08))
    cara := bo - gp
    pincel := 0
    DllCall("gdiplus\GdipCreateSolidFill","uint",_ArgbDeHex(_Tema("color","knob.face","FFFFFF"),255),"ptr*", &pincel,"int")
    DllCall("gdiplus\GdipFillEllipse","ptr",gfx,"ptr",pincel,"float",kx - cara / 2.0,"float",ky - cara / 2.0,"float",cara,"float",cara,"int")
    DllCall("gdiplus\GdipDeleteBrush","ptr",pincel,"int")
    lapiz := 0
    DllCall("gdiplus\GdipCreatePen1","uint",_ArgbDeHex(acento,255),"float",gp,"int",2,"ptr*", &lapiz,"int")
    DllCall("gdiplus\GdipDrawEllipse","ptr",gfx,"ptr",lapiz,"float",kx - cara / 2.0,"float",ky - cara / 2.0,"float",cara,"float",cara,"int")
    DllCall("gdiplus\GdipDeletePen","ptr",lapiz,"int")
}
```

Contenedor, l.4248-4264 (el `ValidateRect` final es obligatorio dejarlo: sin el, Windows vuelve a invalidar):
```ahk
_EstabDibujar() {
    global estabGui
    if !IsObject(estabGui.g)
        return
    hwnd := estabGui.g.Hwnd
    if !DllCall("IsWindowVisible","ptr",hwnd,"ptr")
        return
    hdc := DllCall("user32\GetDC","ptr",hwnd,"ptr")
    gfx := 0
    if (DllCall("gdiplus\GdipCreateFromHDC","ptr",hdc,"ptr*", &gfx,"int") = 0) {
        DllCall("gdiplus\GdipSetSmoothingMode","ptr",gfx,"int",4,"int")
        _EstabPanelPintar(gfx)
        DllCall("gdiplus\GdipDeleteGraphics","ptr",gfx,"int")
    }
    DllCall("user32\ReleaseDC","ptr",hwnd,"ptr",hdc,"int")
    DllCall("user32\ValidateRect","ptr",hwnd,"ptr",0,"int")
}
```

Etiqueta del numero, l.2725 (es la que quieres apagar si el numero pasa al canvas):
```ahk
    estabGui.valorTxt := estabGui.g.Add("Text","x0 y0 w" w " h" estabGui.txtH " Center +0x200 c" ESTAB_COLOR,"")
```

Geometria, l.2782-2790 (vertical) — aqui vive el minimo de knob que te bloquea la opcion del numero dentro:
```ahk
        estabGui.txtH := Max(18,Round(h * 0.10))
        estabGui.txtW := w
        estabGui.knobSize := Max(14,Round(w * 0.58))
        k := Round(estabGui.knobSize / 2)
        estabGui.trackW := Max(6,Round(w * 0.22))
        estabGui.trackX := Round((w - estabGui.trackW) / 2)
        estabGui.trackY := Max(k + 3,Round(h * 0.03))
        estabGui.trackH := Max(24,h - estabGui.txtH - 2 * estabGui.trackY)
```

## Helpers GDI+ que YA existen (usarlos, no reinventarlos)
`_EstabGdipIniciar()`, `_ArgbDeHex(hex,alfa)`, `_EstabPildora(x,y,an,al,radio)` (path de pill cerrado),
`_EstabRellenar(gfx,ruta,hex,alfa)`, `_EstabTrazar(gfx,ruta,hex,grosor)`, `_Tema(seccion,clave,defecto)`,
`_E(n)` (escala, hoy ESC=1.0). `_EstabPanelPintar` recibe **solo** `gfx`.

## Reglas de esta zona
1. **Cada objeto GDI+ que crees, lo borras en el mismo camino** (`GdipDeleteFont`, `GdipDeleteFontFamily`,
   `GdipDeleteStringFormat`, `GdipDeleteBrush`, `GdipDeletePen`, `GdipDeletePath`). Un repintado por tecla que
   filtra fuentes se nota en minutos.
2. **Coste total del repintado <= 35 ms**; hoy va a 4-8 ms. El texto con GDI+ es lo mas caro: si usas
   `GdipDrawString`, crea la `FontFamily`/`Font` **una vez** (static) y reutilizalas, no por repintado.
3. Nada de `SetTimer`, ni `Sleep`, ni `WinGet*`, ni leer el ini dentro del dibujo (ya hay cache en
   `estabGui.*` y `_Tema` cachea).
4. Si necesitas un token nuevo de `theme.ini`, **no lo definas tu**: usa `_Tema("color","nombre","DEFECTO")`
   con un defecto razonable y lista el nombre en `REQUERIMIENTO-PARA-CLAUDE-1` al final.
5. El panel tambien se usa **horizontal** (`estabGui.horiz`); cualquier cambio de geometria tiene que seguir
   teniendo sentido en las dos orientaciones o decir explicitamente que la horizontal queda igual.
6. Apagar `valorTxt` se hace con `estabGui.valorTxt.Visible := false`, **no** con metodos de ventana; y recuerda
   que `_EstabLayout` hace `estabGui.valorTxt.Move(...)` y `ActualizarEstabGUI` le escribe `.Value` — si la
   apagas, di quien deja de llamar a eso o el parche queda a medias.

## Entrega
1. `DECISION`: opcion (a)/(b)/(c) del numero, con la aritmetica de px y la fuente (familia, tamano, por que se
   lee a ese tamano sobre el color elegido).
2. `CAMBIO 1` — `_EstabPanelPintar` completa nueva (ANTES/DESPUES literales, es el bloque de arriba).
3. `CAMBIO 2` — geometria en `_EstabLayout` si tu decision la exige.
4. `CAMBIO 3` — `valorTxt` (apagar o conservar como respaldo).
5. `REQUERIMIENTO-PARA-CLAUDE-1` — tokens nuevos con sus valores propuestos.
6. `RIESGOS` — maximo 3 lineas: que se rompe si el panel se hace mas chico, y que pasa con el modo horizontal.

**Un solo look implementado** (el de volumen/inset, que es el que menos depende del fondo de CSP). Las
variantes "glow de acento" y "neutro CSP" van como **valores de `theme.ini`** (espesor de borde, dos colores
de superficie), no como ramas de codigo.
