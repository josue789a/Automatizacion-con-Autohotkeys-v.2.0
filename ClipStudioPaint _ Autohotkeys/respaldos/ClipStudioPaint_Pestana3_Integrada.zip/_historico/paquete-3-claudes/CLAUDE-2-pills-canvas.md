# CLAUDE 2 — `.ahk`, dos anclas lejanas del look

Adjunto: `PROTOCOLO.md`.

## Alcance (y por que estas limitado a esto)
Solo **dos** funciones del `.ahk`. Todo lo relacionado con el dibujo del panel es de CLAUDE 3 y las zonas
pueden solaparse: **no toques `_EstabPanelPintar`, `_EstabDibujar`, `_EstabLayout` ni `IniciarEstabGUI`**
(aunque se te ocurra algo mejor alli). Tampoco `theme.ini` (CLAUDE 1).

Entregables: (1) contraste del glifo OFF, (2) el panel que queda sin pintar al re-mostrarse.

## CAMBIO 1 — icono OFF invisible
El estado OFF pinta su glifo con `text.disabled` sobre `surface.off` = **1,6:1 de contraste**. El usuario lo
reporto como "desaparecieron los iconos". El ON usa `FFFFFF` y si se ve.

Ancla literal (aparece **una sola vez**, l.3998-4003):
```ahk
_ColorIcono(esON) {
    ; El icono va siempre un punto por encima del label: FFFFFF en ON para que
    ; un glifo fino de ~15 px se lea sobre 636D83; text.disabled en OFF para que
    ; el estado ON/OFF se distinga de un vistazo.
    return esON ? "FFFFFF" : _Tema("color","text.disabled","5A6273")
}
```
Contexto que ya existe y puedes llamar: `_Tema(seccion,clave,defecto)` lee `theme.ini`; `_AlphaTema(clave,defecto)`
existe tambien. CLAUDE 1 va a anadir un token `icon.off` en `[color]` — **usa ese nombre** y deja el defecto
`"B2B2B2"` en la llamada para que el parche funcione aunque el ini todavia no tenga la clave.

## CAMBIO 2 — barra plana al re-mostrar el panel
**Defecto reproducido con captura del usuario**: el panel de estabilizacion se ve como una barra de color
plano (el `BackColor` de la ventana, `3A4260`) sin pista, sin relleno y sin knob, mientras el numero de
abajo si aparece. Causa medida:

- `_EstabDibujar()` (l.4248) **sale sin pintar nada** si la ventana no es visible:
  `if !DllCall("IsWindowVisible","ptr",hwnd,"int") return`
- El canvas solo se repinta desde: cambio de valor, `_EstabLayout`, entrada a foco y toggle de visibilidad.
- `_MostrarPaneles()` re-muestra el panel **y no lo repinta**. Como ademas `ESTAB_REPINTADO := false` no hay
  WM_PAINT que lo cubra, el resultado se queda plano hasta el siguiente cambio de valor.

Ancla literal (unica, l.2013-2024, la primera mitad de `_MostrarPaneles`):
```ahk
_MostrarPaneles() {
    estabHwnd := IsObject(estabGui.g) ? estabGui.g.Hwnd : 0
    for g in [dial,dsGui,ccGui,arGui,hcGui,lockGui,frenteGui,estabBtnGui,reloadGui,estabGui] {
        if !IsObject(g.g)
            continue
        if (g.g.Hwnd = estabHwnd && (!estabGui.visible || !enfoque.activo))
            continue
        try {
            if !DllCall("IsWindowVisible","Ptr",g.g.Hwnd)
                g.g.Show("NoActivate")
        }
    }
```
Restricciones, son el motivo por el que este parche se rechazo antes:
- El repintado va **dentro de la rama que realmente acaba de mostrar la ventana**, no despues del `for`:
  esta funcion se ejecuta cada 500 ms desde un timer y un repintado incondicional serian 4-8 ms cada ciclo
  por nada.
- Solo para el panel de estabilizacion (`g.g.Hwnd = estabHwnd`), no para las demas pills.
- **No dupliques ni muevas la linea `.Show(...)`** y no escribas ese patron en un comentario: el arnes fiscaliza
  el numero de ocurrencias y espera 29. Envolverla en llaves esta bien; reescribirla con otro texto, no.
- La funcion que repinta se llama `_EstabDibujar()` y no recibe argumentos.

## Formato
Los dos bloques con `ANTES` / `DESPUES` / `DELTA LINEAS` / `ANCLA UNICA: si` / `COSTE`, segun el PROTOCOLO.
Si crees que el CAMBIO 2 necesita registrar un handler de WM_PAINT, **no lo propongas**: esta medido que
registrar `OnMessage(0x000F)` en el arranque cuesta +1,3 a +1,7 s y entra en cascada con dos `Redraw()`; es
otra ola con su propia discusion.
