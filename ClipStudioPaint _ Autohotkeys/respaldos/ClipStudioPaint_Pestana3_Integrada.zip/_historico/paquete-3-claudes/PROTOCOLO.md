# PROTOCOLO COMUN — 3 agentes sobre un mismo archivo

Lee esto antes de tu paquete. Es identico para los 3.

## El objetivo
Devolver un parche **aplicable sin discusion y sin iteracion**. Yo (Qoder) aplico los 3 en serie sobre el
archivo real y valido **una sola vez al final** (no por ajuste). Si tu parche no encaja literalmente en el
ancla, se descarta sin aviso.

## El archivo
- Ruta: `C:\Users\jbard\Desktop\AHK-global-main\ClipStudioPaint _ Autohotkeys\XPPEN AHK VERSION ESTABLE.ahk`
- Estado de referencia: **4274 lineas**, sha256 `d6b0c654996f755b1c17eb5c24acb10a856ff8916e6aa231489555a445748915`
- AutoHotkey **v2.0.26**, un solo archivo, **CRLF**, UTF-8 **sin BOM**, pide elevacion en l.3-6 (intencional).
- Es el companion GUI de ClipStudioPaint: ventanas sin caption (`+ToolWindow`), pills de 104x25 y 31x25 px.

## Formato de respuesta OBLIGATORIO
Por cada cambio, exactamente este bloque:

```
### CAMBIO n — <nombre corto>
ANTES (citar textual, con las lineas de contexto que se vean abajo):
<el texto literal del archivo, sin tocar un espacio>
DESPUES:
<el texto literal a insertar>
DELTA LINEAS: +N / -N
ANCLA UNICA: si | (el bloque ANTES aparece una sola vez en el archivo)
COSTE: <ms estimados en la ruta caliente, o "arranque una vez">
```

Nada de: reescribir el archivo, proponer refactors, anadir tests, sugerir arquitectura, ni "habria que
decidir". Si necesitas una decision, **toma la opcion mas conservadora y digela en una linea**.

## Reglas duras (violarlas = parche rechazado)
1. **Prohibido anadir ocurrencias de `.Show(`** — ni en codigo, **ni dentro de un comentario**. Hay un arnes
   que cuenta ese patron con regex sobre el texto crudo y espera exactamente `29/2/3`. Un comentario que
   escriba `.Show()` sube el contador y el arnes rechaza el archivo. Los desplazamientos programaticos van
   con `DllCall("SetWindowPos", ...)`.
2. **No tocar**: `_EstabEmitir` (inyeccion de teclas a CSP), las lineas 3-6 de elevacion,
   `#SingleInstance Force`, `BlockInput`, `WS_EX_TRANSPARENT`/`WS_EX_NOACTIVATE`, ni la deteccion del HWND de CSP.
3. **No escribir `posiciones_gui.ini`** (es UTF-16; solo el propio script lo hace).
4. **Rendimiento**: cualquier funcion que se llame en repintado debe costar **<= 35 ms** (medido: el canvas
   actual va a 4-8 ms). Nada de bucles por ventana, `WinGet`/`WinGetPos` masivos o `Sleep` en esas rutas.
5. **Solo funciones que existen.** Si llamas algo nuevo, tienes que incluir su definicion completa en el
   mismo parche. Trampas reales de v2 ya pisadas aqui: `map` es nombre reservado (clase `Map`); es
   `WinGetPID` no `WinGetProcessID`; es `WinGetClass`, no `WinGetClassName`; no existe `FileClose`; no existe
   `SysGetWorkArea` (usar `MonitorWorkArea`); los out-params se escriben `&var`; backtick dentro de cadena va
   doblado.
6. **Presupuesto de lineas**: el archivo no debe crecer mas de **+60 lineas** entre los 3 paquetes.
7. CRLF. No cambiar la codificacion. No reordenar codigo ajeno. No "aprovechar" para limpiar.

## Lo que NO tienes
- Runtime: no puedes ejecutar AutoHotkey ni ver la pantalla. **No adivines pixel outputs**: pide que se
  valide o usa solo los numeros que van en tu paquete.
- El archivo completo: solo los extractos que te doy en tu paquete. Si necesitas ver otra zona, **dilo en una
  linea** en vez de suponer su contenido.
